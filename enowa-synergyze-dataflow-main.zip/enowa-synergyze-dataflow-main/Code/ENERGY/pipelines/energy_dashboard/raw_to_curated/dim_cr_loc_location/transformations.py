# pylint: disable=line-too-long
# pylint: disable=import-error
# pylint: disable=missing-module-docstring
# pylint: disable=trailing-whitespace
# pylint: disable=inconsistent-return-statements
import logging
import os
import sys
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2
from pyspark.sql import functions as F

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_capacity_item_demand_case: DataFrame,
        df_neom_region_source: DataFrame,
        df_dim_cr_loc_location_area: DataFrame,
) -> DataFrame:
    """
    Transforms capacity_item_demand_case, NEOM region, asset and area data by selecting distinct columns,
    creating SQL temporary views, and returning the final transformed DataFrame.

    Parameters:
    df_neom_region_source (DataFrame): Source region data.
    df_capacity_item_demand_case (DataFrame): demand case data.
    df_dim_cr_loc_location_area (DataFrame): location area data.

    Returns:
    DataFrame: Transformed DataFrame.
    """

    logging.info("Starting the transformation process.")

    df_capacity_item_demand_case = (
        df_capacity_item_demand_case.select(
            "NAME", "LATITUDE", "LONGITUDE", "SUBREGION"
        ).distinct()
    )

    df_neom_region_source = (
        df_neom_region_source.select("REGION", "TYPE", "LATITUDE", "LONGITUDE")
        .where(~F.col("TYPE").isin("Region", "Sub-Region"))
        .distinct()
    )

    df_dim_cr_loc_location_area = (
        df_dim_cr_loc_location_area.select(
            "DIM_LOCATION_AREA_ID", "LOCATION_AREA_ABBREVIATION"
        ).distinct()
    )

    df_capacity_item_demand_case.createOrReplaceTempView("capacity_item_demand_case")
    df_neom_region_source.createOrReplaceTempView("neom_region_source")
    df_dim_cr_loc_location_area.createOrReplaceTempView("dim_cr_loc_location_area")

    sql_query = """
            WITH asset
                AS (
                    select 
                    ast.ASSET AS ASSET_NAME
                    ,coalesce(cidc.LATITUDE, nrs.LATITUDE) AS LATITUDE
                    ,coalesce(cidc.LONGITUDE, nrs.LONGITUDE) AS LONGITUDE
                    ,cidc.SUBREGION
                    from 
                    (
                        select NAME as ASSET from capacity_item_demand_case
                        union
                        select REGION as ASSET from neom_region_source 
                    ) ast
                    LEFT JOIN capacity_item_demand_case cidc 
                    ON ast.ASSET = cidc.NAME
                    LEFT JOIN 
                    ( select * from ( SELECT REGION,LATITUDE,LONGITUDE,
                        row_number() over (partition by REGION order by 1) as row_num 
                        FROM neom_region_source ) where row_num = 1) nrs 
                    ON ast.ASSET = nrs.REGION
                    )
                SELECT la.DIM_LOCATION_AREA_ID AS DIM_LOCATION_AREA_ID
                    ,NULL AS LOCATION_NAME
                    ,ast.ASSET_NAME AS ASSET_NAME
                    ,NULL AS IS_NEOM_LOCATION_YN
                    ,NULL AS LOCATION_WATER_CATEGORY
                    ,NULL AS LOCATION_SAMPLE_CATEGORY
                    ,NULL AS LOCATION_SAMPLE_TYPE
                    ,NULL AS LOCATION_SAMPLE_FREQUENCY
                    ,ast.LATITUDE AS LATITUDE
                    ,ast.LONGITUDE AS LONGITUDE
                    ,NULL AS IS_COMMUNITY_LOCATION
                    ,NULL AS COMMUNITY_LOCATION_TYPE
                    ,NULL AS IS_ENOWA_NETWORK
                    ,NULL AS IS_SWCC_FACILITY_YN
                    ,NULL AS IS_COMMUNITY_YN
                    ,NULL AS OTHER_YN
                    ,NULL AS NOTES
                    ,'ENERGY' AS DOMAIN_TYPE
                    ,CURRENT_DATE () AS LAST_UPDATED_DATE
                    ,CURRENT_DATE () AS CREATED_DATE
                    ,'ENERGY' AS PARTITION_KEY
                FROM asset ast
                LEFT JOIN dim_cr_loc_location_area la 
                    ON ast.SUBREGION = la.LOCATION_AREA_ABBREVIATION
    """
    df_transformed = spark.sql(sqlQuery=sql_query)

    df_transformed = df_transformed.withColumn(
        "DIM_LOCATION_ID", sha2("ASSET_NAME", 256)
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters, returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "CAPACITY_ITEM_DEMAND_CASE": DataFrame for capacity item demand case details.
            - "NEOM_REGION_SOURCE": DataFrame for region location details.
            - "DIM_CR_LOC_LOCATION_AREA": DataFrame for LOCATION area data

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_capacity_item_demand_case = source_dfs["CAPACITY_ITEM_DEMAND_CASE"]
    df_neom_region_source = source_dfs["NEOM_REGION_SOURCE"]
    df_dim_cr_loc_location_area = source_dfs["DIM_CR_LOC_LOCATION_AREA"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_capacity_item_demand_case=df_capacity_item_demand_case,
        df_neom_region_source=df_neom_region_source,
        df_dim_cr_loc_location_area=df_dim_cr_loc_location_area,
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")
    print("dummy spark df passed as argument ", spark_df)

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
