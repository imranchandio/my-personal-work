"""
Module: fact_en_eve_model_opd_ue_value
Description: Process data from raw to curated for the fact_en_eve_model_opd_ue_value.
It contains the necessary functions and logic to create fact_en_eve_model_opd_ue_value
table in curated.

Author: Vaishnavi Ruikar
Date: 26-09-2024
"""
# pylint: disable = import-error
# pylint: disable = E0012,C0103,W0611
import logging
from common_utils import (
    calculate_num_partitions,
    impose_schema
)
from read_utils import read
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import (
    sha2,
    concat_ws,
    current_timestamp,
    col,
    coalesce,
    lit,
)  # pylint: disable =no-name-in-module



def prepare_transformed_df(  # pylint: disable = too-many-arguments,too-many-locals
    spark: SparkSession,
    df_category: DataFrame,
    df_gwap: DataFrame,
    df_duration_curve: DataFrame,
    df_flow_duration: DataFrame,
    df_generation_duration: DataFrame,
    df_hour: DataFrame,
    df_line_duration: DataFrame,
    df_load_duration: DataFrame,
    df_month: DataFrame,
    df_dim_cr_loc_location_group: DataFrame,
    df_dim_en_op_meas_variable: DataFrame,
    df_source_mapping: DataFrame
) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters, using spark
    sql query, Calculating the number of partitions, repartitions the data
    and returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - df_category: DataFrame for CATEGORY.
            - df_gwap: DataFrame for GWAP.
            - df_duration_curve: DataFrame for DURATION_CURVE.
            - df_flow_duration: DataFrame for FLOW_DURATION.
            - df_generation_duration : DataFrame for GENERATION_DURATION.
            - df_hour: DataFrame for HOUR.
            - df_line_duration: DataFrame for LINE_DURATION.
            - df_load_duration: DataFrame for LOAD_DURATION.
            - df_month: DataFrame for MONTH.
            - df_dim_cr_loc_location_group: DataFrame for DIM_CR_LOC_LOCATION_GROUP.
            - df_dim_en_op_meas_variable: DataFrame for DIM_EN_OP_MEAS_VARIABLE.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    logging.info("Starting the transformation process.")

    df_category.createOrReplaceTempView("category_source")
    df_gwap.createOrReplaceTempView("gwap_source")
    df_duration_curve.createOrReplaceTempView("duration_curve_source")
    df_flow_duration.createOrReplaceTempView("flow_duration_source")
    df_generation_duration.createOrReplaceTempView("generation_duration_source")
    df_hour.createOrReplaceTempView("hour_source")
    df_line_duration.createOrReplaceTempView("line_duration_source")
    df_load_duration.createOrReplaceTempView("load_duration_source")
    df_month.createOrReplaceTempView("month_source")
    df_dim_cr_loc_location_group.createOrReplaceTempView("dim_cr_loc_location_group")
    df_dim_en_op_meas_variable.createOrReplaceTempView("dim_en_op_meas_variable")
    df_source_mapping.createOrReplaceTempView("SOURCE_SOURCE")
    logging.info("Created temporary views for SQL operations.")

    sql_query = """
        select distinct DIM_LOCATION_GROUP_ID, PATHWAY_NAME, MEAS_VARIABLE_ID, MEAS_VALUE, 
        MEAS_UNIT, MEAS_FREQUENCY, DURATION, DURATION_TYPE, MODEL_RUN_TIME, PHASE, MEAS_CAPTURE_DATETIME,
        SCENARIO
        from
        (   
            select DIM_LOCATION_GROUP_ID, PATHWAY_NAME, MEAS_VARIABLE_ID, VALUE as MEAS_VALUE, 
            VARIABLE_UNIT as MEAS_UNIT, TO_DATE(RUNTIME,'yyyyMMdd') as MODEL_RUN_TIME, c.PHASE, 
            DURATION, DURATION_TYPE, MEAS_CAPTURE_DATETIME, MEAS_FREQUENCY, VARIABLE, VARIABLE_NAME, 
            c.NAME, LOCATION_GROUP_ABBREVIATION, CONCAT_WS(' ', SOURCE.LABEL, c.PATHWAY_NAME) as SCENARIO
            from
            (
                select distinct NULL as DIM_LOCATION_GROUP_ID, PATHWAY as PATHWAY_NAME, VARIABLE, 
                VALUE, RUNTIME, PHASE, NULL as DURATION, NULL as DURATION_TYPE, YEAR as MEAS_CAPTURE_DATETIME, 
                'Yearly Avg' as MEAS_FREQUENCY, NULL as NAME, NULL as LOCATION_GROUP_ABBREVIATION 
                from category_source 
                union
                select distinct NULL as DIM_LOCATION_GROUP_ID, PATHWAY as PATHWAY_NAME, VARIABLE, VALUE, 
                RUNTIME, PHASE, NULL as DURATION, NULL as DURATION_TYPE, YEAR as MEAS_CAPTURE_DATETIME, 
                'Yearly Avg' as MEAS_FREQUENCY, NULL as NAME, NULL as LOCATION_GROUP_ABBREVIATION 
                from gwap_source 
                union
                select DIM_LOCATION_GROUP_ID,PATHWAY as PATHWAY_NAME, VARIABLE, VALUE, RUNTIME, PHASE, 
                DURATION, DURATION_TYPE, MEAS_CAPTURE_DATETIME, MEAS_FREQUENCY, NAME, LOCATION_GROUP_ABBREVIATION
                from
                (
                    select distinct NAME, PATHWAY, VARIABLE, VALUE, RUNTIME, PHASE, DURATION, 
                    'DURATION CURVE' as DURATION_TYPE, YEAR as MEAS_CAPTURE_DATETIME, 'Yearly Avg' as MEAS_FREQUENCY 
                    from duration_curve_source 
                    union
                    select distinct NAME, PATHWAY, VARIABLE, VALUE, RUNTIME, PHASE, DURATION, 
                    'FLOW DURATION' as DURATION_TYPE, YEAR as MEAS_CAPTURE_DATETIME, 'Yearly Avg' as MEAS_FREQUENCY 
                    from flow_duration_source 
                    union
                    select distinct NAME, PATHWAY, VARIABLE, VALUE, RUNTIME, PHASE, DURATION, 
                    'GENERATION DURATION' as DURATION_TYPE, YEAR as MEAS_CAPTURE_DATETIME, 
                    'Yearly Avg' as MEAS_FREQUENCY 
                    from generation_duration_source 
                    union
                    select distinct NAME, PATHWAY, VARIABLE, VALUE, RUNTIME, PHASE, NULL as DURATION, 
                    NULL as DURATION_TYPE,CONCAT(CONCAT(MONTH,' '),HOUR) as MEAS_CAPTURE_DATETIME, 
                    'Hourly Avg Of A Day' as MEAS_FREQUENCY 
                    from hour_source 
                    union
                    select distinct NAME, PATHWAY, VARIABLE, VALUE, RUNTIME, PHASE, DURATION, 
                    'LINE DURATION' as DURATION_TYPE, YEAR as MEAS_CAPTURE_DATETIME, 'Yearly Avg' as MEAS_FREQUENCY 
                    from line_duration_source 
                    union
                    select distinct NAME, PATHWAY, VARIABLE, VALUE, RUNTIME, PHASE, DURATION, 
                    'LOAD DURATION' as DURATION_TYPE, YEAR as MEAS_CAPTURE_DATETIME, 'Yearly Avg' as MEAS_FREQUENCY 
                    from load_duration_source 
                    union
                    select distinct NAME, PATHWAY, VARIABLE, VALUE, RUNTIME, PHASE, NULL as DURATION, 
                    NULL as DURATION_TYPE, MONTH as MEAS_CAPTURE_DATETIME, 'Daily Avg Of A Month' as MEAS_FREQUENCY  
                    from month_source
                )a
                left join (select distinct LOCATION_GROUP_ABBREVIATION,DIM_LOCATION_GROUP_ID, DOMAIN_TYPE from dim_cr_loc_location_group where DOMAIN_TYPE = 'ENERGY') b
                on upper(a.NAME) = upper(b.LOCATION_GROUP_ABBREVIATION)
            
            )c
            left join SOURCE_SOURCE SOURCE
                ON  CONCAT_WS(' ', c.RUNTIME, c.PHASE, c.PATHWAY_NAME) = SOURCE.SOURCE
            left join (select distinct MEAS_VARIABLE_ID, VARIABLE_NAME, VARIABLE_UNIT from dim_en_op_meas_variable )d
            on c.VARIABLE = d.VARIABLE_NAME
        )where LOCATION_GROUP_ABBREVIATION is not null
        """
    df_transformed = spark.sql(sqlQuery=sql_query)
    logging.info("Executed SQL query for data transformation.")

    df_transformed = (
        df_transformed.withColumn(
            "MODEL_OPD_UE_VALUE_ID",
            sha2(
                concat_ws(
                    "||",
                    coalesce(col("DIM_LOCATION_GROUP_ID"), lit("")),
                    coalesce(col("PATHWAY_NAME"), lit("")),
                    coalesce(col("MEAS_VARIABLE_ID"), lit("")),
                    coalesce(col("MODEL_RUN_TIME"), lit("")),
                    coalesce(col("PHASE"), lit("")),
                    coalesce(col("MEAS_CAPTURE_DATETIME"), lit("")),
                    coalesce(col("DURATION"), lit("")),
                    coalesce(col("DURATION_TYPE"), lit("")),
                ),
                256,
            ),
        )
        .withColumn("LAST_UPDATED_DATE", current_timestamp())
        .withColumn("CREATED_DATE", current_timestamp())
    )

    # df_transformed.show()
    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %s partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(
    spark, source_dfs: dict
) -> DataFrame:  # pylint: disable = too-many-locals
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "CATEGORY": DataFrame for CATEGORY.
            - "GWAP": DataFrame for GWAP.
            - "DURATION_CURVE": DataFrame for DURATION_CURVE.
            - "FLOW_DURATION": DataFrame for FLOW_DURATION.
            - "GENERATION_DURATION": DataFrame for GENERATION_DURATION.
            - "HOUR": DataFrame for HOUR.
            - "LINE_DURATION": DataFrame for LINE_DURATION.
            - "LOAD_DURATION": DataFrame for LOAD_DURATION.
            - "MONTH": DataFrame for MONTH.
            - "DIM_CR_LOC_LOCATION_GROUP": DataFrame for DIM_CR_LOC_LOCATION_GROUP.
            - "DIM_EN_OP_MEAS_VARIABLE": DataFrame for DIM_EN_OP_MEAS_VARIABLE.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_category = source_dfs["CATEGORY"]
    df_gwap = source_dfs["GWAP"]
    df_duration_curve = source_dfs["DURATION_CURVE"]
    df_flow_duration = source_dfs["FLOW_DURATION"]
    df_generation_duration = source_dfs["GENERATION_DURATION"]
    df_hour = source_dfs["HOUR"]
    df_line_duration = source_dfs["LINE_DURATION"]
    df_load_duration = source_dfs["LOAD_DURATION"]
    df_month = source_dfs["MONTH"]
    df_dim_cr_loc_location_group = source_dfs["DIM_CR_LOC_LOCATION_GROUP"]
    df_dim_en_op_meas_variable = source_dfs["DIM_EN_OP_MEAS_VARIABLE"]
    df_source_mapping = source_dfs["SOURCE_MAPPING"]
    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_category=df_category,
        df_gwap=df_gwap,
        df_duration_curve=df_duration_curve,
        df_flow_duration=df_flow_duration,
        df_generation_duration=df_generation_duration,
        df_hour=df_hour,
        df_line_duration=df_line_duration,
        df_load_duration=df_load_duration,
        df_month=df_month,
        df_dim_cr_loc_location_group=df_dim_cr_loc_location_group,
        df_dim_en_op_meas_variable=df_dim_en_op_meas_variable,
        df_source_mapping=df_source_mapping
    )
    transform_df = transform_df.distinct()
    return transform_df


def execute_transform(
    spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage
        configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")
    print("printing spark df", spark_df)

    if task_name == "curated_data_processing_task":
        df = execute_transform(spark, pipeline_storage, task_parameters)
        return df
    return None
