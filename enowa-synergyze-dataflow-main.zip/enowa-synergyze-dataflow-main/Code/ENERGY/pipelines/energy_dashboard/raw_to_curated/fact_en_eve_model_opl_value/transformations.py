"""
This file prepares transformed data for act_en_eve_model_opl_value
"""
# pylint: disable=C0301,E0401,R1710

import logging
import pyspark.sql.functions as F
from common_utils import (
    calculate_num_partitions,
    impose_schema,
    get_current_year_quarter
)
from read_utils import read
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws


def prepare_transformed_df(
        spark: SparkSession,
        df_network_loss: DataFrame,
        df_dim_en_op_meas_variable: DataFrame,
        df_source_mapping: DataFrame
) -> DataFrame:
    """
            Transforms network loss and meas variable data by selecting distinct columns, 
            creating SQL temporary views, and returning the final transformed DataFrame.

            Parameters:
            df_network_loss (DataFrame): network loss data.
            df_dim_en_op_meas_variable (DataFrame): dim meas variable data.
            df_source_mapping: DataFrame

            Returns:
            DataFrame: Transformed DataFrame.
        """

    logging.info("Starting the transformation process.")

    df_network_loss = df_network_loss.select("SOURCE", "networkloss").distinct()
    df_dim_en_op_meas_variable = df_dim_en_op_meas_variable.select(
        "MEAS_VARIABLE_ID", "VARIABLE_NAME", "VARIABLE_UNIT"
    ).distinct()

    df_network_loss.createOrReplaceTempView("network_loss_source")
    df_dim_en_op_meas_variable.createOrReplaceTempView("dim_en_op_meas_variable")
    df_source_mapping.createOrReplaceTempView("SOURCE_SOURCE")

    sql_query = """
        WITH FINAL_CTE
        AS (
            SELECT mv.MEAS_VARIABLE_ID AS MEAS_VARIABLE_ID
                ,TRIM(SUBSTRING(nls.SOURCE, INSTR(nls.SOURCE, ' ') + INSTR(SUBSTRING(nls.SOURCE, INSTR(nls.SOURCE, ' ') + 1), ' ') + 1)) AS PATHWAY_NAME
                ,nls.networkloss AS MEAS_VALUE
                ,mv.VARIABLE_UNIT AS MEAS_UNIT
                ,'QUARTERLY' AS MEAS_FREQUENCY
                ,TO_TIMESTAMP(SUBSTRING(nls.SOURCE, 1, 8), 'yyyyMMdd') AS MODEL_RUN_TIME
                ,nls.SOURCE as SOURCE
                ,TRIM(SUBSTRING(nls.SOURCE, INSTR(nls.SOURCE, ' ') + 1, 2)) AS PHASE
            FROM network_loss_source nls
            LEFT JOIN dim_en_op_meas_variable mv ON mv.VARIABLE_NAME = 'Network Loss'
            )
        SELECT DISTINCT FINAL.MEAS_VARIABLE_ID
            ,FINAL.PATHWAY_NAME
            ,FINAL.MEAS_VALUE
            ,FINAL.MEAS_UNIT
            ,FINAL.MEAS_FREQUENCY
            ,FINAL.MODEL_RUN_TIME
            ,FINAL.PHASE
            ,CONCAT_WS(' ', SOURCE.LABEL, FINAL.PATHWAY_NAME) as SCENARIO
            ,CURRENT_DATE () AS LAST_UPDATED_DATE
            ,CURRENT_DATE () AS CREATED_DATE
        FROM FINAL_CTE FINAL
        LEFT JOIN SOURCE_SOURCE SOURCE 
            ON FINAL.SOURCE = SOURCE.SOURCE
    """
    df_transformed = spark.sql(sqlQuery=sql_query)

    df_transformed = df_transformed.withColumn(
        "MEAS_CAPTURE_DATETIME",
        F.lit(get_current_year_quarter())
    )

    df_transformed = df_transformed.withColumn(
        "MODEL_OPL_VALUE_ID",
        sha2(
            concat_ws(
                "||",
                "MEAS_VARIABLE_ID",
                "PATHWAY_NAME",
                "MODEL_RUN_TIME",
                "PHASE",
                "MEAS_CAPTURE_DATETIME"
            ),
            256
        )
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info(
        "Repartitioning the DataFrame into %d partitions.",
        num_partitions
    )

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters, returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "NETWORK_LOSS": DataFrame for network loss details.
            - "DIM_EN_OP_MEAS_VARIABLE": DataFrame for dimention op meas varaible data

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_network_loss = source_dfs["NETWORK_LOSS"]
    df_dim_en_op_meas_variable = source_dfs["DIM_EN_OP_MEAS_VARIABLE"]
    df_source_mapping = source_dfs["SOURCE_MAPPING"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_network_loss=df_network_loss,
        df_dim_en_op_meas_variable=df_dim_en_op_meas_variable,
        df_source_mapping=df_source_mapping
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration informationls.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")
    print("dummy spark df passed as argument ", spark_df)

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
