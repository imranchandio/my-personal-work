"""
Module: dim_cr_cus_customer_kind
Description: Process data from raw to curated for the dim_cr_cus_customer_kind.
It contains the necessary functions and logic to create dim_cr_cus_customer_kind
table in curated.

Author: Abhishek Singh
Date: 26-09-2024
"""

# pylint: disable = wrong-import-order, too-many-arguments, unused-argument, import-error, inconsistent-return-statements

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws
import logging
import os
import sys
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
    spark: SparkSession,
    df_sectors_mapping: DataFrame,
    df_cur_qtr_mw: DataFrame,
    df_cur_qtr_mwh: DataFrame,
) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "SECTORS_MAPPING": DataFrame for capex.
            - "CURRENT_QTR_DEMAND_DATA_MW": DataFrame for current_qtr_denamd data of mw.
            - "CURRENT_QTR_DEMAND_DATA_MWH": DataFrame for current_qtr_denamd data of mwh.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    logging.info("Starting the transformation process.")

    df_sectors_mapping = df_sectors_mapping.distinct()
    df_cur_qtr_mw = df_cur_qtr_mw.distinct()
    df_cur_qtr_mwh = df_cur_qtr_mwh.distinct()

    df_sectors_mapping.createOrReplaceTempView("sectors_mapping")
    df_cur_qtr_mw.createOrReplaceTempView("current_qtr_demand_date_mw")
    df_cur_qtr_mwh.createOrReplaceTempView("current_qtr_demand_date_mwh")

    logging.info("Created temporary views for SQL operations.")

    logging.info("Executing SQL query for data transformation.")

    sql_query1 = """
                SELECT DISTINCT DEMANDSECTORS AS CUSTOMER_KIND_NAME,
                'DEMAND SECTORS' AS CUSTOMER_KIND_SECTOR,
                null as CUSTOMER_KIND_DETAILS,
                current_date() as LAST_UPDATED_DATE,
                current_date() as CREATED_DATE
                FROM sectors_mapping
                WHERE DEMANDSECTORS IS NOT NULL
                UNION
                SELECT DISTINCT FINANCIALSECTORS AS CUSTOMER_KIND_NAME,
                'FINANCIAL SECTORS' AS CUSTOMER_KIND_SECTOR,
                null as CUSTOMER_KIND_DETAILS,
                current_date() as LAST_UPDATED_DATE,
                current_date() as CREATED_DATE
                FROM sectors_mapping
                WHERE FINANCIALSECTORS IS NOT NULL
                UNION
                select DISTINCT DISTRIBUTIONSECTORS AS CUSTOMER_KIND_NAME,
                'DISTRIBUTION SECTORS' AS CUSTOMER_KIND_SECTOR,
                null as CUSTOMER_KIND_DETAILS,
                current_date() as LAST_UPDATED_DATE,
                current_date() as CREATED_DATE
                FROM sectors_mapping
                WHERE DISTRIBUTIONSECTORS IS NOT NULL
                UNION
                SELECT DISTINCT FINANCIALPARENTSECTORS AS CUSTOMER_KIND_NAME,
                'FINANCIAL PARENT SECTORS' AS CUSTOMER_KIND_SECTOR,
                null as CUSTOMER_KIND_DETAILS,
                current_date() as LAST_UPDATED_DATE,
                current_date() as CREATED_DATE
                FROM sectors_mapping
                WHERE FINANCIALPARENTSECTORS IS NOT NULL
                """

    sql_query2 = """
                SELECT DISTINCT SECTOR AS CUSTOMER_KIND_NAME,
                'DEMAND SECTORS' AS CUSTOMER_KIND_SECTOR,
                null as CUSTOMER_KIND_DETAILS,
                current_date() as LAST_UPDATED_DATE,
                current_date() as CREATED_DATE
                FROM current_qtr_demand_date_mw
                WHERE SECTOR IS NOT NULL
                UNION
                SELECT DISTINCT SECTOR AS CUSTOMER_KIND_NAME,
                'DEMAND SECTORS' AS CUSTOMER_KIND_SECTOR,
                null as CUSTOMER_KIND_DETAILS,
                current_date() as LAST_UPDATED_DATE,
                current_date() as CREATED_DATE
                FROM current_qtr_demand_date_mwh
                WHERE SECTOR IS NOT NULL                
                """

    sector_mapping_df = spark.sql(sqlQuery=sql_query1)

    cur_qtr_data_df = spark.sql(sqlQuery=sql_query2)

    df_transformed = sector_mapping_df.unionByName(cur_qtr_data_df)
    logging.info("Executed SQL query for data transformation.")

    df_transformed = df_transformed.withColumn(
        "CUSTOMER_KIND_ID",
        sha2(concat_ws("||", "CUSTOMER_KIND_NAME", "CUSTOMER_KIND_SECTOR"), 256),
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "SECTORS_MAPPING": DataFrame for capex.
            - "CURRENT_QTR_DEMAND_DATA_MW": DataFrame for current_qtr_denamd data of mw.
            - "CURRENT_QTR_DEMAND_DATA_MWH": DataFrame for current_qtr_denamd data of mwh.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_sectors_mapping = source_dfs["SECTORS_MAPPING"]
    df_cur_qtr_mw = source_dfs["CURRENT_QTR_DEMAND_DATA_MW"]
    df_cur_qtr_mwh = source_dfs["CURRENT_QTR_DEMAND_DATA_MWH"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_sectors_mapping=df_sectors_mapping,
        df_cur_qtr_mw=df_cur_qtr_mw,
        df_cur_qtr_mwh=df_cur_qtr_mwh,
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
    spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if spark_df:
        print("spark_df schema:", spark_df.printSchema())

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
