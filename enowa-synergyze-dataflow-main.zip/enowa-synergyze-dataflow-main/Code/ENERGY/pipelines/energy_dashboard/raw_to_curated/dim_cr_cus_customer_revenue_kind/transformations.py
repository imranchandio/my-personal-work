""" This transformation.py process data from raw zone to curated zone in dim_cr_cus_customer_revenue_kind"""
# pylint: disable=wrong-import-order,wrong-import-position,import-error
import os
import sys
import logging

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")
from common_utils import calculate_num_partitions, impose_schema, trim_spaces
from read_utils import read
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2


# pylint: enable=wrong-import-order,wrong-import-position,import-error


def prepare_transformed_df(
        spark: SparkSession,
        df_current_qtr_demand_data_mw: DataFrame,
        df_representative_profile_source: DataFrame
) -> DataFrame:
    # pylint: disable=line-too-long
    """
        Prepares and transforms the current quarter demand data DataFrame by applying SQL transformations, filtering,
        and repartitioning based on calculated size.

        Args:
            spark (SparkSession): The Spark session used for distributed data processing.
            df_current_qtr_demand_data_mw (DataFrame): Input DataFrame containing current quarter demand data in megawatts.
            df_representative_profile_source (DataFrame): Input DataFrame containing RepresentativeProfiles data.
        Returns:
            DataFrame: The transformed DataFrame with distinct rows, hashed IDs, and optimal partitioning.
    """
    # pylint: enable=line-too-long

    logging.info("Starting the transformation process.")

    df_current_qtr_demand_data_mw.createOrReplaceTempView("CURRENT_QTR_DEMAND_DATA_MW")
    df_representative_profile_source.createOrReplaceTempView("REPRESENTATIVE_PROFILE_SOURCE")
    sql_query1 = """
    WITH CTE AS (
        SELECT DISTINCT
            REPRESENTATIVE_PROFILE as REVENUE_KIND_NAME
        FROM CURRENT_QTR_DEMAND_DATA_MW
        where REPRESENTATIVE_PROFILE is not null or REPRESENTATIVE_PROFILE != ''
        UNION
        SELECT DISTINCT
                RepresentativeProfiles as REVENUE_KIND_NAME
        FROM REPRESENTATIVE_PROFILE_SOURCE
            where RepresentativeProfiles is not null or RepresentativeProfiles != ''
    )
        SELECT DISTINCT
            REVENUE_KIND_NAME as REVENUE_KIND_NAME,
            NULL as REVENUE_KIND_NAME_DESCRIPTION,
            "ENERGY" as DOMAIN_TYPE,
            "ENERGY" as PARTITION_KEY,
            current_date() AS LAST_UPDATED_DATE,
            current_date() AS CREATED_DATE
        FROM CTE        
    """

    df_transformed = spark.sql(sqlQuery=sql_query1)

    df_transformed = df_transformed.withColumn("CUSTOMER_REVENUE_KIND_ID",
                                               sha2("REVENUE_KIND_NAME", 256))

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info(
        "Repartitioning the DataFrame into %d partitions.", num_partitions
    )

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    # pylint: disable=line-too-long
    """
    Transforms the source DataFrame for current quarter demand data by performing data preparation, such as trimming spaces and applying necessary joins and filters.

    Args:
        spark (SparkSession): The Spark session used for distributed data processing.
        source_dfs (dict): A dictionary containing the source DataFrames required for transformation. The key required in this case is:
            - "CURRENT_QTR_DEMAND_DATA_MW": DataFrame with current quarter demand data in megawatts.

    Returns:
        DataFrame: A distinct DataFrame after trimming spaces, joining with other necessary DataFrames, and applying filters.
    """
    # pylint: enable=line-too-long
    df_current_qtr_demand_data_mw = (
        trim_spaces(source_dfs["CURRENT_QTR_DEMAND_DATA_MW"])
    )
    df_representative_profile_source = (
        trim_spaces(source_dfs["REPRESENTATIVE_PROFILE_SOURCE"])
    )

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_current_qtr_demand_data_mw=df_current_qtr_demand_data_mw,
        df_representative_profile_source=df_representative_profile_source
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    # pylint: disable=line-too-long
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    # pylint: enable=line-too-long
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs) -> DataFrame:
    # pylint: disable=line-too-long
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # pylint: enable=line-too-long
    print(spark_df.printSchema())
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)

    return None
