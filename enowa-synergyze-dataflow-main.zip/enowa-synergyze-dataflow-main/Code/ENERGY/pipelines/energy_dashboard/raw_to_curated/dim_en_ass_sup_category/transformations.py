# pylint: disable = wrong-import-order, too-many-arguments, unused-argument, import-error, inconsistent-return-statements
"""
Module: dim_en_ass_sup_category
Description: Process data from raw to curated for the dim_en_ass_sup_category.
It contains the necessary functions and logic to create dim_en_ass_sup_category
table in curated.

Author: Abhishek Singh
Date: 26-09-2024
"""
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws
import logging
import os
import sys
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_capex: DataFrame,
        df_capacity_item_demand_case: DataFrame,
        df_annual_capex_item: DataFrame,
        df_capacity_item: DataFrame,
        df_capex_item: DataFrame,
        df_fo_and_m_cost_item: DataFrame,
        df_energy_item: DataFrame,
        df_model_item: DataFrame,
        df_system_cost_item: DataFrame,
        df_region: DataFrame,
) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "CAPEX": DataFrame for capex.
            - "CAPACITY_ITEM_DEMAND_CASE": DataFrame for capecity item demand case.
            - "ANNUAL_CAPEX_ITEM": DataFrame for annual capex item.
            - "CAPACITY_ITEM": DataFrame for capacity item.
            - "CAPEX_ITEM": DataFrame for capex item.
            - "FO_AND_M_COST_ITEM": DataFrame for fo&m cost item.
            - "ENERGY_ITEM": DataFrame for energy item.
            - "MODEL_ITEM": DataFrame for model item.
            - "SYSTEM_COST_ITEM": DataFrame for system cost item.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    logging.info("Starting the transformation process.")

    df_capex.createOrReplaceTempView("capex")
    df_capacity_item_demand_case.createOrReplaceTempView("capacity_item_demand_case")
    df_annual_capex_item.createOrReplaceTempView("annual_capex_item")
    df_capacity_item.createOrReplaceTempView("capacity_item")
    df_capex_item.createOrReplaceTempView("capex_item")
    df_fo_and_m_cost_item.createOrReplaceTempView("fo_and_m_cost_item")
    df_energy_item.createOrReplaceTempView("energy_item")
    df_model_item.createOrReplaceTempView("model_item")
    df_system_cost_item.createOrReplaceTempView("system_cost_item")
    df_region.createOrReplaceTempView("region")

    logging.info("Created temporary views for SQL operations.")

    logging.info("Executing SQL query for data transformation.")

    sql_query = """
                WITH CombinedData AS (
                    SELECT DISTINCT
                        Technology AS SUP_CATEGORY_NAME,
                        'Assumption category' AS SUP_CATEGORY_DETAILS
                    FROM capex
                    UNION
                    SELECT DISTINCT
                        Category AS SUP_CATEGORY_NAME,
                        'Forecast category' AS SUP_CATEGORY_DETAILS
                    FROM capacity_item_demand_case
                    UNION
                    SELECT DISTINCT
                        Category AS SUP_CATEGORY_NAME,
                        'Forecast category' AS SUP_CATEGORY_DETAILS
                    FROM annual_capex_item
                    UNION
                    SELECT DISTINCT
                        Category AS SUP_CATEGORY_NAME,
                        'Forecast category' AS SUP_CATEGORY_DETAILS
                    FROM capacity_item
                    UNION
                    SELECT DISTINCT
                        Category AS SUP_CATEGORY_NAME,
                        'Forecast category' AS SUP_CATEGORY_DETAILS
                    FROM capex_item
                    UNION
                    SELECT DISTINCT
                        Category AS SUP_CATEGORY_NAME,
                        'Forecast category' AS SUP_CATEGORY_DETAILS
                    FROM fo_and_m_cost_item
                    UNION
                    SELECT DISTINCT
                        Category AS SUP_CATEGORY_NAME,
                        'Forecast category' AS SUP_CATEGORY_DETAILS
                    FROM energy_item
                    UNION
                    SELECT DISTINCT
                        Category AS SUP_CATEGORY_NAME,
                        'Forecast category' AS SUP_CATEGORY_DETAILS
                    FROM model_item
                    UNION
                    SELECT DISTINCT
                        Category AS SUP_CATEGORY_NAME,
                        'Forecast category' AS SUP_CATEGORY_DETAILS
                    FROM system_cost_item
                    UNION
                    SELECT DISTINCT
                        Type AS SUP_CATEGORY_NAME,
                        'Forecast category' AS SUP_CATEGORY_DETAILS
                    FROM region
                    WHERE Type NOT IN ('Region', 'Sub-Region')
                )

                SELECT
                    SUP_CATEGORY_NAME,
                    CASE
                        WHEN SUM(CASE WHEN SUP_CATEGORY_DETAILS = 'Assumption category' THEN 1 ELSE 0 END) > 0
                            AND SUM(CASE WHEN SUP_CATEGORY_DETAILS = 'Forecast category' THEN 1 ELSE 0 END) > 0
                        THEN 'Assumption & Forecast Category'
                        WHEN SUM(CASE WHEN SUP_CATEGORY_DETAILS = 'Assumption category' THEN 1 ELSE 0 END) > 0
                        THEN 'Assumption category'
                        ELSE 'Forecast category'
                    END AS SUP_CATEGORY_DETAILS,
                    current_date() AS LAST_UPDATED_DATE,
                    current_date() AS CREATED_DATE
                FROM CombinedData
                GROUP BY SUP_CATEGORY_NAME
                """

    df_transformed = spark.sql(sqlQuery=sql_query)

    logging.info("Executed SQL query for data transformation.")

    df_transformed = df_transformed.withColumn(
        "SUP_CATEGORY_ID", sha2(concat_ws("||", "SUP_CATEGORY_NAME"), 256)
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "CAPEX": DataFrame for capex.
            - "CAPACITY_ITEM_DEMAND_CASE": DataFrame for capecity item demand case.
            - "ANNUAL_CAPEX_ITEM": DataFrame for annual capex item.
            - "CAPACITY_ITEM": DataFrame for capacity item.
            - "CAPEX_ITEM": DataFrame for capex item.
            - "FO_AND_M_COST_ITEM": DataFrame for fo&m cost item.
            - "ENERGY_ITEM": DataFrame for energy item.
            - "MODEL_ITEM": DataFrame for model item.
            - "SYSTEM_COST_ITEM": DataFrame for system cost item.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_capex = source_dfs["CAPEX"]
    df_capacity_item_demand_case = source_dfs["CAPACITY_ITEM_DEMAND_CASE"]
    df_annual_capex_item = source_dfs["ANNUAL_CAPEX_ITEM"]
    df_capacity_item = source_dfs["CAPACITY_ITEM"]
    df_capex_item = source_dfs["CAPEX_ITEM"]
    df_fo_and_m_cost_item = source_dfs["FO_AND_M_COST_ITEM"]
    df_energy_item = source_dfs["ENERGY_ITEM"]
    df_model_item = source_dfs["MODEL_ITEM"]
    df_system_cost_item = source_dfs["SYSTEM_COST_ITEM"]
    df_region = source_dfs["REGION"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_capex=df_capex,
        df_capacity_item_demand_case=df_capacity_item_demand_case,
        df_annual_capex_item=df_annual_capex_item,
        df_capacity_item=df_capacity_item,
        df_capex_item=df_capex_item,
        df_fo_and_m_cost_item=df_fo_and_m_cost_item,
        df_energy_item=df_energy_item,
        df_model_item=df_model_item,
        df_system_cost_item=df_system_cost_item,
        df_region=df_region,
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print("spark_df schema:", spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
