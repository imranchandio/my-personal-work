# pylint: disable=line-too-long
# pylint: disable=import-error
# pylint: disable=missing-module-docstring
# pylint: disable=trailing-whitespace
# pylint: disable=inconsistent-return-statements
# pylint: disable=too-many-arguments
# pylint: disable=too-many-positional-arguments
import logging
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws
from pyspark.sql import functions as F
from pyspark.sql.types import DecimalType


def prepare_current_qtr_demand_data_mw(
        spark: SparkSession,
        df_current_qtr_demand_data_mw: DataFrame,
        df_unified_pathways_names: DataFrame,
        df_dim_cr_customer_revenue_kind: DataFrame,
        df_dim_cr_loc_location_area: DataFrame,
        df_dim_cr_loc_location_group: DataFrame,
        df_dim_en_op_meas_variable: DataFrame,
        df_dim_cr_loc_customer_service_location: DataFrame,
        df_dim_cr_cus_customer_kind: DataFrame,
) -> DataFrame:
    """
    Transforms multiple input DataFrames by creating SQL temporary views,
    and returning the final transformed DataFrame.

    Parameters:
    spark (SparkSession): Spark session for managing Spark SQL and DataFrames.
    df_current_qtr_demand_data_mw (DataFrame): Current quarter demand data in megawatts.
    df_unified_pathways_names (DataFrame): Unified pathways names data.
    df_dim_cr_customer_revenue_kind (DataFrame): Customer revenue kind dimension data.
    df_dim_cr_loc_location_area (DataFrame): Location area dimension data.
    df_dim_cr_loc_location_group (DataFrame): Location group dimension data.
    df_dim_en_op_meas_variable (DataFrame): Measurement variable dimension data.
    df_dim_cr_loc_customer_service_location (DataFrame): Customer service location dimension data.
    df_dim_cr_cus_customer_kind (DataFrame): Customer kind dimension data.

    Returns:
    DataFrame: Transformed DataFrame with applied transformations on
               demand, and dimension data, leveraging SQL temporary views.
    """

    df_current_qtr_demand_data_mw.createOrReplaceTempView("CURRENT_QTR_DEMAND_DATA_MW")
    df_unified_pathways_names.createOrReplaceTempView("unified_pathways_names_source")
    df_dim_cr_customer_revenue_kind.createOrReplaceTempView(
        "DIM_CR_CUSTOMER_REVENUE_KIND"
    )
    df_dim_cr_loc_location_area.createOrReplaceTempView("DIM_CR_LOC_LOCATION_AREA")
    df_dim_cr_loc_location_group.createOrReplaceTempView("DIM_CR_LOC_LOCATION_GROUP")
    df_dim_en_op_meas_variable.createOrReplaceTempView("DIM_EN_OP_MEAS_VARIABLE")
    df_dim_cr_loc_customer_service_location.createOrReplaceTempView(
        "DIM_CR_LOC_CUSTOMER_SERVICE_LOCATION"
    )
    df_dim_cr_cus_customer_kind.createOrReplaceTempView("DIM_CR_CUS_CUSTOMER_KIND")

    sql_query = """
            SELECT crk.CUSTOMER_REVENUE_KIND_ID
            ,la.DIM_LOCATION_AREA_ID
            ,lg.DIM_LOCATION_GROUP_ID
            ,mv.MEAS_VARIABLE_ID
            ,csl.SERVICE_LOCATION_ID
            ,ck.CUSTOMER_KIND_ID
            ,SOURCE_TAB AS SOURCE_REGION
            ,trim(REPLACE(dd_mw.pathway, 'MW', '')) AS PATHWAY_NAME
            ,upns.unifiedscenarioname AS UNIFIED_SCENARIO_NAME
            ,dd_mw.VALUE AS MEAS_VALUE
            ,'MW' AS MEAS_UNIT
            ,'Yearly' AS MEAS_FREQUENCY
            ,upns.PLANNINGQUATER AS PLANNING_QUARTER
            ,dd_mw.PERIOD AS MEAS_CAPTURE_DATETIME
            ,NULL AS REGION_FOR_HLP
            ,dd_mw.REGION_FOR_POWER_NODES
            ,trim(REPLACE(dd_mw.file_name, '.xlsx', '')) AS FILE_NAME
            ,dd_mw.NOTE AS NOTE
            ,current_timestamp() AS CREATED_DATE
            ,current_timestamp() AS LAST_UPDATED_DATE
        FROM CURRENT_QTR_DEMAND_DATA_MW dd_mw
        LEFT JOIN DIM_CR_CUSTOMER_REVENUE_KIND crk 
            ON dd_mw.REPRESENTATIVE_PROFILE = crk.REVENUE_KIND_NAME
        LEFT JOIN DIM_CR_LOC_LOCATION_AREA la 
            ON dd_mw.SUB_REGION = la.LOCATION_AREA
        LEFT JOIN DIM_CR_LOC_LOCATION_GROUP lg 
            ON UPPER(dd_mw.REGION) = UPPER(lg.LOCATION_GROUP_ABBREVIATION)
        LEFT JOIN DIM_EN_OP_MEAS_VARIABLE mv 
            ON mv.VARIABLE_NAME = 'Peak Load'
        LEFT JOIN DIM_CR_LOC_CUSTOMER_SERVICE_LOCATION csl 
            ON dd_mw.ASSET = csl.service_location_details
        LEFT JOIN (
            SELECT *
            FROM DIM_CR_CUS_CUSTOMER_KIND
            WHERE CUSTOMER_KIND_SECTOR = 'DEMAND SECTORS'
            ) ck ON dd_mw.SECTOR = ck.CUSTOMER_KIND_NAME
        LEFT JOIN unified_pathways_names_source upns 
            ON trim(REPLACE(dd_mw.pathway, 'MW', '')) = trim(upns.demandpathwaysname)
            AND trim(REPLACE(dd_mw.file_name, '.xlsx', '')) = trim(upns.filename)
    """

    df_transformed = spark.sql(sqlQuery=sql_query)

    return df_transformed


def prepare_current_qtr_demand_data_mwh(
        spark: SparkSession,
        df_current_qtr_demand_data_mwh: DataFrame,
        df_unified_pathways_names: DataFrame,
        df_dim_cr_loc_location_area: DataFrame,
        df_dim_cr_loc_location_group: DataFrame,
        df_dim_en_op_meas_variable: DataFrame,
        df_dim_cr_loc_customer_service_location: DataFrame,
        df_dim_cr_cus_customer_kind: DataFrame,
) -> DataFrame:
    """
    Transforms multiple input DataFrames by creating SQL temporary views,
    and returning the final transformed DataFrame.

    Parameters:
    spark (SparkSession): Spark session for managing Spark SQL and DataFrames.
    df_current_qtr_demand_data_mwh (DataFrame): Current quarter demand data in megawatts hours.
    df_unified_pathways_names (DataFrame): Unified pathways names data.
    df_dim_cr_customer_revenue_kind (DataFrame): Customer revenue kind dimension data.
    df_dim_cr_loc_location_area (DataFrame): Location area dimension data.
    df_dim_cr_loc_location_group (DataFrame): Location group dimension data.
    df_dim_en_op_meas_variable (DataFrame): Measurement variable dimension data.
    df_dim_cr_loc_customer_service_location (DataFrame): Customer service location dimension data.
    df_dim_cr_cus_customer_kind (DataFrame): Customer kind dimension data.

    Returns:
    DataFrame: Transformed DataFrame with applied transformations on
               demand, and dimension data, leveraging SQL temporary views.
    """

    df_current_qtr_demand_data_mwh.createOrReplaceTempView(
        "CURRENT_QTR_DEMAND_DATA_MWH"
    )
    df_unified_pathways_names.createOrReplaceTempView("unified_pathways_names_source")
    df_dim_cr_loc_location_area.createOrReplaceTempView("DIM_CR_LOC_LOCATION_AREA")
    df_dim_cr_loc_location_group.createOrReplaceTempView("DIM_CR_LOC_LOCATION_GROUP")
    df_dim_en_op_meas_variable.createOrReplaceTempView("DIM_EN_OP_MEAS_VARIABLE")
    df_dim_cr_loc_customer_service_location.createOrReplaceTempView(
        "DIM_CR_LOC_CUSTOMER_SERVICE_LOCATION"
    )
    df_dim_cr_cus_customer_kind.createOrReplaceTempView("DIM_CR_CUS_CUSTOMER_KIND")

    sql_query = """
                SELECT 
                    NULL as CUSTOMER_REVENUE_KIND_ID,
                    la.DIM_LOCATION_AREA_ID, 
                    lg.DIM_LOCATION_GROUP_ID,
                    mv.MEAS_VARIABLE_ID,
                    csl.SERVICE_LOCATION_ID,
                    ck.CUSTOMER_KIND_ID,
                    SOURCE_TAB AS SOURCE_REGION,
                    trim(REPLACE(dd_mwh.pathway, 'MWh', '')) AS PATHWAY_NAME,
                    upns.unifiedscenarioname AS UNIFIED_SCENARIO_NAME,
                    dd_mwh.VALUE AS MEAS_VALUE,
                    'MWH' AS MEAS_UNIT,
                    'Monthly' AS MEAS_FREQUENCY,
                    upns.PLANNINGQUATER AS PLANNING_QUARTER,
                    dd_mwh.PERIOD AS MEAS_CAPTURE_DATETIME,
                    dd_mwh.REGION_FOR_HLP AS REGION_FOR_HLP,
                    dd_mwh.REGION_FOR_POWER_NODES,
                    trim(REPLACE(dd_mwh.file_name, '.xlsx', '')) AS FILE_NAME,
                    dd_mwh.NOTE as NOTE,
                    current_timestamp() AS CREATED_DATE,
                    current_timestamp() AS LAST_UPDATED_DATE
                FROM CURRENT_QTR_DEMAND_DATA_MWH dd_mwh
                LEFT JOIN DIM_CR_LOC_LOCATION_AREA la
                    ON dd_mwh.SUB_REGION = la.LOCATION_AREA
                LEFT JOIN DIM_CR_LOC_LOCATION_GROUP lg
                    ON UPPER(dd_mwh.REGION) = UPPER(lg.LOCATION_GROUP_ABBREVIATION)
                LEFT JOIN DIM_EN_OP_MEAS_VARIABLE mv
                    ON mv.VARIABLE_NAME = 'Demand'
                LEFT JOIN DIM_CR_LOC_CUSTOMER_SERVICE_LOCATION csl
                    ON dd_mwh.ASSET = csl.service_location_details
                LEFT JOIN (SELECT * FROM DIM_CR_CUS_CUSTOMER_KIND 
                            WHERE CUSTOMER_KIND_SECTOR = 'DEMAND SECTORS') ck
                    ON dd_mwh.SECTOR = ck.CUSTOMER_KIND_NAME
                LEFT JOIN unified_pathways_names_source upns
                    ON trim(REPLACE(dd_mwh.pathway, 'MWh', '')) = trim(upns.demandpathwaysname)
                    and trim(REPLACE(dd_mwh.file_name, '.xlsx', '')) = trim(upns.filename)
            """

    df_transformed = spark.sql(sqlQuery=sql_query)

    return df_transformed


def prepare_transformed_df(
        spark: SparkSession,
        df_current_qtr_demand_data_mw: DataFrame,
        df_current_qtr_demand_data_mwh: DataFrame,
        df_unified_pathways_names: DataFrame,
        df_dim_cr_customer_revenue_kind: DataFrame,
        df_dim_cr_loc_location_area: DataFrame,
        df_dim_cr_loc_location_group: DataFrame,
        df_dim_en_op_meas_variable: DataFrame,
        df_dim_cr_loc_customer_service_location: DataFrame,
        df_dim_cr_cus_customer_kind: DataFrame,
) -> DataFrame:
    """
    Transforms multiple input DataFrames by selecting distinct columns,
    creating SQL temporary views, and returning the final transformed DataFrame.

    Parameters:
    spark (SparkSession): Spark session for managing Spark SQL and DataFrames.
    df_current_qtr_demand_data_mw (DataFrame): Current quarter demand data in megawatts.
    df_current_qtr_demand_data_mwh (DataFrame): Current quarter demand data in megawatt hours.
    df_unified_pathways_names (DataFrame): Unified pathways names data.
    df_dim_cr_customer_revenue_kind (DataFrame): Customer revenue kind dimension data.
    df_dim_cr_loc_location_area (DataFrame): Location area dimension data.
    df_dim_cr_loc_location_group (DataFrame): Location group dimension data.
    df_dim_en_op_meas_variable (DataFrame): Measurement variable dimension data.
    df_dim_cr_loc_customer_service_location (DataFrame): Customer service location dimension
    data.
    df_dim_cr_cus_customer_kind (DataFrame): Customer kind dimension data.

    Returns:
    DataFrame: Transformed DataFrame with applied transformations on network loss,
               demand, and dimension data, leveraging SQL temporary views.
    """

    logging.info("Starting the transformation process.")

    df_unified_pathways_names = (
        df_unified_pathways_names.select(
            "unifiedscenarioname", "PLANNINGQUATER", "filename", "demandpathwaysname"
        ).distinct()
    )

    df_dim_cr_customer_revenue_kind = (
        df_dim_cr_customer_revenue_kind.where(
            F.upper(F.col("DOMAIN_TYPE")) == 'ENERGY'
        ).select("CUSTOMER_REVENUE_KIND_ID", "REVENUE_KIND_NAME")
        .distinct()
    )

    df_dim_cr_loc_location_area = (
        df_dim_cr_loc_location_area.where(
            (F.col("LOCATION_AREA_ABBREVIATION").isNotNull())
            & (F.upper(F.col("DOMAIN_TYPE")) == 'ENERGY-DEMAND')
        )
        .select("DIM_LOCATION_AREA_ID", "LOCATION_AREA")
        .distinct()
    )

    df_dim_cr_loc_location_group = (
        df_dim_cr_loc_location_group.where(
            F.upper(F.col("DOMAIN_TYPE")) == 'ENERGY'
        ).select("DIM_LOCATION_GROUP_ID", "LOCATION_GROUP_ABBREVIATION")
        .distinct()
    )

    df_dim_en_op_meas_variable = df_dim_en_op_meas_variable.select(
        "MEAS_VARIABLE_ID", "VARIABLE_NAME"
    ).distinct()

    df_dim_cr_loc_customer_service_location = (
        df_dim_cr_loc_customer_service_location.select(
            "SERVICE_LOCATION_ID", "service_location_details"
        ).where("DOMAIN_TYPE == 'Energy'").distinct()
    )

    df_dim_cr_cus_customer_kind = df_dim_cr_cus_customer_kind.select(
        "CUSTOMER_KIND_ID", "CUSTOMER_KIND_NAME", "CUSTOMER_KIND_SECTOR"
    ).distinct()

    df_demand_data_mw_data = (
        prepare_current_qtr_demand_data_mw(
            spark=spark,
            df_current_qtr_demand_data_mw=df_current_qtr_demand_data_mw,
            df_unified_pathways_names=df_unified_pathways_names,
            df_dim_cr_customer_revenue_kind=df_dim_cr_customer_revenue_kind,
            df_dim_cr_loc_location_area=df_dim_cr_loc_location_area,
            df_dim_cr_loc_location_group=df_dim_cr_loc_location_group,
            df_dim_en_op_meas_variable=df_dim_en_op_meas_variable,
            df_dim_cr_loc_customer_service_location=df_dim_cr_loc_customer_service_location,
            df_dim_cr_cus_customer_kind=df_dim_cr_cus_customer_kind,
        )
    )

    df_demand_data_mwh_data = prepare_current_qtr_demand_data_mwh(
        spark=spark,
        df_current_qtr_demand_data_mwh=df_current_qtr_demand_data_mwh,
        df_unified_pathways_names=df_unified_pathways_names,
        df_dim_cr_loc_location_area=df_dim_cr_loc_location_area,
        df_dim_cr_loc_location_group=df_dim_cr_loc_location_group,
        df_dim_en_op_meas_variable=df_dim_en_op_meas_variable,
        df_dim_cr_loc_customer_service_location=df_dim_cr_loc_customer_service_location,
        df_dim_cr_cus_customer_kind=df_dim_cr_cus_customer_kind,
    )

    df_transformed_final = df_demand_data_mw_data.unionAll(df_demand_data_mwh_data)

    df_transformed_final = (
        df_transformed_final.withColumn(
            "MEAS_VALUE",
            F.regexp_replace(
                F.regexp_replace(
                    "MEAS_VALUE",
                    " ",
                    ""),
                ",",
                "")
        )
    )
    df_transformed_final = (
        df_transformed_final.withColumn(
            "MEAS_VALUE",
            F.col("MEAS_VALUE").cast(DecimalType(28, 10))
        )
    )

    df_transformed_final = df_transformed_final.withColumn(
        "MODEL_OP_DEMAND_ID",
        sha2(
            concat_ws(
                "||",
                "CUSTOMER_REVENUE_KIND_ID",
                "DIM_LOCATION_AREA_ID",
                "DIM_LOCATION_GROUP_ID",
                "MEAS_VARIABLE_ID",
                "SERVICE_LOCATION_ID",
                "CUSTOMER_KIND_ID",
            ),
            256,
        ),
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 512
    num_partitions = calculate_num_partitions(
        df_transformed_final, max_partition_size_mb
    )

    logging.info(
        "Repartitioning the DataFrame into %d partitions.",
        num_partitions
    )

    df_transformed_final = df_transformed_final.repartition(num_partitions)

    return df_transformed_final


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "NETWORK_LOSS": DataFrame for network loss details.
            - "DIM_EN_OP_MEAS_VARIABLE": DataFrame for dimention op meas varaible data

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_current_qtr_demand_data_mw = source_dfs["CURRENT_QTR_DEMAND_DATA_MW"]
    df_current_qtr_demand_data_mwh = source_dfs["CURRENT_QTR_DEMAND_DATA_MWH"]
    df_unified_pathways_names = source_dfs["UNIFIED_PATHWAYS_NAMES"]
    df_dim_cr_customer_revenue_kind = source_dfs["DIM_CR_CUSTOMER_REVENUE_KIND"]
    df_dim_cr_loc_location_area = source_dfs["DIM_CR_LOC_LOCATION_AREA"]
    df_dim_cr_loc_location_group = source_dfs["DIM_CR_LOC_LOCATION_GROUP"]
    df_dim_en_op_meas_variable = source_dfs["DIM_EN_OP_MEAS_VARIABLE"]
    df_dim_cr_loc_customer_service_location = source_dfs[
        "DIM_CR_LOC_CUSTOMER_SERVICE_LOCATION"
    ]
    df_dim_cr_cus_customer_kind = source_dfs["DIM_CR_CUS_CUSTOMER_KIND"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_current_qtr_demand_data_mw=df_current_qtr_demand_data_mw,
        df_current_qtr_demand_data_mwh=df_current_qtr_demand_data_mwh,
        df_unified_pathways_names=df_unified_pathways_names,
        df_dim_cr_customer_revenue_kind=df_dim_cr_customer_revenue_kind,
        df_dim_cr_loc_location_area=df_dim_cr_loc_location_area,
        df_dim_cr_loc_location_group=df_dim_cr_loc_location_group,
        df_dim_en_op_meas_variable=df_dim_en_op_meas_variable,
        df_dim_cr_loc_customer_service_location=df_dim_cr_loc_customer_service_location,
        df_dim_cr_cus_customer_kind=df_dim_cr_cus_customer_kind,
    )

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration informationls.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")
    print("dummy spark df passed as argument ", spark_df)

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
