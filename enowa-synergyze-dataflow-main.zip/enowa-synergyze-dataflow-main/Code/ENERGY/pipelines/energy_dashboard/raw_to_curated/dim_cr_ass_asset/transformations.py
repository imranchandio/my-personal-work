"""
Module: dim_cr_ass_asset_energy
Description: Process data from raw to curated for the dim_cr_ass_asset.
It contains the necessary functions and logic to create dim_cr_ass_asset table in curated.

"""
# pylint: disable = C0303, R0914, C0103
import logging
from common_utils import calculate_num_partitions, impose_schema  # pylint: disable = import-error
from read_utils import read  # pylint: disable = import-error
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws, current_timestamp


def prepare_transformed_df(
        spark: SparkSession,
        **kwargs
) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters, 
    returning a transformed DataFrame.
    """
    logging.info("Starting the transformation process.")

    df_ksa_market = kwargs.get("df_ksa_market")
    df_ksa_interconnector = kwargs.get("df_ksa_interconnector")
    df_generation = kwargs.get("df_generation")
    df_ess = kwargs.get("df_ess")
    df_capacity_item_demand_case = kwargs.get("df_capacity_item_demand_case")
    df_annual_capex_item = kwargs.get("df_annual_capex_item")
    df_capacity_item = kwargs.get("df_capacity_item")
    df_fo_and_m_cost_item = kwargs.get("df_fo_and_m_cost_item")
    df_capex_item = kwargs.get("df_capex_item")
    df_energy_item = kwargs.get("df_energy_item")
    df_model_item = kwargs.get("df_model_item")
    df_system_cost_item = kwargs.get("df_system_cost_item")
    df_generation_naming_mapping = kwargs.get("df_generation_naming_mapping")
    df_dim_en_ass_sup_category = kwargs.get("df_dim_en_ass_sup_category")
    df_dim_cr_loc_location_group = kwargs.get("df_dim_cr_loc_location_group")
    df_dim_cr_loc_location = kwargs.get("df_dim_cr_loc_location")

    df_ksa_market.createOrReplaceTempView("ksa_market_source")
    df_ksa_interconnector.createOrReplaceTempView("ksa_interconnector_source")
    df_generation.createOrReplaceTempView("generation_source")
    df_ess.createOrReplaceTempView("ess_source")
    df_capacity_item_demand_case.createOrReplaceTempView("capacity_item_demand_case_source")
    df_annual_capex_item.createOrReplaceTempView("annual_capex_item_source")
    df_capacity_item.createOrReplaceTempView("capacity_item_source")
    df_capex_item.createOrReplaceTempView("capex_item_source")
    df_fo_and_m_cost_item.createOrReplaceTempView("fo_and_m_cost_item_source")
    df_energy_item.createOrReplaceTempView("energy_item_source")
    df_model_item.createOrReplaceTempView("model_item_source")
    df_system_cost_item.createOrReplaceTempView("system_cost_item_source")
    df_generation_naming_mapping.createOrReplaceTempView("generation_naming_mapping_source")
    df_dim_en_ass_sup_category.createOrReplaceTempView("dim_en_ass_sup_category")
    df_dim_cr_loc_location_group.createOrReplaceTempView("dim_cr_loc_location_group")
    df_dim_cr_loc_location.createOrReplaceTempView("dim_cr_loc_location")
    logging.info("Created temporary views for SQL operations.")

    sql_query = """
    with 
    all8_data as(   
        select distinct NAME as ASSET_NAME, CATEGORY, REGION, 0 as priority_flag, 
        'capacity_item_demand_case_source' as src from capacity_item_demand_case_source 
        union 
        select distinct NAME as ASSET_NAME, CATEGORY, REGION, 0 as priority_flag, 
        'annual_capex_item_source' as src from annual_capex_item_source 
        union 
        select distinct NAME as ASSET_NAME, CATEGORY, REGION, 0 as priority_flag, 
        'capacity_item_source' as src from capacity_item_source 
        union 
        select distinct NAME as ASSET_NAME, CATEGORY, REGION, 0 as priority_flag, 
        'capex_item_source' as src from capex_item_source 
        union 
        select distinct NAME as ASSET_NAME, CATEGORY, REGION, 0 as priority_flag, 
        'fo_and_m_cost_item_source' as src from fo_and_m_cost_item_source 
        union 
        select distinct NAME as ASSET_NAME, CATEGORY, REGION, 0 as priority_flag, 
        'energy_item_source' as src from energy_item_source 
        union 
        select distinct NAME as ASSET_NAME, CATEGORY, REGION, 1 as priority_flag, 
        'model_item_source' as src from model_item_source 
        union 
        select distinct NAME as ASSET_NAME, CATEGORY, REGION, 0 as priority_flag, 
        'system_cost_item_source' as src from system_cost_item_source
    ),
    all_asset_src as (
        select distinct NAME as ASSET_NAME,'eight_table' as src, null as ASSET_ID from capacity_item_demand_case_source 
        union 
        select distinct NAME as ASSET_NAME,'eight_table' as src, null as ASSET_ID from annual_capex_item_source 
        union 
        select distinct NAME as ASSET_NAME,'eight_table' as src, null as ASSET_ID from capacity_item_source 
        union 
        select distinct NAME as ASSET_NAME,'eight_table' as src, null as ASSET_ID from capex_item_source 
        union 
        select distinct NAME as ASSET_NAME,'eight_table' as src, null as ASSET_ID from fo_and_m_cost_item_source 
        union 
        select distinct NAME as ASSET_NAME,'eight_table' as src, null as ASSET_ID from energy_item_source 
        union 
        select distinct NAME as ASSET_NAME,'eight_table' as src, null as ASSET_ID from model_item_source 
        union 
        select distinct NAME as ASSET_NAME,'eight_table' as src, null as ASSET_ID  from system_cost_item_source 
        union
        select distinct ASSETNAME as ASSET_NAME,'ksa_market_source' as src, null as ASSET_ID  from ksa_market_source 
        union
        select distinct ASSETNAME as ASSET_NAME,'ksa_interconnector_source' as src, null as ASSET_ID 
        from ksa_interconnector_source 
        union
        select distinct ASSETNAME as ASSET_NAME,'generation_source' as src, null as ASSET_ID from generation_source 
        union 
        select distinct ASSETNAME as ASSET_NAME,'ess_source' as src, SN as ASSET_ID from ess_source
    ),
    asset as (
        SELECT DISTINCT ASSET_NAME
        FROM (
            SELECT DISTINCT 
                a.ASSET_NAME AS ASSET_NAME,
                REPLACE(REPLACE(a.ASSET_NAME, '_', ' '), '  ', ' ') AS ASSET_NAME2, 
                b.NAME,
                ROW_NUMBER() OVER (
                    PARTITION BY REPLACE(REPLACE(a.ASSET_NAME, '_', ' '), '  ', ' ') 
                    ORDER BY a.ASSET_NAME DESC
                ) AS rn
            FROM (
                SELECT DISTINCT ASSET_NAME 
                FROM all_asset_src
            ) a
            LEFT JOIN (
                SELECT NAME 
                FROM generation_naming_mapping_source
            ) b ON a.ASSET_NAME = b.NAME
            ORDER BY ASSET_NAME2
        ) 
        WHERE rn = 1 
            AND ASSET_NAME NOT IN ('BLW', 'GoA', 'Tabuk', 'Oxagon', 'LINE East', 'Trojena', 'KSA') 
        ORDER BY ASSET_NAME
    ),
    asset_category_all as (

        select a.ASSET_NAME as ASSET_NAME, a9.CATEGORY as CATEGORY
        from asset a
        left join (select distinct ASSET_NAME, CATEGORY from all8_data) a9
        on a.ASSET_NAME = a9.ASSET_NAME
        order by a.ASSET_NAME

    ),
    asset_category as (
        select distinct ASSET_NAME, CATEGORY, SUP_CATEGORY_ID
        from
        (
            select distinct ASSET_NAME, CATEGORY from asset_category_all where ASSET_NAME in (
                select ASSET_NAME from asset_category_all group by ASSET_NAME having count(ASSET_NAME)= 1 
            ) 
            union
            select distinct ASSET_NAME, CATEGORY from all8_data where ASSET_NAME in (
                select ASSET_NAME from asset_category_all group by ASSET_NAME having count(ASSET_NAME)> 1 
            ) and priority_flag = 1
            order by ASSET_NAME
        ) nd
        left join dim_en_ass_sup_category sc
        on nd.CATEGORY = sc.SUP_CATEGORY_NAME
        order by ASSET_NAME
    ),
    asset_region_all as (

        select a.ASSET_NAME as ASSET_NAME, a9.REGION as REGION
        from asset a
        left join (select distinct ASSET_NAME, REGION from all8_data) a9
        on a.ASSET_NAME = a9.ASSET_NAME
        order by a.ASSET_NAME
    ),
    asset_region as (
        select distinct ASSET_NAME, REGION, DIM_LOCATION_GROUP_ID
        from
        (
            select distinct ASSET_NAME, REGION from asset_region_all where ASSET_NAME in (
                select ASSET_NAME from asset_region_all group by ASSET_NAME having count(ASSET_NAME)= 1 
            ) 
            union
            select distinct ASSET_NAME, REGION from all8_data where ASSET_NAME in (
                select ASSET_NAME from asset_region_all group by ASSET_NAME having count(ASSET_NAME)> 1 
            ) and priority_flag = 1
            order by ASSET_NAME
        ) nd
        left join dim_cr_loc_location_group lg
        on upper(nd.REGION) = upper(lg.LOCATION_GROUP_ABBREVIATION)
        order by ASSET_NAME
    ),
    asset_location as (
        
        select a.ASSET_NAME as ASSET_NAME, l.DIM_LOCATION_ID as DIM_LOCATION_ID
        from asset a
        left join (select distinct ASSET_NAME, DIM_LOCATION_ID from dim_cr_loc_location where DOMAIN_TYPE = 'ENERGY') l
        on a.ASSET_NAME = l.ASSET_NAME
        order by a.ASSET_NAME
    ),
    asset_type as (
        
        select ASSET_NAME,src as CATEGORY,
        CASE WHEN src = 'ksa_market_source' THEN 'Market Asset'
            WHEN src = 'ksa_interconnector_source' THEN 'Grid Asset'
            WHEN src = 'generation_source' THEN 'Generation Asset'
            WHEN src = 'ess_source' THEN 'ESS Asset'
            ELSE NULL
        END as ASSET_TYPE
        from
        ( 
            select distinct a.ASSET_NAME, b.src 
            from 
            (select distinct ASSET_NAME from asset_category where CATEGORY is null) a
            left join (select distinct ASSET_NAME,src from all_asset_src where src != 'eight_table') b
            on a.ASSET_NAME = b.ASSET_NAME
        )
        union
        select distinct ASSET_NAME, CATEGORY,
        CASE WHEN CATEGORY in ('Temp GT', 'PV', 'Wind', 'Permanent GT') THEN 'Generation Asset'
            WHEN CATEGORY in ('Interconnection', 'Interregional', 'KSAIC' , 'Midstream') THEN 'Grid Asset'
            WHEN CATEGORY in ('PHS', 'LFP') THEN 'ESS Asset'
            WHEN CATEGORY in ('KSA Export', 'KSA Import') THEN 'Market Asset'
            ELSE NULL
        END AS ASSET_TYPE
        from asset_category where CATEGORY is not null
        order by ASSET_NAME
    ),
    asset_id as (

        select distinct a.ASSET_NAME, ASSET_ID
        from asset a
        left join (select distinct ASSET_NAME, ASSET_ID from all_asset_src where src = 'ess_source') b
        on a.ASSET_NAME = b.ASSET_NAME
        order by ASSET_NAME

    ),
    all_columns as (
        SELECT 
            a.ASSET_NAME AS ASSET_NAME,
            l.DIM_LOCATION_ID AS DIM_LOCATION_ID,
            r.DIM_LOCATION_GROUP_ID AS DIM_LOCATION_GROUP_ID,
            c.SUP_CATEGORY_ID AS SUP_CATEGORY_ID,
            t.ASSET_TYPE AS ASSET_TYPE,
            t.CATEGORY AS CATEGORY,
            i.ASSET_ID AS ASSET_ID,
            'Energy Asset' AS ASSET_DOMAIN_TYPE, 
            'ENERGY' AS PARTITION_KEY
        FROM 
            asset a
        LEFT JOIN 
            asset_location l ON a.ASSET_NAME = l.ASSET_NAME 
        LEFT JOIN 
            asset_region r ON a.ASSET_NAME = r.ASSET_NAME 
        LEFT JOIN 
            asset_category c ON a.ASSET_NAME = c.ASSET_NAME 
        LEFT JOIN 
            asset_type t ON a.ASSET_NAME = t.ASSET_NAME 
        LEFT JOIN 
            asset_id i ON a.ASSET_NAME = i.ASSET_NAME 
        ORDER BY a.ASSET_NAME
    )
    select distinct DIM_LOCATION_ID, DIM_LOCATION_GROUP_ID, SUP_CATEGORY_ID, 
    ASSET_DOMAIN_TYPE, PARTITION_KEY, ASSET_TYPE, CATEGORY, ASSET_NAME, ASSET_ID 
    from all_columns 
    """
    df_transformed = spark.sql(sqlQuery=sql_query)
    logging.info("Executed SQL query for data transformation.")
    df_transformed = (
        df_transformed
        .withColumn("DIM_ASSET_ID", sha2(concat_ws("||", "ASSET_NAME"), 256))
        .withColumn("LAST_UPDATED_DATE", current_timestamp())
        .withColumn("CREATED_DATE", current_timestamp())
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %s partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:  # pylint: disable = too-many-locals
    """
    Transforms the source DataFrames by performing necessary joins and filters, 
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "KSA_MARKET": DataFrame for KSA_MARKET.
            - "KSA_INTERCONNECTOR": DataFrame for KSA_INTERCONNECTOR.
            - "GENERATION": DataFrame for GENERATION.
            - "ESS": DataFrame for ESS.
            - "CAPACITY_ITEM_DEMAND_CASE": DataFrame for CAPACITY_ITEM_DEMAND_CASE.
            - "ANNUAL_CAPEX_ITEM": DataFrame for ANNUAL_CAPEX_ITEM.
            - "CAPACITY_ITEM": DataFrame for CAPACITY_ITEM.
            - "CAPEX_ITEM": DataFrame for CAPEX_ITEM.
            - "FO_AND_M_COST_ITEM": DataFrame for FO_AND_M_COST_ITEM.
            - "ENERGY_ITEM": DataFrame for ENERGY_ITEM.
            - "MODEL_ITEM": DataFrame for MODEL_ITEM.
            - "SYSTEM_COST_ITEM": DataFrame for SYSTEM_COST_ITEM.
            - "GENERATION_NAMING_MAPPING": DataFrame for GENERATION_NAMING_MAPPING.
            - "DIM_EN_ASS_SUP_CATEGORY": DataFrame for DIM_EN_ASS_SUP_CATEGORY.
            - "DIM_CR_LOC_LOCATION_GROUP": DataFrame for DIM_CR_LOC_LOCATION_GROUP.
            - "DIM_CR_LOC_LOCATION": DataFrame for DIM_CR_LOC_LOCATION.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_ksa_market = source_dfs["KSA_MARKET"]
    df_ksa_interconnector = source_dfs["KSA_INTERCONNECTOR"]
    df_generation = source_dfs["GENERATION"]
    df_ess = source_dfs["ESS"]
    df_capacity_item_demand_case = source_dfs["CAPACITY_ITEM_DEMAND_CASE"]
    df_annual_capex_item = source_dfs["ANNUAL_CAPEX_ITEM"]
    df_capacity_item = source_dfs["CAPACITY_ITEM"]
    df_capex_item = source_dfs["CAPEX_ITEM"]
    df_fo_and_m_cost_item = source_dfs["FO_AND_M_COST_ITEM"]
    df_energy_item = source_dfs["ENERGY_ITEM"]
    df_model_item = source_dfs["MODEL_ITEM"]
    df_system_cost_item = source_dfs["SYSTEM_COST_ITEM"]
    df_generation_naming_mapping = source_dfs["GENERATION_NAMING_MAPPING"]
    df_dim_en_ass_sup_category = source_dfs["DIM_EN_ASS_SUP_CATEGORY"]
    df_dim_cr_loc_location_group = source_dfs["DIM_CR_LOC_LOCATION_GROUP"]
    df_dim_cr_loc_location = source_dfs["DIM_CR_LOC_LOCATION"]
    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_ksa_market=df_ksa_market,
        df_ksa_interconnector=df_ksa_interconnector,
        df_generation=df_generation,
        df_ess=df_ess,
        df_capacity_item_demand_case=df_capacity_item_demand_case,
        df_annual_capex_item=df_annual_capex_item,
        df_capacity_item=df_capacity_item,
        df_capex_item=df_capex_item,
        df_fo_and_m_cost_item=df_fo_and_m_cost_item,
        df_energy_item=df_energy_item,
        df_model_item=df_model_item,
        df_system_cost_item=df_system_cost_item,
        df_generation_naming_mapping=df_generation_naming_mapping,
        df_dim_en_ass_sup_category=df_dim_en_ass_sup_category,
        df_dim_cr_loc_location_group=df_dim_cr_loc_location_group,
        df_dim_cr_loc_location=df_dim_cr_loc_location
    )
    transform_df = transform_df.distinct()
    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage 
        configuration information.
        task_parameters (dict): A dictionary containing task parameters, 
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")
    print("printing spark df", spark_df)

    if task_name == "curated_data_processing_task":
        df = execute_transform(spark, pipeline_storage, task_parameters)
        return df
    return None
