# pylint: disable = too-many-locals, import-error, no-name-in-module, too-many-arguments
"""
Module: fact_en_eve_model_opp_value
Description: Process data from raw to curated for the fact_en_eve_model_opp_value.
It contains the necessary functions and logic to create fact_en_eve_model_opp_value
table in curated.

Author: Abhishek Singh
Date: 06-10-2024
"""
import logging
import os
import sys
from common_utils import (
    calculate_num_partitions,
    impose_schema
)
from read_utils import read
from pyspark.sql import functions as F
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws, current_timestamp, col, coalesce, lit

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_category: DataFrame,
        df_dim_en_ass_sup_category: DataFrame,
        df_dim_en_op_meas_variable: DataFrame,
        df_source_mapping: DataFrame
) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters, using spark
    sql query, Calculating the number of partitions, repartitions the data
    and returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - df_category: DataFrame for CATEGORY.
            - df_dim_en_ass_sup_category: DataFrame for DIM_CR_ASS_ASSET.
            - df_dim_en_op_meas_variable: DataFrame for DIM_EN_OP_MEAS_VARIABLE.
            - df_source_mapping: DataFrame

    Returns:
        DataFrame: The transformed DataFrame.
    """

    logging.info("Starting the transformation process.")

    df_category.createOrReplaceTempView("category_source")
    df_dim_en_ass_sup_category.createOrReplaceTempView("dim_en_ass_sup_category")
    df_dim_en_op_meas_variable.createOrReplaceTempView("dim_en_op_meas_variable")
    df_source_mapping.createOrReplaceTempView("SOURCE_SOURCE")
    logging.info("Created temporary views for SQL operations.")

    sql_query = """
        SELECT DISTINCT SUP_CATEGORY_ID
            ,c.PATHWAY AS PATHWAY_NAME
            ,MEAS_VARIABLE_ID
            ,c.VALUE AS MEAS_VALUE
            ,VARIABLE_UNIT AS MEAS_UNIT
            ,TO_DATE(c.RUNTIME, 'yyyyMMdd') AS MODEL_RUN_TIME
            ,c.PHASE
            ,c.MEAS_CAPTURE_DATETIME
            ,c.MEAS_FREQUENCY
            ,CONCAT_WS(' ', SOURCE.LABEL, c.PATHWAY) as SCENARIO
        FROM (
            SELECT DISTINCT SUP_CATEGORY_ID
                ,CATEGORY
                ,PATHWAY
                ,VARIABLE
                ,VALUE
                ,RUNTIME
                ,PHASE
                ,MEAS_CAPTURE_DATETIME
                ,MEAS_FREQUENCY
            FROM (
                SELECT DISTINCT CATEGORY
                    ,PATHWAY
                    ,VARIABLE
                    ,VALUE
                    ,RUNTIME
                    ,PHASE
                    ,YEAR AS MEAS_CAPTURE_DATETIME
                    ,'Yearly Avg' AS MEAS_FREQUENCY
                FROM category_source
                ) a
            INNER JOIN (
                SELECT DISTINCT SUP_CATEGORY_ID
                    ,SUP_CATEGORY_NAME
                    ,SUP_CATEGORY_DETAILS
                FROM dim_en_ass_sup_category
                ) b ON a.CATEGORY = b.SUP_CATEGORY_NAME
            ) c
        LEFT JOIN SOURCE_SOURCE SOURCE 
            ON CONCAT_WS(' ', c.RUNTIME, c.PHASE, c.PATHWAY) = SOURCE.SOURCE
        LEFT JOIN (
            SELECT DISTINCT MEAS_VARIABLE_ID
                ,VARIABLE_NAME
                ,VARIABLE_UNIT
            FROM dim_en_op_meas_variable
        ) d ON c.VARIABLE = d.VARIABLE_NAME
    """

    df_transformed = spark.sql(sqlQuery=sql_query)
    logging.info("Executed SQL query for data transformation.")

    df_transformed = (
        df_transformed.withColumn(
            "MODEL_OPP_VALUE_ID",
            sha2(
                concat_ws(
                    "||",
                    coalesce(col("SUP_CATEGORY_ID"), lit("")),
                    coalesce(col("PATHWAY_NAME"), lit("")),
                    coalesce(col("MEAS_VARIABLE_ID"), lit("")),
                    coalesce(col("MODEL_RUN_TIME"), lit("")),
                    coalesce(col("PHASE"), lit("")),
                    coalesce(col("MEAS_CAPTURE_DATETIME"), lit("")),
                ),
                256,
            ),
        )
        .withColumn("LAST_UPDATED_DATE", current_timestamp())
        .withColumn("CREATED_DATE", current_timestamp())
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %s partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "CATEGORY": DataFrame for CATEGORY.
            - "DIM_EN_ASS_SUP_CATEGORY": DataFrame for DIM_EN_ASS_SUP_CATEGORY.
            - "DIM_EN_OP_MEAS_VARIABLE": DataFrame for DIM_EN_OP_MEAS_VARIABLE.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_category = source_dfs["CATEGORY"]
    df_dim_en_ass_sup_category = source_dfs["DIM_EN_ASS_SUP_CATEGORY"]
    df_dim_en_op_meas_variable = source_dfs["DIM_EN_OP_MEAS_VARIABLE"]
    df_source_mapping = source_dfs["SOURCE_MAPPING"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_category=df_category,
        df_dim_en_ass_sup_category=df_dim_en_ass_sup_category,
        df_dim_en_op_meas_variable=df_dim_en_op_meas_variable,
        df_source_mapping=df_source_mapping
    )
    transform_df = transform_df.distinct()
    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage
        configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")
    print("printing spark df", spark_df)

    if task_name == "curated_data_processing_task":
        df = execute_transform(spark, pipeline_storage, task_parameters)
        return df
    return None
