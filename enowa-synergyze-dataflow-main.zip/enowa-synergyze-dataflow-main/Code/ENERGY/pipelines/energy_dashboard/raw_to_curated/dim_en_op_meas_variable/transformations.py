"""
Module: dim_en_op_meas_variable
Description: Process data from raw to curated for the dim_en_op_meas_variable.
It contains the necessary functions and logic to create dim_en_op_meas_variable table in curated.

Author: Vaishnavi Ruikar
Date: 16-09-2024
"""

import logging
from common_utils import calculate_num_partitions, impose_schema  # pylint: disable = import-error
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws, current_timestamp
from pyspark.sql.types import StructType, StructField, StringType

COST_VARIABLE = "Cost Variable"
ASSUMPTION_VARIABLE = "Assumption Variable"
OUTPUT_VARIABLE = "Output Variable"
ASSET_VARIABLE = "Asset Variable"
GENERATION_VARIABLE = "Generation Variable"
DEMAND_VARIABLE = "Demand Variable"
GRID_VARIABLE = "Grid Variable"
DOLLAR_MWH = "$/MWh"


def transform(
        spark: SparkSession
) -> DataFrame:
    """
        It contains the necessary functions and logic to create transformed 
        dim_en_op_meas_variable df.
    """

    logging.info("Starting the transformation process.")

    schema = StructType(
        [
            StructField("VARIABLE_NAME", StringType(), True),
            StructField("VARIABLE_UNIT", StringType(), True),
            StructField("VARIABLE_TYPE", StringType(), True),
            StructField("VARIABLE_DETAIL", StringType(), True),
            StructField("VARIABLE_CALCULATION", StringType(), True),
            StructField("VARIABLE_CODE", StringType(), True),
            StructField("VARIABLE_SIGNIFICANCE", StringType(), True),
            StructField("DATA_OWNER", StringType(), True)
        ]
    )

    # Sample data based on the image
    data = [
        ("Fuel Price", "$/MMBtu, $/kg", COST_VARIABLE, None, None, None, ASSUMPTION_VARIABLE, None),
        ("Capex", "$", COST_VARIABLE, None, None, None, ASSUMPTION_VARIABLE, None),
        ("Emission", "lb/ MMBtu", "Emission Variable", None, None, None, ASSUMPTION_VARIABLE, None),
        ("IRECs Cost", DOLLAR_MWH, COST_VARIABLE, None, None, None, ASSUMPTION_VARIABLE, None),
        ("Market Price", DOLLAR_MWH, COST_VARIABLE, None, None, None, ASSUMPTION_VARIABLE, None),
        ("Capacity", "MW", GENERATION_VARIABLE, None, None, None, ASSUMPTION_VARIABLE, None),
        ("Aux Load", "MW", DEMAND_VARIABLE, None, None, None, ASSUMPTION_VARIABLE, None),
        ("Technical Life", "Years", ASSET_VARIABLE, None, None, None, ASSUMPTION_VARIABLE, None),
        ("Economic Life", "Years", ASSET_VARIABLE, None, None, None, ASSUMPTION_VARIABLE, None),
        ("Heat Rate", "Btu/kWh", ASSET_VARIABLE, None, None, None, ASSUMPTION_VARIABLE, None),
        ("Retirement Cost", "$/kW", COST_VARIABLE, None, None, None, ASSUMPTION_VARIABLE, None),
        ("Connection Cost ($000)", "$000", COST_VARIABLE, None, None, None, ASSUMPTION_VARIABLE, None),
        ("Max Power", "MW", ASSET_VARIABLE, None, None, None, ASSUMPTION_VARIABLE, None),
        ("Duration in Hr", "hrs", "Utilization Variable", None, None, None, ASSUMPTION_VARIABLE, None),
        ("Charging Efficiency", "%", ASSET_VARIABLE, None, None, None, ASSUMPTION_VARIABLE, None),
        ("Discharging Efficiency", "%", ASSET_VARIABLE, None, None, None, ASSUMPTION_VARIABLE, None),
        ("Round-Trip Efficiency", "%", ASSET_VARIABLE, None, None, None, ASSUMPTION_VARIABLE, None),
        ("GWAP", "$", COST_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Curtailment", "MWh", GRID_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Generation", "MWh", GENERATION_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Load", "MW", DEMAND_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Unserved Energy", "MWh", DEMAND_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Flow Back", "MWh", GRID_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Flow", "MWh", GRID_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Shadow Price", DOLLAR_MWH, COST_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Price", DOLLAR_MWH, COST_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Build Cost", DOLLAR_MWH, COST_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Export Revenue", DOLLAR_MWH, COST_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("FO&M Cost", DOLLAR_MWH, COST_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Fuel Offtake", "MMBtu", "Utilization variable", None, None, None, OUTPUT_VARIABLE, None),
        ("Generation Cost", DOLLAR_MWH, COST_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Overnight Capital Cost", DOLLAR_MWH, COST_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Grid Connection Cost", "$000", COST_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Overnight Grid Connection Cost", "$000", COST_VARIABLE, None, None, None,
         OUTPUT_VARIABLE, None),
        ("Peak Load", "MW", DEMAND_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Demand", "MWh", DEMAND_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Storage Capacity", "MWh", "Storage Variable ", None, None, None, OUTPUT_VARIABLE, None),
        ("Network Loss", "MWh", GRID_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Line Flow Back", "MWh", GRID_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Line Flow", "MWh", GRID_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Price Duration Curve", None, COST_VARIABLE, None, None, None, OUTPUT_VARIABLE, None),
        ("Line Flow Duration Curve", None, GRID_VARIABLE, None, None, None,
         OUTPUT_VARIABLE, None),
        ("Generation Duration Curve", None, GENERATION_VARIABLE, None, None, None,
         OUTPUT_VARIABLE, None),
        ("Generation Duration Curve Demand", None, GENERATION_VARIABLE, None, None, None,
         OUTPUT_VARIABLE, None),
        ("Demand Duration Curve", None, DEMAND_VARIABLE, None, None, None, OUTPUT_VARIABLE, None)
    ]

    # Create DataFrame
    df = spark.createDataFrame(data, schema)

    # add pk column
    df_transformed = df.withColumn("MEAS_VARIABLE_ID", sha2(concat_ws("||", "VARIABLE_NAME"), 256)) \
        .withColumn("LAST_UPDATED_DATE", current_timestamp()) \
        .withColumn("CREATED_DATE", current_timestamp())

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %s partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed.distinct()


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
) -> DataFrame:
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing 
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, 
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    transformed_df: DataFrame = transform(spark=spark)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs) -> DataFrame:
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")
    print("printing spark df", spark_df)

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)

    return None
