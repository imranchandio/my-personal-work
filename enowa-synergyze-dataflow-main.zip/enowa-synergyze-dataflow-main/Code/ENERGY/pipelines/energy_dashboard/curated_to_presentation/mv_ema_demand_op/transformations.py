# pylint: disable = import-error, missing-module-docstring, inconsistent-return-statements
# pylint: disable=line-too-long
# pylint: disable=import-error
# pylint: disable=too-many-arguments
# pylint: disable=too-many-positional-arguments

import logging
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark import StorageLevel


def prepare_transformed_df(
        spark: SparkSession,
        df_fact_en_eve_model_op_demand: DataFrame,
        df_unified_pathways_names: DataFrame,
        df_dim_cr_loc_customer_service_location: DataFrame,
        df_dim_cr_loc_location_area: DataFrame,
        df_dim_cr_cus_customer_kind: DataFrame,
        df_dim_cr_customer_revenue_kind: DataFrame,
        df_dim_cr_loc_location_group: DataFrame,
        df_neom_region_mapping: DataFrame,
        df_neom_sub_region_mapping: DataFrame,
) -> DataFrame:
    """
    Transforms demand data by joining multiple DataFrames and filtering columns.
    Creates temporary views for SQL operations and executes a transformation query.
    Removes duplicate records from raw DataFrames and partitions the transformed result.
    Calculates an appropriate number of partitions based on maximum partition size.
    Returns the transformed and repartitioned DataFrame for further processing.
    """

    logging.info("Starting the transformation process.")

    df_unified_pathways_names = df_unified_pathways_names.distinct()
    df_neom_region_mapping = df_neom_region_mapping.distinct()
    df_neom_sub_region_mapping = df_neom_sub_region_mapping.distinct()

    logging.info("Removed duplicate records from raw tables.")

    df_fact_en_eve_model_op_demand.createOrReplaceTempView(
        "fact_en_eve_model_op_demand"
    )
    df_unified_pathways_names.createOrReplaceTempView("unified_pathways_names")
    df_dim_cr_loc_customer_service_location.createOrReplaceTempView(
        "DIM_CR_LOC_CUSTOMER_SERVICE_LOCATION"
    )
    df_dim_cr_loc_location_area.createOrReplaceTempView("dim_cr_loc_location_area")
    df_dim_cr_cus_customer_kind.createOrReplaceTempView("dim_cr_cus_customer_kind")
    df_dim_cr_customer_revenue_kind.createOrReplaceTempView(
        "dim_cr_customer_revenue_kind"
    )
    df_dim_cr_loc_location_group.createOrReplaceTempView("dim_cr_loc_location_group")
    df_neom_region_mapping.createOrReplaceTempView("neom_region_mapping_source")
    df_neom_sub_region_mapping.createOrReplaceTempView("neom_sub_region_mapping_source")

    logging.info("Created temporary views for SQL operations.")

    print("df_fact_en_eve_model_op_demand count:", df_fact_en_eve_model_op_demand.count())

    sql_query1 = """
        SELECT
            trim(FACT.FILE_NAME) AS FILE_NAME,
            trim(FACT.PATHWAY_NAME) AS DEMAND_PATHWAY_NAME,
            trim(FACT.PLANNING_QUARTER) as PLANNING_QUARTER,
            trim(FACT.UNIFIED_SCENARIO_NAME) as UNIFIED_SCENARIO_NAME,
            trim(SERVICE_LOCATION_NAME) AS SERVICE_LOCATION,
            trim(SERVICE_LOCATION_DETAILS) as SERVICE_LOCATION_DETAILS,
            trim(SOURCE_REGION) as SOURCE_REGION,
            trim(LOCATION_AREA_ABBREVIATION) AS SUB_REGION_ORIGINAL,
            trim(SUBREGIONREPORT) AS SUB_REGION,
            trim(LOCATION_GROUP_ABBREVIATION) AS REGION_ORIGINAL,
            trim(REGIONREPORT) AS REGION,
            trim(REGION_FOR_POWER_NODES) AS REGION_FOR_POWER_NODE,
            trim(CUSTOMER_KIND_NAME) AS SECTOR,
            trim(REVENUE_KIND_NAME) AS REP_PROFILE,
            NOTE,
            CASE 
                WHEN MEAS_UNIT = 'MWH' THEN MEAS_CAPTURE_DATETIME
                ELSE NULL
            END AS MONTH_YEAR,
            CASE 
                WHEN MEAS_UNIT = 'MW' THEN MEAS_CAPTURE_DATETIME
                ELSE NULL
            END AS YEAR,
            CASE 
                WHEN FACT.MEAS_UNIT = 'MWH' THEN 'Demand'
                WHEN FACT.MEAS_UNIT = 'MW' THEN 'Peak Load'
                ELSE NULL
            END AS VARIABLE,
            FACT.MEAS_VALUE AS VALUE,
            FACT.MEAS_UNIT AS UNIT
        FROM FACT_EN_EVE_MODEL_OP_DEMAND FACT
        LEFT JOIN DIM_CR_LOC_CUSTOMER_SERVICE_LOCATION CSL
            ON FACT.SERVICE_LOCATION_ID = CSL.SERVICE_LOCATION_ID
        LEFT JOIN dim_cr_loc_location_group LG
            ON FACT.DIM_LOCATION_GROUP_ID = LG.DIM_LOCATION_GROUP_ID
        LEFT JOIN DIM_CR_LOC_LOCATION_AREA LA
            ON FACT.DIM_LOCATION_AREA_ID = LA.DIM_LOCATION_AREA_ID
        LEFT JOIN dim_cr_cus_customer_kind CK
            ON FACT.CUSTOMER_KIND_ID = CK.CUSTOMER_KIND_ID
        LEFT JOIN DIM_CR_CUSTOMER_REVENUE_KIND CRK
            ON FACT.CUSTOMER_REVENUE_KIND_ID = CRK.CUSTOMER_REVENUE_KIND_ID
        LEFT JOIN neom_sub_region_mapping_source SUB_REGION_MAPPING
            ON upper(LA.LOCATION_AREA_ABBREVIATION) = upper(SUB_REGION_MAPPING.subregiondata)
        LEFT JOIN neom_region_mapping_source REGION_MAPPING
            ON upper(LG.LOCATION_GROUP_ABBREVIATION) = upper(REGION_MAPPING.regiondata)
    """

    logging.info("Executing SQL query for data transformation.")

    df_transformed = spark.sql(sql_query1)

    print("Record count after running transformations:", df_transformed.count())

    # Convert month_year column into proper date format 1/Month/Year and cast as date type
    df_transformed = df_transformed.withColumn(
        "MONTH_YEAR",
        F.concat(F.lit("1-"),
                 F.substring_index(F.col("MONTH_YEAR"), "-", 1),
                 F.lit("-20"),
                 F.lpad(F.substring_index(F.col("MONTH_YEAR"), "-", -1), 2, "0"))
    )

    # Convert string to date type
    df_transformed = (
        df_transformed.withColumn(
            "MONTH_YEAR",
            F.to_date(df_transformed["MONTH_YEAR"], "d-MMM-yyyy")
        )
    )

    df_transformed = df_transformed.withColumn(
        "YEAR",
        F.when(
            F.col("YEAR").isNull(),
            F.year(F.col("MONTH_YEAR"))
        ).otherwise(F.col("YEAR")).cast("string")
    )

    logging.info("Executed SQL query for data transformation.")

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 1024
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "CAPACITY_ITEM_DEMAND_CASE": DataFrame for capacity item demand case.
            - "DIM_CR_LOC_LOCATION_GROUP": DataFrame for location group.
            - "NEOM_REGION_MAPPING": DataFrame for location mapping.
            - "NEOM_SUB_REGION_MAPPING": DataFrame for sub region mapping.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_fact_en_eve_model_op_demand = source_dfs["FACT_EN_EVE_MODEL_OP_DEMAND"]
    df_unified_pathways_names = source_dfs["UNIFIED_PATHWAYS_NAMES"]

    df_dim_cr_loc_customer_service_location = source_dfs[
        "DIM_CR_LOC_CUSTOMER_SERVICE_LOCATION"
    ].where(
        "DOMAIN_TYPE == 'Energy'"
    )

    df_dim_cr_cus_customer_kind = source_dfs["DIM_CR_CUS_CUSTOMER_KIND"]

    df_dim_cr_loc_location_area = (
        source_dfs["DIM_CR_LOC_LOCATION_AREA"].where("upper(DOMAIN_TYPE) == 'ENERGY-DEMAND'")
    ).select(
        "DIM_LOCATION_AREA_ID",
        "LOCATION_AREA",
        "LOCATION_AREA_ABBREVIATION"
    ).distinct()

    df_dim_cr_loc_location_group = (
        source_dfs["DIM_CR_LOC_LOCATION_GROUP"].where("upper(DOMAIN_TYPE) == 'ENERGY'")
    )
    df_dim_cr_customer_revenue_kind = (
        source_dfs["DIM_CR_CUSTOMER_REVENUE_KIND"].where("upper(DOMAIN_TYPE) == 'ENERGY'")
    )
    df_neom_region_mapping = source_dfs["NEOM_REGION_MAPPING"]
    df_neom_sub_region_mapping = source_dfs["NEOM_SUB_REGION_MAPPING"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_fact_en_eve_model_op_demand=df_fact_en_eve_model_op_demand,
        df_unified_pathways_names=df_unified_pathways_names,
        df_dim_cr_loc_customer_service_location=df_dim_cr_loc_customer_service_location,
        df_dim_cr_cus_customer_kind=df_dim_cr_cus_customer_kind,
        df_dim_cr_loc_location_area=df_dim_cr_loc_location_area,
        df_dim_cr_customer_revenue_kind=df_dim_cr_customer_revenue_kind,
        df_dim_cr_loc_location_group=df_dim_cr_loc_location_group,
        df_neom_region_mapping=df_neom_region_mapping,
        df_neom_sub_region_mapping=df_neom_sub_region_mapping,
    )

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    transformed_df = transformed_df.persist(StorageLevel.MEMORY_AND_DISK)

    return transformed_df


def presentation_datavalidations(spark, spark_df):
    """
    dummy validation task just returns the spark_df
    """
    print("Inside presentation_datavalidations")
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    return spark_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")
    print(spark_df)  # This is required for linting purpose

    if task_name == "curated_data_processing_task":
        df = execute_transform(spark, pipeline_storage, task_parameters)
        print("Final Transformed df")
        return df

    if task_name == "adw_presentation_data_validations_checks":
        print("transformations - adw_presentation_data_validations_checks")
        return presentation_datavalidations(spark, spark_df)

    return None
