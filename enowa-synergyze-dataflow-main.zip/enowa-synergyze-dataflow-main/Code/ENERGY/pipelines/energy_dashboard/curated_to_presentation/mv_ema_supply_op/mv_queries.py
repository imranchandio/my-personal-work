"""
Module: Queries of Supply MV
Description: Process data from curated to presentation for the mv_ema_supply_op.
It contains the necessary SQLs and logic to create mv_ema_supply_op table in presentation.

Author: Mayur Muley
Date: 10-10-2024
"""


class EnergyPrice():
    energy_price = """
        WITH SYSTEM_COST_TOTAL_UPSTREAM_COST_cte AS (
            SELECT DISTINCT 
                 'Energy Price' AS measurement_artifacts
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.duration
                ,fact.phase AS phase
                ,fact.scenario
                ,SUM(
                    CASE WHEN variable.VARIABLE_NAME in ('Generation Cost', 'IRECs Cost') 
                            and ASSET.CATEGORY = 'KSA Import' THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                        WHEN variable.VARIABLE_NAME in ('Export Revenue') 
                            and ASSET.CATEGORY = 'KSA Export' THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))* -1
                        WHEN variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost', 'Generation Cost', 'IRECs Cost') 
                            and ASSET.CATEGORY in('Permanent GT', 'Temp GT') THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                        WHEN variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost') 
                            and ASSET.CATEGORY in('PHS', 'LFP') THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                        WHEN variable.VARIABLE_NAME in ('Generation Cost') 
                            and ASSET.CATEGORY in('PV', 'Wind') THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                    ELSE 0 END
                ) OVER (
                    PARTITION BY
                    FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    )/ 1000000 AS SYSTEM_COST_TOTAL_UPSTREAM_COST
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
            INNER JOIN ASSET_CTE ASSET 
                ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID	
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE 
                ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID	
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost', 'Generation Cost', 
                                            'IRECs Cost', 'Generation', 'Export Revenue', 'Load')
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY in ('Permanent GT', 'Temp GT', 'KSA Import', 
                                        'KSA Export', 'PV', 'Wind', 'PHS', 'LFP')		
        )
        ,ENERGY_TOTAL_DEMAND_CTE AS (
            SELECT
                fact.phase,
                fact.scenario,
                SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS meas_capture_year,
                SUM(fact.meas_value) * 0.968 / 1000000 AS ENERGY_TOTAL_DEMAND
            FROM
            fact_en_eve_model_opd_ue_value fact
            INNER JOIN dim_cr_loc_location_group loc 
                ON fact.dim_location_group_id = loc.dim_location_group_id
            INNER JOIN dim_en_op_meas_variable variable 
                ON fact.meas_variable_id = variable.meas_variable_id
            INNER JOIN source_source source 
                ON source.scenario = fact.scenario
                AND source.phase = fact.phase
                AND source.rank IS NOT NULL
            WHERE
                variable.variable_name = 'Load'
                AND fact.meas_frequency = 'Daily Avg Of A Month'
                AND loc.location_group_abbreviation IN ( 'Oxagon', 'BLW', 'LINE East', 'GoA', 'Trojena' )
            GROUP BY
                fact.phase,
                fact.scenario,
                SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
        )
        SELECT DISTINCT COST.MEASUREMENT_ARTIFACTS as MEASUREMENT_ARTIFACTS
            ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
            ,COST.SUPPLY_CATEGORY
            ,COST.REGION
            ,COST.SUB_REGION
            ,'Energy Price' as VARIABLE
            ,COST.DURATION
            ,CASE 
                    WHEN DEMAND.ENERGY_TOTAL_DEMAND = 0 OR DEMAND.ENERGY_TOTAL_DEMAND IS NULL THEN 0 
                    ELSE COST.SYSTEM_COST_TOTAL_UPSTREAM_COST / DEMAND.ENERGY_TOTAL_DEMAND 
                END AS MEASUREMENT_VALUE
            ,'$/MWh' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,COST.MEAS_CAPTURE_YEAR AS YEAR
            ,COST.PHASE
            ,COST.SCENARIO
            ,'Energy Price' as VISUAL 
        FROM SYSTEM_COST_TOTAL_UPSTREAM_COST_cte COST
        inner join  ENERGY_TOTAL_DEMAND_CTE DEMAND
            ON COST.PHASE = DEMAND.PHASE
            AND COST.SCENARIO = DEMAND.SCENARIO
            AND COST.MEAS_CAPTURE_YEAR = DEMAND.MEAS_CAPTURE_YEAR
    """

    energy_price_category_ksa_import = """
        WITH SYSTEM_COST_TOTAL_UPSTREAM_COST_cte AS (
            SELECT DISTINCT 
                ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.duration
                ,fact.phase AS phase
                ,fact.scenario
                ,SUM(
                    CASE WHEN variable.VARIABLE_NAME in ('Generation Cost', 'IRECs Cost') 
                            and ASSET.CATEGORY = 'KSA Import' THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                        WHEN variable.VARIABLE_NAME in ('Export Revenue') 
                            and ASSET.CATEGORY = 'KSA Export' THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))* -1
                    ELSE 0 END
                ) OVER (
                    PARTITION BY 
                    FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    )/ 1000000 AS SYSTEM_COST_TOTAL_UPSTREAM_COST
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID	
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE 
                ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID	
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME in ('Generation Cost', 'IRECs Cost', 'Export Revenue')
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY in ('KSA Import', 'KSA Export')		
        )
        ,ENERGY_TOTAL_DEMAND_CTE AS (
            SELECT
                fact.phase,
                fact.scenario,
                SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS meas_capture_year,
                SUM(fact.meas_value) * 0.968 / 1000000 AS ENERGY_TOTAL_DEMAND
            FROM
            FACT_EN_EVE_MODEL_OPD_UE_VALUE FACT
            INNER JOIN DIM_CR_LOC_LOCATION_GROUP LOC 
                ON FACT.DIM_LOCATION_GROUP_ID = LOC.DIM_LOCATION_GROUP_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE 
                ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO
                AND SOURCE.PHASE = FACT.PHASE
                AND SOURCE.RANK IS NOT NULL
            WHERE
                variable.variable_name = 'Load'
                AND fact.meas_frequency = 'Daily Avg Of A Month'
                AND loc.location_group_abbreviation IN ( 'Oxagon', 'BLW', 'LINE East', 'GoA', 'Trojena' )
            GROUP BY
                fact.phase,
                fact.scenario,
                SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
        )
        SELECT DISTINCT 'KSA Import' as MEASUREMENT_ARTIFACTS
            ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
            ,COST.SUPPLY_CATEGORY
            ,COST.REGION
            ,COST.SUB_REGION
            ,'Energy Price - Category' as VARIABLE
            ,COST.DURATION
            ,CASE 
                    WHEN DEMAND.ENERGY_TOTAL_DEMAND = 0 OR DEMAND.ENERGY_TOTAL_DEMAND IS NULL THEN 0 
                    ELSE COST.SYSTEM_COST_TOTAL_UPSTREAM_COST / DEMAND.ENERGY_TOTAL_DEMAND 
                END AS MEASUREMENT_VALUE
            ,'$/MWh' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,COST.MEAS_CAPTURE_YEAR AS YEAR
            ,COST.PHASE
            ,COST.SCENARIO
            ,'Energy Price' as VISUAL 
        FROM SYSTEM_COST_TOTAL_UPSTREAM_COST_cte COST
        inner join  ENERGY_TOTAL_DEMAND_CTE DEMAND
            ON COST.PHASE = DEMAND.PHASE
            AND COST.SCENARIO = DEMAND.SCENARIO
            AND COST.MEAS_CAPTURE_YEAR = DEMAND.MEAS_CAPTURE_YEAR
    """

    energy_price_category_others = """
        WITH SYSTEM_COST_TOTAL_UPSTREAM_COST_CTE AS (
            SELECT DISTINCT 
                 ASSET.CATEGORY AS measurement_artifacts
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.duration
                ,fact.phase AS phase
                ,fact.scenario
                ,SUM(
                    CASE WHEN variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost', 'Generation Cost', 'IRECs Cost') 
                            and ASSET.CATEGORY in('Permanent GT', 'Temp GT') THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                        WHEN variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost') 
                            and ASSET.CATEGORY in('PHS', 'LFP') THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                        WHEN variable.VARIABLE_NAME in ('Generation Cost') 
                            and ASSET.CATEGORY in('PV', 'Wind') THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                    ELSE 0 END
                ) OVER (
                    PARTITION BY ASSET.CATEGORY,
                    FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    )/ 1000000 AS SYSTEM_COST_TOTAL_UPSTREAM_COST
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID	
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE 
                ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID	
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost', 'Generation Cost', 'IRECs Cost', 'Generation', 'Export Revenue', 'Load')
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY in ('Permanent GT', 'Temp GT', 'PV', 'Wind', 'PHS', 'LFP')		
        )
        ,ENERGY_TOTAL_DEMAND_CTE AS (
            SELECT
                FACT.PHASE,
                FACT.SCENARIO,
                SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR,
                SUM(FACT.MEAS_VALUE) * 0.968 / 1000000 AS ENERGY_TOTAL_DEMAND
            FROM
            FACT_EN_EVE_MODEL_OPD_UE_VALUE FACT
            INNER JOIN DIM_CR_LOC_LOCATION_GROUP LOC 
                ON FACT.DIM_LOCATION_GROUP_ID = LOC.DIM_LOCATION_GROUP_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE 
                ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO
                AND SOURCE.PHASE = FACT.PHASE
                AND SOURCE.RANK IS NOT NULL
            WHERE
                VARIABLE.VARIABLE_NAME = 'Load'
                AND FACT.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND LOC.LOCATION_GROUP_ABBREVIATION IN ( 'Oxagon', 'BLW', 'LINE East', 'GoA', 'Trojena' )
            GROUP BY
                FACT.PHASE,
                FACT.SCENARIO,
                SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
        )
        SELECT DISTINCT COST.MEASUREMENT_ARTIFACTS as MEASUREMENT_ARTIFACTS
            ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
            ,COST.SUPPLY_CATEGORY
            ,COST.REGION
            ,COST.SUB_REGION
            ,'Energy Price - Category' as VARIABLE
            ,COST.DURATION
            ,CASE 
                    WHEN DEMAND.ENERGY_TOTAL_DEMAND = 0 OR DEMAND.ENERGY_TOTAL_DEMAND IS NULL THEN 0 
                    ELSE COST.SYSTEM_COST_TOTAL_UPSTREAM_COST / DEMAND.ENERGY_TOTAL_DEMAND 
                END AS MEASUREMENT_VALUE
            ,'$/MWh' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,COST.MEAS_CAPTURE_YEAR AS YEAR
            ,COST.PHASE
            ,COST.SCENARIO
            ,'Energy Price' as VISUAL 
        FROM SYSTEM_COST_TOTAL_UPSTREAM_COST_cte COST
        inner join  ENERGY_TOTAL_DEMAND_CTE DEMAND
            ON COST.PHASE = DEMAND.PHASE
            AND COST.SCENARIO = DEMAND.SCENARIO
            AND COST.MEAS_CAPTURE_YEAR = DEMAND.MEAS_CAPTURE_YEAR
    """

    running_price = """
        WITH SYSTEM_COST_TOTAL_UPSTREAM_COST_cte AS (
            SELECT DISTINCT 
                 'Running Price' AS measurement_artifacts
                ,NULL as SUPPLY_CATEGORY
                ,NULL AS REGION
                ,NULL AS SUB_REGION
                ,NULL AS duration
                ,fact.phase AS phase
                ,fact.scenario
                ,SUM(
                    CASE WHEN variable.VARIABLE_NAME in ('Generation Cost', 'IRECs Cost') 
                            and ASSET.CATEGORY = 'KSA Import' THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                        WHEN variable.VARIABLE_NAME in ('Export Revenue') 
                            and ASSET.CATEGORY = 'KSA Export' THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))* -1
                        WHEN variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost', 'Generation Cost', 'IRECs Cost') 
                            and ASSET.CATEGORY in('Permanent GT', 'Temp GT') THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                        WHEN variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost') 
                            and ASSET.CATEGORY in('PHS', 'LFP') THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                        WHEN variable.VARIABLE_NAME in ('Generation Cost') 
                            and ASSET.CATEGORY in('PV', 'Wind') THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                    ELSE 0 END
                ) OVER (
                    PARTITION BY
                    FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    )/ 1000000 AS SYSTEM_COST_TOTAL_UPSTREAM_COST
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
            INNER JOIN ASSET_CTE ASSET 
                ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID	
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE 
                ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID	
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost', 'Generation Cost', 
                                            'IRECs Cost', 'Generation', 'Export Revenue', 'Load')
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY in ('Permanent GT', 'Temp GT', 'KSA Import', 
                                        'KSA Export', 'PV', 'Wind', 'PHS', 'LFP')		
        )
        ,SYSTEM_COST_TOTAL_UPSTREAM_COST_ROLLING_CTE AS (
            SELECT COST.*,
                SUM(
                    COST.SYSTEM_COST_TOTAL_UPSTREAM_COST
                    ) OVER (PARTITION BY SCENARIO, PHASE 
                            ORDER BY CAST(MEAS_CAPTURE_YEAR AS INT) 
                            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                        ) 
                AS RUNNING_SYSTEM_COST_TOTAL_UPSTREAM_COST
            FROM SYSTEM_COST_TOTAL_UPSTREAM_COST_CTE COST	
        )
        ,ENERGY_TOTAL_DEMAND_CTE AS (
            SELECT
                fact.phase,
                fact.scenario,
                SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS meas_capture_year,
                SUM(fact.meas_value) * 0.968 / 1000000 AS ENERGY_TOTAL_DEMAND
            FROM
            fact_en_eve_model_opd_ue_value fact
            INNER JOIN dim_cr_loc_location_group loc 
                ON fact.dim_location_group_id = loc.dim_location_group_id
            INNER JOIN dim_en_op_meas_variable variable 
                ON fact.meas_variable_id = variable.meas_variable_id
            INNER JOIN source_source source 
                ON source.scenario = fact.scenario
                AND source.phase = fact.phase
                AND source.rank IS NOT NULL
            WHERE
                variable.variable_name = 'Load'
                AND fact.meas_frequency = 'Daily Avg Of A Month'
                AND loc.location_group_abbreviation IN ( 'Oxagon', 'BLW', 'LINE East', 'GoA', 'Trojena' )
            GROUP BY
                fact.phase,
                fact.scenario,
                SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
        )
        ,ENERGY_TOTAL_DEMAND_ROLLING_CTE AS (
            SELECT ENERGY.*,
                SUM(
                    ENERGY.ENERGY_TOTAL_DEMAND
                    ) OVER (
                                PARTITION BY SCENARIO, PHASE 
                                ORDER BY CAST(MEAS_CAPTURE_YEAR AS INT) 
                                    ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                        ) 
                AS RUNNING_ENERGY_TOTAL_DEMAND
            FROM ENERGY_TOTAL_DEMAND_CTE ENERGY	
        )
        SELECT DISTINCT COST.MEASUREMENT_ARTIFACTS as MEASUREMENT_ARTIFACTS
            ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
            ,COST.SUPPLY_CATEGORY
            ,COST.REGION
            ,COST.SUB_REGION
            ,'Running Price' as VARIABLE
            ,COST.DURATION
            ,CASE 
                    WHEN DEMAND.RUNNING_ENERGY_TOTAL_DEMAND = 0 OR DEMAND.RUNNING_ENERGY_TOTAL_DEMAND IS NULL THEN 0 
                    ELSE COST.RUNNING_SYSTEM_COST_TOTAL_UPSTREAM_COST / DEMAND.RUNNING_ENERGY_TOTAL_DEMAND 
                END AS MEASUREMENT_VALUE
            ,'$/MWh' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,COST.MEAS_CAPTURE_YEAR AS YEAR
            ,COST.PHASE
            ,COST.SCENARIO
            ,'Energy Price' as VISUAL 
        FROM SYSTEM_COST_TOTAL_UPSTREAM_COST_ROLLING_CTE COST
        inner join  ENERGY_TOTAL_DEMAND_ROLLING_CTE DEMAND
            ON COST.PHASE = DEMAND.PHASE
            AND COST.SCENARIO = DEMAND.SCENARIO
            AND COST.MEAS_CAPTURE_YEAR = DEMAND.MEAS_CAPTURE_YEAR
    """


class EnergyCostSiteSpecificCapex():
    overnight_capex_annualised_capex = """
        WITH TEMP_CTE AS (
            SELECT DISTINCT ASSET.ASSET_NAME AS measurement_artifacts
                ,'Asset' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,FACT.DURATION
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,SUM(FACT.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.ASSET_NAME
                    ,variable.VARIABLE_NAME
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS TOTAL_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME in ('Overnight Capital Cost', 'Build Cost')
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY in ('LFP', 'PHS', 'Permanent GT', 'Temp GT', 'PV', 'Wind')
        )
        
        SELECT MAPPING.GENERATIONNAME AS MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,CASE WHEN VARIABLE = 'Overnight Capital Cost' then 'Overnight CAPEX'
                ELSE 'Annualised CAPEX'
            END AS VARIABLE	
            ,DURATION
            ,TOTAL_MEAS_VALUE/1000000 AS MEASUREMENT_VALUE
            ,'MW' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Energy Cost Site Specific Capex' as VISUAL 
        FROM TEMP_CTE INNER JOIN GENERATION_NAMING_MAPPING_SOURCE MAPPING
            ON TEMP_CTE.MEASUREMENT_ARTIFACTS = MAPPING.NAME
    """


class Gwap():
    gwap_1 = """
        WITH FACT_EN_EVE_MODEL_OPP_VALUE_CTE AS (
            SELECT DISTINCT PHASE, SCENARIO, MEAS_CAPTURE_DATETIME, MEAS_VALUE
            FROM FACT_EN_EVE_MODEL_OPP_VALUE FACT 
            INNER JOIN DIM_EN_ASS_SUP_CATEGORY CATEGORY
                ON FACT.SUP_CATEGORY_ID = CATEGORY.SUP_CATEGORY_ID
            WHERE CATEGORY.SUP_CATEGORY_NAME = 'PV'
        )
        ,FINAL_CTE AS (
            SELECT DISTINCT 
                 ASSET.CATEGORY AS measurement_artifacts
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.duration
                ,fact.phase AS phase
                ,fact.scenario
                ,SUM(
                    CASE WHEN variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost') THEN fact.MEAS_VALUE
                    ELSE '0' END
                ) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(FACT.MEAS_CAPTURE_DATETIME), '/', -1)
                    )/ 1000000 AS SYSTEM_COST
                ,SUM(
                    CASE WHEN variable.VARIABLE_NAME in ('Load') THEN FACT.MEAS_VALUE
                    ELSE '0' END
                ) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(FACT.MEAS_CAPTURE_DATETIME), '/', -1)
                    )/ 1000000 AS ENERGY_LOAD
                ,FACT_OPP.MEAS_VALUE AS GWAP_PV_CATEGORY				
                ,SUM(
                    CASE WHEN variable.VARIABLE_NAME in ('Generation') THEN FACT.MEAS_VALUE
                    ELSE '0' END
                ) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(FACT.MEAS_CAPTURE_DATETIME), '/', -1)
                    )/ 1000000 AS ENERGY	
                ,SUBSTRING_INDEX(TRIM(FACT.MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID	
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE 
                ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID	
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            INNER JOIN FACT_EN_EVE_MODEL_OPP_VALUE_CTE FACT_OPP 
                ON FACT_OPP.PHASE = FACT.PHASE
                AND FACT_OPP.SCENARIO = FACT.SCENARIO
                AND SUBSTRING_INDEX(TRIM(FACT.MEAS_CAPTURE_DATETIME), '/', -1) = FACT_OPP.MEAS_CAPTURE_DATETIME
            WHERE variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost', 'Generation', 'Load')
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY in ('LFP', 'PHS')		
            )
        SELECT DISTINCT MEASUREMENT_ARTIFACTS as MEASUREMENT_ARTIFACTS
            ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,'GWAP' as VARIABLE
            ,DURATION
            ,CASE 
                    WHEN ENERGY = 0 OR ENERGY IS NULL THEN 0 
                    ELSE (SYSTEM_COST + (ENERGY_LOAD * GWAP_PV_CATEGORY)) / ENERGY 
                END AS MEASUREMENT_VALUE
            ,'$/MWh' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'GWAP' as VISUAL 
        FROM FINAL_CTE 
    """

    gwap_2 = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                 ASSET.CATEGORY AS MEASUREMENT_ARTIFACTS
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,FACT.DURATION
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,SUM(
                    CASE WHEN variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost', 'Generation Cost', 'IRECs Cost') 
                            THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                        ELSE 0
                    END
                ) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                ) / 1000000 AS SYSTEM_COST
                ,SUM(
                    CASE WHEN variable.VARIABLE_NAME in ('Generation') 
                            THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                        ELSE 0 
                    END
                ) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                ) / 1000000 AS ENERGY
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID	
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE 
                ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID	
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost', 'Generation Cost', 'IRECs Cost', 'Generation')
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY in ('Permanent GT', 'Temp GT')		
            )
        SELECT DISTINCT MEASUREMENT_ARTIFACTS as MEASUREMENT_ARTIFACTS
            ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,'GWAP' as VARIABLE
            ,DURATION
            ,CASE 
                WHEN ENERGY = 0 OR ENERGY IS NULL THEN 0 
                ELSE (SYSTEM_COST / ENERGY) 
            END AS MEASUREMENT_VALUE
            ,'$/MWh' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'GWAP' as VISUAL 
        FROM FINAL_CTE 
    """

    gwap_3 = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                 ASSET.CATEGORY AS measurement_artifacts
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.duration
                ,fact.phase AS phase
                ,fact.scenario
                ,SUM(
                    CASE WHEN variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost') THEN fact.MEAS_VALUE
                    ELSE '0' END
                ) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    )/ 1000000 AS SYSTEM_COST
                ,SUM(
                    CASE WHEN variable.VARIABLE_NAME in ('Generation') THEN FACT.MEAS_VALUE
                    ELSE '0' END
                ) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    )/ 1000000 AS ENERGY
                ,SUM(
                    CASE WHEN variable.VARIABLE_NAME in ('Curtailment') THEN FACT.MEAS_VALUE
                    ELSE '0' END
                ) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    )/ 1000000 AS ENERGY_CURTAILED	
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID	
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE 
                ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID	
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost', 'Generation', 'Curtailment')
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY in ('PV', 'Wind')		
            )
        SELECT DISTINCT MEASUREMENT_ARTIFACTS as MEASUREMENT_ARTIFACTS
            ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,'GWAP' as VARIABLE
            ,DURATION
            ,SYSTEM_COST / (ENERGY + ENERGY_CURTAILED) AS MEASUREMENT_VALUE
            ,'$/MWh' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'GWAP' as VISUAL 
        FROM final_cte 
    """


class EnergyCostSystemCost():
    system_cost_ksa_import = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                 ASSET.CATEGORY AS MEASUREMENT_ARTIFACTS
                ,ASSET.CATEGORY AS SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,VARIABLE.VARIABLE_NAME AS VARIABLE
                ,FACT.DURATION
                ,FACT.MEAS_UNIT AS VARIABLE_UNIT
                ,FACT.MEAS_FREQUENCY
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,SUM(
                    CASE 
                        WHEN ASSET.CATEGORY = 'KSA Import' 
                             AND VARIABLE.VARIABLE_NAME IN ('Generation Cost', 'IRECs Cost') 
                        THEN FACT.MEAS_VALUE
                        WHEN ASSET.CATEGORY = 'KSA Export' 
                             AND VARIABLE.VARIABLE_NAME IN ('Export Revenue') 
                        THEN FACT.MEAS_VALUE
                        ELSE '0' 
                    END
                ) OVER (
                    PARTITION BY ASSET.CATEGORY,
                                 VARIABLE.VARIABLE_NAME,
                                 FACT.SCENARIO,
                                 FACT.PHASE,
                                 SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                ) AS TOTAL_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID	
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME in ('Generation Cost', 'IRECs Cost', 'Export Revenue')
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY in ('KSA Import', 'KSA Export')
            )
        
        SELECT DISTINCT 'KSA Import' as MEASUREMENT_ARTIFACTS
            ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
            ,'KSA Import' as SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,'System Cost' as VARIABLE
            ,DURATION
            ,SUM(
                (CASE WHEN VARIABLE = 'Export Revenue' then -1*TOTAL_MEAS_VALUE 
                    ELSE TOTAL_MEAS_VALUE 
                END) / 1000000
            ) OVER (PARTITION BY SCENARIO ,PHASE ,MEAS_CAPTURE_YEAR ) AS MEASUREMENT_VALUE
            ,'$ MM' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Energy Cost System Cost' as VISUAL 
        FROM FINAL_CTE where REGION = 'KSA'
    """

    system_cost_others = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                 ASSET.CATEGORY AS measurement_artifacts
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,FACT.DURATION
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,SUM(
                    CASE 
                        WHEN ASSET.CATEGORY IN ('Permanent GT', 'Temp GT', 'PHS', 'LFP') 
                             AND variable.VARIABLE_NAME IN ('Build Cost', 'FO&M Cost') 
                        THEN fact.MEAS_VALUE                        
                        WHEN ASSET.CATEGORY IN ('Permanent GT', 'Temp GT', 'Wind', 'PV') 
                             AND variable.VARIABLE_NAME IN ('Generation Cost') 
                        THEN fact.MEAS_VALUE                        
                        WHEN ASSET.CATEGORY IN ('Permanent GT', 'Temp GT') 
                             AND variable.VARIABLE_NAME IN ('IRECs Cost') 
                        THEN fact.MEAS_VALUE                        
                        ELSE '0' 
                    END
                ) OVER (
                    PARTITION BY ASSET.CATEGORY,
                                 FACT.SCENARIO,
                                 FACT.PHASE,
                                 SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                ) AS TOTAL_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID	
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                and SOURCE.PHASE = FACT.PHASE 
                and SOURCE.RANK is not null
            WHERE variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost', 'Generation Cost', 'IRECs Cost')
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY in ('Permanent GT', 'Temp GT', 'PHS', 'LFP', 'Wind', 'PV')
            )
        
        SELECT DISTINCT MEASUREMENT_ARTIFACTS
            ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,'System Cost' as VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE/1000000 AS MEASUREMENT_VALUE
            ,'$ MM' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Energy Cost System Cost' as VISUAL 
        FROM final_cte
    """

    system_cost_table_ksa_import = """
            WITH FINAL_CTE AS (
                SELECT DISTINCT 
                     ASSET.CATEGORY AS MEASUREMENT_ARTIFACTS
                    ,ASSET.CATEGORY AS SUPPLY_CATEGORY
                    ,ASSET.REGION AS REGION
                    ,ASSET.SUB_REGION AS SUB_REGION
                    ,VARIABLE.VARIABLE_NAME AS VARIABLE
                    ,FACT.DURATION
                    ,FACT.MEAS_UNIT AS VARIABLE_UNIT
                    ,FACT.MEAS_FREQUENCY
                    ,FACT.PHASE AS PHASE
                    ,FACT.SCENARIO
                    ,SUM(
                        CASE 
                            WHEN ASSET.CATEGORY = 'KSA Import' 
                                 AND VARIABLE.VARIABLE_NAME IN ('Generation Cost', 'IRECs Cost') 
                            THEN FACT.MEAS_VALUE
                            WHEN ASSET.CATEGORY = 'KSA Export' 
                                 AND VARIABLE.VARIABLE_NAME IN ('Export Revenue') 
                            THEN FACT.MEAS_VALUE
                            ELSE '0' 
                        END
                    ) OVER (
                        PARTITION BY ASSET.CATEGORY,
                                     VARIABLE.VARIABLE_NAME,
                                     FACT.SCENARIO,
                                     FACT.PHASE,
                                     SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS TOTAL_MEAS_VALUE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
                FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
                INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
                INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID	
                INNER JOIN SOURCE_SOURCE SOURCE 
                    ON SOURCE.SCENARIO = FACT.SCENARIO 
                    AND SOURCE.PHASE = FACT.PHASE 
                    AND SOURCE.RANK IS NOT NULL
                WHERE variable.VARIABLE_NAME in ('Generation Cost', 'IRECs Cost', 'Export Revenue')
                    AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                    AND ASSET.CATEGORY in ('KSA Import', 'KSA Export')
                )

            SELECT DISTINCT 'KSA Import' as MEASUREMENT_ARTIFACTS
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,'KSA Import' as SUPPLY_CATEGORY
                ,REGION
                ,SUB_REGION
                ,'System Cost' as VARIABLE
                ,DURATION
                ,SUM(
                    (CASE WHEN VARIABLE = 'Export Revenue' then -1*TOTAL_MEAS_VALUE 
                        ELSE TOTAL_MEAS_VALUE 
                    END) / 1000000
                ) OVER (PARTITION BY SCENARIO ,PHASE ,MEAS_CAPTURE_YEAR ) AS MEASUREMENT_VALUE
                ,'$ MM' as VARIABLE_UNIT
                ,NULL AS HOUR
                ,NULL AS MONTH
                ,MEAS_CAPTURE_YEAR AS YEAR
                ,PHASE
                ,SCENARIO
                ,'Energy Cost System Cost Table' as VISUAL 
            FROM FINAL_CTE where REGION = 'KSA'
        """

    system_cost_table_others = """
            WITH FINAL_CTE AS (
                SELECT DISTINCT 
                     ASSET.CATEGORY AS measurement_artifacts
                    ,ASSET.CATEGORY as SUPPLY_CATEGORY
                    ,ASSET.REGION AS REGION
                    ,ASSET.SUB_REGION AS SUB_REGION
                    ,variable.VARIABLE_NAME as VARIABLE
                    ,FACT.DURATION
                    ,FACT.PHASE AS PHASE
                    ,FACT.SCENARIO
                    ,SUM(
                        CASE 
                            WHEN ASSET.CATEGORY IN ('Permanent GT', 'Temp GT', 'PHS', 'LFP', 
                                                    'Interconnection', 'Interregional') 
                                 AND variable.VARIABLE_NAME IN ('Build Cost', 'FO&M Cost') 
                            THEN fact.MEAS_VALUE                        
                            WHEN ASSET.CATEGORY IN ('Permanent GT', 'Temp GT', 'Wind', 'PV') 
                                 AND variable.VARIABLE_NAME IN ('Generation Cost') 
                            THEN fact.MEAS_VALUE                        
                            WHEN ASSET.CATEGORY IN ('Permanent GT', 'Temp GT') 
                                 AND variable.VARIABLE_NAME IN ('IRECs Cost') 
                            THEN fact.MEAS_VALUE                        
                            ELSE '0' 
                        END
                    ) OVER (
                        PARTITION BY ASSET.CATEGORY,
                                     FACT.SCENARIO,
                                     FACT.PHASE,
                                     SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS TOTAL_MEAS_VALUE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
                FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
                INNER JOIN ASSET_CTE ASSET 
                    ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
                INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE 
                    ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID	
                INNER JOIN SOURCE_SOURCE SOURCE 
                    ON SOURCE.SCENARIO = FACT.SCENARIO 
                    and SOURCE.PHASE = FACT.PHASE 
                    and SOURCE.RANK is not null
                WHERE variable.VARIABLE_NAME in ('Build Cost', 'FO&M Cost', 'Generation Cost', 'IRECs Cost')
                    AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                    AND ASSET.CATEGORY in ('Permanent GT', 'Temp GT', 'PHS', 'LFP', 
                                            'Wind', 'PV', 'Interconnection', 'Interregional')
                )

            SELECT DISTINCT 
                CASE WHEN MEASUREMENT_ARTIFACTS = 'Interregional' 
                        THEN 'Grid' 
                    ELSE MEASUREMENT_ARTIFACTS 
                END AS MEASUREMENT_ARTIFACTS
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,SUPPLY_CATEGORY
                ,REGION
                ,SUB_REGION
                ,'System Cost' as VARIABLE
                ,DURATION
                ,TOTAL_MEAS_VALUE/1000000 AS MEASUREMENT_VALUE
                ,'$ MM' as VARIABLE_UNIT
                ,NULL AS HOUR
                ,NULL AS MONTH
                ,MEAS_CAPTURE_YEAR AS YEAR
                ,PHASE
                ,SCENARIO
                ,'Energy Cost System Cost Table' as VISUAL 
            FROM final_cte
        """


class SupplyBalanceIntradayMixRL():
    load = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT loc.LOCATION_GROUP_ABBREVIATION AS measurement_artifacts
                ,'Region' AS MEASUREMENT_ARTIFACTS_TYPE
                ,NULL as SUPPLY_CATEGORY
                ,loc.LOCATION_GROUP_ABBREVIATION AS REGION
                ,NULL AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,FACT.DURATION
                ,FACT.PHASE
                ,FACT.SCENARIO
                ,fact.MEAS_VALUE
                ,FACT.MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_UE_VALUE fact
            INNER JOIN DIM_CR_LOC_LOCATION_GROUP loc 
                ON fact.DIM_LOCATION_GROUP_ID = loc.DIM_LOCATION_GROUP_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable 
                ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK is not null		
            WHERE variable.VARIABLE_NAME = 'Load'
                AND FACT.MEAS_FREQUENCY = 'Hourly Avg Of A Day'
            )
        
        SELECT CASE WHEN MEASUREMENT_ARTIFACTS = 'BLW' then 'Bay + LINE West'
                when MEASUREMENT_ARTIFACTS = 'GoA' then 'Gulf of Aqaba'
                ELSE MEASUREMENT_ARTIFACTS
              END AS MEASUREMENT_ARTIFACTS  
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,MEAS_VALUE*0.968 AS MEASUREMENT_VALUE
            ,'MW' as VARIABLE_UNIT
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm') AS HOUR
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'MM') AS MONTH
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyy') AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Supply Balance Intraday MixRL' as VISUAL 
        FROM FINAL_CTE where MEASUREMENT_ARTIFACTS is not null
    """

    network_loss = """
        WITH TEMP_CTE AS (
            SELECT DISTINCT 'Sum of Region' AS MEASUREMENT_ARTIFACTS
                ,'Across ENOWA' AS MEASUREMENT_ARTIFACTS_TYPE
                ,FACT.DURATION
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,sum(FACT.MEAS_VALUE) OVER (
                    PARTITION BY FACT.SCENARIO
                    ,FACT.PHASE
                    ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyyMM')
                    ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm')
                    ) AS TOTAL_MEAS_VALUE
                ,FACT.MEAS_CAPTURE_DATETIME AS MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_UE_VALUE fact
            INNER JOIN DIM_CR_LOC_LOCATION_GROUP loc ON FACT.DIM_LOCATION_GROUP_ID = LOC.DIM_LOCATION_GROUP_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON FACT.MEAS_VARIABLE_ID = variable.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK is not null
            WHERE VARIABLE.VARIABLE_NAME = 'Demand'
                AND FACT.MEAS_FREQUENCY = 'Hourly Avg Of A Day'
        )
        ,FINAL_CTE AS (
            SELECT TEMP_CTE.*,
                TOTAL_MEAS_VALUE * FACT_OPL.MEAS_VALUE AS FINAL_MEAS_VALUE
            FROM TEMP_CTE 
            INNER JOIN  FACT_EN_EVE_MODEL_OPL_VALUE FACT_OPL 
                ON TEMP_CTE.SCENARIO = FACT_OPL.SCENARIO
                AND TEMP_CTE.PHASE = FACT_OPL.PHASE
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE 
                ON FACT_OPL.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID 
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT_OPL.SCENARIO 
                AND SOURCE.PHASE = FACT_OPL.PHASE 
                AND SOURCE.RANK is not null	
            WHERE VARIABLE.VARIABLE_NAME = 'Network Loss'
        )	
        SELECT MEASUREMENT_ARTIFACTS  
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,NULL AS SUPPLY_CATEGORY
            ,NULL AS REGION
            ,NULL AS SUB_REGION
            ,'Network Loss' AS VARIABLE
            ,DURATION
            ,FINAL_MEAS_VALUE*0.032 AS MEASUREMENT_VALUE
            ,'MW' as VARIABLE_UNIT
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm') AS HOUR
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'MM') AS MONTH
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyy') AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Supply Balance Intraday MixRL' as VISUAL 
        FROM FINAL_CTE where MEASUREMENT_ARTIFACTS is not null
    """


class FuelOfftakeMonthly():
    fuel_offtake = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT ASSET.CATEGORY AS MEASUREMENT_ARTIFACTS
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,variable.VARIABLE_NAME
                ,fact.duration
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.phase AS phase
                ,fact.scenario
                ,sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.CATEGORY, fact.scenario
                    ,fact.phase
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', 1)
                    ) AS TOTAL_MEAS_VALUE
                ,MEAS_CAPTURE_DATETIME AS MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Fuel Offtake'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY in ('Permanent GT', 'Temp GT')
            )
        
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE AS MEASUREMENT_VALUE
            ,'MMBtu' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', 1) AS MONTH
            ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Fuel Offtake Monthly' as VISUAL	
        FROM FINAL_CTE
    """


class EnergyCostOvernight():
    overnight_capital_cost = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT ASSET.CATEGORY AS measurement_artifacts
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,FACT.DURATION
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,SUM(fact.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS TOTAL_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
            INNER JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Overnight Capital Cost'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY in ('Interregional', 'LFP', 'Permanent GT', 'PHS', 'PV', 'Temp GT', 'Wind')
            )
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE / 1000000 AS MEASUREMENT_VALUE
            ,'$ MM' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Energy Cost Overnight' as VISUAL 
        FROM final_cte
    """

    overnight_grid_connection_cost = """
            WITH FINAL_CTE AS (
                SELECT DISTINCT ASSET.CATEGORY AS measurement_artifacts
                    ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                    ,ASSET.CATEGORY as SUPPLY_CATEGORY
                    ,ASSET.REGION AS REGION
                    ,ASSET.SUB_REGION AS SUB_REGION
                    ,variable.VARIABLE_NAME as VARIABLE
                    ,FACT.DURATION
                    ,FACT.PHASE AS PHASE
                    ,FACT.SCENARIO
                    ,SUM(fact.MEAS_VALUE) OVER (
                        PARTITION BY ASSET.CATEGORY
                        ,FACT.SCENARIO
                        ,FACT.PHASE
                        ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                        ) AS TOTAL_MEAS_VALUE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
                FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
                INNER JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
                INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
                INNER JOIN SOURCE_SOURCE SOURCE 
                    ON SOURCE.SCENARIO = FACT.SCENARIO 
                    AND SOURCE.PHASE = FACT.PHASE 
                    AND SOURCE.RANK IS NOT NULL
                WHERE variable.VARIABLE_NAME = 'Overnight Grid Connection Cost'
                    AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                    AND ASSET.CATEGORY in ('PV', 'Wind')
                )
            SELECT CASE WHEN MEASUREMENT_ARTIFACTS = 'PV' THEN 'PV Grid Connection'
                ELSE 'Wind Grid Connection'
            END AS MEASUREMENT_ARTIFACTS
                ,MEASUREMENT_ARTIFACTS_TYPE
                ,SUPPLY_CATEGORY
                ,REGION
                ,SUB_REGION
                ,VARIABLE
                ,DURATION
                ,TOTAL_MEAS_VALUE / 1000000 AS MEASUREMENT_VALUE
                ,'$ MM' as VARIABLE_UNIT
                ,NULL AS HOUR
                ,NULL AS MONTH
                ,MEAS_CAPTURE_YEAR AS YEAR
                ,PHASE
                ,SCENARIO
                ,'Energy Cost Overnight' as VISUAL 
            FROM final_cte
        """

    overnight_capital_cost_table = """
            WITH FINAL_CTE AS (
                SELECT DISTINCT ASSET.CATEGORY AS measurement_artifacts
                    ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                    ,ASSET.CATEGORY as SUPPLY_CATEGORY
                    ,ASSET.REGION AS REGION
                    ,ASSET.SUB_REGION AS SUB_REGION
                    ,variable.VARIABLE_NAME as VARIABLE
                    ,FACT.DURATION
                    ,FACT.PHASE AS PHASE
                    ,FACT.SCENARIO
                    ,SUM(fact.MEAS_VALUE) OVER (
                        PARTITION BY ASSET.CATEGORY
                        ,FACT.SCENARIO
                        ,FACT.PHASE
                        ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                        ) AS TOTAL_MEAS_VALUE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
                FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
                INNER JOIN ASSET_CTE asset 
                    ON fact.dim_asset_id = asset.dim_asset_id
                INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable 
                    ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
                INNER JOIN SOURCE_SOURCE SOURCE 
                    ON SOURCE.SCENARIO = FACT.SCENARIO 
                    AND SOURCE.PHASE = FACT.PHASE 
                    AND SOURCE.RANK IS NOT NULL
                WHERE variable.VARIABLE_NAME = 'Overnight Capital Cost'
                    AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                    AND ASSET.CATEGORY in ('Interconnection','Interregional', 'LFP', 
                    'Permanent GT', 'PHS', 'PV', 'Temp GT', 'Wind')
                )
            SELECT CASE WHEN MEASUREMENT_ARTIFACTS = 'Interregional' 
                        THEN 'Grid' 
                    ELSE MEASUREMENT_ARTIFACTS 
                END AS MEASUREMENT_ARTIFACTS
                ,MEASUREMENT_ARTIFACTS_TYPE
                ,SUPPLY_CATEGORY
                ,REGION
                ,SUB_REGION
                ,VARIABLE
                ,DURATION
                ,TOTAL_MEAS_VALUE / 1000000 AS MEASUREMENT_VALUE
                ,'$ MM' as VARIABLE_UNIT
                ,NULL AS HOUR
                ,NULL AS MONTH
                ,MEAS_CAPTURE_YEAR AS YEAR
                ,PHASE
                ,SCENARIO
                ,'Energy Cost Overnight Table' as VISUAL 
            FROM final_cte
        """

    overnight_grid_connection_table_cost = """
                WITH FINAL_CTE AS (
                    SELECT DISTINCT ASSET.CATEGORY AS measurement_artifacts
                        ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                        ,ASSET.CATEGORY as SUPPLY_CATEGORY
                        ,ASSET.REGION AS REGION
                        ,ASSET.SUB_REGION AS SUB_REGION
                        ,variable.VARIABLE_NAME as VARIABLE
                        ,FACT.DURATION
                        ,FACT.PHASE AS PHASE
                        ,FACT.SCENARIO
                        ,SUM(fact.MEAS_VALUE) OVER (
                            PARTITION BY ASSET.CATEGORY
                            ,FACT.SCENARIO
                            ,FACT.PHASE
                            ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                            ) AS TOTAL_MEAS_VALUE
                        ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
                    FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
                    INNER JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
                    INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
                    INNER JOIN SOURCE_SOURCE SOURCE 
                        ON SOURCE.SCENARIO = FACT.SCENARIO 
                        AND SOURCE.PHASE = FACT.PHASE 
                        AND SOURCE.RANK IS NOT NULL
                    WHERE variable.VARIABLE_NAME = 'Overnight Grid Connection Cost'
                        AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                        AND ASSET.CATEGORY in ('PV', 'Wind')
                    )
                SELECT CASE WHEN MEASUREMENT_ARTIFACTS = 'PV' THEN 'PV Grid Connection'
                    ELSE 'Wind Grid Connection'
                END AS MEASUREMENT_ARTIFACTS
                    ,MEASUREMENT_ARTIFACTS_TYPE
                    ,SUPPLY_CATEGORY
                    ,REGION
                    ,SUB_REGION
                    ,VARIABLE
                    ,DURATION
                    ,TOTAL_MEAS_VALUE / 1000000 AS MEASUREMENT_VALUE
                    ,'$ MM' as VARIABLE_UNIT
                    ,NULL AS HOUR
                    ,NULL AS MONTH
                    ,MEAS_CAPTURE_YEAR AS YEAR
                    ,PHASE
                    ,SCENARIO
                    ,'Energy Cost Overnight Table' as VISUAL 
                FROM final_cte
            """


class EnergyCostIrec():
    irecs_cost = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT ASSET.CATEGORY AS measurement_artifacts
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.duration
                ,fact.phase AS phase
                ,fact.scenario
                ,SUM(fact.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS TOTAL_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
            INNER JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'IRECs Cost'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY in ('KSA Import', 'Permanent GT', 'Temp GT')
            )
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE / 1000000 AS MEASUREMENT_VALUE
            ,'$ MM' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Energy Cost IREC' as VISUAL 
        FROM final_cte
    """


class LineDurationCurve():
    flow = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT ASSET.ASSET_NAME AS measurement_artifacts
                ,'Asset' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,FACT.DURATION
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,fact.MEAS_VALUE AS TOTAL_MEAS_VALUE
                ,MEAS_CAPTURE_DATETIME AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Flow'
                AND fact.MEAS_FREQUENCY = 'Yearly Avg'
                AND FACT.DURATION_TYPE = 'LINE DURATION'
        )
            
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE AS MEASUREMENT_VALUE
            ,'MW' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Line Duration Curve' as VISUAL 
        FROM final_cte
    """

class FlowDurationCurve():
    #Aggregated, flow_mw_2 links better to the model. kept for other use
    flow_mw = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                ASSET.ASSET_NAME AS measurement_artifacts,
                'Asset' AS MEASUREMENT_ARTIFACTS_TYPE,
                ASSET.CATEGORY AS SUPPLY_CATEGORY,
                ASSET.REGION AS REGION,
                ASSET.SUB_REGION AS SUB_REGION,
                variable.VARIABLE_NAME AS VARIABLE,
                FACT.DURATION,
                FACT.PHASE AS PHASE,
                FACT.SCENARIO,
                fact.MEAS_VALUE AS TOTAL_MEAS_VALUE,
                MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME in ('Flow' , 'Flow Back')
                AND fact.MEAS_FREQUENCY = 'Yearly Avg'
                AND FACT.DURATION_TYPE = 'FLOW DURATION'
        ),
        AGGREGATED_CTE AS (
            SELECT 
                measurement_artifacts,
                MEASUREMENT_ARTIFACTS_TYPE,
                SUPPLY_CATEGORY,
                REGION,
                SUB_REGION,
                VARIABLE,
                DURATION,
                PHASE,
                SCENARIO,
                MEAS_CAPTURE_DATETIME,
                SUM(CASE WHEN VARIABLE = 'Flow' THEN TOTAL_MEAS_VALUE ELSE 0 END) AS Flow,
                SUM(CASE WHEN VARIABLE = 'Flow Back' THEN TOTAL_MEAS_VALUE ELSE 0 END) AS Flow_Back
            FROM FINAL_CTE
            GROUP BY 
                measurement_artifacts,
                MEASUREMENT_ARTIFACTS_TYPE,
                SUPPLY_CATEGORY,
                REGION,
                SUB_REGION,
                VARIABLE,
                DURATION,
                PHASE,
                SCENARIO,
                MEAS_CAPTURE_DATETIME
        )
        SELECT 
            measurement_artifacts,
            MEASUREMENT_ARTIFACTS_TYPE,
            SUPPLY_CATEGORY,
            REGION,
            SUB_REGION,
            "Flow - Flow_Back" as VARIABLE,
            DURATION,
            (Flow - Flow_Back) as MEASUREMENT_VALUE,
            'MW' AS VARIABLE_UNIT,
            NULL AS HOUR,
            NULL AS MONTH,
            MEAS_CAPTURE_DATETIME AS YEAR,
            PHASE,
            SCENARIO,
            'Flow Duration Curve' AS VISUAL
        FROM AGGREGATED_CTE;
    """
    flow_mw_2 = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                ASSET.ASSET_NAME AS measurement_artifacts,
                'Asset' AS MEASUREMENT_ARTIFACTS_TYPE,
                ASSET.CATEGORY AS SUPPLY_CATEGORY,
                ASSET.REGION AS REGION,
                ASSET.SUB_REGION AS SUB_REGION,
                variable.VARIABLE_NAME AS VARIABLE,
                FACT.DURATION,
                FACT.PHASE AS PHASE,
                FACT.SCENARIO,
                fact.MEAS_VALUE AS TOTAL_MEAS_VALUE,
                MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME in ('Flow' , 'Flow Back')
                AND fact.MEAS_FREQUENCY = 'Yearly Avg'
                AND FACT.DURATION_TYPE = 'FLOW DURATION'
        )
        SELECT 
            measurement_artifacts,
            MEASUREMENT_ARTIFACTS_TYPE,
            SUPPLY_CATEGORY,
            REGION,
            SUB_REGION,
            VARIABLE,
            DURATION,
            TOTAL_MEAS_VALUE as MEASUREMENT_VALUE,
            'MW' AS VARIABLE_UNIT,
            NULL AS HOUR,
            NULL AS MONTH,
            MEAS_CAPTURE_DATETIME AS YEAR,
            PHASE,
            SCENARIO,
            'Flow Duration Curve 2' AS VISUAL
        FROM FINAL_CTE;
    """

class FlowDurationGraph():
    load = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                CASE 
                    WHEN ASSET.CATEGORY IN ('LFP', 'PHS') 
                        THEN CONCAT(ASSET.CATEGORY, ' ', variable.VARIABLE_NAME)
                    ELSE ASSET.CATEGORY
                END AS measurement_artifacts,
                'Asset' AS MEASUREMENT_ARTIFACTS_TYPE,
                ASSET.CATEGORY AS SUPPLY_CATEGORY,
                ASSET.REGION AS REGION,
                ASSET.SUB_REGION AS SUB_REGION,
                variable.VARIABLE_NAME AS VARIABLE,
                FACT.MEAS_UNIT AS VARIABLE_UNIT,
                FACT.DURATION,
                FACT.PHASE AS PHASE,
                FACT.SCENARIO,
                fact.MEAS_VALUE AS TOTAL_MEAS_VALUE,
                MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Load'
                AND fact.MEAS_FREQUENCY = 'Yearly Avg'
                AND FACT.DURATION_TYPE = 'FLOW DURATION'
                AND ASSET.CATEGORY in ('KSA Export', 'LFP', 'PHS')
        )
        SELECT 
            measurement_artifacts,
            MEASUREMENT_ARTIFACTS_TYPE,
            SUPPLY_CATEGORY,
            REGION,
            SUB_REGION,
            VARIABLE,
            DURATION,
            (TOTAL_MEAS_VALUE)*-1 as MEASUREMENT_VALUE,
            VARIABLE_UNIT,
            NULL AS HOUR,
            NULL AS MONTH,
            MEAS_CAPTURE_DATETIME AS YEAR,
            PHASE,
            SCENARIO,
            'Flow Duration Graph' AS VISUAL
        FROM FINAL_CTE;
        """
    
    generation = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                ASSET.CATEGORY AS measurement_artifacts,
                'Asset' AS MEASUREMENT_ARTIFACTS_TYPE,
                ASSET.CATEGORY AS SUPPLY_CATEGORY,
                ASSET.REGION AS REGION,
                ASSET.SUB_REGION AS SUB_REGION,
                variable.VARIABLE_NAME AS VARIABLE,
                FACT.MEAS_UNIT AS VARIABLE_UNIT,
                FACT.DURATION,
                FACT.PHASE AS PHASE,
                FACT.SCENARIO,
                fact.MEAS_VALUE AS TOTAL_MEAS_VALUE,
                MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Generation'
                AND fact.MEAS_FREQUENCY = 'Yearly Avg'
                AND FACT.DURATION_TYPE = 'FLOW DURATION'
                AND ASSET.CATEGORY in 
                ('KSA Import', 'LFP', 'PHS', 'Permanent GT', 'PV', 'Temp GT','Wind')
        )
        SELECT 
            measurement_artifacts,
            MEASUREMENT_ARTIFACTS_TYPE,
            SUPPLY_CATEGORY,
            REGION,
            SUB_REGION,
            VARIABLE,
            DURATION,
            (TOTAL_MEAS_VALUE) as MEASUREMENT_VALUE,
            VARIABLE_UNIT,
            NULL AS HOUR,
            NULL AS MONTH,
            MEAS_CAPTURE_DATETIME AS YEAR,
            PHASE,
            SCENARIO,
            'Flow Duration Graph' AS VISUAL
        FROM FINAL_CTE;
        """
    
    curtailment = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                CONCAT(ASSET.CATEGORY, ' Curtailed') as measurement_artifacts,
                'Asset' AS MEASUREMENT_ARTIFACTS_TYPE,
                ASSET.CATEGORY AS SUPPLY_CATEGORY,
                ASSET.REGION AS REGION,
                ASSET.SUB_REGION AS SUB_REGION,
                variable.VARIABLE_NAME AS VARIABLE,
                FACT.MEAS_UNIT AS VARIABLE_UNIT,
                FACT.DURATION,
                FACT.PHASE AS PHASE,
                FACT.SCENARIO,
                fact.MEAS_VALUE AS TOTAL_MEAS_VALUE,
                MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Curtailment'
                AND fact.MEAS_FREQUENCY = 'Yearly Avg'
                AND FACT.DURATION_TYPE = 'FLOW DURATION'
                AND ASSET.CATEGORY in 
                ('PV', 'Wind')
        )
        SELECT 
            measurement_artifacts,
            MEASUREMENT_ARTIFACTS_TYPE,
            SUPPLY_CATEGORY,
            REGION,
            SUB_REGION,
            VARIABLE,
            DURATION,
            (TOTAL_MEAS_VALUE) as MEASUREMENT_VALUE,
            VARIABLE_UNIT,
            NULL AS HOUR,
            NULL AS MONTH,
            MEAS_CAPTURE_DATETIME AS YEAR,
            PHASE,
            SCENARIO,
            'Flow Duration Graph' AS VISUAL
        FROM FINAL_CTE;
        """

    unserved_energy = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                'Unserved Energy' AS measurement_artifacts,
                'Asset' AS MEASUREMENT_ARTIFACTS_TYPE,
                ASSET.CATEGORY AS SUPPLY_CATEGORY,
                ASSET.REGION AS REGION,
                ASSET.SUB_REGION AS SUB_REGION,
                variable.VARIABLE_NAME AS VARIABLE,
                FACT.MEAS_UNIT AS VARIABLE_UNIT,
                FACT.DURATION,
                FACT.PHASE AS PHASE,
                FACT.SCENARIO,
                fact.MEAS_VALUE AS TOTAL_MEAS_VALUE,
                MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Unserved Energy'
                AND fact.MEAS_FREQUENCY = 'Yearly Avg'
                AND FACT.DURATION_TYPE = 'FLOW DURATION'
        )
        SELECT 
            measurement_artifacts,
            MEASUREMENT_ARTIFACTS_TYPE,
            SUPPLY_CATEGORY,
            REGION,
            SUB_REGION,
            VARIABLE,
            DURATION,
            (TOTAL_MEAS_VALUE) as MEASUREMENT_VALUE,
            VARIABLE_UNIT,
            NULL AS HOUR,
            NULL AS MONTH,
            MEAS_CAPTURE_DATETIME AS YEAR,
            PHASE,
            SCENARIO,
            'Flow Duration Graph' AS VISUAL
        FROM FINAL_CTE;
        """
    
class LoadDurationGraph():
    load = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                CASE 
                    WHEN ASSET.CATEGORY IN ('LFP', 'PHS') 
                        THEN CONCAT(ASSET.CATEGORY, ' ', variable.VARIABLE_NAME)
                    ELSE ASSET.CATEGORY
                END AS measurement_artifacts,
                'Asset' AS MEASUREMENT_ARTIFACTS_TYPE,
                ASSET.CATEGORY AS SUPPLY_CATEGORY,
                ASSET.REGION AS REGION,
                ASSET.SUB_REGION AS SUB_REGION,
                variable.VARIABLE_NAME AS VARIABLE,
                FACT.MEAS_UNIT AS VARIABLE_UNIT,
                FACT.DURATION,
                FACT.PHASE AS PHASE,
                FACT.SCENARIO,
                fact.MEAS_VALUE AS TOTAL_MEAS_VALUE,
                MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Load'
                AND fact.MEAS_FREQUENCY = 'Yearly Avg'
                AND FACT.DURATION_TYPE = 'LOAD DURATION'
                AND ASSET.CATEGORY in ('KSA Export', 'LFP', 'PHS')
        )
        SELECT 
            measurement_artifacts,
            MEASUREMENT_ARTIFACTS_TYPE,
            SUPPLY_CATEGORY,
            REGION,
            SUB_REGION,
            VARIABLE,
            DURATION,
            (TOTAL_MEAS_VALUE)*-1 as MEASUREMENT_VALUE,
            VARIABLE_UNIT,
            NULL AS HOUR,
            NULL AS MONTH,
            MEAS_CAPTURE_DATETIME AS YEAR,
            PHASE,
            SCENARIO,
            'LOAD DURATION Graph' AS VISUAL
        FROM FINAL_CTE;
        """
    
    generation = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                ASSET.CATEGORY AS measurement_artifacts,
                'Asset' AS MEASUREMENT_ARTIFACTS_TYPE,
                ASSET.CATEGORY AS SUPPLY_CATEGORY,
                ASSET.REGION AS REGION,
                ASSET.SUB_REGION AS SUB_REGION,
                variable.VARIABLE_NAME AS VARIABLE,
                FACT.MEAS_UNIT AS VARIABLE_UNIT,
                FACT.DURATION,
                FACT.PHASE AS PHASE,
                FACT.SCENARIO,
                fact.MEAS_VALUE AS TOTAL_MEAS_VALUE,
                MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Generation'
                AND fact.MEAS_FREQUENCY = 'Yearly Avg'
                AND FACT.DURATION_TYPE = 'LOAD DURATION'
                AND ASSET.CATEGORY in 
                ('KSA Import', 'LFP', 'PHS', 'Permanent GT', 'PV', 'Temp GT','Wind')
        )
        SELECT 
            measurement_artifacts,
            MEASUREMENT_ARTIFACTS_TYPE,
            SUPPLY_CATEGORY,
            REGION,
            SUB_REGION,
            VARIABLE,
            DURATION,
            (TOTAL_MEAS_VALUE) as MEASUREMENT_VALUE,
            VARIABLE_UNIT,
            NULL AS HOUR,
            NULL AS MONTH,
            MEAS_CAPTURE_DATETIME AS YEAR,
            PHASE,
            SCENARIO,
            'LOAD DURATION Graph' AS VISUAL
        FROM FINAL_CTE;
        """
    
    curtailment = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                CONCAT(ASSET.CATEGORY, ' Curtailed') as measurement_artifacts,
                'Asset' AS MEASUREMENT_ARTIFACTS_TYPE,
                ASSET.CATEGORY AS SUPPLY_CATEGORY,
                ASSET.REGION AS REGION,
                ASSET.SUB_REGION AS SUB_REGION,
                variable.VARIABLE_NAME AS VARIABLE,
                FACT.MEAS_UNIT AS VARIABLE_UNIT,
                FACT.DURATION,
                FACT.PHASE AS PHASE,
                FACT.SCENARIO,
                fact.MEAS_VALUE AS TOTAL_MEAS_VALUE,
                MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Curtailment'
                AND fact.MEAS_FREQUENCY = 'Yearly Avg'
                AND FACT.DURATION_TYPE = 'LOAD DURATION'
                AND ASSET.CATEGORY in 
                ('PV', 'Wind')
        )
        SELECT 
            measurement_artifacts,
            MEASUREMENT_ARTIFACTS_TYPE,
            SUPPLY_CATEGORY,
            REGION,
            SUB_REGION,
            VARIABLE,
            DURATION,
            (TOTAL_MEAS_VALUE) as MEASUREMENT_VALUE,
            VARIABLE_UNIT,
            NULL AS HOUR,
            NULL AS MONTH,
            MEAS_CAPTURE_DATETIME AS YEAR,
            PHASE,
            SCENARIO,
            'LOAD DURATION Graph' AS VISUAL
        FROM FINAL_CTE;
        """

    unserved_energy = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                'Unserved Energy' AS measurement_artifacts,
                'Asset' AS MEASUREMENT_ARTIFACTS_TYPE,
                ASSET.CATEGORY AS SUPPLY_CATEGORY,
                ASSET.REGION AS REGION,
                ASSET.SUB_REGION AS SUB_REGION,
                variable.VARIABLE_NAME AS VARIABLE,
                FACT.MEAS_UNIT AS VARIABLE_UNIT,
                FACT.DURATION,
                FACT.PHASE AS PHASE,
                FACT.SCENARIO,
                fact.MEAS_VALUE AS TOTAL_MEAS_VALUE,
                MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Unserved Energy'
                AND fact.MEAS_FREQUENCY = 'Yearly Avg'
                AND FACT.DURATION_TYPE = 'LOAD DURATION'
        )
        SELECT 
            measurement_artifacts,
            MEASUREMENT_ARTIFACTS_TYPE,
            SUPPLY_CATEGORY,
            REGION,
            SUB_REGION,
            VARIABLE,
            DURATION,
            (TOTAL_MEAS_VALUE) as MEASUREMENT_VALUE,
            VARIABLE_UNIT,
            NULL AS HOUR,
            NULL AS MONTH,
            MEAS_CAPTURE_DATETIME AS YEAR,
            PHASE,
            SCENARIO,
            'LOAD DURATION Graph' AS VISUAL
        FROM FINAL_CTE;
        """
    
    demand = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT
                lg.location_group_abbreviation AS measurement_artifacts
                ,'Across ENOWA' AS MEASUREMENT_ARTIFACTS_TYPE
                ,NULL as SUPPLY_CATEGORY
                ,NULL AS REGION
                ,NULL AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,FACT.DURATION
                ,FACT.MEAS_UNIT AS VARIABLE_UNIT
                ,FACT.PHASE
                ,FACT.SCENARIO
                ,FACT.MEAS_VALUE
                ,FACT.MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_UE_VALUE fact
            INNER JOIN DIM_CR_LOC_LOCATION_GROUP lg ON fact.DIM_LOCATION_GROUP_ID = lg.DIM_LOCATION_GROUP_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID	
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                and SOURCE.PHASE = FACT.PHASE 
                and SOURCE.RANK is not null
            WHERE variable.VARIABLE_NAME in ('Load') 
                AND fact.MEAS_FREQUENCY = 'Yearly Avg'
                AND FACT.DURATION_TYPE = 'LOAD DURATION'
                AND lg.LOCATION_GROUP_ABBREVIATION is not null
            )
        
        SELECT 
            CASE
                WHEN MEASUREMENT_ARTIFACTS = 'BLW' THEN 'Bay + LINE West'
                ELSE MEASUREMENT_ARTIFACTS
            END AS MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,'Demand' as VARIABLE
            ,DURATION
            ,sum(MEAS_VALUE) * 0.968 AS MEASUREMENT_VALUE
            ,VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_DATETIME AS YEAR
            ,PHASE
            ,SCENARIO
            ,'LOAD DURATION Demand' as VISUAL 
        FROM final_cte
        Group by MEASUREMENT_ARTIFACTS, MEASUREMENT_ARTIFACTS_TYPE, SUPPLY_CATEGORY
        , REGION, SUB_REGION, DURATION, VARIABLE_UNIT, MEAS_CAPTURE_DATETIME
        , PHASE, SCENARIO
    """

class StorageCapacity():
    storage_capacity_1 = """
        WITH FINAL_CTE AS (
            SELECT ASSET.CATEGORY AS measurement_artifacts
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,'Storage Capacity' as VARIABLE
                ,fact.duration
                ,fact.phase AS phase
                ,fact.scenario
                ,sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,fact.scenario
                    ,fact.phase
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS TOTAL_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM fact_en_eve_model_opd_value fact
            INNER JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID	
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                and SOURCE.PHASE = FACT.PHASE 
                and SOURCE.RANK is not null
            WHERE variable.VARIABLE_NAME = 'Storage Capacity'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', 1) = '01'
                AND ASSET.CATEGORY = 'PHS'
            )
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE / 1000 AS MEASUREMENT_VALUE
            ,'GWh' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Storage Capacity' as VISUAL 
        FROM final_cte
    """

    storage_capacity_2 = """
        WITH FINAL_CTE AS (
            SELECT  REPLACE(CONCAT_WS(' ', SPLIT(ASSET_NAME, '_')[0], SPLIT(ASSET_NAME, '_')[1]), '_', ' ') AS measurement_artifacts
                ,'Asset Sub-Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,'Storage Capacity' as VARIABLE
                ,fact.duration
                ,fact.phase AS phase
                ,fact.scenario
                ,sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY REPLACE(CONCAT_WS(' ', SPLIT(ASSET_NAME, '_')[0], SPLIT(ASSET_NAME, '_')[1]), '_', ' ')
                    ,fact.scenario
                    ,fact.phase
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS TOTAL_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM fact_en_eve_model_opd_value fact
            INNER JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                and SOURCE.PHASE = FACT.PHASE 
                and SOURCE.RANK is not null	
            WHERE variable.VARIABLE_NAME = 'Storage Capacity'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', 1) = '01'
                AND ASSET.CATEGORY = 'LFP'
                
            )
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE / 1000 AS MEASUREMENT_VALUE
            ,'GWh' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Storage Capacity' as VISUAL 
        FROM final_cte
    """

class StorageUtilization():

    utilization = """
        WITH FINAL_CTE AS (
            SELECT  
                CASE 
                    WHEN ASSET.ASSET_NAME LIKE '%PHS%' THEN 'PHS'
                    WHEN ASSET.ASSET_NAME LIKE 'LFP%' THEN REPLACE(CONCAT_WS(' ', SPLIT(ASSET_NAME, '_')[0], SPLIT(ASSET_NAME, '_')[1]), '_', ' ')
                    ELSE NULL
                END AS MEASUREMENT_ARTIFACTS
                ,'Asset Sub-Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION as REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.phase
                ,fact.scenario
                ,fact.MEAS_UNIT as VARIABLE_UNIT
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
                ,SUM(fact.MEAS_VALUE) as TOTAL_MEAS_VALUE
            FROM fact_en_eve_model_opd_value fact
            INNER JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                and SOURCE.PHASE = FACT.PHASE 
                and SOURCE.RANK is not null	
            WHERE variable.VARIABLE_NAME = 'Generation'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY in ('LFP','PHS')
            GROUP BY
                CASE 
                    WHEN ASSET.ASSET_NAME LIKE '%PHS%' THEN 'PHS'
                    WHEN ASSET.ASSET_NAME LIKE 'LFP%' THEN REPLACE(CONCAT_WS(' ', SPLIT(ASSET_NAME, '_')[0], SPLIT(ASSET_NAME, '_')[1]), '_', ' ')
                    ELSE NULL
                END                
                ,ASSET.CATEGORY
                ,ASSET.REGION
                ,ASSET.SUB_REGION
                ,variable.VARIABLE_NAME
                ,fact.phase
                ,fact.scenario
                ,fact.MEAS_UNIT 
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)

            )
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,NULL AS DURATION
            ,TOTAL_MEAS_VALUE /365 /0.911  AS MEASUREMENT_VALUE
            ,VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Generation For Utilization' as VISUAL 
        FROM final_cte
        WHERE PHASE = 'ST'
"""
            #       GROUP BY
            #     CASE 
            #         WHEN ASSET.ASSET_NAME LIKE '%PHS%' THEN 'PHS'
            #         WHEN ASSET.ASSET_NAME LIKE 'LFP%' THEN REPLACE(CONCAT_WS(' ', SPLIT(ASSET_NAME, '_')[0], SPLIT(ASSET_NAME, '_')[1]), '_', ' ')
            #         ELSE NULL
            #     END                
            #     ,ASSET.CATEGORY 
            #     ,ASSET.SUB_REGION
            #     ,variable.VARIABLE_NAME
            #     ,fact.duration
            #     ,fact.scenario
            #     ,fact.phase
            #     ,fact.MEAS_UNIT 
            #     ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
            # HAVING fact.phase = 'ST'  
    # Generation only with 0.911 factor needs to be revised
    storage_utilization = """
        WITH FINAL_CTE AS (
            SELECT   
                CASE 
                    WHEN ASSET.ASSET_NAME LIKE '%PHS%' THEN 'PHS'
                    WHEN ASSET.ASSET_NAME LIKE 'LFP%' THEN  REPLACE(CONCAT_WS(' ', SPLIT(ASSET_NAME, '_')[0], SPLIT(ASSET_NAME, '_')[1]), '_', ' ') 
                    ELSE NULL
                END AS MEASUREMENT_ARTIFACTS
                ,'Asset Sub-Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME AS VARIABLE
                ,fact.duration
                ,fact.phase AS phase
                ,fact.scenario
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
                ,CASE
                WHEN ASSET.ASSET_NAME LIKE '%PHS%'
                THEN 
                    sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY 
                        ASSET.CATEGORY
                        ,fact.scenario
                        ,fact.phase
                        ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) / 1000 / 0.911 / EXTRACT(DAY FROM LAST_DAY(TO_DATE(MEAS_CAPTURE_DATETIME, 'MM/DD/YYYY')))
                ELSE
                    sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY 
                        REPLACE(CONCAT_WS(' ', SPLIT(ASSET_NAME, '_')[0], SPLIT(ASSET_NAME, '_')[1]), '_', ' ')
                        ,fact.scenario
                        ,fact.phase
                        ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) /1000 / 0.911 / EXTRACT(DAY FROM LAST_DAY(TO_DATE(MEAS_CAPTURE_DATETIME, 'MM/DD/YYYY')))
                END AS TOTAL_MEAS_VALUE
            FROM fact_en_eve_model_opd_value fact
            INNER JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                and SOURCE.PHASE = FACT.PHASE 
                and SOURCE.RANK is not null	
            WHERE variable.VARIABLE_NAME = 'Generation'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', 1) = '01' 
        )
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE AS MEASUREMENT_VALUE
            ,'GWh' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Generation For Utilization Obselete' as VISUAL 
        FROM final_cte
        Where MEASUREMENT_ARTIFACTS IS NOT NULL
"""

class SupplyBalanceIntradayMix():
    demand = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                'Sum Of Region' AS measurement_artifacts
                ,'Across ENOWA' AS MEASUREMENT_ARTIFACTS_TYPE
                ,NULL as SUPPLY_CATEGORY
                ,NULL AS REGION
                ,NULL AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,FACT.DURATION
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY FACT.SCENARIO
                    ,FACT.PHASE
                    ,variable.VARIABLE_NAME 
                    ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyyMM')
                    ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm')
                    ) AS TOTAL_MEAS_VALUE
                ,FACT.MEAS_CAPTURE_DATETIME AS MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_UE_VALUE fact
            INNER JOIN DIM_CR_LOC_LOCATION_GROUP lg ON fact.DIM_LOCATION_GROUP_ID = lg.DIM_LOCATION_GROUP_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID	
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                and SOURCE.PHASE = FACT.PHASE 
                and SOURCE.RANK is not null
            WHERE variable.VARIABLE_NAME in ('Load') 
                AND fact.MEAS_FREQUENCY = 'Hourly Avg Of A Day'
                and lg.LOCATION_GROUP_ABBREVIATION is not null
            )
        
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,'Demand' as VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE * 0.968 AS MEASUREMENT_VALUE
            ,'MW' as VARIABLE_UNIT
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm') AS HOUR
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'MM') AS MONTH
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyy') AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Supply Balance Intraday Mix' as VISUAL 
        FROM final_cte
    """

    generation_output_and_load = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                CASE WHEN variable.VARIABLE_NAME = 'Load' THEN CONCAT(ASSET.CATEGORY,' Load')
                    ELSE ASSET.CATEGORY 
                END AS measurement_artifacts
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.duration
                ,fact.phase AS phase
                ,fact.scenario
                ,sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,fact.scenario
                    ,fact.phase
                    ,variable.VARIABLE_NAME 
                    ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyyMM')
                    ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm')
                    ) AS total_meas_value
                ,FACT.MEAS_CAPTURE_DATETIME AS MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
            INNER JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID	
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                and SOURCE.PHASE = FACT.PHASE 
                and SOURCE.RANK is not null
            WHERE variable.VARIABLE_NAME in ('Generation', 'Load')
                AND fact.MEAS_FREQUENCY = 'Hourly Avg Of A Day'
            )
        
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,case when VARIABLE = 'Generation' then TOTAL_MEAS_VALUE 
                else -1*TOTAL_MEAS_VALUE
             END AS MEASUREMENT_VALUE
            ,'MW' as VARIABLE_UNIT
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm') AS HOUR
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'MM') AS MONTH
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyy') AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Supply Balance Intraday Mix' as VISUAL 
        FROM final_cte
    """

    curtailment = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                 CASE WHEN ASSET.CATEGORY = 'PV' then 'PV Curtailed'
                    WHEN ASSET.CATEGORY = 'Wind' then 'Wind Curtailed' 
                END AS measurement_artifacts
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,FACT.DURATION
                ,fact.MEAS_UNIT AS variable_unit
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyyMM')
                    ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm')
                    ) AS TOTAL_MEAS_VALUE
                ,FACT.MEAS_CAPTURE_DATETIME AS MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID	
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK is not null
            WHERE variable.VARIABLE_NAME = 'Curtailment'
                AND fact.MEAS_FREQUENCY = 'Hourly Avg Of A Day'
            )
        
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE AS MEASUREMENT_VALUE
            ,'MW' as VARIABLE_UNIT
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm') AS HOUR
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'MM') AS MONTH
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyy') AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Supply Balance Intraday Mix' as VISUAL 
        FROM final_cte
    """


class SupplyCapacity():
    peak_load_1 = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT loc.LOCATION_GROUP_ABBREVIATION AS measurement_artifacts
                ,'Region' AS MEASUREMENT_ARTIFACTS_TYPE
                ,NULL as SUPPLY_CATEGORY
                ,loc.LOCATION_GROUP_ABBREVIATION AS REGION
                ,NULL AS SUB_REGION
                ,VARIABLE.VARIABLE_NAME AS VARIABLE
                ,FACT.DURATION
                ,FACT.MEAS_UNIT AS VARIABLE_UNIT
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,CASE WHEN loc.LOCATION_GROUP_ABBREVIATION  = 'LINE East' 
                        THEN SUM(CAST(fact.MEAS_VALUE AS DECIMAL(30,15))) OVER (
                                    PARTITION BY loc.LOCATION_GROUP_ABBREVIATION
                                    ,FACT.SCENARIO
                                    ,FACT.PHASE
                                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                                )
                    ELSE MAX(CAST(fact.MEAS_VALUE AS DECIMAL(30,15))) OVER (
                                PARTITION BY loc.LOCATION_GROUP_ABBREVIATION
                                ,fact.scenario
                                ,fact.phase
                                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                            )
                END AS MAX_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_UE_VALUE FACT
            INNER JOIN DIM_CR_LOC_LOCATION_GROUP loc ON fact.DIM_LOCATION_GROUP_ID = loc.DIM_LOCATION_GROUP_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            WHERE variable.VARIABLE_NAME = 'Peak Load'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'	
                and loc.LOCATION_GROUP_ABBREVIATION in ('Oxagon', 'BLW', 
                                                        'GoA', 'LINE East', 'Trojena')
            )
        
        SELECT DISTINCT 
            CASE WHEN MEASUREMENT_ARTIFACTS = 'BLW' THEN 'Bay + LINE West'
                WHEN MEASUREMENT_ARTIFACTS = 'GoA' THEN 'Gulf of Aqaba'
                ELSE MEASUREMENT_ARTIFACTS
            END AS MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,'Peak Load' as VARIABLE
            ,DURATION
            ,MAX_MEAS_VALUE*0.968/1000 AS MEASUREMENT_VALUE
            ,'GW' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Supply Capacity' as VISUAL 
        FROM FINAL_CTE
    """

    peak_load_2 = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT ASSET.CATEGORY AS measurement_artifacts
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,VARIABLE.VARIABLE_NAME AS VARIABLE
                ,FACT.DURATION
                ,FACT.MEAS_UNIT AS VARIABLE_UNIT
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,SUM(FACT.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS TOTAL_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            LEFT JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            LEFT JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            WHERE variable.VARIABLE_NAME = 'Capacity'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'	
                AND SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', 1) = '01'
                and ASSET.CATEGORY in ('Wind', 'Temp GT', 'Interconnection', 'Permanent GT', 'PHS', 'LFP', 'PV')
            )
        
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,'Capacity' as VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE/1000 AS MEASUREMENT_VALUE
            ,'GW' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Supply Capacity' as VISUAL 
        FROM FINAL_CTE
    """


class CapacityFactor():
    cf = """
        WITH TOTAL_MEAS_VALUE_ENERGY_CTE AS (
            SELECT DISTINCT ASSET.CATEGORY AS measurement_artifacts
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,FACT.DURATION
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,SUM(
                    CASE 
                        WHEN ASSET.CATEGORY IN ('PV' ,'Wind') 
                            AND VARIABLE.VARIABLE_NAME in ('Generation' , 'Curtailment') 
                            THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                        WHEN ASSET.CATEGORY IN ('Permanent GT' ,'Temp GT') 
                            AND VARIABLE.VARIABLE_NAME in ('Generation') 
                            THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15))
                        ELSE 0
                    END
                ) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                ) / 1000000 AS TOTAL_MEAS_VALUE_ENERGY
                ,SUM(
                    CASE 
                        WHEN ASSET.CATEGORY IN ('Permanent GT' ,'Temp GT' ,'PV' ,'Wind') 
                            AND VARIABLE.VARIABLE_NAME in ('Capacity') 
                            AND SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', 1) = '01'
                            THEN CAST(fact.MEAS_VALUE AS DECIMAL(30,15)) ELSE 0 END
                ) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                ) / 1000 AS TOTAL_MEAS_VALUE_CAPACITY
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.meas_variable_id = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE VARIABLE.VARIABLE_NAME in ('Generation' , 'Curtailment', 'Capacity')
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY IN ('Permanent GT' ,'Temp GT' ,'PV' ,'Wind')
            )
        ,FINAL_CTE as (
        SELECT energy.MEASUREMENT_ARTIFACTS
            ,'Category' as MEASUREMENT_ARTIFACTS_TYPE
            ,energy.SUPPLY_CATEGORY
            ,energy.REGION
            ,energy.SUB_REGION
            ,'CF' as VARIABLE
            ,energy.DURATION
            ,case 
                when TOTAL_MEAS_VALUE_CAPACITY = 0 then null 
                else TOTAL_MEAS_VALUE_ENERGY / ((TOTAL_MEAS_VALUE_CAPACITY * 365 * 24)/1000)
            END AS MEASUREMENT_VALUE
            ,NULL as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,energy.MEAS_CAPTURE_YEAR AS YEAR
            ,energy.PHASE
            ,energy.SCENARIO
            ,'Capacity Factor' as VISUAL 
        FROM TOTAL_MEAS_VALUE_ENERGY_CTE energy 
        )
        SELECT * FROM FINAL_CTE WHERE MEASUREMENT_VALUE > 0.01 OR MEASUREMENT_VALUE IS NOT NULL
    """


class CapacityVsPeakDemand():
    capacity = """ 
        WITH final_cte AS (
            SELECT DISTINCT ASSET.CATEGORY AS MEASUREMENT_ARTIFACTS
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION                
                ,var.VARIABLE_NAME as VARIABLE
                ,FACT.DURATION
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,SUM(CAST(fact.MEAS_VALUE AS DECIMAL(30,15))) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                ) AS TOTAL_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            LEFT JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            LEFT JOIN DIM_EN_OP_MEAS_VARIABLE var ON fact.meas_variable_id = var.MEAS_VARIABLE_ID	
            WHERE var.VARIABLE_NAME = 'Capacity'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', 1) = '01'
        )   

        SELECT DISTINCT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,'GW' as VARIABLE_UNIT
            ,PHASE
            ,SCENARIO
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,TOTAL_MEAS_VALUE / 1000 AS MEASUREMENT_VALUE
            ,'Capacity Vs Peak Demand' as VISUAL
        FROM final_cte
    """

    peak_load = """
        WITH final_cte AS (
            SELECT DISTINCT 'Sum of Region' AS measurement_artifacts
                ,'Across ENOWA' AS MEASUREMENT_ARTIFACTS_TYPE
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.duration
                ,fact.MEAS_UNIT AS variable_unit
                ,fact.phase AS phase
                ,fact.scenario
                ,loc.LOCATION_GROUP_ABBREVIATION
                ,CASE WHEN loc.LOCATION_GROUP_ABBREVIATION  = 'LINE East' 
                        THEN SUM(CAST(fact.MEAS_VALUE AS DECIMAL(30,15))) OVER (
                                    PARTITION BY loc.LOCATION_GROUP_ABBREVIATION
                                    ,FACT.SCENARIO
                                    ,FACT.PHASE
                                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                                ) * 0.968/1000
                    ELSE MAX(CAST(fact.MEAS_VALUE AS DECIMAL(30,15))) OVER (
                                PARTITION BY loc.LOCATION_GROUP_ABBREVIATION
                                ,fact.scenario
                                ,fact.phase
                                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                            ) * 0.968/1000
                END AS MAX_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_UE_VALUE FACT
            INNER JOIN DIM_CR_LOC_LOCATION_GROUP loc ON fact.DIM_LOCATION_GROUP_ID = loc.DIM_LOCATION_GROUP_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            WHERE variable.VARIABLE_NAME = 'Peak Load'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND loc.LOCATION_GROUP_ABBREVIATION in ('BLW', 'GoA', 'LINE East', 'Oxagon', 'Trojena')
        )             
        
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,NULL as SUPPLY_CATEGORY
            ,NULL AS REGION
            ,NULL AS SUB_REGION
            ,VARIABLE
            ,DURATION
            ,SUM(MAX_MEAS_VALUE) AS MEASUREMENT_VALUE
            ,'GW' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Capacity Vs Peak Demand' as VISUAL
        FROM FINAL_CTE
        GROUP BY measurement_artifacts
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,VARIABLE
            ,DURATION
            ,VARIABLE_UNIT
            ,PHASE
            ,SCENARIO
            ,MEAS_CAPTURE_YEAR
    """


class SiteSpecificCapacity():
    capacity = """
    WITH final_cte AS (
        SELECT DISTINCT ASSET.ASSET_NAME AS MEASUREMENT_ARTIFACTS
            ,'Asset' AS MEASUREMENT_ARTIFACTS_TYPE
            ,ASSET.CATEGORY as SUPPLY_CATEGORY
            ,ASSET.REGION AS REGION
            ,ASSET.SUB_REGION AS SUB_REGION
            ,variable.VARIABLE_NAME as VARIABLE
            ,FACT.DURATION
            ,FACT.PHASE AS PHASE
            ,FACT.SCENARIO
            ,MAX(CAST(fact.MEAS_VALUE AS DECIMAL(30,15))) OVER (
                PARTITION BY ASSET.ASSET_NAME
                ,FACT.SCENARIO
                ,FACT.PHASE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                ) AS max_meas_value
            ,fact.PATHWAY_NAME
            ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
        FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
        LEFT JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
        LEFT JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
        WHERE variable.VARIABLE_NAME = 'Capacity'
            AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
            AND SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', 1) = '01'
        )
    
    SELECT MEASUREMENT_ARTIFACTS
        ,MEASUREMENT_ARTIFACTS_TYPE
        ,SUPPLY_CATEGORY
        ,REGION
        ,SUB_REGION
        ,VARIABLE
        ,DURATION
        ,'MW' as VARIABLE_UNIT
        ,PHASE
        ,SCENARIO
        ,NULL AS HOUR
        ,NULL AS MONTH
        ,MEAS_CAPTURE_YEAR AS YEAR
        ,sum(max_meas_value) AS MEASUREMENT_VALUE
        ,'Site Specific Capacity' as VISUAL
    FROM final_cte
    GROUP BY MEASUREMENT_ARTIFACTS
        ,MEASUREMENT_ARTIFACTS_TYPE
        ,SUPPLY_CATEGORY
        ,REGION
        ,SUB_REGION
        ,VARIABLE
        ,DURATION
        ,PHASE
        ,SCENARIO
        ,MEAS_CAPTURE_YEAR
    """


class KsaInterconnectInterconnection():
    capacity = """
        WITH final_cte AS (
            SELECT DISTINCT ASSET.ASSET_NAME AS MEASUREMENT_ARTIFACTS
                ,'Asset' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.duration
                ,fact.MEAS_UNIT AS variable_unit
                ,fact.phase AS phase
                ,fact.scenario
                ,fact.MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            LEFT JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            LEFT JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            WHERE variable.VARIABLE_NAME = 'Capacity'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY = 'Interconnection'
                AND SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', 1) = '01'
            )

        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,MEAS_VALUE/1000 AS MEASUREMENT_VALUE
            ,'GW' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'KSA Interconnect Interconnection' as VISUAL 
        FROM FINAL_CTE
    """


class KsaInterconnectExportImport():
    generation = """
        WITH final_cte AS (
            SELECT DISTINCT ASSET.CATEGORY AS MEASUREMENT_ARTIFACTS
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,VARIABLE.VARIABLE_NAME AS VARIABLE
                ,VARIABLE.VARIABLE_NAME
                ,FACT.DURATION
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.CATEGORY, fact.scenario
                    ,fact.phase
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS TOTAL_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            LEFT JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            LEFT JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            WHERE variable.VARIABLE_NAME = 'Generation'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY = 'KSA Import'
        )

        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE/1000000 AS MEASUREMENT_VALUE
            ,'GW' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'KSA Interconnect Export Import' as VISUAL 
        FROM FINAL_CTE
    """

    load = """
        WITH final_cte AS (
            SELECT DISTINCT ASSET.CATEGORY AS MEASUREMENT_ARTIFACTS
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,variable.VARIABLE_NAME
                ,fact.duration
                ,fact.MEAS_UNIT AS variable_unit
                ,fact.phase AS phase
                ,fact.scenario
                ,sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.CATEGORY, fact.scenario
                    ,fact.phase
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS TOTAL_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            LEFT JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            LEFT JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            WHERE variable.VARIABLE_NAME = 'Load'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY = 'KSA Export'
        )

        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE/1000000 AS MEASUREMENT_VALUE
            ,'GW' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'KSA Interconnect Export Import' as VISUAL 
        FROM FINAL_CTE
    """


class Emission():
    emission_query = """
        WITH final_cte AS (
            SELECT DISTINCT CATEGORY.SUP_CATEGORY_NAME AS MEASUREMENT_ARTIFACTS
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,CATEGORY.SUP_CATEGORY_NAME as SUPPLY_CATEGORY
                ,NULL AS REGION
                ,NULL AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.duration
                ,fact.phase AS phase
                ,fact.scenario
                ,sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY CATEGORY.SUP_CATEGORY_NAME, fact.scenario
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS TOTAL_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN DIM_CR_ASS_ASSET ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_ASS_SUP_CATEGORY CATEGORY ON ASSET.SUP_CATEGORY_ID = CATEGORY.SUP_CATEGORY_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
				ON SOURCE.SCENARIO = FACT.SCENARIO 
				AND SOURCE.PHASE = FACT.PHASE
				AND SOURCE.RANK is not null
            WHERE variable.VARIABLE_NAME = 'Emission'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
        )
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE/1000000 AS MEASUREMENT_VALUE
            ,'Mt CO2-e' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Emission' as VISUAL 
        FROM FINAL_CTE
    """


class FuelOfftake():
    fuel_offtake = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT ASSET.CATEGORY AS MEASUREMENT_ARTIFACTS
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,VARIABLE.VARIABLE_NAME
                ,FACT.DURATION
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.phase AS phase
                ,fact.scenario
                ,sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.CATEGORY, FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS TOTAL_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
			INNER JOIN SOURCE_SOURCE SOURCE 
				ON SOURCE.SCENARIO = FACT.SCENARIO 
				AND SOURCE.PHASE = FACT.PHASE
				AND SOURCE.RANK is not null
            WHERE variable.VARIABLE_NAME = 'Fuel Offtake'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
            )
        
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE AS MEASUREMENT_VALUE
            ,'MMBtu' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Fuel Offtake' as VISUAL	
        FROM FINAL_CTE
    """


class KsaInterconnectFlowExportImport():
    generation = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT ASSET.CATEGORY AS MEASUREMENT_ARTIFACTS
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.duration
                ,fact.MEAS_UNIT AS variable_unit
                ,fact.phase AS phase
                ,fact.scenario
                ,sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY fact.scenario
                    ,fact.phase
                    ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyyMM')
                    ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm')
                    ) AS TOTAL_MEAS_VALUE
                ,FACT.MEAS_CAPTURE_DATETIME AS MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
				ON SOURCE.SCENARIO = FACT.SCENARIO 
				AND SOURCE.PHASE = FACT.PHASE
				AND SOURCE.RANK is not null
            WHERE variable.VARIABLE_NAME = 'Generation'
                AND fact.MEAS_FREQUENCY = 'Hourly Avg Of A Day'
                AND ASSET.CATEGORY = 'KSA Import'
            )
        
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE AS MEASUREMENT_VALUE
            ,'MW' as VARIABLE_UNIT
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm') AS HOUR
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'MM') AS MONTH
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyy') AS YEAR
            ,PHASE
            ,SCENARIO
            ,'KSA Interconnect Flow Export Import' as VISUAL 
        FROM FINAL_CTE
    """

    load = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT ASSET.CATEGORY AS MEASUREMENT_ARTIFACTS
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY AS SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,VARIABLE.VARIABLE_NAME AS VARIABLE
                ,FACT.DURATION
                ,FACT.MEAS_UNIT AS VARIABLE_UNIT
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,SUM(FACT.MEAS_VALUE) OVER (
                    PARTITION BY FACT.SCENARIO
                    ,FACT.PHASE
                    ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyyMM')
                    ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm')
                    ) AS TOTAL_MEAS_VALUE
                ,FACT.MEAS_CAPTURE_DATETIME AS MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
				ON SOURCE.SCENARIO = FACT.SCENARIO 
				AND SOURCE.PHASE = FACT.PHASE
				AND SOURCE.RANK is not null
            WHERE variable.VARIABLE_NAME = 'Load'
                AND fact.MEAS_FREQUENCY = 'Hourly Avg Of A Day'
                AND ASSET.CATEGORY = 'KSA Export'
            )
        
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE AS MEASUREMENT_VALUE
            ,'MW' as VARIABLE_UNIT
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm') AS HOUR
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'MM') AS MONTH
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyy') AS YEAR
            ,PHASE
            ,SCENARIO
            ,'KSA Interconnect Flow Export Import' as VISUAL 
        FROM FINAL_CTE
    """


class KsaInterconnectFlow():
    flow = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT ASSET.ASSET_NAME AS MEASUREMENT_ARTIFACTS
                ,'Asset' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY AS SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,VARIABLE.VARIABLE_NAME AS VARIABLE
                ,FACT.DURATION
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,FACT.MEAS_VALUE
                ,FACT.MEAS_CAPTURE_DATETIME AS MEAS_CAPTURE_DATETIME
            FROM fact_en_eve_model_opd_value fact
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
				ON SOURCE.SCENARIO = FACT.SCENARIO 
				AND SOURCE.PHASE = FACT.PHASE
				AND SOURCE.RANK is not null
            WHERE variable.VARIABLE_NAME = 'Flow'
                AND fact.MEAS_FREQUENCY = 'Hourly Avg Of A Day'
            )
        
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,MEAS_VALUE AS MEASUREMENT_VALUE
            ,'MW' as VARIABLE_UNIT
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm') AS HOUR
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'MM') AS MONTH
            ,date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyy') AS YEAR
            ,PHASE
            ,SCENARIO
            ,'KSA Interconnect Flow' as VISUAL 	
        FROM final_cte
    """


class SupplyBalanceEnergyMix():
    generation_output_1 = """
        WITH KSA_IMPORT_CTE AS (
            SELECT DISTINCT ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,fact.duration
                ,fact.phase AS phase
                ,fact.scenario
                ,sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,fact.scenario
                    ,fact.phase
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS total_meas_value
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
            LEFT JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
            LEFT JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID	
            WHERE variable.VARIABLE_NAME = 'Generation'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY = 'KSA Import'		
            )
        ,KSA_EXPORT_CTE AS (
            SELECT DISTINCT FACT.DURATION
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,SUM(FACT.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS TOTAL_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
            LEFT JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
            LEFT JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID	
            WHERE variable.VARIABLE_NAME = 'Load'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY = 'KSA Export'		
            )
        
        SELECT 'KSA Import' as measurement_artifacts
            ,'Category' as MEASUREMENT_ARTIFACTS_TYPE	
            ,'KSA Import' as SUPPLY_CATEGORY
            ,KSA_IMPORT_CTE.REGION
            ,KSA_IMPORT_CTE.SUB_REGION
            ,'Generation Output' AS VARIABLE
            ,KSA_IMPORT_CTE.DURATION
            ,(KSA_IMPORT_CTE.TOTAL_MEAS_VALUE - KSA_EXPORT_CTE.TOTAL_MEAS_VALUE)/1000000 AS MEASUREMENT_VALUE
            ,'TWh' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,KSA_IMPORT_CTE.MEAS_CAPTURE_YEAR AS YEAR
            ,KSA_IMPORT_CTE.PHASE
            ,KSA_IMPORT_CTE.SCENARIO
            , 'Supply Balance Energy Mix' as Visual	
        FROM KSA_IMPORT_CTE INNER JOIN KSA_EXPORT_CTE	
        ON KSA_IMPORT_CTE.SCENARIO = KSA_EXPORT_CTE.SCENARIO
        AND KSA_IMPORT_CTE.PHASE = KSA_EXPORT_CTE.PHASE
        AND KSA_IMPORT_CTE.MEAS_CAPTURE_YEAR = KSA_EXPORT_CTE.MEAS_CAPTURE_YEAR
    """

    generation_output_2 = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                ASSET.CATEGORY AS measurement_artifacts
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY AS SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,VARIABLE.VARIABLE_NAME AS VARIABLE
                ,FACT.DURATION
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,SUM(FACT.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,FACT.SCENARIO
                    ,FACT.PHASE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS TOTAL_MEAS_VALUE
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM fact_en_eve_model_opd_value fact
            LEFT JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
            LEFT JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID	
            WHERE variable.VARIABLE_NAME = 'Generation'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND ASSET.CATEGORY in ('Permanent GT', 'PV', 'Temp GT', 'Wind')
            )
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,TOTAL_MEAS_VALUE / 1000000 AS MEASUREMENT_VALUE
            ,'TWh' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Supply Balance Energy Mix' as VISUAL 	
        FROM final_cte
    """

    generation_output_3 = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                CASE WHEN ASSET.CATEGORY = 'PV' then 'PV Curtailed'
                    WHEN ASSET.CATEGORY = 'Wind' then 'Wind Curtailed' 
                END AS measurement_artifacts
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.duration
                ,fact.phase AS phase
                ,fact.scenario
                ,sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,fact.scenario
                    ,fact.phase
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS total_meas_value
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM fact_en_eve_model_opd_value fact
            LEFT JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
            LEFT JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID	
            WHERE variable.VARIABLE_NAME = 'Curtailment'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
            )
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,total_meas_value / 1000000 AS MEASUREMENT_VALUE
            ,'TWh' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Supply Balance Energy Mix' as VISUAL 	
        FROM final_cte
    """

    demand = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 'Sum of Region' AS measurement_artifacts
                ,'Across ENOWA' AS MEASUREMENT_ARTIFACTS_TYPE
                ,VARIABLE.VARIABLE_NAME AS VARIABLE
                ,FACT.DURATION
                ,FACT.MEAS_UNIT AS VARIABLE_UNIT
                ,FACT.PHASE AS PHASE
                ,FACT.SCENARIO
                ,loc.LOCATION_GROUP_ABBREVIATION
                ,sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY loc.LOCATION_GROUP_ABBREVIATION
                    ,fact.scenario
                    ,fact.phase
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS total_meas_value
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM FACT_EN_EVE_MODEL_OPD_UE_VALUE FACT
            INNER JOIN DIM_CR_LOC_LOCATION_GROUP loc ON fact.DIM_LOCATION_GROUP_ID = loc.DIM_LOCATION_GROUP_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
            WHERE variable.VARIABLE_NAME = 'Load'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND loc.LOCATION_GROUP_ABBREVIATION in ('BLW', 'GoA', 'LINE East', 'Oxagon', 'Trojena')
        )             
        
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,NULL as SUPPLY_CATEGORY
            ,MEASUREMENT_ARTIFACTS AS REGION
            ,NULL AS SUB_REGION
            ,'Demand' AS VARIABLE
            ,DURATION
            ,SUM(TOTAL_MEAS_VALUE)*0.968 / 1000000 AS MEASUREMENT_VALUE
            ,'TW' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Supply Balance Energy Mix' as VISUAL
        FROM FINAL_CTE
        GROUP BY measurement_artifacts
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,VARIABLE
            ,DURATION
            ,VARIABLE_UNIT
            ,PHASE
            ,SCENARIO
            ,MEAS_CAPTURE_YEAR
    """

class SupplyBalanceEnergyMixDrilldown():
    ksaNetImport = """
        WITH gen_cte AS (
    SELECT  DISTINCT
        asset.CATEGORY AS measurement_artifacts,
        'Category' AS MEASUREMENT_ARTIFACTS_TYPE,
        asset.CATEGORY AS SUPPLY_CATEGORY,
        'all' AS REGION,
        NULL AS SUB_REGION,
        'Generation' AS VARIABLE,
        fact.duration,
        fact.phase AS phase,
        fact.scenario,
        SUM(CAST(fact.MEAS_VALUE AS DOUBLE)) OVER (
            PARTITION BY asset.CATEGORY, fact.scenario, fact.phase, 
            REGEXP_EXTRACT(TRIM(MEAS_CAPTURE_DATETIME), '/([^/]+)$', 1)
        ) AS meas_val,
        REGEXP_EXTRACT(TRIM(MEAS_CAPTURE_DATETIME), '/([^/]+)$', 1) AS Year
    FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
    INNER JOIN ASSET_CTE asset 
        ON fact.dim_asset_id = asset.dim_asset_id
    INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable 
        ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
    WHERE 
        variable.VARIABLE_NAME = 'Generation'
        AND asset.CATEGORY = 'KSA Import'
        AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
    ),
    load_cte AS (
        SELECT  DISTINCT
            asset.CATEGORY AS measurement_artifacts,
            'Category' AS MEASUREMENT_ARTIFACTS_TYPE,
            asset.CATEGORY AS SUPPLY_CATEGORY,
            'all' AS REGION,
            NULL AS SUB_REGION,
            'Load' AS VARIABLE,
            fact.duration,
            fact.phase AS phase,
            fact.scenario,
            SUM(CAST(fact.MEAS_VALUE AS DOUBLE)) OVER (
                PARTITION BY asset.CATEGORY, fact.scenario, fact.phase, 
                REGEXP_EXTRACT(TRIM(MEAS_CAPTURE_DATETIME), '/([^/]+)$', 1)
            ) AS meas_val,
            REGEXP_EXTRACT(TRIM(MEAS_CAPTURE_DATETIME), '/([^/]+)$', 1) AS Year
        FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
        INNER JOIN ASSET_CTE asset 
            ON fact.dim_asset_id = asset.dim_asset_id
        INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable 
            ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
        WHERE 
            variable.VARIABLE_NAME = 'Load'
            AND asset.CATEGORY = 'KSA Export'
            AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
    ),
    join_cte AS (
        SELECT DISTINCT
            'KSA Net-Import' AS Measurement_Artifacts, 
            'KSA Net-Import' AS SUPPLY_CATEGORY,
            g.REGION,
            g.scenario,
            g.phase,
            g.Year,
            g.meas_val AS ksaimport,
            l.meas_val AS ksaexport
        FROM gen_cte g 
        INNER JOIN load_cte l
            ON g.Year = l.Year
            AND g.REGION = l.REGION
            AND g.scenario = l.scenario
            AND g.phase = l.phase
    ),
    adjust_cte AS (
        SELECT DISTINCT
            j.Measurement_Artifacts AS MEASUREMENT_ARTIFACTS,
            'Category' AS MEASUREMENT_ARTIFACTS_TYPE,
            j.SUPPLY_CATEGORY,
            j.REGION,
            NULL AS SUB_REGION,
            'Supply' AS VARIABLE,
            '' AS DURATION,
            GREATEST(CAST((j.ksaimport - j.ksaexport)/1000000 AS DECIMAL(28,6)),0) AS MEASUREMENT_VALUE,
            '' AS VARIABLE_UNIT,
            NULL AS HOUR,
            NULL AS MONTH,
            j.Year AS YEAR,
            j.phase AS PHASE,
            j.scenario AS SCENARIO,
            'Supply Balance Energy Mix DrillDown' AS VISUAL
        FROM join_cte j
    )
    SELECT * FROM adjust_cte;

    """

    locLoad = """
    WITH FINAL_CTE AS (
    SELECT  
        loc.LOCATION_GROUP_ABBREVIATION AS measurement_artifacts,
        'Location Group Abbreviation' AS MEASUREMENT_ARTIFACTS_TYPE,
        VARIABLE.VARIABLE_NAME AS VARIABLE,
        FACT.DURATION,
        FACT.MEAS_UNIT AS VARIABLE_UNIT,
        FACT.PHASE AS PHASE,
        FACT.SCENARIO,
        loc.LOCATION_GROUP_ABBREVIATION,
       /* SUM(CAST(fact.MEAS_VALUE AS DOUBLE)) OVER (
            PARTITION BY loc.LOCATION_GROUP_ABBREVIATION,
                         fact.scenario,
                         fact.phase,
                         REGEXP_EXTRACT(TRIM(MEAS_CAPTURE_DATETIME), '/([^/]+)$', 1)
        ) AS total_meas_value,*/

        CAST(fact.MEAS_VALUE AS DOUBLE) AS total_meas_value,
        REGEXP_EXTRACT(TRIM(MEAS_CAPTURE_DATETIME), '/([^/]+)$', 1) AS MEAS_CAPTURE_YEAR
    FROM FACT_EN_EVE_MODEL_OPD_UE_VALUE FACT
    INNER JOIN DIM_CR_LOC_LOCATION_GROUP loc 
        ON fact.DIM_LOCATION_GROUP_ID = loc.DIM_LOCATION_GROUP_ID
    INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable 
        ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
    WHERE variable.VARIABLE_NAME = 'Load'
        AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
        AND loc.LOCATION_GROUP_ABBREVIATION IN ('BLW', 'GoA', 'LINE East', 'OXAGON', 'Trojena')
    )
    , CTE2 AS (
        SELECT 
            MEASUREMENT_ARTIFACTS,
            MEASUREMENT_ARTIFACTS_TYPE,
            NULL AS SUPPLY_CATEGORY,
            MEASUREMENT_ARTIFACTS AS REGION,
            NULL AS SUB_REGION,
            'Demand' AS VARIABLE,
            DURATION,
            SUM(TOTAL_MEAS_VALUE) * 0.968 / 1000000 AS MEASUREMENT_VALUE,
            'TW' AS VARIABLE_UNIT,
            NULL AS HOUR,
            NULL AS MONTH,
            MEAS_CAPTURE_YEAR AS YEAR,
            PHASE,
            SCENARIO,
            'Supply Balance Energy Mix DrillDown' AS VISUAL
        FROM FINAL_CTE
        GROUP BY 
            MEASUREMENT_ARTIFACTS,
            MEASUREMENT_ARTIFACTS_TYPE,
            VARIABLE,
            DURATION,
            VARIABLE_UNIT,
            PHASE,
            SCENARIO,
            MEAS_CAPTURE_YEAR
    )
    
    SELECT * FROM CTE2
    """

    locGeneration = """
            WITH FINAL_CTE AS (
                SELECT DISTINCT 
                    ASSET.CATEGORY AS measurement_artifacts
                    ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                    ,ASSET.CATEGORY AS SUPPLY_CATEGORY
                    ,ASSET.REGION AS REGION
                    ,ASSET.SUB_REGION AS SUB_REGION
                    ,FACT.DURATION
                    ,FACT.PHASE AS PHASE
                    ,FACT.SCENARIO
                    ,SUM(FACT.MEAS_VALUE) OVER (
                        PARTITION BY ASSET.CATEGORY
                        ,FACT.SCENARIO
                        ,FACT.PHASE
                        ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                        ) AS TOTAL_MEAS_VALUE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
                FROM fact_en_eve_model_opd_value fact
                LEFT JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
                LEFT JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID	
                WHERE variable.VARIABLE_NAME = 'Generation'
                    AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                    AND ASSET.CATEGORY in ( 'Permanent GT', 'PV', 'Temp GT', 'Wind','LFP','PHS')
                )
            SELECT MEASUREMENT_ARTIFACTS
                ,MEASUREMENT_ARTIFACTS_TYPE
                ,SUPPLY_CATEGORY
                ,REGION
                ,SUB_REGION
                ,'Supply' AS VARIABLE
                ,DURATION
                ,TOTAL_MEAS_VALUE / 1000000 AS MEASUREMENT_VALUE
                ,'TWh' as VARIABLE_UNIT
                ,NULL AS HOUR
                ,NULL AS MONTH
                ,MEAS_CAPTURE_YEAR AS YEAR
                ,PHASE
                ,SCENARIO
                ,'Supply Balance Energy Mix DrillDown' as VISUAL 	
            FROM final_cte
        """
    LfpPhs = """
            WITH FINAL_CTE AS (
                SELECT DISTINCT 
                    ASSET.CATEGORY AS measurement_artifacts
                    ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                    ,ASSET.CATEGORY AS SUPPLY_CATEGORY
                    ,ASSET.REGION AS REGION
                    ,ASSET.SUB_REGION AS SUB_REGION
                    ,FACT.DURATION
                    ,FACT.PHASE AS PHASE
                    ,FACT.SCENARIO
                    ,SUM(FACT.MEAS_VALUE) OVER (
                        PARTITION BY ASSET.CATEGORY
                        ,FACT.SCENARIO
                        ,FACT.PHASE
                        ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                        ) AS TOTAL_MEAS_VALUE
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
                FROM fact_en_eve_model_opd_value fact
                LEFT JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
                LEFT JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID	
                WHERE variable.VARIABLE_NAME = 'Load'
                    AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                    AND ASSET.CATEGORY in ( 'LFP','PHS')
                )
            SELECT MEASUREMENT_ARTIFACTS
                ,MEASUREMENT_ARTIFACTS_TYPE
                ,SUPPLY_CATEGORY
                ,REGION
                ,SUB_REGION
                ,'Demand' AS VARIABLE
                ,DURATION
                ,TOTAL_MEAS_VALUE / 1000000 AS MEASUREMENT_VALUE
                ,'TWh' as VARIABLE_UNIT
                ,NULL AS HOUR
                ,NULL AS MONTH
                ,MEAS_CAPTURE_YEAR AS YEAR
                ,PHASE
                ,SCENARIO
                ,'Supply Balance Energy Mix DrillDown' as VISUAL 	
            FROM final_cte
        """

    curtailment = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                CASE WHEN ASSET.CATEGORY = 'PV' then 'PV Curtailed'
                    WHEN ASSET.CATEGORY = 'Wind' then 'Wind Curtailed' 
                END AS measurement_artifacts
                ,'Category' AS MEASUREMENT_ARTIFACTS_TYPE
                ,ASSET.CATEGORY as SUPPLY_CATEGORY
                ,ASSET.REGION AS REGION
                ,ASSET.SUB_REGION AS SUB_REGION
                ,variable.VARIABLE_NAME as VARIABLE
                ,fact.duration
                ,fact.phase AS phase
                ,fact.scenario
                ,sum(fact.MEAS_VALUE) OVER (
                    PARTITION BY ASSET.CATEGORY
                    ,fact.scenario
                    ,fact.phase
                    ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1)
                    ) AS total_meas_value
                ,SUBSTRING_INDEX(TRIM(MEAS_CAPTURE_DATETIME), '/', -1) AS MEAS_CAPTURE_YEAR
            FROM fact_en_eve_model_opd_value fact
            LEFT JOIN ASSET_CTE asset ON fact.dim_asset_id = asset.dim_asset_id
            LEFT JOIN DIM_EN_OP_MEAS_VARIABLE variable ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID	
            WHERE variable.VARIABLE_NAME = 'Curtailment'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
            )
        SELECT MEASUREMENT_ARTIFACTS
            ,MEASUREMENT_ARTIFACTS_TYPE
            ,SUPPLY_CATEGORY
            ,REGION
            ,SUB_REGION
            ,VARIABLE
            ,DURATION
            ,total_meas_value / 1000000 AS MEASUREMENT_VALUE
            ,'TWh' as VARIABLE_UNIT
            ,NULL AS HOUR
            ,NULL AS MONTH
            ,MEAS_CAPTURE_YEAR AS YEAR
            ,PHASE
            ,SCENARIO
            ,'Supply Balance Energy Mix DrillDown' as VISUAL 	
        FROM final_cte
    """

    unservedEnergy = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                'Unserved Energy' AS measurement_artifacts,
                'Asset' AS MEASUREMENT_ARTIFACTS_TYPE,
                ASSET.CATEGORY AS SUPPLY_CATEGORY,
                ASSET.REGION AS REGION,
                ASSET.SUB_REGION AS SUB_REGION,
                variable.VARIABLE_NAME AS VARIABLE,
                FACT.MEAS_UNIT AS VARIABLE_UNIT,
                FACT.DURATION,
                FACT.PHASE AS PHASE,
                FACT.SCENARIO,
                fact.MEAS_VALUE AS TOTAL_MEAS_VALUE,
                MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Unserved Energy'
                AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month'
                AND FACT.DURATION_TYPE = 'LOAD DURATION'
        )
        SELECT 
            measurement_artifacts,
            MEASUREMENT_ARTIFACTS_TYPE,
            SUPPLY_CATEGORY,
            REGION,
            SUB_REGION,
            VARIABLE,
            DURATION,
            (TOTAL_MEAS_VALUE) as MEASUREMENT_VALUE,
            VARIABLE_UNIT,
            NULL AS HOUR,
            NULL AS MONTH,
            MEAS_CAPTURE_DATETIME AS YEAR,
            PHASE,
            SCENARIO,
            'Supply Balance Energy Mix DrillDown'  AS VISUAL
        FROM FINAL_CTE;
        """

    ksaImport="""SELECT  DISTINCT
        asset.CATEGORY AS measurement_artifacts,
        'Category' AS MEASUREMENT_ARTIFACTS_TYPE,
        asset.CATEGORY AS SUPPLY_CATEGORY,
        'all' AS REGION,
        NULL AS SUB_REGION,
        'Generation' AS VARIABLE,
        fact.duration,
        SUM(CAST(fact.MEAS_VALUE AS DOUBLE)) OVER (
            PARTITION BY asset.CATEGORY, fact.scenario, fact.phase, 
            REGEXP_EXTRACT(TRIM(MEAS_CAPTURE_DATETIME), '/([^/]+)$', 1)
        )/1000000 AS MEASUREMENT_VALUE,
        '' as VARIABLE_UNIT,
            NULL AS HOUR,
            NULL AS MONTH,
            REGEXP_EXTRACT(TRIM(MEAS_CAPTURE_DATETIME), '/([^/]+)$', 1) AS Year,
        fact.phase AS phase,
        fact.scenario,
        'Supply Balance Energy Mix DrillDown'  AS VISUAL
    FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
    INNER JOIN ASSET_CTE asset 
        ON fact.dim_asset_id = asset.dim_asset_id
    INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable 
        ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
    WHERE 
        variable.VARIABLE_NAME = 'Generation'
        AND asset.CATEGORY = 'KSA Import'
        AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month' """   



    ksaExport="""SELECT  DISTINCT
            asset.CATEGORY AS measurement_artifacts,
            'Category' AS MEASUREMENT_ARTIFACTS_TYPE,
            asset.CATEGORY AS SUPPLY_CATEGORY,
            'all' AS REGION,
            NULL AS SUB_REGION,
            'Load' AS VARIABLE,
            fact.duration,
            SUM(CAST(fact.MEAS_VALUE AS DOUBLE)) OVER (
                PARTITION BY asset.CATEGORY, fact.scenario, fact.phase, 
                REGEXP_EXTRACT(TRIM(MEAS_CAPTURE_DATETIME), '/([^/]+)$', 1)
            )/1000000 AS MEASUREMENT_VALUE,
            '' as VARIABLE_UNIT,
                NULL AS HOUR,
                NULL AS MONTH,
                REGEXP_EXTRACT(TRIM(MEAS_CAPTURE_DATETIME), '/([^/]+)$', 1) AS Year,
            fact.phase AS phase,
            fact.scenario,
            'Supply Balance Energy Mix DrillDown'  AS VISUAL
        FROM FACT_EN_EVE_MODEL_OPD_VALUE fact
        INNER JOIN ASSET_CTE asset 
            ON fact.dim_asset_id = asset.dim_asset_id
        INNER JOIN DIM_EN_OP_MEAS_VARIABLE variable 
            ON fact.meas_variable_id = variable.MEAS_VARIABLE_ID
        WHERE 
            variable.VARIABLE_NAME = 'Load'
            AND asset.CATEGORY = 'KSA Export'
            AND fact.MEAS_FREQUENCY = 'Daily Avg Of A Month' """ 

class IntradayPrice():
    load = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                CASE 
                    WHEN ASSET.CATEGORY IN ('LFP', 'PHS') 
                        THEN CONCAT(ASSET.CATEGORY, ' ', variable.VARIABLE_NAME)
                    ELSE ASSET.CATEGORY
                END AS measurement_artifacts,
                'Asset' AS MEASUREMENT_ARTIFACTS_TYPE,
                ASSET.CATEGORY AS SUPPLY_CATEGORY,
                ASSET.REGION AS REGION,
                ASSET.SUB_REGION AS SUB_REGION,
                variable.VARIABLE_NAME AS VARIABLE,
                FACT.MEAS_UNIT AS VARIABLE_UNIT,
                FACT.DURATION,
                FACT.PHASE AS PHASE,
                FACT.SCENARIO,
                fact.MEAS_VALUE AS TOTAL_MEAS_VALUE,
                MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Load'
                AND fact.MEAS_FREQUENCY = 'Hourly Avg Of A Day'
                AND ASSET.CATEGORY in ('KSA Export', 'LFP', 'PHS')
        )
        SELECT 
            measurement_artifacts,
            MEASUREMENT_ARTIFACTS_TYPE,
            SUPPLY_CATEGORY,
            REGION,
            SUB_REGION,
            VARIABLE,
            DURATION,
            (TOTAL_MEAS_VALUE)*-1 as MEASUREMENT_VALUE,
            VARIABLE_UNIT,
            date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm') AS HOUR,
            date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'MM') AS MONTH,
            date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyy') AS YEAR,
            PHASE,
            SCENARIO,
            'Intraday Price' AS VISUAL
        FROM FINAL_CTE;
        """
    
    generation = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                ASSET.CATEGORY AS measurement_artifacts,
                'Asset' AS MEASUREMENT_ARTIFACTS_TYPE,
                ASSET.CATEGORY AS SUPPLY_CATEGORY,
                ASSET.REGION AS REGION,
                ASSET.SUB_REGION AS SUB_REGION,
                variable.VARIABLE_NAME AS VARIABLE,
                FACT.MEAS_UNIT AS VARIABLE_UNIT,
                FACT.DURATION,
                FACT.PHASE AS PHASE,
                FACT.SCENARIO,
                fact.MEAS_VALUE AS TOTAL_MEAS_VALUE,
                MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Generation'
                AND fact.MEAS_FREQUENCY = 'Hourly Avg Of A Day'
                AND ASSET.CATEGORY in 
                ('KSA Import', 'LFP', 'PHS', 'Permanent GT', 'PV', 'Temp GT','Wind')
        )
        SELECT 
            measurement_artifacts,
            MEASUREMENT_ARTIFACTS_TYPE,
            SUPPLY_CATEGORY,
            REGION,
            SUB_REGION,
            VARIABLE,
            DURATION,
            (TOTAL_MEAS_VALUE) as MEASUREMENT_VALUE,
            VARIABLE_UNIT,
            date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm') AS HOUR,
            date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'MM') AS MONTH,
            date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyy') AS YEAR,
            PHASE,
            SCENARIO,
            'Intraday Price' AS VISUAL
        FROM FINAL_CTE;
        """
    
    curtailment = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                CONCAT(ASSET.CATEGORY, ' Curtailed') as measurement_artifacts,
                'Asset' AS MEASUREMENT_ARTIFACTS_TYPE,
                ASSET.CATEGORY AS SUPPLY_CATEGORY,
                ASSET.REGION AS REGION,
                ASSET.SUB_REGION AS SUB_REGION,
                variable.VARIABLE_NAME AS VARIABLE,
                FACT.MEAS_UNIT AS VARIABLE_UNIT,
                FACT.DURATION,
                FACT.PHASE AS PHASE,
                FACT.SCENARIO,
                fact.MEAS_VALUE AS TOTAL_MEAS_VALUE,
                MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Curtailment'
                AND fact.MEAS_FREQUENCY = 'Hourly Avg Of A Day'
                AND ASSET.CATEGORY in 
                ('PV', 'Wind')
        )
        SELECT 
            measurement_artifacts,
            MEASUREMENT_ARTIFACTS_TYPE,
            SUPPLY_CATEGORY,
            REGION,
            SUB_REGION,
            VARIABLE,
            DURATION,
            (TOTAL_MEAS_VALUE) as MEASUREMENT_VALUE,
            VARIABLE_UNIT,
            date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm') AS HOUR,
            date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'MM') AS MONTH,
            date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyy') AS YEAR,
            PHASE,
            SCENARIO,
            'Intraday Price' AS VISUAL
        FROM FINAL_CTE;
        """

    unserved_energy = """
        WITH FINAL_CTE AS (
            SELECT DISTINCT 
                'Unserved Energy' AS measurement_artifacts,
                'Asset' AS MEASUREMENT_ARTIFACTS_TYPE,
                ASSET.CATEGORY AS SUPPLY_CATEGORY,
                ASSET.REGION AS REGION,
                ASSET.SUB_REGION AS SUB_REGION,
                variable.VARIABLE_NAME AS VARIABLE,
                FACT.MEAS_UNIT AS VARIABLE_UNIT,
                FACT.DURATION,
                FACT.PHASE AS PHASE,
                FACT.SCENARIO,
                fact.MEAS_VALUE AS TOTAL_MEAS_VALUE,
                MEAS_CAPTURE_DATETIME
            FROM FACT_EN_EVE_MODEL_OPD_VALUE FACT
            INNER JOIN ASSET_CTE ASSET ON FACT.DIM_ASSET_ID = ASSET.DIM_ASSET_ID
            INNER JOIN DIM_EN_OP_MEAS_VARIABLE VARIABLE ON FACT.MEAS_VARIABLE_ID = VARIABLE.MEAS_VARIABLE_ID
            INNER JOIN SOURCE_SOURCE SOURCE 
                ON SOURCE.SCENARIO = FACT.SCENARIO 
                AND SOURCE.PHASE = FACT.PHASE 
                AND SOURCE.RANK IS NOT NULL
            WHERE variable.VARIABLE_NAME = 'Unserved Energy'
                AND fact.MEAS_FREQUENCY = 'Hourly Avg Of A Day'
        )
        SELECT 
            measurement_artifacts,
            MEASUREMENT_ARTIFACTS_TYPE,
            SUPPLY_CATEGORY,
            REGION,
            SUB_REGION,
            VARIABLE,
            DURATION,
            (TOTAL_MEAS_VALUE) as MEASUREMENT_VALUE,
            VARIABLE_UNIT,
            date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'HH:mm') AS HOUR,
            date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'MM') AS MONTH,
            date_format(to_timestamp(MEAS_CAPTURE_DATETIME, 'MM/dd/yyyy hh:mm a'), 'yyyy') AS YEAR,
            PHASE,
            SCENARIO,
            'Intraday Price' AS VISUAL
        FROM FINAL_CTE;
        """
  