"""
Module: mv_ema_supply_op
Description: Process data from raw to curated for the mv_ema_supply_op.
It contains the necessary functions and logic to create mv_ema_supply_op table in curated.

Author: Vaishnavi Ruikar
Date: 10-10-2024
"""

# pylint: disable=line-too-long
# pylint: disable=import-error
# pylint: disable=missing-module-docstring
# pylint: disable=trailing-whitespace
# pylint: disable=inconsistent-return-statements
# pylint: disable=too-many-arguments
# pylint: disable=too-many-positional-arguments

import logging
from common_utils import (
    calculate_num_partitions,
    impose_schema,
)  # pylint: disable = import-error
from read_utils import read  # pylint: disable = import-error
from pyspark.sql import DataFrame, SparkSession
import mv_queries as mq
import pyspark.sql.functions as F
from pyspark import StorageLevel


def prepare_asset_cte(
        spark: SparkSession,
        df_dim_cr_ass_asset: DataFrame,
        df_dim_cr_loc_location_group: DataFrame,
        df_dim_cr_loc_location: DataFrame,
        df_dim_cr_loc_location_area: DataFrame
):
    df_dim_cr_ass_asset.createOrReplaceTempView("dim_cr_ass_asset")
    df_dim_cr_loc_location_group.createOrReplaceTempView("dim_cr_loc_location_group")
    df_dim_cr_loc_location.createOrReplaceTempView("dim_cr_loc_location")
    df_dim_cr_loc_location_area.createOrReplaceTempView("dim_cr_loc_location_area")

    sql_query = """
        SELECT DISTINCT ASSET.DIM_ASSET_ID, ASSET.SUP_CATEGORY_ID, 
            ASSET.ASSET_NAME, LG.LOCATION_GROUP_ABBREVIATION AS REGION, 
            NULL AS SUB_REGION , CATEGORY.SUP_CATEGORY_NAME as CATEGORY
        FROM 
        DIM_CR_ASS_ASSET ASSET 
        LEFT JOIN DIM_EN_ASS_SUP_CATEGORY CATEGORY 
            ON ASSET.SUP_CATEGORY_ID = CATEGORY.SUP_CATEGORY_ID
        LEFT JOIN DIM_CR_LOC_LOCATION_GROUP LG 
            ON LG.DIM_LOCATION_GROUP_ID = ASSET.DIM_LOCATION_GROUP_ID    
    """

    return spark.sql(sql_query)


def prepare_transformed_df(  # pylint: disable = too-many-arguments,too-many-locals
        spark: SparkSession,
        df_fact_en_eve_model_opd_value: DataFrame,
        df_dim_cr_ass_asset: DataFrame,
        df_dim_en_op_meas_variable: DataFrame,
        df_dim_en_ass_sup_category: DataFrame,
        df_fact_en_eve_model_opd_ue_value: DataFrame,
        df_dim_cr_loc_location_group: DataFrame,
        df_dim_cr_loc_location: DataFrame,
        df_dim_cr_loc_location_area: DataFrame,
        df_source: DataFrame,
        df_fact_en_eve_model_opl_value: DataFrame,
        df_fact_en_eve_model_opp_value: DataFrame,
        df_generation_naming_mapping: DataFrame
) -> DataFrame:
    logging.info("Starting the transformation process.")

    df_fact_en_eve_model_opd_value.createOrReplaceTempView(
        "fact_en_eve_model_opd_value"
    )
    df_dim_cr_ass_asset.createOrReplaceTempView("dim_cr_ass_asset")
    df_dim_en_op_meas_variable.createOrReplaceTempView("dim_en_op_meas_variable")
    df_dim_en_ass_sup_category.createOrReplaceTempView("dim_en_ass_sup_category")
    df_fact_en_eve_model_opd_ue_value.createOrReplaceTempView(
        "fact_en_eve_model_opd_ue_value"
    )
    df_dim_cr_loc_location_group.createOrReplaceTempView("dim_cr_loc_location_group")
    df_dim_cr_loc_location.createOrReplaceTempView("dim_cr_loc_location")
    df_dim_cr_loc_location_area.createOrReplaceTempView("dim_cr_loc_location_area")
    df_asset_cte = prepare_asset_cte(
        spark=spark,
        df_dim_cr_ass_asset=df_dim_cr_ass_asset,
        df_dim_cr_loc_location_group=df_dim_cr_loc_location_group,
        df_dim_cr_loc_location=df_dim_cr_loc_location,
        df_dim_cr_loc_location_area=df_dim_cr_loc_location_area
    ).repartition(1)
    df_asset_cte.createOrReplaceTempView("asset_cte")

    df_source = df_source.withColumn(
        "SCENARIO",
        F.concat_ws(
            " ",
            F.col("LABEL"),
            F.when(
                F.col("NAME") == F.lit('P2 Reference - No brine'),
                'P2 Reference with No brine'
            ).otherwise(F.col("NAME"))
        )
    )
    df_source.createOrReplaceTempView("SOURCE_SOURCE")
    df_fact_en_eve_model_opl_value.createOrReplaceTempView("FACT_EN_EVE_MODEL_OPL_VALUE")
    df_fact_en_eve_model_opp_value.createOrReplaceTempView("FACT_EN_EVE_MODEL_OPP_VALUE")
    df_generation_naming_mapping.createOrReplaceTempView("GENERATION_NAMING_MAPPING_SOURCE")

    logging.info("Created temporary views for SQL operations.")

    # Initialize df_transformed
    df_transformed = spark.sql(mq.CapacityVsPeakDemand.capacity)

    # For appending more data, keep on appending new queries to the list
    queries_list = [
        mq.CapacityVsPeakDemand.peak_load,
        mq.SiteSpecificCapacity.capacity,
        mq.KsaInterconnectInterconnection.capacity,
        mq.KsaInterconnectExportImport.load, mq.KsaInterconnectExportImport.generation,
        mq.Emission.emission_query,
        mq.FuelOfftake.fuel_offtake,
        mq.KsaInterconnectFlowExportImport.generation, mq.KsaInterconnectFlowExportImport.load,
        mq.KsaInterconnectFlow.flow,
        mq.SupplyBalanceEnergyMix.generation_output_1, mq.SupplyBalanceEnergyMix.generation_output_2,
        mq.SupplyBalanceEnergyMix.generation_output_3, mq.SupplyBalanceEnergyMix.demand,
        mq.SupplyCapacity.peak_load_1, mq.SupplyCapacity.peak_load_2,
        mq.CapacityFactor.cf,
        mq.LineDurationCurve.flow,
        mq.SupplyBalanceIntradayMix.demand, mq.SupplyBalanceIntradayMix.generation_output_and_load,
        mq.SupplyBalanceIntradayMix.curtailment,
        mq.StorageCapacity.storage_capacity_1, mq.StorageCapacity.storage_capacity_2,
        mq.EnergyCostIrec.irecs_cost,
        mq.EnergyCostOvernight.overnight_capital_cost, mq.EnergyCostOvernight.overnight_capital_cost_table,
        mq.EnergyCostOvernight.overnight_grid_connection_cost,
        mq.EnergyCostOvernight.overnight_grid_connection_table_cost,
        mq.FuelOfftakeMonthly.fuel_offtake,
        mq.SupplyBalanceIntradayMixRL.load, mq.SupplyBalanceIntradayMixRL.network_loss,
        mq.EnergyCostSystemCost.system_cost_ksa_import, mq.EnergyCostSystemCost.system_cost_others,
        mq.EnergyCostSystemCost.system_cost_table_ksa_import, mq.EnergyCostSystemCost.system_cost_table_others,
        mq.Gwap.gwap_1, mq.Gwap.gwap_2, mq.Gwap.gwap_3,
        mq.EnergyCostSiteSpecificCapex.overnight_capex_annualised_capex,
        mq.EnergyPrice.energy_price, mq.EnergyPrice.energy_price_category_ksa_import,
        mq.EnergyPrice.energy_price_category_others, mq.EnergyPrice.running_price,
        mq.StorageUtilization.storage_utilization,mq.StorageUtilization.utilization,
        mq.FlowDurationCurve.flow_mw, mq.FlowDurationCurve.flow_mw_2,
        mq.FlowDurationGraph.load, mq.FlowDurationGraph.generation, mq.FlowDurationGraph.curtailment, mq.FlowDurationGraph.unserved_energy,
        mq.LoadDurationGraph.load, mq.LoadDurationGraph.generation, mq.LoadDurationGraph.curtailment, mq.LoadDurationGraph.unserved_energy,
        mq.LoadDurationGraph.demand,
        mq.SupplyBalanceEnergyMixDrilldown.ksaNetImport,mq.SupplyBalanceEnergyMixDrilldown.locLoad,mq.SupplyBalanceEnergyMixDrilldown.locGeneration,
        mq.SupplyBalanceEnergyMixDrilldown.LfpPhs,mq.SupplyBalanceEnergyMixDrilldown.curtailment,mq.SupplyBalanceEnergyMixDrilldown.unservedEnergy,
        mq.SupplyBalanceEnergyMixDrilldown.ksaImport,mq.SupplyBalanceEnergyMixDrilldown.ksaExport,
        mq.IntradayPrice.load,mq.IntradayPrice.curtailment,mq.IntradayPrice.generation,mq.IntradayPrice.unserved_energy
        
    ]

    try:
        for query in queries_list:
            df_transformed = df_transformed.unionByName(spark.sql(query))
    except Exception as err:
        print(f"prepare_tranformed_df():: Error occured while processing query {query}")
        logging.error(f"Error Info: {err}")
        raise

    print("df_transformed schema:", df_transformed.printSchema())

    logging.info("Calculating the number of partitions.")
    max_partition_size_mb = 1024
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)
    logging.info("Repartitioning the DataFrame into %s partitions.", num_partitions)
    df_transformed = df_transformed.repartition(num_partitions)

    df_transformed = df_transformed.persist(StorageLevel.MEMORY_AND_DISK)

    return df_transformed


def transform(
        spark, source_dfs: dict
) -> DataFrame:  # pylint: disable = too-many-locals
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "FACT_EN_EVE_MODEL_OPD_VALUE": DataFrame for FACT_EN_EVE_MODEL_OPD_VALUE.
            - "DIM_CR_ASS_ASSET": DataFrame for DIM_CR_ASS_ASSET.
            - "DIM_EN_OP_MEAS_VARIABLE": DataFrame for DIM_EN_OP_MEAS_VARIABLE.
            - "DIM_EN_ASS_SUP_CATEGORY": DataFrame for DIM_EN_ASS_SUP_CATEGORY.
            - "FACT_EN_EVE_MODEL_OPD_UE_VALUE": DataFrame for FACT_EN_EVE_MODEL_OPD_UE_VALUE.
            - "DIM_CR_LOC_LOCATION_GROUP": DataFrame for DIM_CR_LOC_LOCATION_GROUP.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    energy_domain_filter = "upper(DOMAIN_TYPE) == 'ENERGY'"

    df_fact_en_eve_model_opd_value: DataFrame = source_dfs["FACT_EN_EVE_MODEL_OPD_VALUE"]
    df_dim_cr_ass_asset: DataFrame = (
        source_dfs["DIM_CR_ASS_ASSET"].where("upper(ASSET_DOMAIN_TYPE) == 'ENERGY ASSET'")
    )
    df_dim_en_op_meas_variable: DataFrame = source_dfs["DIM_EN_OP_MEAS_VARIABLE"]
    df_dim_en_ass_sup_category: DataFrame = source_dfs["DIM_EN_ASS_SUP_CATEGORY"]
    df_fact_en_eve_model_opd_ue_value: DataFrame = source_dfs["FACT_EN_EVE_MODEL_OPD_UE_VALUE"]
    df_dim_cr_loc_location_group: DataFrame = (
        source_dfs["DIM_CR_LOC_LOCATION_GROUP"].where(energy_domain_filter)
    )
    df_dim_cr_loc_location: DataFrame = (
        source_dfs["DIM_CR_LOC_LOCATION"].where(energy_domain_filter)
    )
    df_dim_cr_loc_location_area: DataFrame = (
        source_dfs["DIM_CR_LOC_LOCATION_AREA"].where(energy_domain_filter)
    )
    df_source = source_dfs["SOURCE"]
    df_fact_en_eve_model_opl_value = source_dfs["FACT_EN_EVE_MODEL_OPL_VALUE"]
    df_fact_en_eve_model_opp_value = source_dfs["FACT_EN_EVE_MODEL_OPP_VALUE"]
    df_generation_naming_mapping = source_dfs["GENERATION_NAMING_MAPPING"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_fact_en_eve_model_opd_value=df_fact_en_eve_model_opd_value,
        df_dim_cr_ass_asset=df_dim_cr_ass_asset,
        df_dim_en_op_meas_variable=df_dim_en_op_meas_variable,
        df_dim_en_ass_sup_category=df_dim_en_ass_sup_category,
        df_fact_en_eve_model_opd_ue_value=df_fact_en_eve_model_opd_ue_value,
        df_dim_cr_loc_location_group=df_dim_cr_loc_location_group,
        df_dim_cr_loc_location=df_dim_cr_loc_location,
        df_dim_cr_loc_location_area=df_dim_cr_loc_location_area,
        df_source=df_source,
        df_fact_en_eve_model_opl_value=df_fact_en_eve_model_opl_value,
        df_fact_en_eve_model_opp_value=df_fact_en_eve_model_opp_value,
        df_generation_naming_mapping=df_generation_naming_mapping
    )
    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage
        configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def presentation_datavalidations(spark, spark_df):
    """
    dummy validation task just returns the spark_df
    """
    print("Inside presentation_datavalidations")
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    return spark_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")
    print("printing spark df", spark_df)

    if task_name == "curated_data_processing_task":
        df = execute_transform(spark, pipeline_storage, task_parameters)
        print("Final Transformed df")
        return df

    if task_name == "adw_presentation_data_validations_checks":
        print("transformations - adw_presentation_data_validations_checks")
        return presentation_datavalidations(spark, spark_df)

    return None
