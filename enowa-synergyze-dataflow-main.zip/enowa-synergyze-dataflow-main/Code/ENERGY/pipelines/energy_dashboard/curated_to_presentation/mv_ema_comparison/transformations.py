import logging
import os
import sys

# Add the utility folder to sys.path
current_dir = os.path.dirname(os.path.abspath(__file__))  # Current directory of transformations.py
utility_dir = os.path.join(current_dir, "../../../../../src/utility")  # Navigate to src/utility
sys.path.append(os.path.normpath(utility_dir))  # Normalize the path for compatibility

from common_utils import calculate_num_partitions, impose_schema
from read_utils import read
from pyspark.sql import DataFrame, SparkSession
from pyspark import StorageLevel


def prepare_transformed_df(
        df_comparison: DataFrame
) -> DataFrame:
    """
    Transforms demand data by joining multiple DataFrames and filtering columns.
    Creates temporary views for SQL operations and executes a transformation query.
    Removes duplicate records from raw DataFrames and partitions the transformed result.
    Calculates an appropriate number of partitions based on maximum partition size.
    Returns the transformed and repartitioned DataFrame for further processing.
    """

    df_comparison = df_comparison.withColumnRenamed("Order", "SORT_ORDER")
    print("df_comparison schema:", df_comparison.printSchema())

    df_transformed = df_comparison

    logging.info("Calculating the number of partitions.")
    max_partition_size_mb = 1024
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)
    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "CAPACITY_ITEM_DEMAND_CASE": DataFrame for capacity item demand case.
            - "DIM_CR_LOC_LOCATION_GROUP": DataFrame for location group.
            - "NEOM_REGION_MAPPING": DataFrame for location mapping.
            - "NEOM_SUB_REGION_MAPPING": DataFrame for sub region mapping.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    print("SparkSession:", spark)  # Printing spark session to avoid sonar issue

    logging.info("Starting transformation process.")

    if "COMPARISON" not in source_dfs or source_dfs["COMPARISON"] is None:
        logging.error("Source DataFrame 'COMPARISON' is missing.")
        raise ValueError("Source DataFrame 'COMPARISON' is missing or None.")

    df_comparison = source_dfs["COMPARISON"]
    transform_df = prepare_transformed_df(df_comparison=df_comparison)
    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    transformed_df = transformed_df.persist(StorageLevel.MEMORY_AND_DISK)

    return transformed_df


def presentation_datavalidations(spark, spark_df):
    """
    dummy validation task just returns the spark_df
    """
    print("Inside presentation_datavalidations")
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    return spark_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")
    if spark_df:  # This is required for linting purpose
        print(spark_df.printSchema())

    if task_name == "curated_data_processing_task":
        df = execute_transform(spark, pipeline_storage, task_parameters)
        return df

    if task_name == "adw_presentation_data_validations_checks":
        return presentation_datavalidations(spark, spark_df)

    return None
