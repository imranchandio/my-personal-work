"""
This is transformation file for MWh pathway for Energy Demand data
"""

import logging
from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from common_utils import impose_schema


def execute_transform(
        source_df, pipeline_storage: list[dict], task_parameters: dict
):
    # pylint: disable = line-too-long
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        source_df: Source dataframe
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    # pylint: enable = line-too-long
    logging.info("Inside execute_transform function")

    transformed_df = source_df

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    logging.info("Imposing schema on transformed_df")

    if transformed_df:
        transformed_df = impose_schema(transformed_df, target_schema)

    logging.info("Final transformed_df schema: %s", transformed_df.printSchema())

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    # pylint: disable = line-too-long
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: source dataframe
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    print("Spark Session:", spark)  # Printing spark session object to avoid SonarQube issues
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")
    spark_df = spark_df.withColumn(
    "PARTITION_KEY", 
    F.regexp_replace(
        F.regexp_replace(F.col("file_name"), r"[^\w]", "_"),
        r"_+", "_"
    )
    )

    if task_name == "energy_data_movement_task":
        return execute_transform(spark_df, pipeline_storage, task_parameters)
