"""
Module: unified_pathways_names
Description: Process data from raw to curated for the unified_pathways_names.
It contains the necessary functions and logic to create unified_pathways_names
table in curated.

Author: Vaishnavi Ruikar
Date: 30-10-2024
"""
import pyspark.sql.functions as F


def main(spark, spark_df, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name = kwargs.get('task_name')
    spark_df = spark_df.withColumn(
    "PARTITION_KEY", 
    F.regexp_replace(
        F.regexp_replace(F.col("file_name"), r"[^\w]", "_"),
        r"_+", "_"
    )
    )
    if task_name == "data_movement_task":
        print("transformations - main")
        print(spark)
        return spark_df
    return None
