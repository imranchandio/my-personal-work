# pylint: disable=line-too-long
# pylint: disable=wrong-import-order,wrong-import-position,import-error, ungrouped-imports
"""
This is transformation file for MWh pathway for Energy Demand data
"""

import logging
import os
from pyspark.sql import DataFrame, SparkSession
from common_utils import (
    impose_schema,
    calculate_num_partitions,
    list_files_from_object_uri,
    add_current_year_quarter,
    get_excel_sheet_names,
    delete_all_files_from_object_uri,
    get_current_year_quarter
)
import pyspark.sql.functions as F
import gc
from read_utils import excel_reader
from oci_services import OCIConnectionFactory
from pyspark.sql.types import StringType
import re
import datetime
import time

YYYYQQ_PATTERN = r"(\d{4}Q[1-4])"
SOURCE_TAB = "Source tab"


def extract_file_name(file_name):
    """
    Extracts the file name in the format "Current quarter demand data - YYYYQQ.xlsx"
    if the file name contains a YYYYQQ pattern (e.g., '2024Q1').
    If no YYYYQQ pattern is found, returns "Current quarter demand data.xlsx".

    Args:
        file_name (str): The original file name.

    Returns:
        str: The extracted or modified file name.
    """
    # Check if the file name contains YYYYQQ pattern
    match = re.search(YYYYQQ_PATTERN, file_name)
    if match:
        # If YYYYQQ is found, return "Current quarter demand data - YYYYQQ.xlsx"
        return f"Current Quarter Demand Data - {match.group(1)}.xlsx"
    else:
        # If YYYYQQ is not found, return "Current quarter demand data.xlsx"
        return "Current Quarter Demand Data.xlsx"


def unpivot_data(df: DataFrame, column_mapping: dict):
    # pylint: disable=line-too-long
    """
    Unpivots the DataFrame by converting specified period columns into rows.

    Parameters:
    ----------
    df : DataFrame
        The DataFrame to be unpivoted.
    column_mapping : dict
        A mapping of non-period columns to their names.

    Returns:
    -------
    DataFrame
        A new DataFrame with period columns unpivoted into rows.
    """
    # pylint: enable=line-too-long
    # List of non-period columns (columns you don't want to unpivot)
    non_period_columns = list(column_mapping.values())

    # List of period columns (columns you want to unpivot)
    period_columns = [
        column for column in df.columns if column not in non_period_columns
    ]

    # Generate the stack expression for unpivoting
    n = len(period_columns)
    stack_expr = "stack({}, {}) as (PERIOD, VALUE)".format(
        n, ", ".join([f"'{column}', `{column}`" for column in period_columns])
    )

    # Unpivot using selectExpr and stack
    unpivoted_df = df.selectExpr(
        *[f"`{col}`" for col in non_period_columns], stack_expr
    )

    return unpivoted_df


def prepare_transformed_df_mwh(df: DataFrame):
    """
    Prepares and transforms the DataFrame for MWH data by renaming columns and unpivoting.

    Parameters:
    ----------
    df : DataFrame
        The DataFrame to be transformed.

    Returns:
    -------
    DataFrame
        The transformed DataFrame with renamed columns and additional computed columns.
    """
    print("Inside prepare_transformed_df function MWH")

    column_mapping = {
        "Asset": "ASSET",
        "Note": "NOTE",
        SOURCE_TAB: "SOURCE_TAB",
        "Sub-region": "SUB_REGION",
        "Region": "REGION",
        "Region for HLP": "REGION_FOR_HLP",
        "Region for power nodes": "REGION_FOR_POWER_NODES",
        "Sector": "SECTOR",
        "PATHWAY": "PATHWAY",
        "FILE_NAME": "FILE_NAME",
    }

    for old_name, new_name in column_mapping.items():
        df = df.withColumnRenamed(old_name, new_name)

    unpivoted_df = unpivot_data(df, column_mapping)

    return unpivoted_df


def prepare_transformed_df_mw(df: DataFrame):
    # pylint: disable=line-too-long
    """
    Prepares and transforms the DataFrame for MW data by renaming columns, adding missing columns, and unpivoting.

    Parameters:
    ----------
    df : DataFrame
        The DataFrame to be transformed.

    Returns:
    -------
    DataFrame
        The transformed DataFrame with renamed columns and additional computed columns.
    """
    # pylint: enable=line-too-long
    print("Inside prepare_transformed_df function MW")

    column_mapping = {
        "Region": "REGION",
        "Sub-region": "SUB_REGION",
        "Region for power nodes": "REGION_FOR_POWER_NODES",
        "Sector": "SECTOR",
        "Asset": "ASSET",
        "Representative profile": "REPRESENTATIVE_PROFILE",
        "PATHWAY": "PATHWAY",
        "FILE_NAME": "FILE_NAME",
        "Note": "NOTE",
        SOURCE_TAB: "SOURCE_TAB",
    }

    # Check if Notes and Source tab columns in df.
    # If no, add these columns as these columns are not available in historical files
    if "Note" not in df.columns:
        df = df.withColumn("Note", F.lit(None).cast(StringType()))
    if SOURCE_TAB not in df.columns:
        df = df.withColumn(SOURCE_TAB, F.lit(None).cast(StringType()))

    for old_name, new_name in column_mapping.items():
        df = df.withColumnRenamed(old_name, new_name)

    unpivoted_df = unpivot_data(df, column_mapping)

    return unpivoted_df


def get_storage_config(storage_config, storage_name):
    # pylint: disable=line-too-long
    """
    Retrieve a storage configuration by matching the given storage name.

    This function searches for a storage configuration within a list of dictionaries based on the provided storage name.

    Args:
        storage_config (list of dict): A list of dictionaries containing storage configurations.
        storage_name (str): The name of the storage configuration to retrieve.

    Returns:
        dict or None: A dictionary containing the storage configuration if found, otherwise None.
    """
    # pylint: enable=line-too-long
    for config in storage_config:
        if config["name"].strip().lower() == storage_name.strip().lower():
            return config
    return None


def write(target_info: dict, spark_df: DataFrame):
    # pylint: disable=line-too-long
    """
    Writes a Spark DataFrame to a target location with optional partitioning.

    Parameters:
    target_info : dict
        Dictionary with keys: 'target_url', 'write_mode', 'file_partition_col', 'type', and 'header'.
    spark_df : DataFrame
        The DataFrame to be written.

    Returns:
    None
    """
    # pylint: enable=line-too-long
    print("Inside write funtion..")
    target_file_url = target_info.get("target_url")
    mode = target_info.get("write_mode")
    partition_col = target_info.get("file_partition_col")
    file_format = target_info.get("type")
    header = target_info.get("header")

    if partition_col:
        spark_df.write.partitionBy(*partition_col).options(header=header).mode(
            mode
        ).format(file_format).save(target_file_url)
    else:
        spark_df.write.options(header=header).mode(mode).format(file_format).save(
            target_file_url
        )

    spark_df.unpersist()
    del spark_df
    gc.collect()
    logging.info("Data saved to Object Storage!")
    logging.info("Data Loader Task --- FINISHED !")


# pylint: disable=too-many-locals,too-many-statements
def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    # pylint: disable=line-too-long
    """
    Processes Excel files from Object Storage, transforms their data, and writes the results to a target location.

    Parameters:
    ----------
    spark : SparkSession
        The active Spark session.
    pipeline_storage : list[dict]
        Configuration details for source and target storage.
    task_parameters : dict
        Parameters specifying the source and target storage names.

    Returns:
    -------
    tuple
        A tuple containing the execution status, message, list of processed file URIs, and the processed count.
    """
    # pylint: enable=line-too-long
    logging.info("Inside execute_transform function")
    processed_count = 0
    passed_files_target = []
    execution_status = ""
    execution_message = ""
    # pylint: disable=broad-exception-caught

    # Initialize the Object Storage client
    oci_factory = OCIConnectionFactory()
    object_storage_client = oci_factory.get_oci_client("ObjectStorageClient")

    source_config = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["source"]:
            source_config = storage_config
            print("source_config:", source_config)

    list_of_files = list_files_from_object_uri(source_config=source_config)
    logging.info("List of files to process: %s", list_of_files)
    absolute_file_uri = ""

    # Split file functionality testing code Started
    generated_files = []

    for filename in list_of_files:
        print("inside the new split file functionality")
        namespace = source_config["namespace"]
        bucket_name = source_config["bucket_name"]
        target_path = f"oci://{bucket_name}@{namespace}/{source_config['temp_path']}"
        source_config["filename"] = filename
        absolute_file_uri = source_config["source_url"] + filename.split("/")[-1]
        print("absolute_file_uri_updated : ", absolute_file_uri)

        # Fetch the sheet names for the current file
        sheets = get_excel_sheet_names(
            object_storage_client=object_storage_client,
            namespace=namespace,
            bucket_name=bucket_name,
            object_name=filename,
        )

        if source_config["sheet_pattern"] == "MWh":
            # Process sheets that contain "MWh"
            sheets_to_process = [sheet for sheet in sheets if "MWh" in sheet]
        elif source_config["sheet_pattern"] == "MW":
            # Process sheets that contain "MW" but not "MWh"
            sheets_to_process = [
                sheet for sheet in sheets if "MW" in sheet and "MWh" not in sheet
            ]
        else:
            print("Sheet name with out MW and MWh in it")

        for sheet in sheets_to_process:
            sheet_name = (
                sheet  # Assuming `sheet` is just the name, correct index if necessary
            )
            print("sheet_name : ", sheet_name)
            source_config["sheet_name"] = sheet_name
            source_file_name = source_config["filename"].split("/")[-1]
            source_config["source_file_url"] = (
                    source_config["source_url"] + source_file_name
            )

            try:
                # Read each sheet from the current file
                sheet_df: DataFrame = excel_reader(
                    spark=spark, source_config=source_config
                )

                target_file_name = f"{source_file_name.split('.')[0]}_{sheet_name}.csv"
                target_file_path = os.path.join(target_path, target_file_name)

                sheet_df.coalesce(1).write.mode("overwrite").option(
                    "header", "true"
                ).csv(target_file_path)

                generated_files.append(target_file_path)
                print(f"Saved {target_file_name} as a .csv at {target_path}")

                sheet_df.unpersist()
                del sheet_df
                gc.collect()

            except Exception as e:
                logging.info("Load Failed: %s", target_path)
                logging.info("Error Details: %s", e)

        passed_files_target.append(absolute_file_uri)
        print("passed_files_target values after appended: ", passed_files_target)

    logging.info("files filtered in this stage: %s", generated_files)

    for file_path in generated_files:
        print("reading the file :", file_path)

        # to retrive the file name and sheet name from the new split files
        file_name = file_path.split("/")[-1]
        sheet_name = re.search(r"_(.*?)\.csv", file_name).group(1)
        print(f"Extracted sheet name: {sheet_name}")

        try:
            df = spark.read.option("header", "true").csv(file_path)

            # Drop blank rows
            df = df.dropna(how="all")

            # Extract the first row (header row)
            header_row = df.first()

            # Create a new schema using the first row's values as the column names
            new_column_names = [str.strip(str(c)) for c in header_row]

            # Recreate the DataFrame with new column names and drop the first row
            df_with_new_header = df.toDF(*new_column_names).filter(
                F.trim(df["_c0"]) != new_column_names[0]
            )

            # converting the split file_name to original file name 
            file_name_col = file_name.split("_")[0] + ".xlsx"

            df_with_new_header = df_with_new_header.withColumn(
                "PATHWAY", F.lit(sheet_name)
            ).withColumn("FILE_NAME", F.lit(extract_file_name(file_name_col)))

            if "MWH" in str.upper(sheet_name):
                print(f"Processing MWH file: {sheet_name}")
                transformed_df = prepare_transformed_df_mwh(df=df_with_new_header)
            elif "MW" in str.upper(sheet_name):
                print(f"Processing MW file: {sheet_name}")
                transformed_df = prepare_transformed_df_mw(df=df_with_new_header)
            else:
                print(f"Unknown file type: {sheet_name}")
                raise ValueError(f"Unrecognized sheet name format: {sheet_name}")

            # If file_name is Current Quarter Demand Data.xlsx then add YYYYQTR to file_name
            # e.g 'Current Quarter Demand Data.xlsx' updated to 'Current Quarter Demand Data - 2024Q3.xlsx'
            updated_file_name = add_current_year_quarter(file_name_col)
            transformed_df = transformed_df.withColumn(
                "UPDATED_FILE_NAME", F.lit(updated_file_name)
            )

            transformed_df = (
                transformed_df.withColumn(
                    "PARTITION_KEY",
                    F.concat_ws(
                        "-",
                        F.coalesce(
                            F.regexp_extract(F.col("FILE_NAME"), YYYYQQ_PATTERN, 1),
                            F.lit(""),
                        ),
                        F.col("PATHWAY"),
                    ),
                )
                .withColumn(
                    "SCENARIO_NAME",
                    F.when(
                        F.col("UPDATED_FILE_NAME").rlike(YYYYQQ_PATTERN),
                        F.regexp_extract(
                            F.col("UPDATED_FILE_NAME"), YYYYQQ_PATTERN, 1
                        ),
                    ).otherwise(get_current_year_quarter()),
                )
                .withColumn("CREATED_DATE", F.current_timestamp())
            )

            transformed_df = transformed_df.drop("UPDATED_FILE_NAME")

            target_schema = {}
            target_info = {}
            for storage_config in pipeline_storage:
                if storage_config["name"] == task_parameters["target"]:
                    target_schema = storage_config["schema"]
                    target_info = storage_config

            logging.info("execute_transform(): Imposing schema on transformed_df")

            if transformed_df:
                transformed_df = impose_schema(transformed_df, target_schema)

            max_partition_size_mb = 256
            num_partitions = calculate_num_partitions(
                transformed_df, max_partition_size_mb
            )
            logging.info(
                "execute_transform(): Repartitioning the DataFrame into %s partitions.",
                num_partitions,
            )
            transformed_df = transformed_df.coalesce(num_partitions)
            logging.info(
                "execute_transform(): Final transformed_df schema: %s",
                transformed_df.printSchema(),
            )

            # write to target
            write(target_info, transformed_df)

            execution_status = "SUCCESS"
            execution_message = (
                f"Successfully processed data from {sheet_name} "
                f"sheet in file {file_path}"
            )

            transformed_df.unpersist()
            del transformed_df
            gc.collect()

        except Exception as e:
            print(f"Failed to read file {file_path}")
            print(f"Error: {e}")

    deleted_files = delete_all_files_from_object_uri(source_config)
    print("Total files deleted : ", len(deleted_files))
    print("passed_files_target : ", passed_files_target)

    return execution_status, execution_message, passed_files_target, processed_count


# pylint: disable = inconsistent-return-statements
def main(spark: SparkSession, **kwargs):
    # pylint: disable = line-too-long
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # pylint: enable = line-too-long

    spark.conf.set("spark.sql.adaptive.enabled", "true")
    spark.conf.set("spark.sql.shuffle.partitions", "200")

    # Adding 10sec sleep to finish staging to landing file copy
    time.sleep(10)

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "energy_data_movement_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
