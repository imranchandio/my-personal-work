"""
This is the transformation file for tawzea monthly report
"""

# pylint:disable=import-error,unused-variable,unused-argument, raise-missing-from,broad-exception-raised

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_date, month, year, concat, lpad


def transform_dataframe(df):
    """
    This function transforms the input dataframe, removing rows with missing data,
    and creates a PARTITION_KEY based on the month extracted from the CreatedOn column.

    Returns:
        DataFrame: The resulting DataFrame from the transformation.

    Raises:
        Exception: If an error occurs during transformation.
    """
    try:
        # Filter out unwanted rows
        df = df.filter(
            (col("CreatedOn").isNotNull())
            & (col("CreatedOn") != "")
            & (col("CreatedOn") != "CreatedOn")
        )

        # Convert 'CreatedOn' to date
        # df = df.withColumn("CreatedOn", to_date(df["CreatedOn"], "yyyy-MM-dd HH:mm:ss"))
        df = df.withColumn("CreatedOn", to_date(df["CreatedOn"], "yyyy-MM-dd"))

        # Set the month as the PARTITION_KEY
        # df = df.withColumn("PARTITION_KEY", month(df["CreatedOn"]))

        # Set the PARTITION_KEY to a combination of year and month (e.g., 'YYYY-MM')
        df = df.withColumn(
            "PARTITION_KEY",
            concat(year(df["CreatedOn"]), lpad(month(df["CreatedOn"]), 2, "0")),
        )

        # Filter out rows where PARTITION_KEY is null or 0
        df = df.filter(col("PARTITION_KEY").isNotNull() & (col("PARTITION_KEY") != 0))

        return df

    except Exception as e:
        raise ValueError("Error in Transforming Data: " + str(e))


def main(spark, spark_df, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: source dataframe
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    print("Spark Session:", spark)  # Printing spark session object to avoid SonarQube issues

    # Extract arguments from kwargs
    task_name = kwargs.get("task_name")
    if task_name == "data_movement_task":
        print("transformations - main")
        transformed_df = transform_dataframe(spark_df)
        return transformed_df

    raise ValueError(f"Unsupported task name: {task_name}")
