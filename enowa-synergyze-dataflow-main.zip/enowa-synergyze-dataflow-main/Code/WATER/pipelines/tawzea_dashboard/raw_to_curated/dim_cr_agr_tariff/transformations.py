"""
Module: dim_cr_agr_tariff
Description: Process data from raw to curated for the dim_cr_agr_tariff.
It contains the necessary functions and logic to create dim_cr_agr_tariff table in curated.

Author: Abhishek Singh
Date: 21-10-2024
"""

# pylint: disable = import-error, too-many-arguments, too-many-locals

import logging
import os
import sys
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession, df_tawzea_monthly_report: DataFrame,
        df_dim_cr_pro_service: DataFrame
) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        tawzea_monthly_report: DataFrame for TAWZEA_MONTHLY_REPORT.
    Returns:
        DataFrame: The transformed DataFrame.
    """
    logging.info("Starting the transformation process.")

    df_tawzea_monthly_report.show()
    df_dim_cr_pro_service.show()

    df_tawzea_monthly_report.createOrReplaceTempView("tawzea_monthly_report")
    df_dim_cr_pro_service.createOrReplaceTempView("dim_cr_pro_service")

    logging.info("Created temporary views for SQL operations.")

    sql_query = """
                SELECT
                DIM_SERVICE_ID,
                TARIFFPRICE AS TARIFF_RATE,
                NULL AS FIXED_RATE,
                NULL AS VARIABLE_RATE,
                DISCOUNTAMOUNT AS DISCOUNT_RATE,
                DISCOUNTPER AS DISCOUNT_PERCENT,
                TariffNetPrice AS NET_TARIFF_PRICE,
                'RECYCLE WATER SERVICE TARIFF' AS TARIFF_SUB_DOMAIN,
                'Water' AS TARIFF_DOMAIN,
                'TAWZEA' as PARTITION_KEY,
                'TAWZEA' as DOMAIN_TYPE,
                current_timestamp AS LAST_UPDATED_DATE,
                current_timestamp AS CREATED_DATE
                FROM tawzea_monthly_report a
                LEFT JOIN
                dim_cr_pro_service b ON
                a.SERVICECATEGORY = b.SERVICE
    """

    df_transformed = spark.sql(sqlQuery=sql_query)
    df_transformed.show()

    logging.info("Executed SQL query for data transformation.")

    df_transformed = df_transformed.withColumn(
        "DIM_TARIFF_ID",
        sha2(concat_ws("||", "DIM_SERVICE_ID", "TARIFF_RATE", "DISCOUNT_RATE"), 256),
    )

    df_transformed.show()

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %s partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
        tawzea_monthly_report: DataFrame for TAWZEA_MONTHLY_REPORT.
        df_dim_cr_pro_service: DataFrame for DIM_CR_PRO_SERVICE.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_tawzea_monthly_report = source_dfs["TAWZEA_MONTHLY_REPORT"]
    df_dim_cr_pro_service = source_dfs["DIM_CR_PRO_SERVICE"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_tawzea_monthly_report=df_tawzea_monthly_report,
        df_dim_cr_pro_service=df_dim_cr_pro_service
    )

    transform_df = transform_df.distinct()
    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage
        configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")
    print("printing spark df", spark_df)

    if task_name == "curated_data_processing_task":
        df = execute_transform(spark, pipeline_storage, task_parameters)
        return df
    return None
