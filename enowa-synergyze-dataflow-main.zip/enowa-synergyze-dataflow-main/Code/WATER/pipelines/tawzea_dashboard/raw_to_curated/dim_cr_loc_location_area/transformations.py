# pylint: disable = wrong-import-order, too-many-arguments, unused-argument, import-error, inconsistent-return-statements
"""
Module: dim_cr_loc_locaton_area
Description: Process data from raw to curated for the dim_cr_loc_locaton_area.
It contains the necessary functions and logic to create dim_cr_loc_locaton_area table in curated.

Author: Abhishek Singh
Date: 21-10-2024
"""
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws
import logging
import os
import sys
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession, df_tawzea_monthly_report: DataFrame
) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "TAWZEA_MONTHLY_REPORT": DataFrame for TAWZEA_MONTHLY_REPORT.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    logging.info("Starting the transformation process.")

    df_tawzea_monthly_report.show()

    df_tawzea_monthly_report.createOrReplaceTempView("tawzea_monthly_report")

    logging.info("Created temporary views for SQL operations.")

    logging.info("Executing SQL query for data transformation.")

    sql_query = """
                SELECT 
                NULL AS DIM_LOCATION_GROUP_ID,
                DELIVERYZONE AS LOCATION_AREA,
                DELIVERYZONE AS LOCATION_AREA_ABBREVIATION,
                NULL AS LATITUDE,
                NULL AS LONGITUDE,
                'TAWZEA' as PARTITION_KEY,
                'TAWZEA' as DOMAIN_TYPE,
                current_timestamp AS LAST_UPDATED_DATE,
                current_timestamp AS CREATED_DATE
                FROM
                tawzea_monthly_report
                """

    df_transformed = spark.sql(sqlQuery=sql_query)

    logging.info("Executed SQL query for data transformation.")

    df_transformed = df_transformed.withColumn(
        "DIM_LOCATION_AREA_ID", sha2(concat_ws("||", "LOCATION_AREA_ABBREVIATION"), 256)
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "TAWZEA_MONTHLY_REPORT": DataFrame for TAWZEA_MONTHLY_REPORT.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_tawzea_monthly_report = source_dfs["TAWZEA_MONTHLY_REPORT"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark, df_tawzea_monthly_report=df_tawzea_monthly_report
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
