# pylint: disable = wrong-import-order, too-many-arguments, unused-argument, import-error, inconsistent-return-statements
"""
Module: mw_rw_tawzea_daily
Description: Process data from raw to curated for the mw_rw_tawzea_daily.
It contains the necessary functions and logic to create mw_rw_tawzea_daily table in curated.

Author: Abhishek Singh
Date: 29-10-2024
"""
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws
import logging
import os
import sys
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_dim_cr_ass_asset: DataFrame,
        df_fact_ws_eve_tawzea_daily_report: DataFrame,
) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "TAWZEA_MONTHLY_REPORT": DataFrame for TAWZEA_MONTHLY_REPORT.
            - "FACT_WS_EVE_TAWZEA_DAILY_REPORT": DataFrame for FACT_WS_EVE_TAWZEA_DAILY_REPORT.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    logging.info("Starting the transformation process.")

    df_dim_cr_ass_asset.show()
    df_fact_ws_eve_tawzea_daily_report.show()

    df_dim_cr_ass_asset.createOrReplaceTempView("dim_cr_ass_asset")
    df_fact_ws_eve_tawzea_daily_report.createOrReplaceTempView(
        "fact_ws_eve_tawzea_daily_report"
    )

    logging.info("Created temporary views for SQL operations.")

    logging.info("Executing SQL query for data transformation.")

    sql_query = """
                SELECT
                RECORD_DATE AS Date,
                ASSET_NAME AS StationName,
                OPENING_VOLUME AS OPENINGREADING_m3,
                CLOSING_VOLUME AS CLOSINGREADING_m3,
                PA_SUPPLY_VOLUME AS PublicAuthority_Consumption_m3,
                TOTAL_SALES_VOLUME AS TotalSales_m3,
                DUBA_PORT_SUPPLY_VOLUME AS DubaPort_Supply_m3,
                PA_NUMBER_OF_TANKER AS PublicAuthority_NumberOfTanker,
                TOTAL_NUMBER_OF_TANKER AS NumberOfTanker,
                SUPPLY_EXCLUDE_VOLUME AS EXCLUDE_CONSUMPTION_m3,
                COMMENTS
                FROM fact_ws_eve_tawzea_daily_report a
                LEFT JOIN
                dim_cr_ass_asset b on
                a.DIM_ASSET_ID = b.DIM_ASSET_ID
                """

    df_transformed = spark.sql(sqlQuery=sql_query)

    df_transformed.show()

    logging.info("Executed SQL query for data transformation.")

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "FACT_WS_EVE_TAWZEA_DAILY_REPORT": DataFrame for FACT_WS_EVE_TAWZEA_DAILY_REPORT.
            - "DIM_CR_ASS_ASSET": for DIM_CR_ASS_ASSET

    Returns:
        DataFrame: The transformed DataFrame.
    """

    logging.info("Starting the transformation process.")

    df_dim_cr_ass_asset = source_dfs["DIM_CR_ASS_ASSET"]
    df_fact_ws_eve_tawzea_daily_report = source_dfs["FACT_WS_EVE_TAWZEA_DAILY_REPORT"]

    # Perform joins, filters, etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_fact_ws_eve_tawzea_daily_report=df_fact_ws_eve_tawzea_daily_report,
        df_dim_cr_ass_asset=df_dim_cr_ass_asset,
    )

    logging.info("Transformation completed successfully..")

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
