# pylint:disable = unused-argument,import-error
"""
    This is the transformation file for FACT_WSR_EVE_SALES_DATA fact table
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_dim_cr_pro_service: DataFrame,
        df_dim_cr_agr_contract_stage: DataFrame,
        df_fact_wsr_eve_contract_result: DataFrame
) -> DataFrame:
    '''
        This function prepares the dataframe from the raw layer based on business logic.
    '''
    logging.info("Starting the transformation process.")

    # Register DataFrames as temporary views to use SQL syntax
    df_dim_cr_pro_service.createOrReplaceTempView("dim_cr_pro_service")
    df_dim_cr_agr_contract_stage.createOrReplaceTempView("dim_cr_agr_contract_stage")
    df_fact_wsr_eve_contract_result.createOrReplaceTempView("fact_wsr_eve_contract_result")

    # Perform the transformation using SQL query
    df_transformed = spark.sql("""
        WITH joined_df AS (
            SELECT 
                srv.SERVICE AS SERVICE_NAME,
                upper(stage.CONTRACT_STAGE) AS CONTRACT_STAGE,
                fact.CONTRACT_COUNT AS CONTRACT_COUNT
            FROM fact_wsr_eve_contract_result fact
            LEFT JOIN dim_cr_pro_service srv
                ON fact.DIM_SERVICE_ID = srv.DIM_SERVICE_ID AND srv.DOMAIN_TYPE = 'WSR'
            LEFT JOIN dim_cr_agr_contract_stage stage
                ON fact.DIM_CONTRACT_STAGE_ID = stage.DIM_CONTRACT_STAGE_ID AND stage.DOMAIN_TYPE = 'WSR'
        )
        SELECT 
            SERVICE_NAME AS REVENUE_STREAMS,
            CAST(SUM(CASE WHEN CONTRACT_STAGE = 'ACCEPTANCE' THEN CONTRACT_COUNT ELSE 0 END) AS FLOAT) AS ACCEPTANCE,
            CAST(SUM(CASE WHEN CONTRACT_STAGE = 'ASSESSMENT' THEN CONTRACT_COUNT ELSE 0 END) AS FLOAT) AS ASSESSMENT,
            CAST(SUM(CASE WHEN CONTRACT_STAGE = 'EXECUTED' THEN CONTRACT_COUNT ELSE 0 END) AS FLOAT) AS EXECUTED,
            CAST(SUM(CASE WHEN CONTRACT_STAGE = 'COMPLETED' THEN CONTRACT_COUNT ELSE 0 END) AS FLOAT) AS COMPLETED,
            CAST(SUM(CASE WHEN CONTRACT_STAGE = 'ARCHIVED' THEN CONTRACT_COUNT ELSE 0 END) AS FLOAT) AS ARCHIVED,
            CAST(SUM(CASE WHEN CONTRACT_STAGE = 'OPPORTUNITYINHAND' THEN CONTRACT_COUNT ELSE 0 END) AS FLOAT) AS OPPORTUNITY_IN_HAND,
            CAST(SUM(CASE WHEN CONTRACT_STAGE = 'OPPORTUNITYLOST' THEN CONTRACT_COUNT ELSE 0 END) AS FLOAT) AS OPPORTUNITY_LOST
        FROM joined_df
        GROUP BY SERVICE_NAME
        HAVING SERVICE_NAME IS NOT NULL;
    """)

    # Repartition DataFrame for better performance based on partition size
    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)
    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)
    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "DIM_CR_PRO_SERVICE": DataFrame for service data.
            - "DIM_CR_AGR_CONTRACT_STAGE": DataFrame for contract stage data.
            - "FACT_WSR_EVE_CONTRACT_RESULT": DataFrame for FACT_WSR_EVE_CONTRACT_RESULT data.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_dim_cr_pro_service = source_dfs["DIM_CR_PRO_SERVICE"]
    df_dim_cr_agr_contract_stage = source_dfs["DIM_CR_AGR_CONTRACT_STAGE"]
    df_fact_wsr_eve_contract_result = source_dfs["FACT_WSR_EVE_CONTRACT_RESULT"]

    # Apply transformations based on business logic
    transform_df = prepare_transformed_df(
        spark=spark,
        df_dim_cr_pro_service=df_dim_cr_pro_service,
        df_dim_cr_agr_contract_stage=df_dim_cr_agr_contract_stage,
        df_fact_wsr_eve_contract_result=df_fact_wsr_eve_contract_result
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def presentation_datavalidations(spark: SparkSession, spark_df):
    """
        function for data validation
    """
    logging.info("Spark session received for data validation: %s", spark)
    return spark_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    elif task_name == "adw_presentation_data_validations_checks":
        return presentation_datavalidations(spark, spark_df)
