# pylint:disable = unused-argument,import-error
"""
    This is the transformation file for MV_WSR_DATA materialized view.
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import upper, regexp_replace, col
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def normalize_variable_names(df: DataFrame) -> DataFrame:
    """
    Normalizes VARIABLE_NAME by removing spaces, slashes, hyphens,
    underscores, and converting to uppercase.
    """
    logging.info("Normalizing variable names for consistency.")
    if "VARIABLE_NAME" in df.columns:
        return df.withColumn(
            "VARIABLE_NAME_NORMALIZED",
            upper(
                regexp_replace(
                    regexp_replace(
                        regexp_replace(
                            regexp_replace(col("VARIABLE_NAME"), ' ', ''),
                            '/', ''
                        ),
                        '-', ''
                    ),
                    '_', ''
                )
            )
        )
    else:
        raise ValueError("VARIABLE_NAME column not found in DataFrame")


def prepare_transformed_df(
        spark: SparkSession,
        df_dim_cr_cus_customer: DataFrame,
        df_dim_cr_agr_contract: DataFrame,
        df_dim_cr_pro_service: DataFrame,
        df_fact_wsr_eve_sales_data: DataFrame,
        df_dim_cr_op_meas_variable: DataFrame,
        df_dim_cr_fin_invoice: DataFrame,
        df_dim_cr_agr_tariff: DataFrame
) -> DataFrame:
    '''
        This function prepares the MV_WSR_DATA materialized view from multiple curated datasets.
    '''
    logging.info("Starting the transformation process for MV_WSR_DATA.")

    # Normalize variable names
    df_dim_cr_op_meas_variable = normalize_variable_names(df_dim_cr_op_meas_variable)

    df_fact_wsr_eve_sales_data = df_fact_wsr_eve_sales_data.withColumn(
        "MEAS_VALUE",
        regexp_replace(col("MEAS_VALUE"), ",", "")  # .cast("float")
    )

    # Step 1: Create temp views for SQL transformations
    df_dim_cr_cus_customer.createOrReplaceTempView("dim_cr_cus_customer")
    df_dim_cr_agr_contract.createOrReplaceTempView("dim_cr_agr_contract")
    df_dim_cr_pro_service.createOrReplaceTempView("dim_cr_pro_service")
    df_fact_wsr_eve_sales_data.createOrReplaceTempView("fact_wsr_eve_sales_data")
    df_dim_cr_op_meas_variable.createOrReplaceTempView("dim_cr_op_meas_variable")
    df_dim_cr_fin_invoice.createOrReplaceTempView("dim_cr_fin_invoice")
    df_dim_cr_agr_tariff.createOrReplaceTempView("dim_cr_agr_tariff")

    # Step 2: Perform SQL transformations
    sql_query = """
        WITH joined_df AS (
            SELECT 
                f.FACT_WSR_EVE_SALES_DATA_ID,
                f.MEAS_VARIABLE_ID,
                f.DIM_CUSTOMER_ID,
                f.DIM_SERVICE_ID,
                f.DIM_CONTRACT_ID,
                f.DIM_INVOICE_ID,
                f.DIM_TARIFF_ID,
                f.SERVICE_YEAR,
                f.SERVICE_MONTH,
                f.NO_OF_DAYS,
                f.PERIOD_NAME,
                f.PERIOD_FROM,
                f.PERIOD_TO,
                f.MEAS_VALUE,
                f.NOTE,
                f.INVOICE_STATUS,
                f.COLLECTED_MONTH,
                f.COLLECTED_YEAR,
                f.COLLECTED_DATE,
                cc.CUSTOMER_NAME_EN,
                ps.SERVICE AS CONTRACT_TYPE,
                ac.CONTRACT_NO,
                fi.INVOICE_NO,
                fi.INVOICE_MONTH,
                fi.INVOICE_YEAR,
                fi.INVOICE_DATE,
                ta.VARIABLE_RATE,
                ta.TARIFF_RATE,
                ta.FIXED_RATE,
                mv.VARIABLE_NAME_NORMALIZED
            FROM fact_wsr_eve_sales_data f

            -- Join with DIM_CR_CUS_CUSTOMER using DIM_CUSTOMER_ID foreign key
            LEFT JOIN dim_cr_cus_customer cc
                ON f.DIM_CUSTOMER_ID = cc.DIM_CUSTOMER_ID AND cc.DOMAIN_TYPE = 'WSR'

            -- Join with DIM_CR_PRO_SERVICE using DIM_SERVICE_ID foreign key
            LEFT JOIN dim_cr_pro_service ps
                ON f.DIM_SERVICE_ID = ps.DIM_SERVICE_ID AND ps.DOMAIN_TYPE = 'WSR'

            -- Join with DIM_CR_AGR_CONTRACT using DIM_CONTRACT_ID foreign key
            LEFT JOIN dim_cr_agr_contract ac
                ON f.DIM_CONTRACT_ID = ac.DIM_CONTRACT_ID AND ac.DOMAIN_TYPE = 'WSR'

            -- Join with DIM_CR_FIN_INVOICE using DIM_INVOICE_ID foreign key
            LEFT JOIN dim_cr_fin_invoice fi
                ON f.DIM_INVOICE_ID = fi.DIM_INVOICE_ID AND fi.DOMAIN_TYPE = 'WSR'

            -- Join with DIM_CR_AGR_TARIFF using DIM_TARIFF_ID foreign key
            LEFT JOIN dim_cr_agr_tariff ta
                ON f.DIM_TARIFF_ID = ta.DIM_TARIFF_ID AND ta.DOMAIN_TYPE = 'WSR'

            -- Join with DIM_CR_OP_MEAS_VARIABLE using MEAS_VARIABLE_ID foreign key
            LEFT JOIN dim_cr_op_meas_variable mv
                ON f.MEAS_VARIABLE_ID = mv.MEAS_VARIABLE_ID AND mv.DOMAIN_TYPE = 'WSR'
        )
        SELECT *
        FROM joined_df

    """
    logging.info("printing the transformation process for df_joined")

    df_joined = spark.sql(sql_query)
    df_joined.createOrReplaceTempView("joined_data")

    # Step 3: Perform pivot operation using SQL
    sql_pivot_query = """
        SELECT
            CUSTOMER_NAME_EN AS CUSTOMER_NAME,
            CONTRACT_NO AS CONTRACT_NO,
            CONTRACT_TYPE AS CONTRACT_TYPE,
            CONCAT(SERVICE_MONTH, '-', CAST(SERVICE_YEAR AS INT)) AS MONTHYEAR,
            TO_DATE(
                CONCAT('1900-', SERVICE_MONTH, '-01'), 
                'yyyy-MMM-dd'
            ) AS MONTH_SORT_DATE,
            TO_DATE(
                CONCAT('01-', SUBSTR(PERIOD_NAME, 1, 6)), 
                'dd-MMM-yy'
            ) AS PERIOD_NAME_SORT_DATE,
            CASE WHEN INVOICE_NO IS NOT NULL 
                THEN CONCAT(PERIOD_NAME, ' / ', CAST(INVOICE_NO AS VARCHAR(255))) 
                ELSE '' 
            END AS PERIOD_NAME_AND_INVOICE_NUMBER,
            CASE WHEN INVOICE_MONTH != '' 
                THEN TO_DATE(
                    CONCAT('01-', INVOICE_MONTH, '-1990'), 
                    'd-MMM-yyyy'
                ) 
                ELSE NULL 
            END AS INVOICE_MONTH_SORT_DATE,
            SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED  = 'DAYSOUTSTANDINGSALES' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) AS DAYS_OF_SALES_OUTSTANDING,
            SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED  = 'CURRYEARREVNOTINVOICED' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) AS CURRENT_YEAR_REVENUE_NOT_INVOICED,
            SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED  = 'LASTYEARREVNOTINVOICED' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) AS PREVIOUS_YEAR_REVENUE_NOT_INVOICED,
            SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED  = 'REVENUENOTINVOICED' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) AS REVENUE_NOT_INVOICED,
            SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED  = 'OUTSTANDINGAGING' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) AS OUTSTANDING_AGING,
            SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED  = 'OUTSTANDINGAMOUNT' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) AS OUTSTANDING,
            CASE 
                WHEN INVOICE_STATUS = 'Received' THEN 'Collected'
                WHEN INVOICE_STATUS = 'O/S' THEN 'Outstanding'
                ELSE INVOICE_STATUS
            END AS INVOICE_STATUS,
            INVOICE_NO AS INVOICE_NUMBER,
            INVOICE_MONTH AS INVOICE_MONTH,
            CAST(INVOICE_YEAR AS INT) AS INVOICE_YEAR,
            TO_DATE(INVOICE_DATE, 'd-MMM-yy') AS INVOICE_DATE,
            SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED  = 'TOTALVARIABLECOST' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) AS TOTAL_VARIABLE_COST_SAR,
            VARIABLE_RATE AS VARIABLE_COST_RATE_SAR_PER_M3,
            SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED  = 'TOTALFIXEDFEECOST' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) AS TOTAL_FIXED_FEE_COST_SAR,
            SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED  = 'DAILYFIXEDFEECOST' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) AS DAILY_FIXED_FEE_COST_SAR_PER_DAY,
            SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED  = 'COMMITTEDQUANTITY' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) AS COMMITTED_QUANTITY_M3,
            NOTE AS NOTES,
            SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED  = 'GROSSTOTALSALES' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) AS GROSS_TOTAL_SALES_SAR,
            SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED  = 'VAT' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) AS VAT,
            SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED  = 'NETTOTALSALES' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) AS NET_TOTAL_SALES_SAR,
            TARIFF_RATE AS RATE,
            NO_OF_DAYS AS NO_OF_DAYS,
            TO_DATE(Period_To, 'd-MMM-yy') AS PERIOD_TO,
            TO_DATE(Period_From, 'd-MMM-yy') AS PERIOD_FROM,
            PERIOD_NAME AS PERIOD_NAME,
            SERVICE_MONTH AS SERVICE_MONTH,
            CAST(SERVICE_YEAR AS INT) AS SERVICE_YEAR,
            TO_DATE(
                CONCAT(
                    '01-',
                    COLLECTED_MONTH,
                    '-',
                    CAST(CAST(COLLECTED_YEAR AS INT) AS VARCHAR(4))
                ),
                'dd-MMM-yyyy'
            ) AS PAYMENT_PERIOD_SORT_DATE,
            CONCAT(
                COLLECTED_MONTH, 
                '-', 
                CAST(CAST(COLLECTED_YEAR AS INT) AS VARCHAR(4))
            ) AS PAYMENT_PERIOD_MONTH_YEAR,
            SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED = 'WATERSALESVOLUMEQUANTITYSUPPLIED' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) AS WATER_SALES_VOLUME_QUANTITY_SUPPLIED_M3,
            TO_DATE(COLLECTED_DATE, 'd-MMM-yy') AS COLLECTED_DATE,
            CAST(COLLECTED_YEAR AS INT) AS COLLECTED_YEAR,
            COLLECTED_MONTH AS COLLECTED_MONTH,
            SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED  = 'COLLECTEDAMOUNT' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) AS COLLECTED_AMOUNT,
            FIXED_RATE AS FIXED_COST_RATE_SAR_PER_M3, 
            CASE WHEN SUM(CASE 
                    WHEN VARIABLE_NAME_NORMALIZED  = 'COLLECTEDAMOUNT' 
                    THEN MEAS_VALUE 
                    ELSE 0 
                END) > 0 THEN 'Collected'
                WHEN SUM(CASE 
                        WHEN VARIABLE_NAME_NORMALIZED = 'OUTSTANDINGAMOUNT' 
                        THEN MEAS_VALUE 
                        ELSE 0 
                    END) > 0 THEN 'Outstanding'
                WHEN SUM(CASE 
                        WHEN VARIABLE_NAME_NORMALIZED  = 'REVENUENOTINVOICED' 
                        THEN MEAS_VALUE 
                        ELSE 0 
                    END) > 0 THEN 'Revenue Not Invoiced'
                ELSE NULL
            END AS ACCOUNT_RECEIVABLE_STATUS
        FROM joined_data
        GROUP BY
            CUSTOMER_NAME_EN,
            CONTRACT_NO,
            CONTRACT_TYPE,
            SERVICE_MONTH,
            SERVICE_YEAR,
            PERIOD_NAME,
            INVOICE_NO,
            INVOICE_MONTH,
            INVOICE_STATUS,
            INVOICE_YEAR,
            INVOICE_DATE,
            VARIABLE_RATE,
            FIXED_RATE,
            TARIFF_RATE,
            NO_OF_DAYS,
            PERIOD_TO,
            PERIOD_FROM,
            NOTE,
            SERVICE_MONTH,
            SERVICE_YEAR,
            TO_DATE(COLLECTED_DATE, 'd-MMM-yy'),
            COLLECTED_YEAR,
            COLLECTED_MONTH
    """
    df_pivoted = spark.sql(sql_pivot_query)
    df_pivoted.createOrReplaceTempView("df_pivoted")

    # Repartition DataFrame for better performance based on partition size
    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_pivoted, max_partition_size_mb)
    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)
    df_transformed = df_pivoted.repartition(num_partitions)

    return df_transformed


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "DIM_CR_CUS_CUSTOMER": DataFrame for customer data.
            - "DIM_CR_AGR_CONTRACT": DataFrame for contract data.
            - "DIM_CR_PRO_SERVICE": DataFrame for service data.
            - "FACT_WSR_EVE_SALES_DATA": DataFrame for sales data.
            - "DIM_CR_OP_MEAS_VARIABLE": DataFrame for operational measurement variables.
            - "DIM_CR_FIN_INVOICE": DataFrame for invoice data.
            - "DIM_CR_AGR_TARIFF": DataFrame for tariff data.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_dim_cr_cus_customer = source_dfs["DIM_CR_CUS_CUSTOMER"]
    df_dim_cr_agr_contract = source_dfs["DIM_CR_AGR_CONTRACT"]
    df_dim_cr_pro_service = source_dfs["DIM_CR_PRO_SERVICE"]
    df_fact_wsr_eve_sales_data = source_dfs["FACT_WSR_EVE_SALES_DATA"]
    df_dim_cr_op_meas_variable = source_dfs["DIM_CR_OP_MEAS_VARIABLE"]
    df_dim_cr_fin_invoice = source_dfs["DIM_CR_FIN_INVOICE"]
    df_dim_cr_agr_tariff = source_dfs["DIM_CR_AGR_TARIFF"]

    # Apply transformations based on business logic
    transform_df = prepare_transformed_df(
        spark=spark,
        df_dim_cr_cus_customer=df_dim_cr_cus_customer,
        df_dim_cr_agr_contract=df_dim_cr_agr_contract,
        df_dim_cr_pro_service=df_dim_cr_pro_service,
        df_fact_wsr_eve_sales_data=df_fact_wsr_eve_sales_data,
        df_dim_cr_op_meas_variable=df_dim_cr_op_meas_variable,
        df_dim_cr_fin_invoice=df_dim_cr_fin_invoice,
        df_dim_cr_agr_tariff=df_dim_cr_agr_tariff
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df is not None:
        # Log the schema of spark_df if it's not None
        logging.info("Schema of spark_df:\n%s", spark_df.schema.simpleString())
    else:
        logging.warning("spark_df is None; skipping schema logging.")
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
