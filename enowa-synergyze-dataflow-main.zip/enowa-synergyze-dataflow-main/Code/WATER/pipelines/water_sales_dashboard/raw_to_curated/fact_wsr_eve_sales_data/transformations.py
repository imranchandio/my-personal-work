# pylint:disable = unused-argument,import-error
"""
    This is the transformation file for FACT_WSR_EVE_SALES_DATA fact table
"""
import logging
import os
import sys
from datetime import datetime
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import lit
from pyspark.sql.types import DoubleType
from pyspark.sql import functions as F
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")

# Define a function to add missing columns with default null values of specified type
def ensure_columns(df: DataFrame, columns: list, dtype: str) -> DataFrame:
    """
    Ensures that the specified columns exist in the DataFrame. 
    If any of the specified columns are missing,
    they are added with all values set as null, cast to the specified data type.

    Parameters:
    df (DataFrame): The DataFrame to modify.
    columns (list): A list of column names to check and ensure in the DataFrame.
    dtype (str): The data type to which the column should be cast if it is added.

    Returns:
    DataFrame: The modified DataFrame with the ensured columns.
    """
    for column in columns:
        if column not in df.columns:
            df = df.withColumn(column, lit(None).cast(dtype))
    return df


def prepare_transformed_df(
        spark: SparkSession,
        df_database: DataFrame,
        df_dim_cr_fin_tax_charge: DataFrame,
        df_dim_cr_op_meas_variable: DataFrame,
        df_dim_cr_cus_customer: DataFrame,
        df_dim_cr_pro_service: DataFrame,
        df_dim_cr_agr_contract: DataFrame,
        df_dim_cr_fin_invoice: DataFrame,
        df_dim_cr_agr_tariff: DataFrame
) -> DataFrame:
    '''
        This function prepares the dataframe from the raw layer based on business logic.
    '''
    logging.info("Starting the transformation process.")

    df_database = df_database.withColumn(
        "PERIODTO_PARSED",
        F.to_date(F.col("PERIODTO"), "d-MMM-yy")
    )

    df_database = df_database.withColumn(
        "INVOICE_DATE_PARSED",
        F.to_date(F.col("INVOICEDATE"), "d-MMM-yy")
    )

    df_dim_cr_fin_invoice = df_dim_cr_fin_invoice.withColumn(
        "INVOICE_DATE_PARSED",
        F.to_date(F.col("INVOICE_DATE"), "d-MMM-yy")
    )

    # Ensure all required columns are present by adding missing ones as null placeholders
    required_columns = [
        "WATERSALESVOLUMEQUANTITYSUPPLIEDM3", "NETTOTALSALESSAR", "VAT", "GROSSTOTALSALESSAR",
        "COLLECTEDAMOUNT", "OUTSTANDING", "OUTSTANDINGAGING", "REVENUENOTINVOICED",
        "PREVIOUSYEARREVENUENOTINVOICED", "CURRENTYEARREVENUENOTINVOICED", "DAYSOFSALESOUTSTANDING",
        "COMMITTEDQUANTITYM3", "DAILYFIXEDFEECOSTSARDAY", "TOTALFIXEDFEECOSTSAR",
        "TOTALVARIABLECOSTSAR"
    ]
    df_database = ensure_columns(df_database, required_columns, DoubleType())

    # Step 1: Set up temp views for SQL queries
    df_database.createOrReplaceTempView("DATABASE_SOURCE")
    df_dim_cr_fin_tax_charge.createOrReplaceTempView("DIM_CR_FIN_TAX_CHARGE_WSR")
    df_dim_cr_cus_customer.createOrReplaceTempView("DIM_CR_CUS_CUSTOMER_WSR")
    df_dim_cr_pro_service.createOrReplaceTempView("DIM_CR_PRO_SERVICE_WSR")
    df_dim_cr_agr_contract.createOrReplaceTempView("DIM_CR_AGR_CONTRACT_WSR")
    df_dim_cr_fin_invoice.createOrReplaceTempView("DIM_CR_FIN_INVOICE_WSR")
    df_dim_cr_op_meas_variable.createOrReplaceTempView("DIM_CR_OP_MEAS_VARIABLE")

    # List of required tariff columns with expected data type
    required_tariff_columns = ["VARIABLE_RATE", "FIXED_RATE"]
    # Apply the function to df_dim_cr_agr_tariff DataFrame
    df_dim_cr_agr_tariff = ensure_columns(df_dim_cr_agr_tariff, \
                                          required_tariff_columns, DoubleType())
    df_dim_cr_agr_tariff.createOrReplaceTempView("DIM_CR_AGR_TARIFF_WSR")

    # Step 2: Execute the initial join query with TAX_CHARGE table
    # and other dims (excluding MEAS_VARIABLE)
    sql_query_tax_charge = """
        SELECT
            ws.CONTRACTNO AS CONTRACT_NO,
            ws.CUSTOMERNAME AS CUSTOMER_NAME,
            ws.YEAR AS SERVICE_YEAR,
            ws.MONTH AS SERVICE_MONTH,
            ws.INVOICESTATUS AS INVOICE_STATUS,
            ws.PERIODNAME AS PERIOD_NAME,
            ws.PERIODFROM AS PERIOD_FROM,
            ws.PERIODTO AS PERIOD_TO,
            ws.NOOFDAYS AS NO_OF_DAYS,
            ws.INVOICEYEAR AS INVOICE_YEAR,
            ws.INVOICEMONTH AS INVOICE_MONTH,
            ws.COLLECTEDDATE AS COLLECTED_DATE,
            ws.COLLECTEDYEAR AS COLLECTED_YEAR,
            ws.COLLECTEDMONTH AS COLLECTED_MONTH,
            ws.NOTES AS NOTE,
            ws.WATERSALESVOLUMEQUANTITYSUPPLIEDM3,
            ws.NETTOTALSALESSAR,
            ws.VAT,
            ws.GROSSTOTALSALESSAR,
            ws.COLLECTEDAMOUNT,
            ws.OUTSTANDING, 
            ws.OUTSTANDINGAGING,
            ws.REVENUENOTINVOICED, 
            ws.PREVIOUSYEARREVENUENOTINVOICED, 
            ws.CURRENTYEARREVENUENOTINVOICED,
            ws.DAYSOFSALESOUTSTANDING,
            ws.COMMITTEDQUANTITYM3, 
            ws.DAILYFIXEDFEECOSTSARDAY,
            ws.TOTALFIXEDFEECOSTSAR, 
            ws.TOTALVARIABLECOSTSAR,
            tc.DIM_TAX_CHARGE_ID,
            cc.DIM_CUSTOMER_ID,
            ps.DIM_SERVICE_ID,
            ac.DIM_CONTRACT_ID,
            fi.DIM_INVOICE_ID,
            ta.DIM_TARIFF_ID
        FROM DATABASE_SOURCE ws
        LEFT JOIN DIM_CR_FIN_TAX_CHARGE_WSR tc
            ON (
                ((ws.PERIODTO_PARSED > DATE '2020-07-01' AND tc.TAX_CHARGE_RATE = '15' AND tc.TAX_CHARGE_TYPE = 'VAT')
                OR (ws.PERIODTO_PARSED <= DATE '2020-07-01' AND tc.TAX_CHARGE_RATE = '5' AND tc.TAX_CHARGE_TYPE = 'VAT'))
                AND tc.DOMAIN_TYPE = 'WSR'
            )
        LEFT JOIN DIM_CR_CUS_CUSTOMER_WSR cc
            ON ws.CUSTOMERNAME = cc.CUSTOMER_NAME_EN AND ws.CONTRACTNO = cc.CUSTOMER_NO AND  cc.DOMAIN_TYPE = 'WSR'
        LEFT JOIN DIM_CR_PRO_SERVICE_WSR ps
            ON ws.CONTRACTTYPE = ps.SERVICE AND ps.DOMAIN_TYPE = 'WSR'
        LEFT JOIN DIM_CR_AGR_CONTRACT_WSR ac
            ON ws.CONTRACTNO = ac.CONTRACT_NO AND ps.DIM_SERVICE_ID = ac.DIM_SERVICE_ID AND ac.DOMAIN_TYPE = 'WSR'
        LEFT JOIN DIM_CR_FIN_INVOICE_WSR fi
            ON ws.INVOICE_DATE_PARSED = fi.INVOICE_DATE_PARSED AND ws.INVOICENUMBER = fi.INVOICE_NO AND fi.DOMAIN_TYPE = 'WSR'
        LEFT JOIN DIM_CR_AGR_TARIFF_WSR ta
            ON ws.RATE = ta.TARIFF_RATE 
            AND ws.FIXEDCOSTSARM3 = ta.FIXED_RATE
            AND ws.VARIABLECOSTRATESARM3 = ta.VARIABLE_RATE
            AND ps.DIM_SERVICE_ID = ta.DIM_SERVICE_ID
            AND ta.DOMAIN_TYPE = 'WSR'
    """

    df_with_tax_charge = spark.sql(sql_query_tax_charge)
    df_with_tax_charge.createOrReplaceTempView("df_with_tax_charge")
    logging.info("Step 2.1: Completed join with TAX_CHARGE table")

    # Step 3: Apply unpivot logic
    df_unpivoted = df_with_tax_charge.select(
        "CONTRACT_NO",
        "CUSTOMER_NAME",
        "SERVICE_YEAR",
        "SERVICE_MONTH",
        "INVOICE_STATUS",
        "PERIOD_NAME",
        "PERIOD_FROM",
        "PERIOD_TO",
        "NO_OF_DAYS",
        "INVOICE_YEAR",
        "INVOICE_MONTH",
        "COLLECTED_DATE",
        "COLLECTED_YEAR",
        "COLLECTED_MONTH",
        "NOTE",
        "DIM_TAX_CHARGE_ID",
        "DIM_CUSTOMER_ID",
        "DIM_SERVICE_ID",
        "DIM_CONTRACT_ID",
        "DIM_INVOICE_ID",
        "DIM_TARIFF_ID",
        F.explode(F.array(
            F.struct(F.lit("Water Sales Volume/Quantity Supplied").alias("VARIABLE_NAME"),
                     df_with_tax_charge["WATERSALESVOLUMEQUANTITYSUPPLIEDM3"].alias("MEAS_VALUE")),
            F.struct(F.lit("Net Total Sales").alias("VARIABLE_NAME"),
                     df_with_tax_charge["NETTOTALSALESSAR"].alias("MEAS_VALUE")),
            F.struct(F.lit("VAT").alias("VARIABLE_NAME"),
                     df_with_tax_charge["VAT"].alias("MEAS_VALUE")),
            F.struct(F.lit("Gross Total Sales").alias("VARIABLE_NAME"),
                     df_with_tax_charge["GROSSTOTALSALESSAR"].alias("MEAS_VALUE")),
            F.struct(F.lit("COLLECTED_AMOUNT").alias("VARIABLE_NAME"),
                     df_with_tax_charge["COLLECTEDAMOUNT"].alias("MEAS_VALUE")),
            F.struct(F.lit("OUTSTANDING_AMOUNT").alias("VARIABLE_NAME"),
                     df_with_tax_charge["OUTSTANDING"].alias("MEAS_VALUE")),
            F.struct(F.lit("OUTSTANDING_AGING").alias("VARIABLE_NAME"),
                     df_with_tax_charge["OUTSTANDINGAGING"].alias("MEAS_VALUE")),
            F.struct(F.lit("REVENUE_NOT_INVOICED").alias("VARIABLE_NAME"),
                     df_with_tax_charge["REVENUENOTINVOICED"].alias("MEAS_VALUE")),
            F.struct(F.lit("LAST_YEAR_REV_NOT_INVOICED").alias("VARIABLE_NAME"),
                     df_with_tax_charge["PREVIOUSYEARREVENUENOTINVOICED"].alias("MEAS_VALUE")),
            F.struct(F.lit("CURR_YEAR_REV_NOT_INVOICED").alias("VARIABLE_NAME"),
                     df_with_tax_charge["CURRENTYEARREVENUENOTINVOICED"].alias("MEAS_VALUE")),
            F.struct(F.lit("DAYS_OUTSTANDING_SALES").alias("VARIABLE_NAME"),
                     df_with_tax_charge["DAYSOFSALESOUTSTANDING"].alias("MEAS_VALUE")),
            F.struct(F.lit("Committed Quantity").alias("VARIABLE_NAME"),
                     df_with_tax_charge["COMMITTEDQUANTITYM3"].alias("MEAS_VALUE")),
            F.struct(F.lit("Daily Fixed Fee Cost").alias("VARIABLE_NAME"),
                     df_with_tax_charge["DAILYFIXEDFEECOSTSARDAY"].alias("MEAS_VALUE")),
            F.struct(F.lit("Total Fixed Fee Cost").alias("VARIABLE_NAME"),
                     df_with_tax_charge["TOTALFIXEDFEECOSTSAR"].alias("MEAS_VALUE")),
            F.struct(F.lit("Total Variable Cost").alias("VARIABLE_NAME"),
                     df_with_tax_charge["TOTALVARIABLECOSTSAR"].alias("MEAS_VALUE"))

        )).alias("VARIABLES")
    ).select(
        "CONTRACT_NO",
        "CUSTOMER_NAME",
        "SERVICE_YEAR",
        "SERVICE_MONTH",
        "INVOICE_STATUS",
        "PERIOD_NAME",
        "PERIOD_FROM",
        "PERIOD_TO",
        "NO_OF_DAYS",
        "INVOICE_YEAR",
        "INVOICE_MONTH",
        "COLLECTED_DATE",
        "COLLECTED_YEAR",
        "COLLECTED_MONTH",
        "NOTE",
        "VARIABLES.VARIABLE_NAME",
        "VARIABLES.MEAS_VALUE",
        "DIM_TAX_CHARGE_ID",
        "DIM_CUSTOMER_ID",
        "DIM_SERVICE_ID",
        "DIM_CONTRACT_ID",
        "DIM_INVOICE_ID",
        "DIM_TARIFF_ID"
    )

    df_unpivoted.createOrReplaceTempView("df_unpivoted")

    # Perform the join using Spark SQL
    join_query = """
    SELECT 
        unpvt.*,
        op_meas.MEAS_VARIABLE_ID AS MEAS_VARIABLE_ID,
        op_meas.VARIABLE_NAME AS VARIABLE_NAME
    FROM 
        df_unpivoted AS unpvt
    LEFT JOIN 
        DIM_CR_OP_MEAS_VARIABLE AS op_meas
    ON 
        UPPER(REPLACE(REPLACE(REPLACE(unpvt.VARIABLE_NAME, ' ', ''), '/', ''), '-', '')) =
        UPPER(REPLACE(REPLACE(REPLACE(op_meas.VARIABLE_NAME, ' ', ''), '/', ''), '-', ''))
        AND op_meas.DOMAIN_TYPE = 'WSR'
    """
    df_final = spark.sql(join_query)
    df_final.createOrReplaceTempView("df_final")

    # Step 2: Generate the primary key (FACT_WSR_EVE_SALES_DATA_ID) and apply other business logic
    # DIM_CUSTOMER_ID, DIM_SERVICE_ID, DIM_CONTRACT_ID,
    # DIM_INVOICE_ID, DIM_TARIFF_ID, SERVICE_YEAR, SERVICE_MONTH, INVOICE_STATUS - 15 distinct
    sql_query_step_2 = """
        SELECT
            sha2(concat_ws('||', MEAS_VARIABLE_ID, DIM_CUSTOMER_ID, DIM_SERVICE_ID, DIM_CONTRACT_ID, 
                           DIM_INVOICE_ID, DIM_TARIFF_ID, SERVICE_YEAR, SERVICE_MONTH, INVOICE_STATUS), 256) 
                           AS FACT_WSR_EVE_SALES_DATA_ID,
            DIM_TAX_CHARGE_ID,
            MEAS_VARIABLE_ID,
            DIM_CUSTOMER_ID,
            DIM_SERVICE_ID,
            DIM_CONTRACT_ID,
            DIM_INVOICE_ID,
            DIM_TARIFF_ID,
            SERVICE_YEAR,
            SERVICE_MONTH,
            INVOICE_STATUS,
            PERIOD_NAME,
            PERIOD_FROM,
            PERIOD_TO,
            MEAS_VALUE,
            NO_OF_DAYS,
            INVOICE_YEAR,
            INVOICE_MONTH,
            COLLECTED_DATE,
            COLLECTED_YEAR,
            COLLECTED_MONTH,
            NOTE,
            current_timestamp() AS LAST_UPDATED_DATE,
            current_timestamp() AS CREATED_DATE,
            'WSR_PARTITION' AS PARTITION_KEY
        FROM df_final
    """
    df_transformed = spark.sql(sql_query_step_2)

    # Repartition DataFrame for better performance based on partition size
    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)
    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)
    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "DATABASE": DataFrame for raw data from the water sales dashboard.
            - "DIM_CR_FIN_TAX_CHARGE": DataFrame for tax charge data.
            - "DIM_CR_OP_MEAS_VARIABLE": DataFrame for measurement variable data.
            - "DIM_CR_CUS_CUSTOMER": DataFrame for customer data.
            - "DIM_CR_PRO_SERVICE": DataFrame for service data.
            - "DIM_CR_AGR_CONTRACT": DataFrame for contract data.
            - "DIM_CR_FIN_INVOICE": DataFrame for invoice data.
            - "DIM_CR_AGR_TARIFF": DataFrame for tariff data.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_database = source_dfs["DATABASE"]
    df_dim_cr_fin_tax_charge = source_dfs["DIM_CR_FIN_TAX_CHARGE"]
    df_dim_cr_op_meas_variable = source_dfs["DIM_CR_OP_MEAS_VARIABLE"]
    df_dim_cr_cus_customer = source_dfs["DIM_CR_CUS_CUSTOMER"]
    df_dim_cr_pro_service = source_dfs["DIM_CR_PRO_SERVICE"]
    df_dim_cr_agr_contract = source_dfs["DIM_CR_AGR_CONTRACT"]
    df_dim_cr_fin_invoice = source_dfs["DIM_CR_FIN_INVOICE"]
    df_dim_cr_agr_tariff = source_dfs["DIM_CR_AGR_TARIFF"]

    # Apply transformations based on business logic
    transform_df = prepare_transformed_df(
        spark=spark,
        df_database=df_database,
        df_dim_cr_fin_tax_charge=df_dim_cr_fin_tax_charge,
        df_dim_cr_op_meas_variable=df_dim_cr_op_meas_variable,
        df_dim_cr_cus_customer=df_dim_cr_cus_customer,
        df_dim_cr_pro_service=df_dim_cr_pro_service,
        df_dim_cr_agr_contract=df_dim_cr_agr_contract,
        df_dim_cr_fin_invoice=df_dim_cr_fin_invoice,
        df_dim_cr_agr_tariff=df_dim_cr_agr_tariff
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df is not None:
        # Log the schema of spark_df if it's not None
        logging.info("Schema of spark_df:\n%s", spark_df.schema.simpleString())
    else:
        logging.warning("spark_df is None; skipping schema logging.")
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
