# pylint:disable = unused-argument,import-error
"""
    This is the transformation file for dim_cr_cus_customer dimension
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_database: DataFrame
) -> DataFrame:
    '''
        This function prepares the dataframe from the raw layer based on business logic.
    '''
    logging.info("Starting the transformation process.")

    # Create temp views to use SQL on DataFrames
    df_database.createOrReplaceTempView("database")

    # Step 1: Join the data from water sales with the service mapping table
    sql_query_step_1 = """
        SELECT
            sha2(concat_ws('||', ws.CONTRACTNO, ws.CUSTOMERNAME), 256) AS DIM_CUSTOMER_ID,
            ws.CONTRACTNO AS CUSTOMER_NO,
            NULL AS CUSTOMER_NAME_AR,
            ws.CUSTOMERNAME AS CUSTOMER_NAME_EN,
            'Water Supply' AS CUSTOMER_TYPE,
            current_timestamp() AS LAST_UPDATED_DATE,
            current_timestamp() AS CREATED_DATE,
            'WSR' AS DOMAIN_TYPE,
            'WSR_PARTITION' AS PARTITION_KEY
        FROM database ws
    """
    df_transformed = spark.sql(sql_query_step_1)
    logging.info("Step 1: Transformed data according to business logic")

    # Repartition DataFrame for better performance based on partition size
    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)
    return df_transformed


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "DATABASE": DataFrame for raw data DATABASE.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_database = source_dfs["DATABASE"]

    # Apply transformations based on business logic
    transform_df = prepare_transformed_df(
        spark=spark,
        df_database=df_database,
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print("spark_df schema:", spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
