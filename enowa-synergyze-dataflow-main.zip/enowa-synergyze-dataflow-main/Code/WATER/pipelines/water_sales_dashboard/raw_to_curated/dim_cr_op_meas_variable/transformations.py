# pylint:disable = unused-argument, import-error
"""
    This is the transformation file for dim_cr_op_meas_variable dimension
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, current_timestamp, col
from pyspark.sql.types import StructType, StructField, StringType
from common_utils import calculate_num_partitions, impose_schema

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")

# Define constants
SALES_VARIABLE = "Sales Variable"
FINANCIAL_VARIABLE = "Financial Variable"
TAX_VARIABLE = "Tax Variable"


def transform(
        spark: SparkSession
) -> DataFrame:
    '''
        This function prepares the dataframe from the raw data.
    '''
    logging.info("Starting the transformation process using business logic.")

    schema = StructType(
        [
            StructField("VARIABLE_NAME", StringType(), True),
            StructField("VARIABLE_UNIT", StringType(), True),
            StructField("VARIABLE_TYPE", StringType(), True),
            StructField("VARIABLE_DETAIL", StringType(), True),
            StructField("VARIABLE_CALCULATION", StringType(), True),
            StructField("VARIABLE_CODE", StringType(), True),
            StructField("VARIABLE_SIGNIFICANCE", StringType(), True),
            StructField("DATA_OWNER", StringType(), True),
            StructField("DOMAIN_TYPE", StringType(), True),
            StructField("PARTITION_KEY", StringType(), True)
        ]
    )

    data = [
        ("Water Sales Volume/Quantity Supplied", "m3", SALES_VARIABLE, SALES_VARIABLE,
         None, None, None, None, "WSR", "WSR_PARTITION"),
        ("Net Total Sales", "SAR", SALES_VARIABLE, SALES_VARIABLE,
         None, None, None, None, "WSR", "WSR_PARTITION"),
        ("VAT", "SAR", TAX_VARIABLE, TAX_VARIABLE, None, None,
         None, None, "WSR", "WSR_PARTITION"),
        ("Gross Total Sales", "SAR", SALES_VARIABLE, SALES_VARIABLE,
         None, None, None, None, "WSR", "WSR_PARTITION"),
        ("COLLECTED_AMOUNT", "SAR", SALES_VARIABLE, SALES_VARIABLE,
         None, None, None, None, "WSR", "WSR_PARTITION"),
        ("OUTSTANDING_AMOUNT", "SAR", FINANCIAL_VARIABLE, FINANCIAL_VARIABLE,
         None, None, None, None, "WSR", "WSR_PARTITION"),
        ("OUTSTANDING_AGING", None, SALES_VARIABLE, SALES_VARIABLE, None, None,
         None, None, "WSR", "WSR_PARTITION"),
        ("REVENUE_NOT_INVOICED", "SAR", FINANCIAL_VARIABLE, FINANCIAL_VARIABLE,
         None, None, None, None, "WSR", "WSR_PARTITION"),
        ("LAST_YEAR_REV_NOT_INVOICED", "SAR", FINANCIAL_VARIABLE, FINANCIAL_VARIABLE,
         None, None, None, None, "WSR", "WSR_PARTITION"),
        ("CURR_YEAR_REV_NOT_INVOICED", "SAR", FINANCIAL_VARIABLE, FINANCIAL_VARIABLE,
         None, None, None, None, "WSR", "WSR_PARTITION"),
        ("DAYS_OUTSTANDING_SALES", None, SALES_VARIABLE, SALES_VARIABLE, None, None,
         None, None, "WSR", "WSR_PARTITION"),
        ("Committed Quantity", "m3", SALES_VARIABLE, SALES_VARIABLE, None, None, None,
         None, "WSR", "WSR_PARTITION"),
        ("Daily Fixed Fee Cost", "SAR/Day", FINANCIAL_VARIABLE, FINANCIAL_VARIABLE,
         None, None, None, None, "WSR", "WSR_PARTITION"),
        ("Total Fixed Fee Cost", "SAR", FINANCIAL_VARIABLE, FINANCIAL_VARIABLE, None,
         None, None, None, "WSR", "WSR_PARTITION"),
        ("Total Variable Cost", "SAR", FINANCIAL_VARIABLE, FINANCIAL_VARIABLE, None,
         None, None, None, "WSR", "WSR_PARTITION")
        # Add more rows here as needed based on the business logic
    ]

    # Create DataFrame
    df = spark.createDataFrame(data, schema)

    # add pk column
    df_transformed = df.withColumn(
        "MEAS_VARIABLE_ID",
        sha2(col("VARIABLE_NAME").cast("string"), 256)
    ).withColumn(
        "LAST_UPDATED_DATE", current_timestamp()
    ).withColumn(
        "CREATED_DATE", current_timestamp()
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed.distinct()


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """

    transformed_df: DataFrame = transform(spark=spark)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df is not None:
        # Log the schema of spark_df if it's not None
        logging.info("Schema of spark_df:\n%s", spark_df.schema.simpleString())
    else:
        logging.warning("spark_df is None; skipping schema logging.")

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
