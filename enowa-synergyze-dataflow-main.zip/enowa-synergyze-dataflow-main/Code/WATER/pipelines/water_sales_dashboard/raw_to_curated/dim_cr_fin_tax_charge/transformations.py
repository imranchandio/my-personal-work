# pylint:disable = unused-argument,import-error
"""
    This is the transformation file for dim_cr_cus_customer dimension
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def transform(
        spark: SparkSession
) -> DataFrame:
    '''
        This function prepares the dataframe from the raw layer based on business logic.
    '''
    logging.info("Starting the transformation process.")

    # Step 1: Create a DataFrame with hardcoded values and add the necessary columns
    hardcoded_data = [('15', "VAT", "Water", "Water Supply", "for 15 : >Jul 2020 % taxrate"),
                      ('5', "VAT", "Water", "Water Supply", "for 5 : <Jul 2020 % taxrate")]

    columns = ["TAX_CHARGE_RATE", "TAX_CHARGE_TYPE", "TAX_CHARGE_DOMAIN",
               "TAX_CHARGE_SUB_DOMAIN", "TAX_CHARGE_DETAIL"]
    df_temp = spark.createDataFrame(hardcoded_data, columns)
    df_temp.createOrReplaceTempView("tax_charge_data")

    # Step 2: Use SQL to format columns and add calculated values
    sql_query = """
        SELECT 
            sha2(TAX_CHARGE_RATE, 256) AS DIM_TAX_CHARGE_ID,
            TAX_CHARGE_TYPE,
            TAX_CHARGE_DOMAIN,
            TAX_CHARGE_SUB_DOMAIN,
            TAX_CHARGE_DETAIL,
            TAX_CHARGE_RATE,
            NULL AS DIM_SERVICE_ID,
            current_timestamp() AS LAST_UPDATED_DATE,
            current_timestamp() AS CREATED_DATE,
            'WSR' AS DOMAIN_TYPE,
            'WSR_PARTITION' AS PARTITION_KEY
        FROM tax_charge_data
    """

    # Step 3: Execute SQL and get transformed DataFrame
    df_transformed = spark.sql(sql_query)

    # Repartition DataFrame for better performance based on partition size
    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)
    return df_transformed.distinct()


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    transformed_df: DataFrame = transform(spark=spark)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print("spark_df schema:", spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
