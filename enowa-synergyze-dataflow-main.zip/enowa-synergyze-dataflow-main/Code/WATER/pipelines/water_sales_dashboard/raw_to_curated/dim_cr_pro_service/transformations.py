# pylint:disable = unused-argument,import-error
"""
    This is the transformation file for dim_cr_agr_contract dimension
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_database: DataFrame,
        df_applications_by_contract_status: DataFrame
) -> DataFrame:
    '''
        This function prepares the dataframe from the raw layer based on business logic.
    '''
    try:
        logging.info("Starting the transformation process.")

        # Create temp views to use SQL on DataFrames
        df_database.createOrReplaceTempView("database")
        df_applications_by_contract_status.createOrReplaceTempView("applications")

        # Step 1: Select distinct values from Contract_Type and Revenue_Streams and combine
        sql_query_step_1 = """
            SELECT DISTINCT CONTRACTTYPE AS Service
            FROM database
            UNION
            SELECT DISTINCT REVENUESTREAMS AS Service
            FROM applications
            WHERE REVENUESTREAMS != 'TOTALS'
        """
        df_combined_data = spark.sql(sql_query_step_1)
        df_combined_data.createOrReplaceTempView("combined_services")

        logging.info("Step 1: Combined distinct values from Contract_Type and Revenue_Streams")

        # Step 2: Derive the service category based on the Service column
        sql_query_step_2 = """
            SELECT
                Service,
                CASE
                    WHEN Service = 'Bulk Water Supply' THEN 'Water Supply'
                    WHEN Service = 'Potable Water' THEN 'Potable Water'
                    WHEN Service = 'Recycled Water Supply' THEN 'Recycle Water'
                    WHEN Service = 'Filling Station Ops' THEN 'Water Filling'
                    WHEN Service = 'Waste Water' THEN 'Waste Water'
                    WHEN Service = 'Connection Fees' THEN 'Water Supply Connection'
                    ELSE 'Unknown'
                END AS SERVICE_CATEGORY
            FROM combined_services
        """
        df_service_category = spark.sql(sql_query_step_2)
        df_service_category.createOrReplaceTempView("service_category")
        logging.info("Step 2: Derived the service category based on the Service column")

        # Step 3: Generate the final transformed data by adding additional columns
        sql_query_step_3 = """
            SELECT
                sha2(Service, 256) AS DIM_SERVICE_ID,
                'Water' AS SERVICE_DOMAIN_TYPE,
                SERVICE_CATEGORY,
                Service,
                current_timestamp() AS LAST_UPDATED_DATE,
                current_timestamp() AS CREATED_DATE,
                'WSR' AS DOMAIN_TYPE,   
                'WSR_PARTITION' AS PARTITION_KEY
            FROM service_category
        """
        df_transformed = spark.sql(sql_query_step_3)
        logging.info("Step 3: Generated the final transformed data using Spark SQL")

        logging.info("Executed SQL query for data transformation.")

        # Repartition DataFrame for better performance based on partition size
        max_partition_size_mb = 256
        num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

        logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

        df_transformed = df_transformed.repartition(num_partitions)

        return df_transformed

    except Exception as e:
        logging.error("Error in applying transformations: %s", str(e))
        raise


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "APPLICATIONS_BY_CONTRACT_STATUS": DataFrame for raw data 
               APPLICATIONS_BY_CONTRACT_STATUS.
            - "DATABASE": DataFrame for raw data DATABASE.
            - "DIM_CR_PRO_SERVICE": DataFrame for service mapping DIM_CR_PRO_SERVICE.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_applications_by_contract_status = source_dfs["APPLICATIONS_BY_CONTRACT_STATUS"]
    df_database = source_dfs["DATABASE"]

    # Apply transformations based on business logic
    transform_df = prepare_transformed_df(
        spark=spark,
        df_database=df_database,
        df_applications_by_contract_status=df_applications_by_contract_status,
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df is not None:
        # Log the schema of spark_df if it's not None
        logging.info("Schema of spark_df:\n%s", spark_df.schema.simpleString())
    else:
        logging.warning("spark_df is None; skipping schema logging.")

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
