# transformations.py
"""
Transformation logic for FACT_WSR_EVE_CONTRACT_RESULT fact table
"""

import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import lit
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_applications_by_contract_status: DataFrame,
        df_dim_cr_pro_service: DataFrame,
        df_dim_cr_agr_contract_stage: DataFrame
) -> DataFrame:
    """
    Prepare the transformation for FACT_WSR_EVE_CONTRACT_RESULT table based on business logic.
    """

    logging.info("Starting the transformation process for FACT_WSR_EVE_CONTRACT_RESULT.")

    # Check if any of the source DataFrames are empty
    if df_applications_by_contract_status.rdd.isEmpty() or df_dim_cr_pro_service.rdd.isEmpty() \
            or df_dim_cr_agr_contract_stage.rdd.isEmpty():
        logging.warning("One or more input DataFrames are empty. Returning an empty DataFrame.")
        return spark.createDataFrame([], df_applications_by_contract_status.schema)

    # Step 1: Create temp views to use SQL on DataFrames for transformation
    df_applications_by_contract_status.createOrReplaceTempView("applications_by_contract_status")

    df_dim_cr_pro_service.createOrReplaceTempView("dim_cr_pro_service")
    df_dim_cr_agr_contract_stage.createOrReplaceTempView("dim_cr_agr_contract_stage")

    # Step 2: Select and unpivot data from 'Applications by Contract Status'
    logging.info("Unpivoting the data from `applications_by_contract_status`.")

    df_unpivoted = df_applications_by_contract_status.selectExpr(
        "REVENUESTREAMS",
        "TOTALNOOFCONTRACTS",
        """
        stack(
        7, 
        'Assessment', ASSESSMENT, 
        'Acceptance', ACCEPTANCE, 
        'Executed', EXECUTED, 
        'Completed', COMPLETED, 
        'Archived', ARCHIVED, 
        'OpportunityInHand', OPPORTUNITYINHAND, 
        'OpportunityLost', OPPORTUNITYLOST
    ) as (CONTRACT_STAGE, STAGE_VALUE)
    """
    )
    df_unpivoted.createOrReplaceTempView("unpivoted_data")

    # Step 3: Perform join with `dim_cr_pro_service` to get `DIM_SERVICE_ID`
    logging.info("Joining unpivoted data with `dim_cr_pro_service` to get `DIM_SERVICE_ID`.")
    df_joined_service = spark.sql("""
        SELECT
            ud.REVENUESTREAMS,
            ud.CONTRACT_STAGE,
            ud.STAGE_VALUE,
            ds.DIM_SERVICE_ID
        FROM unpivoted_data ud
        JOIN dim_cr_pro_service ds ON ds.SERVICE = ud.REVENUESTREAMS
        AND ds.DOMAIN_TYPE = 'WSR'                    
    """)
    df_joined_service.createOrReplaceTempView("joined_service_data")

    # Step 4: Perform join with `dim_cr_agr_contract_stage` to get `DIM_CONTRACT_STAGE_ID`
    logging.info("Joining result with `dim_cr_agr_contract_stage` to get `DIM_CONTRACT_STAGE_ID`.")
    df_joined_stage = spark.sql("""
        SELECT
            js.REVENUESTREAMS,
            js.CONTRACT_STAGE,
            js.STAGE_VALUE,
            js.DIM_SERVICE_ID,
            dcs.DIM_CONTRACT_STAGE_ID
        FROM joined_service_data js
        JOIN dim_cr_agr_contract_stage dcs
            ON upper(dcs.CONTRACT_STAGE) = upper(js.CONTRACT_STAGE)
            AND dcs.DOMAIN_TYPE = 'WSR'
    """)
    df_joined_stage.createOrReplaceTempView("joined_stage_data")

    # Step 5: Final selection and aggregation
    logging.info("Performing final selection and generating FACT_CONTRACT_RESULT_ID.")
    df_final = spark.sql("""
        SELECT
            sha2(concat_ws('||', js.DIM_SERVICE_ID, js.DIM_CONTRACT_STAGE_ID), 256) AS FACT_CONTRACT_RESULT_ID,
            js.DIM_SERVICE_ID,
            js.DIM_CONTRACT_STAGE_ID,
            js.STAGE_VALUE AS CONTRACT_COUNT,
            current_timestamp() AS LAST_UPDATED_DATE,
            current_timestamp() AS CREATED_DATE
        FROM joined_stage_data js
    """)

    # Step 3: Add PARTITION_KEY column
    df_final = df_final.withColumn("PARTITION_KEY", lit("WSR_PARTITION"))

    # Repartition DataFrame for better performance based on partition size
    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_final, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_final = df_final.repartition(num_partitions)

    return df_final


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "DATABASE": DataFrame for raw data DATABASE.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_applications_by_contract_status = source_dfs["APPLICATIONS_BY_CONTRACT_STATUS"]
    df_dim_cr_pro_service = source_dfs["DIM_CR_PRO_SERVICE"]
    df_dim_cr_agr_contract_stage = source_dfs["DIM_CR_AGR_CONTRACT_STAGE"]

    # Apply transformations based on business logic
    transform_df = prepare_transformed_df(
        spark=spark,
        df_applications_by_contract_status=df_applications_by_contract_status,
        df_dim_cr_pro_service=df_dim_cr_pro_service,
        df_dim_cr_agr_contract_stage=df_dim_cr_agr_contract_stage
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )
    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.
    """
    if spark_df is not None:
        # Log the schema of spark_df if it's not None
        logging.info("Schema of spark_df:\n%s", spark_df.schema.simpleString())
    else:
        logging.warning("spark_df is None; skipping schema logging.")

    task_name = kwargs.get("task_name")
    task_parameters = kwargs.get("task_parameters")
    pipeline_storage = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
