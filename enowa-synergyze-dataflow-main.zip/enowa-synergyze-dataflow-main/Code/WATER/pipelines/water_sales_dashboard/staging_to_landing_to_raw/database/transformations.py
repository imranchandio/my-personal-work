"""
Module: database
Description: Process data from raw to curated for the database.
It contains the necessary functions and logic to create database 
table in curated.
"""
import logging
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col, regexp_replace, lit, when
from pyspark.sql.types import DoubleType


def transform_dataframe(df: DataFrame) -> DataFrame:
    """
    Executes the appropriate transformations on the DataFrame.
    
    Args:
        df (DataFrame): The input DataFrame.
        
    Returns:
        DataFrame: The resulting transformed DataFrame.
    """
    # Ensure all required columns are present by adding missing ones as null placeholders
    required_columns = ["FixedCostSARm3", "VariablecostRateSARm3"]
    for col_name in required_columns:
        if col_name not in df.columns:
            logging.info("Adding missing column '%s' with null values.", col_name)
            df = df.withColumn(col_name, lit(None).cast(DoubleType()))

        # Replace NULL values with 0 for numeric consistency
        df = df.withColumn(
            col_name,
            when(col(col_name).isNull(), lit(0)).otherwise(col(col_name))
        )

    # List of target columns for transformation
    target_columns = [
        "WaterSalesVolumeQuantitySuppliedm3",
        "NetTotalSalesSAR",
        "VAT",
        "GrossTotalSalesSAR",
        "CommittedQuantitym3",
        "DailyFixedFeeCostSARDay",
        "TotalFixedFeeCostSAR",
        "VariablecostRateSARm3",
        "TotalVariableCostSAR"
    ]
    logging.info("Starting transformation on target columns.")

    # Apply transformations only to target columns
    for column in target_columns:
        if column in df.columns:
            logging.info(
                "Transforming column '%s' by handling negative values.",
                column
            )
            df = df.withColumn(
                column,
                regexp_replace(
                    col(column), r"^\((.*)\)$", "-$1"
                )
            )
        else:
            logging.warning(
                "Column '%s' not found in DataFrame. Skipping transformation.",
                column
            )

    return df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df (DataFrame): Dummy DataFrame, included only to avoid argument warnings.
        **kwargs: Additional arguments, including:
            - task_name (str): The name of the task to execute.

    Returns:
        DataFrame: The resulting DataFrame from the executed task, or None if task is not supported.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    print("Spark Session:", spark)  # Printing spark session object to avoid SonarQube issues

    task_name = kwargs.get("task_name")
    if task_name == "data_movement_task":
        logging.info("Executing 'data_movement_task'.")
        return transform_dataframe(spark_df)
    else:
        logging.warning("Unsupported task name: '%s'.", task_name)
        return None
