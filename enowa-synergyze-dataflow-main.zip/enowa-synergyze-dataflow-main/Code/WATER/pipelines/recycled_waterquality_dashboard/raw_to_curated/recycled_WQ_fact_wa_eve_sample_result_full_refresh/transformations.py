from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
import logging
from pyspark import StorageLevel
from common_utils import (
    calculate_num_partitions,
    impose_schema,
    perform_reorder_and_als_deduplication,
    trim_spaces
)
from read_utils import read

SAMPLE_PARAMETER_VALUE = "SAMPLE_PARAMETER_VALUE"
RECEIVED_DATE = "ReceivedDate"
SAMPLING_DATE = "SamplingDate"


def apply_als_exclusions(
        spark: SparkSession,
        df_als_active: DataFrame,
        df_parameter_mapping: DataFrame,
        df_location_mapping: DataFrame,
        df_exclusion_table: DataFrame
) -> DataFrame:
    """
    Applies various exclusions to an ALS active DataFrame using SQL logic with PySpark.

    This function performs multiple transformations using SQL Common Table Expressions (CTEs) to:
    1. Add default values for missing TEST and SAMPLENAME fields in the ALS active DataFrame.
    2. Map parameters and locations using provided mapping DataFrames, falling back to default values if necessary.
    3. Apply exclusions based on sample numbers, sample results, parameter surrogates, and purchase order numbers.
    4. Return the final DataFrame with all exclusions applied.

    Args:
        spark (SparkSession): The Spark session object.
        df_als_active (DataFrame): The input PySpark DataFrame containing ALS active data.
        df_parameter_mapping (DataFrame): The DataFrame used for mapping parameters.
        df_location_mapping (DataFrame): The DataFrame used for mapping locations.
        df_exclusion_table (DataFrame): The DataFrame containing exclusion rules.

    Returns:
        DataFrame: A PySpark DataFrame with exclusions applied, based on the defined logic.
    """
    # Register the input DataFrames as temporary views for SQL queries
    df_als_active.createOrReplaceTempView("als_source")
    df_exclusion_table.createOrReplaceTempView("dim_wa_op_exclusion")
    df_parameter_mapping.createOrReplaceTempView("parameter_mapping_source")
    df_location_mapping.createOrReplaceTempView("location_mapping_source")

    # SQL query using multiple CTEs to apply exclusions
    sql_query = """
        WITH als_active_final AS (
            SELECT 
                als.*,
                NVL(als.test, '') AS parameter_name,
                NVL(als.samplename, '') AS location_name
            FROM als_source als
        ),
        sample_excl AS (
            SELECT 
                als_f.*
            FROM als_active_final als_f
            LEFT JOIN (
                SELECT dim_exclusion_id, sample_no 
                FROM dim_wa_op_exclusion 
                WHERE exclusion_type = 'Sample No Exclusion'
            ) excl 
                ON als_f.samplenumber = excl.sample_no
            WHERE excl.dim_exclusion_id IS NULL
        ),
        sample_result_excl AS (
            SELECT 
                smp_ex.*
            FROM sample_excl smp_ex
            LEFT JOIN (
                SELECT dim_exclusion_id, sample_no, location_name, parameter_name, sampling_date 
                FROM dim_wa_op_exclusion 
                WHERE exclusion_type = 'Sample Result Exclusion'
            ) et 
                ON to_date(smp_ex.samplingdate, 'dd-MM-yyyy') = to_date(et.sampling_date, 'MM/dd/yy')
                AND smp_ex.samplenumber = et.sample_no
                AND smp_ex.location_name = et.location_name
                AND smp_ex.parameter_name = et.parameter_name
            WHERE et.dim_exclusion_id IS NULL
        ),
        param_surrogates_excl AS (
            SELECT 
                als.*
            FROM sample_result_excl als
            LEFT JOIN (
                SELECT dim_exclusion_id, parameter_name 
                FROM dim_wa_op_exclusion 
                WHERE exclusion_type = 'Parameter Surrogates'
            ) et 
                ON als.parameter_name = et.parameter_name
            WHERE et.dim_exclusion_id IS NULL
        ),
        po_excl AS (
            SELECT
                als.*
            FROM param_surrogates_excl als
            WHERE als.purchaseorderno IS NOT NULL
        )
        SELECT DISTINCT * 
        FROM po_excl;
    """

    # Execute the SQL query and return the result
    return spark.sql(sql_query)


def drop_duplicates_from_sample_result(spark: SparkSession, df: DataFrame) -> DataFrame:
    """
    Removes duplicate records from a DataFrame based on specific columns and criteria using SQL logic.

    This function identifies and removes duplicates by grouping rows based on the columns:
    'DIM_SAMPLE_ID', 'SAMPLE_CAPTURE_DATE', 'PARAMETER_MAPPING_PARAMETER_NAME',
    'LOCATION_MAPPING_LOCATION_NAME', and 'SAMPLE_DESCRIPTION'. The deduplication logic is as follows:

    - If a group has multiple records (record count > 1) and at least one of them has a status
      of 'Pending', the 'Pending' record(s) are flagged for removal.
    - Records that are not flagged as 'Pending' are kept.

    The function uses two common table expressions (CTEs):
    1. `count_cte`: Counts the total number of records and the number of 'Pending' records in each group.
    2. `dedup_cte`: Flags records for removal or keeps them based on the deduplication logic.

    Args:
        spark (SparkSession): The Spark session object.
        df (DataFrame): The input DataFrame containing sample result data.

    Returns:
        DataFrame: A DataFrame with duplicates removed according to the defined criteria.
    """
    # Create a temporary view of the DataFrame for SQL operations
    df.createOrReplaceTempView("sample_result")
    df_cols = df.columns

    # SQL query to perform deduplication using CTEs
    sql_query = """
    WITH distinct_cte as (
        select distinct DIM_SAMPLE_ID, 
                    SAMPLE_CAPTURE_DATE,
                    PARAMETER_MAPPING_PARAMETER_NAME,
                    LOCATION_MAPPING_LOCATION_NAME,
                    SAMPLE_DESCRIPTION,
                    SAMPLE_TEST_STATUS
        FROM  sample_result     
    )    
    ,count_cte AS (
        SELECT 
            DIM_SAMPLE_ID, 
            SAMPLE_CAPTURE_DATE, 
            PARAMETER_MAPPING_PARAMETER_NAME, 
            LOCATION_MAPPING_LOCATION_NAME, 
            SAMPLE_DESCRIPTION,
            COUNT(*) AS record_count,
            SUM(CASE WHEN UPPER(SAMPLE_TEST_STATUS) = 'PENDING' THEN 1 ELSE 0 END) AS pending_count
        FROM distinct_cte
        GROUP BY 
            DIM_SAMPLE_ID, 
            SAMPLE_CAPTURE_DATE, 
            PARAMETER_MAPPING_PARAMETER_NAME, 
            LOCATION_MAPPING_LOCATION_NAME, 
            SAMPLE_DESCRIPTION
    ),
    dedup_cte AS (
        SELECT 
            res.*,
            CASE 
                WHEN cte.record_count > 1 
                     AND cte.pending_count > 0 
                     AND res.SAMPLE_TEST_STATUS = 'Pending' 
                THEN 'Remove' 
                ELSE 'Keep' 
            END AS dedup_flag
        FROM sample_result res
        LEFT JOIN count_cte cte ON
            res.DIM_SAMPLE_ID = cte.DIM_SAMPLE_ID AND
            COALESCE(res.SAMPLE_CAPTURE_DATE, '') = COALESCE(cte.SAMPLE_CAPTURE_DATE, '') AND 
            COALESCE(res.PARAMETER_MAPPING_PARAMETER_NAME, '') = COALESCE(cte.PARAMETER_MAPPING_PARAMETER_NAME, '') AND 
            COALESCE(res.LOCATION_MAPPING_LOCATION_NAME, '') = COALESCE(cte.LOCATION_MAPPING_LOCATION_NAME, '') AND 
            COALESCE(res.SAMPLE_DESCRIPTION, '') = COALESCE(cte.SAMPLE_DESCRIPTION, '')
    )
    SELECT * FROM dedup_cte WHERE dedup_flag = 'Keep'
    """

    # Execute the SQL query and select only the original columns
    df_deduped = spark.sql(sql_query).select(*df_cols)

    return df_deduped


def prepare_als_active_data(
        spark: SparkSession,
        df_als_active: DataFrame,
        df_parameter_mapping: DataFrame,
        df_parameter_attribute: DataFrame,
        df_location_mapping: DataFrame,
        df_location_attribute: DataFrame,
        df_exclusion_table: DataFrame,
        df_dim_cr_ass_asset: DataFrame,
        df_dim_cr_loc_location: DataFrame,
        df_dim_wa_reg_parameter: DataFrame,
        df_dim_wa_op_sample: DataFrame,
        df_dim_wa_org_waterqa_supplier: DataFrame,
) -> DataFrame:
    logging.info("PREPARE_ALS_ACTIVE_DATA: Getting complete als data")

    df_als_active = df_als_active.withColumn(
        RECEIVED_DATE,
        F.coalesce(
            F.to_date(
                F.regexp_replace(RECEIVED_DATE, " ", "-"), "yyyy-MM-dd"),
            F.to_date(F.regexp_replace(RECEIVED_DATE, " ", "-"), "dd-MM-yyyy"),
        ),
    ).withColumn(
        SAMPLING_DATE,
        F.coalesce(
            F.to_date(F.regexp_replace(SAMPLING_DATE, " ", "-"), "yyyy-MM-dd"),
            F.to_date(F.regexp_replace(SAMPLING_DATE, " ", "-"), "dd-MM-yyyy"),
        ),
    )

    # Apply als exclusions
    df_als_active_excl: DataFrame = apply_als_exclusions(
        spark=spark,
        df_als_active=df_als_active,
        df_exclusion_table=df_exclusion_table,
        df_location_mapping=df_location_mapping,
        df_parameter_mapping=df_parameter_mapping,
    )

    df_als_active_dedup = perform_reorder_and_als_deduplication(df=df_als_active_excl)

    df_als_active_excl_filtered = df_als_active_dedup.filter(
        (F.col("SamplingDate").isNotNull()) | (F.col("Result").isNotNull()) | (F.col("Result") != ''))

    df_als_active_excl_filtered.createOrReplaceTempView("als_active")
    df_parameter_mapping.createOrReplaceTempView("parameter_mapping")
    df_parameter_attribute.createOrReplaceTempView("parameter_attribute")
    df_location_mapping.createOrReplaceTempView("location_mapping")
    df_location_attribute.createOrReplaceTempView("location_attribute")

    df_dim_cr_ass_asset.createOrReplaceTempView("dim_cr_ass_asset")
    df_dim_cr_loc_location.createOrReplaceTempView("dim_cr_loc_location")
    df_dim_wa_reg_parameter.createOrReplaceTempView("dim_wa_reg_parameter")
    df_dim_wa_op_sample.createOrReplaceTempView("dim_wa_op_sample")
    df_dim_wa_org_waterqa_supplier.createOrReplaceTempView(
        "dim_wa_org_waterqa_supplier"
    )

    sql_query = """
    select distinct
        sha2(
            concat_ws("||",
                NVL(CAST(aa.SampleName AS STRING), '-'),
                NVL(CAST(aa.Test AS STRING), '-'),
                NVL(CAST(aa.SampleNumber AS STRING), '-'),
                NVL(CAST(aa.SamplingDate AS STRING), '-')
            ), 256
        ) as FACT_SAMPLE_RESULT_ID,
        asset.DIM_ASSET_ID as DIM_ASSET_ID,
        dim_loc.DIM_LOCATION_ID  as DIM_LOCATION_ID,
        dim_reg_param.DIM_PARAMETER_ID as DIM_PARAMETER_ID,
        dim_reg_param.DIM_WATERQA_SUPPLIER_ID as DIM_WATERQA_SUPPLIER_ID,
        dim_sample.DIM_SAMPLE_ID as DIM_SAMPLE_ID,
        aa.Result as SAMPLE_PARAMETER_VALUE,
        aa.Unit as SAMPLE_PARAMETER_UNIT,
        aa.SamplingDate as SAMPLE_CAPTURE_DATE,
        aa.Test as SAMPLE_TEST_NAME,
        'WATER' as SAMPLE_DOMAIN_TYPE,
        'RECYCLED WATER' as SAMPLE_SUB_DOMAIN_TYPE,
        coalesce(pm.ParameterName, aa.Test) AS PARAMETER_MAPPING_PARAMETER_NAME,
        CASE
           WHEN aa.TestStatus like 'Pend%' THEN 'Pending' ELSE 'Completed'
        END as SAMPLE_TEST_STATUS,
        aa.SampleEvaluation as SAMPLE_TEST_EVALUATION,
        aa.SampleName as SAMPLE_LOCATION_NAME,
        coalesce(lm.LocationName, aa.SampleName)  AS LOCATION_MAPPING_LOCATION_NAME,
        CASE WHEN pm.Test IS NULL THEN "Not in Mapping"
            ELSE "Mapped"
        END AS PARAMETER_MAPPING_FLAG,
        CASE WHEN pa.ParameterName IS NULL THEN "Not in Attribute"
            ELSE "In Attribute"
        END AS PARAMETER_ATTRIBUTE_FLAG,
        CASE WHEN lm.LocationNameSource IS NULL THEN "Not in Mapping"
            ELSE "Mapped"
        END AS LOCATION_MAPPING_FLAG,
        CASE WHEN la.LocationName IS NULL THEN "Not in Attribute"
            ELSE "In Attribute"
        END AS LOCATION_ATTRIBUTE_FLAG,
        dim_sample.REPORTING_DATE as REPORTING_DATE,
        dim_sample.SAMPLE_DESCRIPTION as SAMPLE_DESCRIPTION,
        current_timestamp() AS CREATED_DATE,
        current_timestamp() AS LAST_UPDATED_DATE,
        trim(aa.SampleStatus) as SAMPLE_STATUS
    from
    als_active aa
    left join location_mapping lm on trim(aa.SampleName) = trim(lm.LocationNameSource)
    left join location_attribute la on trim(lm.LocationName) = trim(la.LocationName)
    left join dim_cr_loc_location dim_loc on trim(lm.LocationName) = trim(dim_loc.LOCATION_NAME)
    left join dim_wa_op_sample dim_sample on trim(aa.SampleNumber) = (dim_sample.SAMPLE_NO)
    left join parameter_mapping pm on trim(aa.Test) = trim(pm.Test)
    left join parameter_attribute pa on trim(pm.ParameterName) = trim(pa.ParameterName)
    left join dim_wa_reg_parameter dim_reg_param on trim(pm.ParameterName) = trim(dim_reg_param.PARAMETER_NAME)
        and dim_reg_param.PRIMARY_STANDARD_FLAG = 'Primary'
    left join dim_cr_ass_asset asset on trim(la.AssetID) = trim(asset.ASSET_ID)
        and trim(dim_loc.DIM_LOCATION_ID) = trim(asset.DIM_LOCATION_ID)
    where upper(trim(aa.SampleName)) not like 'PHASE 2 DDP SWRO%'
    and upper(trim(aa.Test)) != 'MISCELLANEOUS TESTS'
    and upper(trim(aa.Test)) != 'SUBCONTRACTED ANALYSIS'
    and upper(trim(aa.WorkOrder)) not in ("BATCH", "WORKORDER")
    and (upper(trim(aa.MATRIX_SUBMATRIX)) LIKE 'WATER%WASTE WATER' OR
    upper(trim(aa.MATRIX_SUBMATRIX)) LIKE 'WATER%EFFLUENT' OR
    upper(trim(aa.MATRIX_SUBMATRIX)) LIKE 'WATER%INFLUENT' OR
    upper(trim(aa.MATRIX_SUBMATRIX)) LIKE 'WATER%WASTEWATER' OR
    upper(trim(aa.MATRIX_SUBMATRIX)) LIKE 'SOIL%SLUDGE')
    """

    df_als_active_final = spark.sql(sql_query)

    df_als_active_final_dedup = drop_duplicates_from_sample_result(spark=spark, df=df_als_active_final)

    df_als_active_final_dedup = df_als_active_final_dedup.drop("SAMPLE_DESCRIPTION")

    df_als_active_final_dedup = df_als_active_final_dedup.withColumn(
        "reporting_date_dt",
        F.to_date("reporting_date")
    )

    max_dates_df = (
        df_als_active_final_dedup.
        groupBy("FACT_SAMPLE_RESULT_ID").
        agg(
            F.max("reporting_date_dt").alias("max_reporting_date")
        )
    )

    df_final = (
        df_als_active_final_dedup.
        join(
            max_dates_df,
            (df_als_active_final_dedup.FACT_SAMPLE_RESULT_ID == max_dates_df.FACT_SAMPLE_RESULT_ID)
            & (df_als_active_final_dedup.reporting_date_dt == max_dates_df.max_reporting_date)
        )
        .select(df_als_active_final_dedup["*"]))

    df_final = df_final.drop("reporting_date_dt")

    return df_final


def cleanse_sample_parameter_value(df: DataFrame) -> DataFrame:
    """
        Cleanses the SAMPLE_PARAMETER_VALUE column in the
        given DataFrame by applying specific transformations:

        1. Replaces values like "ND" or "NOT DETECTED" (case-insensitive) with "0".
        2. Replaces certain variations of the word "Pending"
            (e.g., "Pending", "pending", "pe0ing", "(Pending)", etc.) with "NULL".

        Args:
            df (DataFrame): The input PySpark DataFrame containing the SAMPLE_PARAMETER_VALUE column.

        Returns:
            DataFrame: A transformed PySpark DataFrame with the SAMPLE_PARAMETER_VALUE column cleansed.
    """
    df_transformed_final = df.withColumn(
        SAMPLE_PARAMETER_VALUE,
        F.when(F.upper(F.col(SAMPLE_PARAMETER_VALUE)).isin("ND", "NOT DETECTED", "NOT DETECTED (-/+ PER 600ML)"),
               "0"
               ).otherwise(F.col(SAMPLE_PARAMETER_VALUE))
    )

    # List of values to check
    values_to_check = ["Pending", "pending", "pe0ing", "(Pending)", "(pending)", "(pe0ing)"]

    # Create `when` conditions dynamically
    condition = F.lit(False)
    for value in values_to_check:
        condition = condition | F.col(SAMPLE_PARAMETER_VALUE).contains(value)

    # Apply the transformation
    df_transformed_final = df_transformed_final.withColumn(
        SAMPLE_PARAMETER_VALUE,
        F.when(condition, "0").otherwise(F.col(SAMPLE_PARAMETER_VALUE))
    )

    return df_transformed_final


def prepare_transformed_df(
        spark: SparkSession,
        df_als_active: DataFrame,
        df_location_mapping: DataFrame,
        df_parameter_mapping: DataFrame,
        df_location_attribute: DataFrame,
        df_parameter_attribute: DataFrame,
        df_exclusion_table: DataFrame,
        df_dim_cr_ass_asset: DataFrame,
        df_dim_cr_loc_location: DataFrame,
        df_dim_wa_reg_parameter: DataFrame,
        df_dim_wa_op_sample: DataFrame,
        df_dim_wa_org_waterqa_supplier: DataFrame
) -> DataFrame:
    logging.info("Starting the transformation process for FACT_WA_EVE_SAMPLE_RESULT.")

    df_als_active_final = prepare_als_active_data(
        spark=spark,
        df_als_active=df_als_active,
        df_location_mapping=df_location_mapping,
        df_location_attribute=df_location_attribute,
        df_parameter_mapping=df_parameter_mapping,
        df_parameter_attribute=df_parameter_attribute,
        df_dim_cr_ass_asset=df_dim_cr_ass_asset,
        df_dim_cr_loc_location=df_dim_cr_loc_location,
        df_dim_wa_reg_parameter=df_dim_wa_reg_parameter,
        df_dim_wa_op_sample=df_dim_wa_op_sample,
        df_exclusion_table=df_exclusion_table,
        df_dim_wa_org_waterqa_supplier=df_dim_wa_org_waterqa_supplier,
    )

    df_als_active_final_fltr: DataFrame = cleanse_sample_parameter_value(df=df_als_active_final)

    df_transformed_final = df_als_active_final_fltr

    logging.info("Executed SQL query for data transformation.")

    df_transformed_final = df_transformed_final.persist(StorageLevel.MEMORY_AND_DISK)

    logging.info("Transformation process completed.")
    return df_transformed_final.distinct()


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrame by performing necessary transformations and returns the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames.
        primary_cols: List of primary columns
    Returns:
        DataFrame: The transformed DataFrame.
    """
    logging.info("Starting the transformation process.")

    df_als_active: DataFrame = source_dfs["ALS"]

    df_location_mapping: DataFrame = trim_spaces(source_dfs["LOCATION_MAPPING"])
    df_parameter_mapping: DataFrame = trim_spaces(source_dfs["PARAMETER_MAPPING"])

    df_location_attribute: DataFrame = trim_spaces(source_dfs["LOCATION_ATTRIBUTE"])
    df_parameter_attribute: DataFrame = trim_spaces(source_dfs["PARAMETER_ATTRIBUTE"])
    df_exclusion_table: DataFrame = source_dfs["EXCLUSION_TABLE"]
    df_dim_cr_ass_asset: DataFrame = (
        source_dfs["DIM_CR_ASS_ASSET"].select(
            "DIM_ASSET_ID",
            "DIM_LOCATION_ID",
            "ASSET_ID"
        ).distinct()
    )
    df_dim_cr_loc_location: DataFrame = (
        source_dfs["DIM_CR_LOC_LOCATION"]
        .select("DIM_LOCATION_ID", "LOCATION_NAME")
        .distinct()
    )
    df_dim_wa_reg_parameter: DataFrame = source_dfs["DIM_WA_REG_PARAMETER"].distinct()

    df_dim_wa_op_sample: DataFrame = (
        source_dfs["DIM_WA_OP_SAMPLE"].select(
            "DIM_SAMPLE_ID",
            "SAMPLE_NO",
            "SAMPLE_DESCRIPTION",
            "REPORTING_DATE"
        ).distinct()
    )
    df_dim_wa_org_waterqa_supplier: DataFrame = (
        source_dfs["DIM_WA_ORG_WATERQA_SUPPLIER"]
        .select("DIM_WATERQA_SUPPLIER_ID", "SUPPLIER_NAME", "SUPPLIER_CODE")
        .distinct()
    )

    df_transformed = prepare_transformed_df(
        spark=spark,
        df_als_active=df_als_active,
        df_location_mapping=df_location_mapping,
        df_parameter_mapping=df_parameter_mapping,
        df_location_attribute=df_location_attribute,
        df_parameter_attribute=df_parameter_attribute,
        df_exclusion_table=df_exclusion_table,
        df_dim_cr_ass_asset=df_dim_cr_ass_asset,
        df_dim_cr_loc_location=df_dim_cr_loc_location,
        df_dim_wa_reg_parameter=df_dim_wa_reg_parameter,
        df_dim_wa_op_sample=df_dim_wa_op_sample,
        df_dim_wa_org_waterqa_supplier=df_dim_wa_org_waterqa_supplier
    )

    logging.info("Data transformation completed.")

    max_partition_size_mb = 1024
    logging.info("Calculating the number of partitions.")
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)
    logging.info(f"Repartitioning DataFrame into {num_partitions} partitions.")

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    target_schema = {}

    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = transform(
        spark=spark, source_dfs=source_dfs
    )

    print(
        "execute_transform():transformed_df schema before imposing:",
        transformed_df.printSchema()
    )

    transformed_df = impose_schema(transformed_df, target_schema)

    print(
        "execute_transform(): transformed_df schema after imposing::",
        transformed_df.printSchema()
    )

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "50MB")

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
