from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
import logging
from pyspark.sql.types import FloatType, DecimalType, IntegerType
import re
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

THRESHOLD_NOT_AVAILABLE = "Threshold Not Available"
EXCEEDS_MIN = "Exceeds Min"
EXCEEDS_MAX = "Exceeds Max"
COMPLIANT = "Compliant"
NON_COMPLIANT = "Non-Compliant"
NOT_DETECTED = "Not Detected"
PENDING = "Pending"
SAMPLE_TEST_STATUS = "SAMPLE_TEST_STATUS"
STRING = "string"
BIOLOGICAL = "Biological"
CALCULATED_TEST_RESULT = "CALCULATED_TEST_RESULT"
EXCLUDED_PARAM_UNITS = ["cells/mL", "cells/100 mL", "MPN/100 mL"]
SAMPLE_PARAMETER_UNIT = "SAMPLE_PARAMETER_UNIT"
PARAMETER_THRESHOLD_MAX = "PARAMETER_THRESHOLD_MAX"
PARAMETER_THRESHOLD_MIN = "PARAMETER_THRESHOLD_MIN"
THRESHOLD_EXCEPTION_STATUS = "THRESHOLD_EXCEPTION_STATUS"
CALC_SAMPLE_PARAMETER_VALUE = "CALC_SAMPLE_PARAMETER_VALUE"
COMPLIANCE_STATUS = "COMPLIANCE_STATUS"
PARAMETER_TYPE = "PARAMETER_TYPE"


def extract_number(text):
    if text:
        match = re.search(r"\d+\.?\d*", text)
        return float(match.group()) if match else None
    return None


def prepare_transformed_df(
        df_dim_wa_reg_parameter: DataFrame,
        df_fact_wa_eve_sample_result: DataFrame,
        df_parameter_unit_conversion: DataFrame,
) -> DataFrame:
    logging.info(
        "Starting the transformation process for FACT_WA_EVE_WQD_SAMPLE_RESULT."
    )

    udf_extract_number = F.udf(extract_number, FloatType())

    df_dim_wa_reg_parameter = df_dim_wa_reg_parameter.withColumn(
        PARAMETER_THRESHOLD_MAX, udf_extract_number(PARAMETER_THRESHOLD_MAX)
    ).withColumn(
        PARAMETER_THRESHOLD_MIN, udf_extract_number(PARAMETER_THRESHOLD_MIN)
    )

    df_joined = (
        df_fact_wa_eve_sample_result.alias("fact")
        .join(
            df_dim_wa_reg_parameter.alias("reg_param"),
            F.col("fact.DIM_PARAMETER_ID") == F.col("reg_param.DIM_PARAMETER_ID"),
            "LEFT_OUTER",
        ).select(
            F.col("fact.FACT_SAMPLE_RESULT_ID"),
            F.col("fact.DIM_PARAMETER_ID"),
            F.col("fact.SAMPLE_TEST_STATUS"),
            F.col("fact.SAMPLE_PARAMETER_VALUE"),
            F.col("fact.SAMPLE_PARAMETER_UNIT"),
            F.col("reg_param.NON_DETECTION_VARIABLE"),
            F.col("reg_param.PARAMETER_THRESHOLD_MIN").cast(DecimalType(10, 4)),
            F.col("reg_param.PARAMETER_THRESHOLD_MAX").cast(DecimalType(10, 4)),
            F.col("reg_param.PARAMETER_UNIT"),
            F.col("reg_param.PARAMETER_TYPE")
        )
    )

    df_joined = (
        df_joined.alias("fact")
        .join(
            df_parameter_unit_conversion.alias("param_unit_conv"),
            (
                    F.lower(F.col("fact.SAMPLE_PARAMETER_UNIT"))
                    == F.lower(F.col("param_unit_conv.als_parameter_unit"))
            )
            & (
                    F.lower(F.col("fact.PARAMETER_UNIT"))
                    == F.lower(F.col("param_unit_conv.parameter_attribute_parameter_unit"))
            ),
            "LEFT_OUTER",
        )
        .select(
            F.col("fact.*"),
            F.col("param_unit_conv.conversion_multiplier").cast(DecimalType(10, 4)),
        )
    )

    # PREPARE SAMPLE_PARAMETER_VALUE column for FloatType() casting

    # Replace 'nd', 'Not detected' with 0
    df_joined = df_joined.withColumn(
        CALC_SAMPLE_PARAMETER_VALUE,
        F.when(
            F.lower(
                F.col("SAMPLE_PARAMETER_VALUE")).isin(["nd", "not detected"]),
            0
        ).otherwise(F.col("SAMPLE_PARAMETER_VALUE")),
    )

    # Remove special characters to cast to DecimalType
    df_joined = df_joined.withColumn(
        CALC_SAMPLE_PARAMETER_VALUE,
        F.trim(
            F.regexp_replace(
                F.col(CALC_SAMPLE_PARAMETER_VALUE),
                "[^0-9.-]",
                ''
            )
        ),
    )

    # Cast the column to FloatType
    df_joined = df_joined.withColumn(
        CALCULATED_TEST_RESULT,
        F.round(F.col(CALC_SAMPLE_PARAMETER_VALUE), 0)
    )

    df_joined = df_joined.withColumn(
        CALCULATED_TEST_RESULT, F.expr(
            """
            CASE 
                WHEN CALC_SAMPLE_PARAMETER_VALUE - floor(CALC_SAMPLE_PARAMETER_VALUE) = 0.5 
                THEN floor(CALC_SAMPLE_PARAMETER_VALUE) 
                ELSE round(CALC_SAMPLE_PARAMETER_VALUE) 
            END
            """
        )
    )

    df_joined.createOrReplaceTempView("final")

    df_transformed_1 = (
        df_joined.alias("df_joined")
        .select(
            F.col("df_joined.*"),
            F.sha2(F.col("FACT_SAMPLE_RESULT_ID").cast(STRING), 256).alias(
                "FACT_WATERQUALITY_OVERVIEW_ID"
            ),
            F.when(F.col(SAMPLE_TEST_STATUS) == F.lit(PENDING), PENDING)
            .when(F.col(SAMPLE_TEST_STATUS).startswith(NOT_DETECTED), NOT_DETECTED)
            .when(F.col(CALCULATED_TEST_RESULT).isNotNull(), "Detected")
            .otherwise(NOT_DETECTED)
            .alias("SAMPLE_RESULT_DETECTION"),
            F.when(
                F.col(PARAMETER_THRESHOLD_MIN).isNull()
                & F.col(PARAMETER_THRESHOLD_MAX).isNull(),
                THRESHOLD_NOT_AVAILABLE,
            )
            .otherwise(
                F.concat_ws(
                    " - ",
                    F.col(PARAMETER_THRESHOLD_MIN).cast(STRING),
                    F.col(PARAMETER_THRESHOLD_MAX).cast(STRING),
                )
            )
            .alias("THRESHOLD_RANGE"),
            F.when(
                F.col(SAMPLE_TEST_STATUS) == F.lit(PENDING),
                PENDING
            ).when(
                (F.col(PARAMETER_TYPE) != BIOLOGICAL) &
                (F.col(PARAMETER_THRESHOLD_MIN).isNotNull()) &
                (F.col(CALCULATED_TEST_RESULT).isNotNull()) &
                (F.col(CALCULATED_TEST_RESULT) < F.col(PARAMETER_THRESHOLD_MIN)),
                NON_COMPLIANT,
            ).when(
                (F.col(PARAMETER_TYPE) != BIOLOGICAL) &
                (F.col(PARAMETER_THRESHOLD_MIN).isNotNull()) &
                (F.col(CALCULATED_TEST_RESULT).isNotNull()) &
                (F.col(CALCULATED_TEST_RESULT) > F.col(PARAMETER_THRESHOLD_MAX)),
                NON_COMPLIANT,
            ).when(
                (F.col(PARAMETER_TYPE) == BIOLOGICAL) &
                (F.col(PARAMETER_THRESHOLD_MIN).isNotNull()) &
                (
                        (F.col(CALCULATED_TEST_RESULT).isNotNull()) &
                        (F.col(CALCULATED_TEST_RESULT) > 0)
                ) &
                (~ F.col(SAMPLE_PARAMETER_UNIT).isin(EXCLUDED_PARAM_UNITS)),
                NON_COMPLIANT,
            ).when(
                (F.col(PARAMETER_THRESHOLD_MIN).isNotNull()) &
                (
                        (F.col(CALCULATED_TEST_RESULT).isNotNull()) &
                        (F.col(CALCULATED_TEST_RESULT) > 0)
                ) &
                (F.col(CALCULATED_TEST_RESULT) < F.col(PARAMETER_THRESHOLD_MIN)) &
                (~ F.col(SAMPLE_PARAMETER_UNIT).isin(EXCLUDED_PARAM_UNITS)),
                NON_COMPLIANT,
            ).when(
                (F.col(PARAMETER_THRESHOLD_MAX).isNotNull()) &
                (
                        (F.col(CALCULATED_TEST_RESULT).isNotNull()) &
                        (F.col(CALCULATED_TEST_RESULT) > 0)
                ) &
                (F.col(CALCULATED_TEST_RESULT) > F.col(PARAMETER_THRESHOLD_MAX)) &
                (~ F.col(SAMPLE_PARAMETER_UNIT).isin(EXCLUDED_PARAM_UNITS)),
                NON_COMPLIANT,
            ).otherwise(COMPLIANT)
            .alias(THRESHOLD_EXCEPTION_STATUS),
        )
    )

    df_transformed_2 = df_transformed_1.alias("df_transformed_1").select(
        F.col("df_transformed_1.*"),
        F.when(F.col(SAMPLE_TEST_STATUS) == F.lit(PENDING), PENDING)
        .when(
            F.col(PARAMETER_THRESHOLD_MIN).isNull()
            | F.col(PARAMETER_THRESHOLD_MAX).isNull(),
            THRESHOLD_NOT_AVAILABLE,
        )
        .when(
            (F.col(CALCULATED_TEST_RESULT) >= F.col(PARAMETER_THRESHOLD_MIN))
            & (F.col(CALCULATED_TEST_RESULT) <= F.col(PARAMETER_THRESHOLD_MAX)),
            COMPLIANT,
        )
        .when(
            F.col(CALCULATED_TEST_RESULT) < F.col(PARAMETER_THRESHOLD_MIN),
            EXCEEDS_MIN,
        )
        .when(
            F.col(CALCULATED_TEST_RESULT) > F.col(PARAMETER_THRESHOLD_MAX),
            EXCEEDS_MAX,
        )
        .otherwise(NON_COMPLIANT)
        .alias(COMPLIANCE_STATUS),
        F.when(
            (F.col(THRESHOLD_EXCEPTION_STATUS) == F.lit(NON_COMPLIANT))
            & (F.col(COMPLIANCE_STATUS) == F.lit(EXCEEDS_MAX)),
            F.col(CALCULATED_TEST_RESULT) - F.col(PARAMETER_THRESHOLD_MAX),
        )
        .when(
            (F.col(THRESHOLD_EXCEPTION_STATUS) == F.lit(NON_COMPLIANT))
            & (F.col(COMPLIANCE_STATUS) == F.lit(EXCEEDS_MIN)),
            F.col(PARAMETER_THRESHOLD_MIN) - F.col(CALCULATED_TEST_RESULT),
        )
        .when(F.col(THRESHOLD_EXCEPTION_STATUS).isin(COMPLIANT, PENDING), 0.0)
        .otherwise(0.0)
        .alias("NON_COMPLIANT_AMOUNT"),
        F.when(
            (F.col(THRESHOLD_EXCEPTION_STATUS) == F.lit(NON_COMPLIANT))
            & (F.col(COMPLIANCE_STATUS) == F.lit(EXCEEDS_MAX)),
            (F.col(CALCULATED_TEST_RESULT) - F.col(PARAMETER_THRESHOLD_MAX))
            / F.col(PARAMETER_THRESHOLD_MAX),
        )
        .when(
            (F.col(THRESHOLD_EXCEPTION_STATUS) == F.lit(NON_COMPLIANT))
            & (F.col(COMPLIANCE_STATUS) == F.lit(EXCEEDS_MIN)),
            (F.col(PARAMETER_THRESHOLD_MIN) - F.col(CALCULATED_TEST_RESULT))
            / F.col(PARAMETER_THRESHOLD_MIN),
        )
        .when(F.col(THRESHOLD_EXCEPTION_STATUS).isin(COMPLIANT, PENDING), 0.0)
        .otherwise(0.0)
        .alias("NON_COMPLIANT_PERCENTAGE"),
        F.current_date().alias("LAST_UPDATED_DATE"),
        F.current_date().alias("CREATED_DATE"),
    )

    logging.info("Executed SQL query for data transformation.")

    max_partition_size_mb = 1024
    logging.info("Calculating the number of partitions.")
    num_partitions = calculate_num_partitions(df_transformed_2, max_partition_size_mb)
    logging.info(f"Repartitioning DataFrame into {num_partitions} partitions.")

    df_transformed = df_transformed_2.repartition(num_partitions)

    logging.info("Transformation process completed.")
    return df_transformed.distinct()


def transform(source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrame by performing necessary transformations and returns the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    logging.info("Starting the transformation process.")

    df_dim_wa_reg_parameter: DataFrame = source_dfs["DIM_WA_REG_PARAMETER"]
    df_fact_wa_eve_sample_result: DataFrame = source_dfs["FACT_WA_EVE_SAMPLE_RESULT"]
    df_parameter_unit_conversion: DataFrame = source_dfs["PARAMETER_UNIT_CONVERSION"]

    # Perform joins, filters, etc.
    df_transformed = prepare_transformed_df(
        df_dim_wa_reg_parameter=df_dim_wa_reg_parameter,
        df_fact_wa_eve_sample_result=df_fact_wa_eve_sample_result,
        df_parameter_unit_conversion=df_parameter_unit_conversion
    )

    logging.info("Data transformation completed.")

    return df_transformed


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df = transform(source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    select_cols = [schema["name"] for schema in target_schema]
    transformed_df = transformed_df.select(*select_cols)

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
