from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import regexp_replace, monotonically_increasing_id, lit
import logging
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")
from common_utils import calculate_num_partitions, impose_schema, trim_spaces
from read_utils import read


def prepare_sample_exclusion(
    spark: SparkSession, df_sample_exclude: DataFrame
) -> DataFrame:
    df_sample_exclude.createOrReplaceTempView("sample_exclude")  # PARTITION_KEY, DOMAIN_TYPE
    sql_query = """
    SELECT DISTINCT
        "Sample No Exclusion" as EXCLUSION_TYPE,
        se.SampleNo as SAMPLE_NO,
        NULL as PURCHASE_ORDER,
        NULL as SAMPLING_DATE,
        NULL as LOCATION_NAME,
        NULL as PARAMETER_NAME,
        "WATER" as DOMAIN_TYPE,
        "RECYCLED WATER" as SUB_DOMAIN_TYPE,
        "RECYCLED WATER" as PARTITION_KEY,
        current_timestamp() as LAST_UPDATED_DATE,
        current_timestamp() as CREATED_DATE
    from sample_exclude se
    """
    return spark.sql(sqlQuery=sql_query)


def prepare_sample_result_exclusion(
    spark: SparkSession, df_sample_results_exclude: DataFrame
):
    df_sample_results_exclude.createOrReplaceTempView("sample_results_exclude")  # PARTITION_KEY, DOMAIN_TYPE
    sql_query = """
        SELECT DISTINCT
            "Sample Result Exclusion" as EXCLUSION_TYPE,
            sre.SampleNo as SAMPLE_NO,
            NULL as PURCHASE_ORDER,
            sre.SamplingDate as SAMPLING_DATE,
            sre.LocationName as LOCATION_NAME,
            sre.ParameterName as PARAMETER_NAME,
            "WATER" as DOMAIN_TYPE,
            "RECYCLED WATER" as SUB_DOMAIN_TYPE,
            "RECYCLED WATER" as PARTITION_KEY,
            current_timestamp() as LAST_UPDATED_DATE,
            current_timestamp() as CREATED_DATE
        from sample_results_exclude sre
        """
    return spark.sql(sqlQuery=sql_query)


def prepare_purchase_order_exclusion(
    spark: SparkSession, df_purchase_orders: DataFrame
):
    df_purchase_orders.createOrReplaceTempView("purchase_orders")  # PARTITION_KEY, DOMAIN_TYPE
    sql_query = """
            SELECT DISTINCT
                "PO Exclusion" as EXCLUSION_TYPE,
                NULL as SAMPLE_NO,
                po.PurchaseOrderNumbers as PURCHASE_ORDER,
                NULL as SAMPLING_DATE,
                NULL as LOCATION_NAME,
                NULL as PARAMETER_NAME,
                "WATER" as DOMAIN_TYPE,
                "RECYCLED WATER" as SUB_DOMAIN_TYPE,
                "RECYCLED WATER" as PARTITION_KEY,
                current_timestamp() as LAST_UPDATED_DATE,
                current_timestamp() as CREATED_DATE
            from purchase_orders po
            """
    df_output = spark.sql(sqlQuery=sql_query)

    df_output = df_output.withColumn(
        "PURCHASE_ORDER", regexp_replace("PURCHASE_ORDER", "^PO# ", "")
    )
    return df_output


def prepare_parameter_surrogate_exclusion(
    spark: SparkSession, df_parameter_surrogates: DataFrame
):
    df_parameter_surrogates.createOrReplaceTempView("parameter_surrogates")  # PARTITION_KEY, DOMAIN_TYPE
    sql_query = """
                SELECT DISTINCT
                    "Parameter Surrogates" as EXCLUSION_TYPE,
                    NULL as SAMPLE_NO,
                    NULL as PURCHASE_ORDER,
                    NULL as SAMPLING_DATE,
                    NULL as LOCATION_NAME,
                    ps.Surrogates as PARAMETER_NAME,
                    "WATER" as DOMAIN_TYPE,
                    "RECYCLED WATER" as SUB_DOMAIN_TYPE,
                    "RECYCLED WATER" as PARTITION_KEY,
                    current_timestamp() as LAST_UPDATED_DATE,
                    current_timestamp() as CREATED_DATE
                from parameter_surrogates ps
                """
    return spark.sql(sqlQuery=sql_query)


def prepare_transformed_df(
    spark: SparkSession,
    df_sample_exclude: DataFrame,
    df_sample_results_exclude: DataFrame,
    df_parameter_surrogates: DataFrame,
    df_purchase_orders: DataFrame,
) -> DataFrame:

    logging.info("Starting the transformation process.")

    df_sample_exclusion = prepare_sample_exclusion(
        spark=spark, df_sample_exclude=df_sample_exclude
    )
    df_sample_result_exclusion = prepare_sample_result_exclusion(
        spark=spark, df_sample_results_exclude=df_sample_results_exclude
    )
    df_purchase_order_exclusion = prepare_purchase_order_exclusion(
        spark=spark, df_purchase_orders=df_purchase_orders
    )
    df_parameter_surrogate_exclusion = prepare_parameter_surrogate_exclusion(
        spark=spark, df_parameter_surrogates=df_parameter_surrogates
    )

    df_transformed = (
        df_sample_exclusion.unionByName(df_sample_result_exclusion)
        .unionByName(df_purchase_order_exclusion)
        .unionByName(df_parameter_surrogate_exclusion)
    )

    df_transformed = df_transformed.withColumn("DIM_EXCLUSION_ID", monotonically_increasing_id())

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info(f"Repartitioning the DataFrame into {num_partitions} partitions.")

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters, returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "LOCATION_MAPPING": DataFrame for location mapping.
            - "LOCATION_ATTRIBUTE": DataFrame for location attribute.
            - "DIM_CR_LOC_LOCATION_AREA": DataFrame for location area.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_sample_exclude = trim_spaces(source_dfs["SAMPLE_EXCLUDE"])
    df_sample_results_exclude = trim_spaces(source_dfs["SAMPLE_RESULTS_EXCLUDE"])
    df_parameter_surrogates = trim_spaces(source_dfs["PARAMETER_SURROGATES"])
    df_purchase_orders = trim_spaces(source_dfs["PURCHASE_ORDERS"])

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_sample_exclude=df_sample_exclude,
        df_sample_results_exclude=df_sample_results_exclude,
        df_parameter_surrogates=df_parameter_surrogates,
        df_purchase_orders=df_purchase_orders,
    )

    return transform_df


def execute_transform(
    spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    print("execute_transform: transformed_df schema::")
    transformed_df.printSchema()

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
