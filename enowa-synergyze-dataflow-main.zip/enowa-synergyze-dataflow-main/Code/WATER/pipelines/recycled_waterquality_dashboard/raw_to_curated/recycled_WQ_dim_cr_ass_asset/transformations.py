"""
Module: dim_cr_ass_asset
Description: Process data from raw to curated for the dim_cr_ass_asset.
It contains the necessary functions and logic to create dim_cr_ass_asset table in curated.

Author: Vaishnavi Ruikar
Date: 23-09-2024
"""
import logging
import os
import sys
from common_utils import calculate_num_partitions, impose_schema  # pylint: disable = import-error
from read_utils import read  # pylint: disable = import-error
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
    spark: SparkSession,
    df_location_attribute: DataFrame,
    df_dim_cr_loc_location: DataFrame,
) -> DataFrame:
    """
        It contains the necessary functions and logic to create transformed
        dim_cr_ass_asset df.
    """
    logging.info("Starting the transformation process.")
    df_location_attribute = df_location_attribute.distinct()
    logging.info("Removed duplicate records from df_location_attribute.")

    df_location_attribute.createOrReplaceTempView("location_attribute")
    df_dim_cr_loc_location.createOrReplaceTempView("dim_cr_loc_location")
    logging.info("Created temporary views for SQL operations.")

    sql_query = """
        SELECT
            loc.DIM_LOCATION_ID AS DIM_LOCATION_ID,
            'Water Asset' AS ASSET_DOMAIN_TYPE,
            'Recycled Water Asset' AS ASSET_SUB_DOMAIN_TYPE,
            'RECYCLED WATER' as PARTITION_KEY,
            la.AssetID AS ASSET_ID,
            la.AssetType AS ASSET_TYPE,
            NULL as ASSET_NAME,
            NULL as DIM_LOCATION_GROUP_ID,
            NULL as SUP_CATEGORY_ID,
            current_date() AS LAST_UPDATED_DATE,
            current_date() AS CREATED_DATE
        FROM location_attribute la
        LEFT JOIN dim_cr_loc_location loc ON la.LocationName = loc.LOCATION_NAME
        """

    logging.info("Executing SQL query for data transformation.")
    df_transformed = spark.sql(sql_query)
    logging.info("Executed SQL query for data transformation.")
    df_transformed = df_transformed.withColumn("DIM_ASSET_ID", sha2(concat_ws("||", "DIM_LOCATION_ID", "ASSET_ID"), 256))

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %s partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "LOCATION_ATTRIBUTE": DataFrame for location attribute.
            - "DIM_CR_LOC_LOCATION_AREA": DataFrame for location area.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_location_attribute = source_dfs["LOCATION_ATTRIBUTE"]
    df_dim_cr_loc_location = source_dfs["DIM_CR_LOC_LOCATION"]

    # Perform joins, filters, etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_location_attribute=df_location_attribute,
        df_dim_cr_loc_location=df_dim_cr_loc_location,
    )
    logging.info("Data transformation completed.")
    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
    spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage
        configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided

    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")
    print("printing spark df", spark_df)

    if task_name == "curated_data_processing_task":
        df = execute_transform(spark, pipeline_storage, task_parameters)
        print("Final Transformed df")
        df.show()
        return df
    return None
