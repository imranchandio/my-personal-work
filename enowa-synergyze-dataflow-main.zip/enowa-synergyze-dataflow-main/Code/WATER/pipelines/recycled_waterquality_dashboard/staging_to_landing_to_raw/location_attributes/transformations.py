def main(spark, spark_df, **kwargs):
    # Extract arguments from kwargs with default values if not provided
    task_name = kwargs.get('task_name')
    print("Spark session:", spark)
    if task_name == "data_movement_task":
        print("transformations - main")
        return spark_df
