from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from pyspark.sql.window import Window
import logging
from common_utils import calculate_num_partitions, impose_schema, \
    standardize_date_format
from read_utils import read


def prepare_df_sample(df_sample: DataFrame):
    """
    Processes a DataFrame to remove duplicate rows based on distinct values and retrieves
    the latest record per unique identifier based on specified date columns.

    This function performs the following steps:
    1. Removes duplicate rows from the input DataFrame.
    2. Assigns a row number to each record within each unique identifier group
       (partitioned by "DIM_SAMPLE_ID"), ordered by "REPORTING_DATE" (descending)
       and "CREATED_DATE" (descending).
    3. Filters to keep only the latest record (row number = 1) for each unique identifier.

    Args:
        df_sample (DataFrame): Input Spark DataFrame with columns "DIM_SAMPLE_ID",
                               "REPORTING_DATE", and "CREATED_DATE".

    Returns:
        DataFrame: Processed Spark DataFrame containing the latest unique records
                   for each "DIM_SAMPLE_ID".
    """
    df_sample = df_sample.distinct()
    window_spec = Window.partitionBy("DIM_SAMPLE_ID").orderBy(
        F.col("REPORTING_DATE").desc(), F.col("CREATED_DATE").desc()
    )
    df_sample_with_row_number = df_sample.withColumn(
        "row_number", F.row_number().over(window_spec)
    )
    latest_df_sample = df_sample_with_row_number.filter(F.col("row_number") == 1).drop(
        "row_number"
    )
    return latest_df_sample


def prepare_df_sample_batch(df_sample_batch: DataFrame):
    df_sample_batch = df_sample_batch.distinct()
    window_spec = Window.partitionBy("DIM_SAMPLE_BATCH_ID").orderBy(
        F.col("REPORTING_DATE").desc(), F.col("CREATED_DATE").desc()
    )
    df_with_row_number = df_sample_batch.withColumn(
        "row_number", F.row_number().over(window_spec)
    )
    latest_df = df_with_row_number.filter(F.col("row_number") == 1).drop("row_number")
    return latest_df


def prepare_df_sample_result_fact(df_sample_result_fact: DataFrame):
    df_sample_result_fact = df_sample_result_fact.distinct()
    window_spec = Window.partitionBy(
        "SAMPLE_LOCATION_NAME", "SAMPLE_TEST_NAME",
        "SAMPLE_CAPTURE_DATE").orderBy(
        F.col("REPORTING_DATE").asc(), F.col("CREATED_DATE").asc()
    )
    df_with_row_number = df_sample_result_fact.withColumn(
        "row_number", F.row_number().over(window_spec)
    )
    latest_df = df_with_row_number.filter(F.col("row_number") == 1).drop("row_number")
    return latest_df


def prepare_transformed_df(
        spark: SparkSession,
        df_sample: DataFrame,
        df_sample_batch: DataFrame,
        df_asset: DataFrame,
        df_location: DataFrame,
        df_parameter: DataFrame,
        df_location_area: DataFrame,
        df_waterqa_supplier: DataFrame,
        df_fact_wa_eve_sample_result: DataFrame,
        df_rwqd_sample_result_fact: DataFrame,
        df_dim_wa_op_exclusion: DataFrame
) -> DataFrame:
    logging.info("Starting the transformation process for location attributes.")

    logging.info(
        "Removed duplicate records from all the sources and Created temporary views"
    )

    df_sample = prepare_df_sample(df_sample)
    df_sample.createOrReplaceTempView("DIM_WA_OP_SAMPLE")

    df_sample_batch = prepare_df_sample_batch(df_sample_batch)
    df_sample_batch.createOrReplaceTempView("DIM_WA_OP_SAMPLE_BATCH")

    df_asset = df_asset.distinct()
    df_asset.createOrReplaceTempView("DIM_CR_ASS_ASSET")

    df_location = df_location.distinct()
    df_location.createOrReplaceTempView("DIM_CR_LOC_LOCATION")

    df_parameter = df_parameter.distinct()
    df_parameter.createOrReplaceTempView("DIM_WA_REG_PARAMETER")

    df_location_area = df_location_area.distinct()
    df_location_area.createOrReplaceTempView("DIM_CR_LOC_LOCATION_AREA")

    df_waterqa_supplier = df_waterqa_supplier.distinct()
    df_waterqa_supplier.createOrReplaceTempView("DIM_WA_ORG_WATERQA_SUPPLIER")

    df_fact_wa_eve_sample_result.createOrReplaceTempView("FACT_WA_EVE_SAMPLE_RESULT")

    df_rwqd_sample_result_fact = df_rwqd_sample_result_fact.distinct()
    df_rwqd_sample_result_fact.createOrReplaceTempView("FACT_WA_EVE_RWQD_SAMPLE_RESULT")

    df_dim_wa_op_exclusion.distinct().createOrReplaceTempView("DIM_WA_OP_EXCLUSION")

    df_transformed = spark.sql(
        """
        select
                CASE WHEN smpl.SAMPLE_SOURCE != 'SWCC' AND smpl.SAMPLE_NO IS NULL THEN 'ALS Field'
                    ELSE smpl.SAMPLE_NO
                END AS SAMPLE_ID,
                CASE WHEN smpl.SAMPLE_SOURCE = 'SWCC' then 'SWCC'
                    ELSE smpl_bt.PURCHASE_ORDER_NO
                END AS SAMPLE_PURCHASE_ORDER,
                CASE
                    WHEN smpl.SAMPLE_SOURCE = 'SWCC' THEN NULL
                    ELSE smpl.SAMPLE_DESCRIPTION
                END AS SAMPLING_PROGRAM,
                CASE WHEN smpl.SAMPLE_SOURCE = 'SWCC' THEN 'SWCC'
                    ELSE 'ALS'
                END AS WATER_QUALITY_SUPPLIER,
                coalesce(smpl_rslt.LOCATION_MAPPING_LOCATION_NAME, smpl_rslt.SAMPLE_LOCATION_NAME)
                    AS LOCATION_NAME,
                loc.LATITUDE AS LOCATION_LATITUDE,
                loc.LONGITUDE AS LOCATION_LONGITUDE,
                smpl_rslt.LOCATION_ATTRIBUTE_FLAG AS LOCATION_ATTRIBUTE_FLAG,
                smpl_rslt.LOCATION_MAPPING_FLAG AS LOCATION_MAPPING_FLAG,
                loc.LOCATION_SAMPLE_FREQUENCY AS LOCATION_SAMPLE_FREQUENCY,
                loc_area.LOCATION_AREA AS LOCATION_AREA,
                asst.ASSET_TYPE AS ASSET_TYPE,
                coalesce(smpl_rslt.PARAMETER_MAPPING_PARAMETER_NAME, smpl_rslt.SAMPLE_TEST_NAME)
                    AS PARAMETER_NAME,
                smpl_rslt.PARAMETER_ATTRIBUTE_FLAG AS PARAMETER_ATTRIBUTE_FLAG,
                smpl_rslt.PARAMETER_MAPPING_FLAG AS PARAMETER_MAPPING_FLAG,
                parm.PARAMETER_SYMBOL AS PARAMETER_SYMBOL,
                parm.PARAMETER_UNIT AS PARAMETER_UNIT,
                smpl_rslt.SAMPLE_PARAMETER_UNIT AS REPORTED_PARAMETER_UNIT,
                CASE WHEN upper(parm.THRESHOLD_PRIORITY) == upper('Commonly Tested') THEN "Frequent"
                    ELSE "Non-Frequent"
                END AS PARAMETER_TESTING_FREQUENCY,
                parm.PARAMETER_TYPE AS PARAMETER_TYPE,
                wqd_smpl_rst.CALCULATED_TEST_RESULT AS SAMPLE_CALCULATED_RESULT,
                smpl_rslt.SAMPLE_PARAMETER_VALUE AS REPORTED_TEST_RESULT,
                smpl_rslt.SAMPLE_TEST_STATUS AS SAMPLE_STATUS,
                wqd_smpl_rst.SAMPLE_RESULT_DETECTION AS DETECTION_STATUS,
                parm.THRESHOLD_LIMIT_STANDARD AS THRESHOLD_SOURCE,
                parm.THRESHOLD_PRIORITY AS THRESHOLD_PRIORITY,
                parm.PARAMETER_THRESHOLD_MIN AS MIN_THRESHOLD_VALUE,
                parm.PARAMETER_THRESHOLD_MAx AS MAX_THRESHOLD_VALUE,
                wqd_smpl_rst.THRESHOLD_RANGE AS THRESHOLD_RANGE,
                wqd_smpl_rst.THRESHOLD_EXCEPTION_STATUS AS THRESHOLD_EXCEPTION_STATUS,
                wqd_smpl_rst.COMPLIANCE_STATUS AS COMPLIANCE_STATUS,
                wqd_smpl_rst.NON_COMPLIANT_AMOUNT AS NON_COMPLIANT_AMOUNT,
                wqd_smpl_rst.NON_COMPLIANT_PERCENTAGE AS NON_COMPLIANT_PERCENTAGE,
                smpl_rslt.SAMPLE_CAPTURE_DATE AS SAMPLE_DATE,
                smpl_bt.RECEIVED_DATE AS SAMPLE_RECEIVED_DATE,
                loc.LOCATION_SAMPLE_CATEGORY as LOCATION_SAMPLE_CATEGORY,
                smpl_rslt.REPORTING_DATE as REPORTING_DATE,
                case when excl.DIM_EXCLUSION_ID is null
                    then 'NOT ENOWA PO'
                    else 'ENOWA PO'
                end as IS_ENOWA_PO
            from
            FACT_WA_EVE_SAMPLE_RESULT smpl_rslt
            left join FACT_WA_EVE_RWQD_SAMPLE_RESULT wqd_smpl_rst
                ON smpl_rslt.FACT_SAMPLE_RESULT_ID = wqd_smpl_rst.FACT_SAMPLE_RESULT_ID
                AND COALESCE(smpl_rslt.DIM_PARAMETER_ID, '') = COALESCE(wqd_smpl_rst.DIM_PARAMETER_ID, '')
            left join DIM_WA_OP_SAMPLE smpl
                ON smpl_rslt.DIM_SAMPLE_ID = smpl.DIM_SAMPLE_ID
            left join DIM_WA_OP_SAMPLE_BATCH smpl_bt
                ON smpl.DIM_SAMPLE_BATCH_ID = smpl_bt.DIM_SAMPLE_BATCH_ID
            left join DIM_CR_LOC_LOCATION loc
                ON smpl_rslt.DIM_LOCATION_ID = loc.DIM_LOCATION_ID
            left join DIM_CR_LOC_LOCATION_AREA loc_area
                ON loc.DIM_LOCATION_AREA_ID = loc_area.DIM_LOCATION_AREA_ID
            left join DIM_CR_ASS_ASSET asst
                ON smpl_rslt.DIM_ASSET_ID = asst.DIM_ASSET_ID
            left join DIM_WA_REG_PARAMETER parm
                ON smpl_rslt.DIM_PARAMETER_ID = parm.DIM_PARAMETER_ID
                AND parm.PRIMARY_STANDARD_FLAG = 'Primary'
            left join DIM_WA_ORG_WATERQA_SUPPLIER wtr_suplr
                ON smpl_rslt.DIM_WATERQA_SUPPLIER_ID = wtr_suplr.DIM_WATERQA_SUPPLIER_ID
            left join DIM_WA_OP_EXCLUSION excl
                on upper(EXCLUSION_TYPE) = 'PO EXCLUSION'
                and regexp_replace(smpl_bt.PURCHASE_ORDER_NO, '[PO #]','') =
                regexp_replace(excl.PURCHASE_ORDER, '[PO #]','')
        """
    )

    logging.info("Standardizing date columns")
    date_col_list = ["SAMPLE_DATE", "SAMPLE_RECEIVED_DATE"]
    df_transformed = standardize_date_format(df=df_transformed, column_list=date_col_list)

    logging.info("Executed SQL query for data transformation.")

    max_partition_size_mb = 1024
    logging.info("Calculating the number of partitions.")
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)
    logging.info(f"Repartitioning DataFrame into {num_partitions} partitions.")

    df_transformed = df_transformed.repartition(num_partitions)

    logging.info("Transformation process completed.")
    return df_transformed


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrame by performing necessary transformations and
    returns the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with
        the key "LOCATION_ATTRIBUTE".

    Returns:
        DataFrame: The transformed DataFrame.
    """
    logging.info("Starting the transformation process.")

    df_sample = source_dfs["DIM_WA_OP_SAMPLE"]
    df_sample_batch = source_dfs["DIM_WA_OP_SAMPLE_BATCH"]
    df_asset = source_dfs["DIM_CR_ASS_ASSET"]
    df_location = source_dfs["DIM_CR_LOC_LOCATION"]
    df_parameter = source_dfs["DIM_WA_REG_PARAMETER"]
    df_location_area = source_dfs["DIM_CR_LOC_LOCATION_AREA"]
    df_waterqa_supplier = source_dfs["DIM_WA_ORG_WATERQA_SUPPLIER"]
    df_fact_wa_eve_sample_result = source_dfs["FACT_WA_EVE_SAMPLE_RESULT"]
    df_rwqd_sample_result_fact = source_dfs["FACT_WA_EVE_RWQD_SAMPLE_RESULT"]
    df_dim_wa_op_exclusion = source_dfs["DIM_WA_OP_EXCLUSION"]

    # Filtering the DataFrame with WQD records
    df_waterqa_supplier = df_waterqa_supplier.filter(
        F.upper(df_waterqa_supplier.DOMAIN_TYPE) == "WATER"
    )

    # Perform joins, filters, etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_sample=df_sample,
        df_sample_batch=df_sample_batch,
        df_asset=df_asset,
        df_location=df_location,
        df_parameter=df_parameter,
        df_location_area=df_location_area,
        df_waterqa_supplier=df_waterqa_supplier,
        df_fact_wa_eve_sample_result=df_fact_wa_eve_sample_result,
        df_rwqd_sample_result_fact=df_rwqd_sample_result_fact,
        df_dim_wa_op_exclusion=df_dim_wa_op_exclusion
    )
    logging.info("Data transformation completed.")

    transform_df = transform_df.filter(F.col("SAMPLE_PURCHASE_ORDER").isNotNull())

    # transform_df = transform_df.orderBy(F.col("SAMPLE_ID").asc())
    #
    # # Deduplication logic
    # logging.info("deduplicating the records")
    # window_spec = Window.partitionBy("LOCATION_NAME", "PARAMETER_NAME", "SAMPLE_DATE") \
    #     .orderBy(F.lit(1))
    # transform_df_row_num = transform_df.withColumn(
    #     "row_number", F.row_number().over(window_spec)
    # )
    # transform_df_filtered = transform_df_row_num.filter(F.col("row_number") == F.lit(1))
    # transform_df_filtered = transform_df_filtered.drop("row_number", "REPORTING_DATE")

    transform_df_filtered = transform_df.drop("REPORTING_DATE")

    logging.info("Transformation completed successfully..")

    return transform_df_filtered


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage
        configuration information.
        task_parameters (dict): A dictionary containing task parameters, including
        the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    print(
        "execute_transform(): transformed_df schema:",
        transformed_df.printSchema()
    )

    return transformed_df.distinct()


def presentation_datavalidations(spark_df: DataFrame):
    print("Inside presentation_datavalidations")
    return spark_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the
            pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """

    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "50MB")

    print("Spark Session:", spark)  # Printing spark session object to avoid SonarQube issues

    if spark_df is not None:
        # Log the schema of spark_df if it's not None
        logging.info("Schema of spark_df:\n%s", spark_df.schema.simpleString())
    else:
        logging.warning("spark_df is None; skipping schema logging.")

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    elif task_name == "adw_presentation_data_validations_checks":
        print("transformations - adw_presentation_data_validations_checks")
        return presentation_datavalidations(spark_df)
