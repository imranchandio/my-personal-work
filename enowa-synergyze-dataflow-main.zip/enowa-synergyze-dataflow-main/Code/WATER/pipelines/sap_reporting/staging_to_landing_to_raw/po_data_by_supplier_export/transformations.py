"""
This is the transformation file for wbse_transaction_data
"""

# pylint:disable=import-error,unused-variable,unused-argument, raise-missing-from,broad-exception-raised
import logging
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import lit


def transform_dataframe(
    df: DataFrame
) -> DataFrame:
    """
    Transforms the input DataFrame by displaying its content and returning it.

    Args:
        df (DataFrame): The input Spark DataFrame to be transformed.

    Returns:
        DataFrame: The unchanged DataFrame after displaying its content.

    Notes:
        - This function can be expanded in the future to perform actual data transformations.
    """
    df = df.withColumn("OUTLINE_AGREEMENT", lit(None))
    df.show(truncate=False)

    return df



def main(spark: SparkSession, spark_df: DataFrame, **kwargs):

    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: source dataframe
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    print("Spark Session:", spark)  # Printing spark session object to avoid SonarQube issues
    if spark_df is not None:
        # Log the schema of spark_df if it's not None
        logging.info("Schema of spark_df:\n%s", spark_df.schema.simpleString())
    else:
        logging.warning("spark_df is None; skipping schema logging.")
    # Extract arguments from kwargs
    task_name = kwargs.get("task_name")

    raise ValueError(f"Unsupported task name: {task_name}")
