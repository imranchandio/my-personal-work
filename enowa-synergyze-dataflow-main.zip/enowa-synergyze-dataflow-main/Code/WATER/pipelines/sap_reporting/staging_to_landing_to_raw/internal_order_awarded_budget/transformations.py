"""
Module Description: Process data from raw to curated for the internal_order_budget.
"""
from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
import logging


def transform(df_source: DataFrame):
    """
        Converts specified date columns in the input DataFrame to TimestampType.

        Args:
            df_source (DataFrame): Input PySpark DataFrame.

        Returns:
            DataFrame: DataFrame with specified date columns transformed to TimestampType.
    """
    date_columns = ["DATE_DT", "LAST_REFRESH_DATE"]
    for column in date_columns:
        df_source = df_source.withColumn(
            column,
            F.to_timestamp(F.col(column), "yyyy-MM-dd HH:mm:ss")
        )
    return df_source


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")

    # Extract arguments from kwargs with default values if not provided
    task_name = kwargs.get('task_name')
    logging.debug(f"Spark session:{spark}")
    if task_name == "data_movement_task":
        logging.info("Executing transform function..")
        return transform(df_source=spark_df)
    return None
