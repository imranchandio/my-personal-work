"""
This is the transformation file for wbse_commitments
"""

# pylint:disable=import-error,unused-variable,unused-argument, raise-missing-from,broad-exception-raised
import logging
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import lit
from pyspark.sql.types import StringType


def transform_dataframe(
    df: DataFrame
) -> DataFrame:
    """
    Transforms the input DataFrame by displaying its content and returning it.

    Args:
        df (DataFrame): The input Spark DataFrame to be transformed.

    Returns:
        DataFrame: The unchanged DataFrame after displaying its content.

    Notes:
        - This function can be expanded in the future to perform actual data transformations.
    """
    df = df.withColumn("EXCHANGE_RATE", lit(None).cast(StringType()))

    return df



def main(spark, spark_df, **kwargs):
    # Extract arguments from kwargs with default values if not provided
    task_name = kwargs.get('task_name')
    print("spark session object", spark)
    if task_name == "data_movement_task":
        return transform_dataframe(spark_df)
