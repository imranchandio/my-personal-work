"""
Module Description: Process data from raw to curated for the internal_order_commitments.
"""
from pyspark.sql import DataFrame, SparkSession
import logging


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name = kwargs.get('task_name')
    logging.debug(f"Spark session:{spark}")
    if task_name == "data_movement_task":
        return spark_df
    return None