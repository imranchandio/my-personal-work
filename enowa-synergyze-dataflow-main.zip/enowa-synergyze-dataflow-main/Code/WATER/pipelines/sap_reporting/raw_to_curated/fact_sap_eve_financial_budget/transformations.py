# pylint:disable = C0301

# OCID: ocid1.dataflowapplication.oc1.me-jeddah-1.anvgkljrsvwgetyay4e4hq6ldq4xjdoeoxjzuonpovrbpaqk2vybfcjpqmca

import logging
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")

from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from common_utils import calculate_num_partitions, impose_schema, trim_spaces
from read_utils import read
import transform_queries as queries


def prepare_transformed_df(**kwargs) -> DataFrame:
    logging.info("Starting the transformation process.")

    dataframes = {
        "WBSE_CURRENT_BUDGET": "df_wbse_current_budget",
        "INTERNAL_ORDER_CURRENT_BUDGET": "df_internal_order_current_budget",
        "COST_CENTER_CURRENT_BUDGET": "df_cost_center_current_budget",
        "WBSE_AWARDED_BUDGET": "df_wbse_awarded_budget",
        "INTERNAL_ORDER_AWARDED_BUDGET": "df_internal_order_awarded_budget",
        "COST_CENTER_AWARDED_BUDGET": "df_cost_center_awarded_budget",
        "WBSE_BUDGET": "df_wbse_budget",
        "INTERNAL_ORDER_BUDGET": "df_internal_order_budget",
        "COST_CENTER_BUDGET": "df_cost_center_budget",
        "DIM_CR_FIN_ACCOUNT": "df_dim_cr_fin_account",
        "DIM_CR_FIN_COST_CENTER": "df_dim_cr_fin_cost_center",
        "DIM_CR_FIN_COST_ELEMENT": "df_dim_cr_fin_cost_element",
        "DIM_CR_REG_EXCHANGE_RATE": "df_dim_cr_reg_exchange_rate",
        "DIM_CR_FIN_FUND_CENTER": "df_dim_cr_fin_fund_center",
        "DIM_CR_FIN_FUND_GROUP_SAP": "df_dim_cr_fin_fund_group_sap",
        "DIM_CR_FIN_FUNCTIONAL_AREA": "df_dim_cr_fin_functional_area",
        "DIM_CR_WORK_PROGRAM": "df_dim_cr_work_program",
        "DIM_CR_WORK_WORK_ORDER": "df_dim_cr_work_work_order",
        "DIM_CR_CUS_CUSTOMER_KIND_SAP": "df_dim_cr_cus_customer_kind_sap"
    }

    for view_name, df_key in dataframes.items():
        kwargs.get(df_key).createOrReplaceTempView(view_name)

    # Execute the SQL query to generate the output DataFrame
    df_wbse_current_budget_transformed: DataFrame = kwargs.get("spark").sql(
        queries.WBSE_CURRENT_BUDGET
    )
    df_internal_order_current_budget_transformed: DataFrame = kwargs.get("spark").sql(
        queries.INTERNAL_ORDER_CURRENT_BUDGET
    )
    df_cost_center_current_budget_transformed: DataFrame = kwargs.get("spark").sql(
        queries.COST_CENTER_CURRENT_BUDGET
    )
    df_wbse_awarded_budget_transformed: DataFrame = kwargs.get("spark").sql(
        queries.WBSE_AWARDED_BUDGET
    )
    df_internal_order_awarded_budget_transformed: DataFrame = kwargs.get("spark").sql(
        queries.INTERNAL_ORDER_AWARDED_BUDGET
    )
    df_cost_center_awarded_budget_transformed: DataFrame = kwargs.get("spark").sql(
        queries.COST_CENTER_AWARDED_BUDGET
    )
    df_wbse_budget_transformed: DataFrame = kwargs.get("spark").sql(
        queries.WBSE_BUDGET
    )
    df_internal_order_budget_transformed: DataFrame = kwargs.get("spark").sql(
        queries.INTERNAL_ORDER_BUDGET
    )
    df_cost_center_budget_transformed: DataFrame = kwargs.get("spark").sql(
        queries.COST_CENTER_BUDGET
    )

    df_transformed = df_wbse_current_budget_transformed.unionByName(
        df_internal_order_current_budget_transformed
    ).unionByName(
        df_cost_center_current_budget_transformed
    ).unionByName(
        df_wbse_awarded_budget_transformed
    ).unionByName(
        df_internal_order_awarded_budget_transformed
    ).unionByName(
        df_cost_center_awarded_budget_transformed
    ).unionByName(
        df_wbse_budget_transformed
    ).unionByName(
        df_internal_order_budget_transformed
    ).unionByName(
        df_cost_center_budget_transformed
    )

    # List of columns for generating the key
    columns = [
        'DIM_ACCOUNT_ID', 'DIM_COST_CENTER_ID',
        'DIM_COST_ELEMENT_ID', 'DIM_EXCHANGE_RATE_ID', 'DIM_FUND_CENTER_ID',
        'DIM_FUND_GROUP_ID', 'DIM_FUNCTIONAL_AREA_ID', 'DIM_PROGRAM_ID',
        'DIM_WORK_ORDER_ID', 'CUSTOMER_KIND_ID', 'BUDGET_VERSION',
        'BUDGET_FISCAL_YEAR', 'BUDGET_PERIOD', 'BUDGET_TRANSACTION_CODE',
        'BUDGET_VALUE_TYPE', 'BUDGET_ATTRIBUTE', 'BUDGET_VALUE_IN_COMPANY_CURRENCY',
        'BUDGET_DATE', 'BUDGET_LAST_REFRESH_DATE', 'BUDGET_DELETION_INDICATOR',
        'BUDGET_SECTOR_REQ_N_RESP', 'BUDGET_REGION_REQ_N_RESP'
    ]

    # Generate the key
    df_transformed = df_transformed.withColumn(
        "FACT_FINANCIAL_BUDGET_ID",
        F.sha2(
            F.concat_ws(
                "||",
                *[F.coalesce(F.col(col), F.lit("-")) for col in columns]
            ),
            256
        )
    )

    # Technical metadata columns
    df_transformed = df_transformed.withColumn(
        "LAST_UPDATED_DATE", F.current_timestamp()
    ).withColumn(
        "CREATED_DATE", F.current_timestamp()
    )

    print(
        "df_transformed schema before imposing schema:",
        df_transformed.printSchema()
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 1024
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info(
        f"Repartitioning the DataFrame into {num_partitions} partitions."
    )

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters, returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_wbse_current_budget = source_dfs["WBSE_CURRENT_BUDGET"]
    df_internal_order_current_budget = source_dfs["INTERNAL_ORDER_CURRENT_BUDGET"]
    df_cost_center_current_budget = source_dfs["COST_CENTER_CURRENT_BUDGET"]
    df_wbse_awarded_budget = source_dfs["WBSE_AWARDED_BUDGET"]
    df_internal_order_awarded_budget = source_dfs["INTERNAL_ORDER_AWARDED_BUDGET"]
    df_cost_center_awarded_budget = source_dfs["COST_CENTER_AWARDED_BUDGET"]
    df_wbse_budget = source_dfs["WBSE_BUDGET"]
    df_internal_order_budget = source_dfs["INTERNAL_ORDER_BUDGET"]
    df_cost_center_budget = source_dfs["COST_CENTER_BUDGET"]
    df_dim_cr_fin_account = source_dfs["DIM_CR_FIN_ACCOUNT"]
    df_dim_cr_fin_cost_center = source_dfs["DIM_CR_FIN_COST_CENTER"]
    df_dim_cr_fin_cost_element = source_dfs["DIM_CR_FIN_COST_ELEMENT"]
    df_dim_cr_reg_exchange_rate = source_dfs["DIM_CR_REG_EXCHANGE_RATE"]
    df_dim_cr_fin_fund_center = source_dfs["DIM_CR_FIN_FUND_CENTER"]
    df_dim_cr_fin_fund_group_sap = source_dfs["DIM_CR_FIN_FUND_GROUP_SAP"]
    df_dim_cr_fin_functional_area = source_dfs["DIM_CR_FIN_FUNCTIONAL_AREA"]
    df_dim_cr_work_program = source_dfs["DIM_CR_WORK_PROGRAM"]
    df_dim_cr_work_work_order = source_dfs["DIM_CR_WORK_WORK_ORDER"]
    df_dim_cr_cus_customer_kind_sap = source_dfs["DIM_CR_CUS_CUSTOMER_KIND_SAP"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_wbse_current_budget=df_wbse_current_budget,
        df_internal_order_current_budget=df_internal_order_current_budget,
        df_cost_center_current_budget=df_cost_center_current_budget,
        df_wbse_awarded_budget=df_wbse_awarded_budget,
        df_internal_order_awarded_budget=df_internal_order_awarded_budget,
        df_cost_center_awarded_budget=df_cost_center_awarded_budget,
        df_wbse_budget=df_wbse_budget,
        df_internal_order_budget=df_internal_order_budget,
        df_cost_center_budget=df_cost_center_budget,
        df_dim_cr_fin_account=df_dim_cr_fin_account,
        df_dim_cr_fin_cost_center=df_dim_cr_fin_cost_center,
        df_dim_cr_fin_cost_element=df_dim_cr_fin_cost_element,
        df_dim_cr_reg_exchange_rate=df_dim_cr_reg_exchange_rate,
        df_dim_cr_fin_fund_center=df_dim_cr_fin_fund_center,
        df_dim_cr_fin_fund_group_sap=df_dim_cr_fin_fund_group_sap,
        df_dim_cr_fin_functional_area=df_dim_cr_fin_functional_area,
        df_dim_cr_work_program=df_dim_cr_work_program,
        df_dim_cr_work_work_order=df_dim_cr_work_work_order,
        df_dim_cr_cus_customer_kind_sap=df_dim_cr_cus_customer_kind_sap
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")

    if spark_df:
        print(spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
