WBSE_CURRENT_BUDGET = """
        Select          
            fin_acc.DIM_ACCOUNT_ID,
            fin_cc.DIM_COST_CENTER_ID,
            fin_ce.DIM_COST_ELEMENT_ID,
            exc.DIM_EXCHANGE_RATE_ID,
            fin_fc.DIM_FUND_CENTER_ID,
            fin_fg.DIM_FUND_GROUP_ID,
            fin_fa.DIM_FUNCTIONAL_AREA_ID,
            wp.DIM_PROGRAM_ID,
            work.DIM_WORK_ORDER_ID,
            ck.CUSTOMER_KIND_ID,
            src.Version as BUDGET_VERSION,
            src.Fiscal_Year as BUDGET_FISCAL_YEAR,
            src.Period as BUDGET_PERIOD,
            src.Transaction as BUDGET_TRANSACTION_CODE,
            src.Value_Type as BUDGET_VALUE_TYPE,
            src.Attribute as BUDGET_ATTRIBUTE,
            src.VALUE_IN_COMPANY_CURRENCY as BUDGET_VALUE_IN_COMPANY_CURRENCY,
            src.DATE as BUDGET_DATE,
            src.LAST_REFRESH_DATE as BUDGET_LAST_REFRESH_DATE,
            src.DELETION_INDICATOR as BUDGET_DELETION_INDICATOR,
            src.Sector_Req_AND_Resp as BUDGET_SECTOR_REQ_N_RESP,
            src.REGION_REQ_AND_RESP as BUDGET_REGION_REQ_N_RESP,
            'WBSE BUDGET' as BUDGET_CATEGORY,
            'CURRENT BUDGET' as BUDGET_TYPE
        From
            WBSE_CURRENT_BUDGET src
            left join DIM_CR_FIN_ACCOUNT fin_acc
                ON coalesce(src.ACCOUNT, '-') = coalesce(fin_acc.ACCOUNT_NAME, '-')
            left join DIM_CR_FIN_COST_CENTER fin_cc
                ON coalesce(src.REQUESTING_COST_CENTER_KEY, '-') = coalesce(fin_cc.REQUEST_CCTR, '-')
                AND coalesce(src.RESPONSIBLE_COST_CENTER_KEY, '-') = coalesce(fin_cc.RESPONSIBLE_CCTR, '-')
            left join DIM_CR_FIN_COST_ELEMENT fin_ce
                ON coalesce(src.COST_ELEMENT, '-') = coalesce(fin_ce.COST_ELEMENT_NUMBER, '-')
                AND coalesce(src.COST_ELEMENT_DESC, '-') = coalesce(fin_ce.COST_ELEMENT_SHORT_TEXT, '-')
            left join DIM_CR_REG_EXCHANGE_RATE exc
                ON coalesce(src.CURRENCY, '-') = coalesce(exc.CURRENCY_FROM, '-')
            left join DIM_CR_FIN_FUND_CENTER fin_fc
                ON coalesce(src.FUND, '-') = coalesce(fin_fc.FUND_CENTER_NAME, '-')
                AND coalesce(src.FUNDS_CENTER_DESC, '-') = coalesce(fin_fc.FUND_CENTER_DESCRIPTION, '-')
                AND coalesce(src.FUNDS_CENTER, '-') = coalesce(fin_fc.FUND_CENTER_CODE, '-')
            left join DIM_CR_FIN_FUND_GROUP_SAP fin_fg
                ON coalesce(src.REQUESTING_REGION, '-') = coalesce(fin_fg.REQUESTING_FUND_GROUP, '-')
                AND coalesce(src.RESPONSIBLE_REGION, '-') = coalesce(fin_fg.RESPONSIBLE_FUND_GROUP, '-')
                AND fin_fg.FUND_GROUP_NAME is null
                AND fin_fg.HIERARCHY_GROUP is null
                AND fin_fg.SEMI_GROUP_CODE is null
            left join DIM_CR_FIN_FUNCTIONAL_AREA fin_fa
                ON coalesce(src.FUND_AREA, '-') = coalesce(fin_fa.FUNCTIONAL_AREA, '-')
            left join DIM_CR_WORK_PROGRAM wp
                ON coalesce(src.Program_Definition_Key, '-') = coalesce(wp.PROGRAM_DEFINITION_KEY, '-')
                AND coalesce(src.Program_Definition_Desc, '-') = coalesce(wp.PROGRAM_DEFINITION_DESC, '-')
            left join DIM_CR_WORK_WORK_ORDER work
                ON coalesce(src.WBS_Element, '-') = coalesce(work.ORDER, '-')
                AND coalesce(src.WBS_Element_Desc, '-') = coalesce(work.ORDER_DESCRIPTION, '-')
                AND coalesce(src.WBS_Element_Key, '-') = coalesce(work.ORDER_ELEMENT_KEY, '-')
            left join DIM_CR_CUS_CUSTOMER_KIND_SAP ck
                ON coalesce(src.Requesting_Sector, '-') = coalesce(ck.REQUESTING_SECTOR, '-')
                AND coalesce(src.RESPONSIBLE_SECTOR, '-') = coalesce(ck.RESPONSIBLE_SECTOR, '-')
                AND ck.CUSTOMER_KIND_SECTOR is null
"""

INTERNAL_ORDER_CURRENT_BUDGET = """
        Select          
            fin_acc.DIM_ACCOUNT_ID,
            fin_cc.DIM_COST_CENTER_ID,
            fin_ce.DIM_COST_ELEMENT_ID,
            exc.DIM_EXCHANGE_RATE_ID,
            fin_fc.DIM_FUND_CENTER_ID,
            fin_fg.DIM_FUND_GROUP_ID,
            fin_fa.DIM_FUNCTIONAL_AREA_ID,
            NULL AS DIM_PROGRAM_ID,
            work.DIM_WORK_ORDER_ID,
            ck.CUSTOMER_KIND_ID,
            src.Version as BUDGET_VERSION,
            src.Fiscal_Year as BUDGET_FISCAL_YEAR,
            src.Period as BUDGET_PERIOD,
            src.Transaction as BUDGET_TRANSACTION_CODE,
            src.Value_Type as BUDGET_VALUE_TYPE,
            src.Attribute as BUDGET_ATTRIBUTE,
            src.VALUE_IN_COMPANY_CURRENCY as BUDGET_VALUE_IN_COMPANY_CURRENCY,
            src.DATE as BUDGET_DATE,
            src.LAST_REFRESH_DATE as BUDGET_LAST_REFRESH_DATE,
            NULL as BUDGET_DELETION_INDICATOR,
            src.Sector_Req_AND_Resp as BUDGET_SECTOR_REQ_N_RESP,
            src.REGION_REQ_AND_RESP as BUDGET_REGION_REQ_N_RESP,
            'IO BUDGET' as BUDGET_CATEGORY,
            'CURRENT BUDGET' as BUDGET_TYPE
        From
            INTERNAL_ORDER_CURRENT_BUDGET src
            left join DIM_CR_FIN_ACCOUNT fin_acc
                ON coalesce(src.ACCOUNT, '-') = coalesce(fin_acc.ACCOUNT_NAME, '-')
            left join DIM_CR_FIN_COST_CENTER fin_cc
                ON coalesce(src.REQUESTING_COST_CENTER_KEY, '-') = coalesce(fin_cc.REQUEST_CCTR, '-')
                AND coalesce(src.RESPONSIBLE_COST_CENTER_KEY, '-') = coalesce(fin_cc.RESPONSIBLE_CCTR, '-')
            left join DIM_CR_FIN_COST_ELEMENT fin_ce
                ON coalesce(src.COST_ELEMENT, '-') = coalesce(fin_ce.COST_ELEMENT_NUMBER, '-')
                AND coalesce(src.COST_ELEMENT_DESC, '-') = coalesce(fin_ce.COST_ELEMENT_SHORT_TEXT, '-')
            left join DIM_CR_REG_EXCHANGE_RATE exc
                ON coalesce(src.CURRENCY, '-') = coalesce(exc.CURRENCY_FROM, '-')
            left join DIM_CR_FIN_FUND_CENTER fin_fc
                ON coalesce(src.FUND, '-') = coalesce(fin_fc.FUND_CENTER_NAME, '-')
                AND coalesce(src.FUNDS_CENTER_DESC, '-') = coalesce(fin_fc.FUND_CENTER_DESCRIPTION, '-')
                AND coalesce(src.FUNDS_CENTER, '-') = coalesce(fin_fc.FUND_CENTER_CODE, '-')
            left join DIM_CR_FIN_FUND_GROUP_SAP fin_fg
                ON coalesce(src.REQUESTING_REGION, '-') = coalesce(fin_fg.REQUESTING_FUND_GROUP, '-')
                AND coalesce(src.RESPONSIBLE_REGION, '-') = coalesce(fin_fg.RESPONSIBLE_FUND_GROUP, '-')
                AND fin_fg.FUND_GROUP_NAME is null
                AND fin_fg.HIERARCHY_GROUP is null
                AND fin_fg.SEMI_GROUP_CODE is null
            left join DIM_CR_FIN_FUNCTIONAL_AREA fin_fa
                ON coalesce(src.FUND_AREA, '-') = coalesce(fin_fa.FUNCTIONAL_AREA, '-')
            left join DIM_CR_WORK_WORK_ORDER work
                ON coalesce(src.ORDER, '-') = coalesce(work.ORDER, '-')
                AND work.IO_WBS_DESCRIPTION is null
                AND work.ORDER_DESCRIPTION is null
                AND work.ORDER_ELEMENT_KEY is null
            left join DIM_CR_CUS_CUSTOMER_KIND_SAP ck
                ON coalesce(src.Requesting_Sector, '-') = coalesce(ck.REQUESTING_SECTOR, '-')
                AND coalesce(src.RESPONSIBLE_SECTOR, '-') = coalesce(ck.RESPONSIBLE_SECTOR, '-')
                AND ck.CUSTOMER_KIND_SECTOR is null
"""

COST_CENTER_CURRENT_BUDGET = """
        Select          
            fin_acc.DIM_ACCOUNT_ID,
            fin_cc.DIM_COST_CENTER_ID,
            fin_ce.DIM_COST_ELEMENT_ID,
            exc.DIM_EXCHANGE_RATE_ID,
            fin_fc.DIM_FUND_CENTER_ID,
            fin_fg.DIM_FUND_GROUP_ID,
            fin_fa.DIM_FUNCTIONAL_AREA_ID,
            NULL AS DIM_PROGRAM_ID,
            NULL AS DIM_WORK_ORDER_ID,
            ck.CUSTOMER_KIND_ID,
            src.Version as BUDGET_VERSION,
            src.Fiscal_Year as BUDGET_FISCAL_YEAR,
            src.Period as BUDGET_PERIOD,
            src.BUSINESS_TRANSACTION as BUDGET_TRANSACTION_CODE,
            NULL as BUDGET_VALUE_TYPE,
            src.Attribute as BUDGET_ATTRIBUTE,
            src.VALUE_IN_COMPANY_CURRENCY as BUDGET_VALUE_IN_COMPANY_CURRENCY,
            src.DATE as BUDGET_DATE,
            src.LAST_REFRESH_DATE as BUDGET_LAST_REFRESH_DATE,
            NULL as BUDGET_DELETION_INDICATOR,
            NULL as BUDGET_SECTOR_REQ_N_RESP,
            NULL as BUDGET_REGION_REQ_N_RESP,
            'COST CENTER BUDGET' as BUDGET_CATEGORY,
            'CURRENT BUDGET' as BUDGET_TYPE
        From
            COST_CENTER_CURRENT_BUDGET src
            left join DIM_CR_FIN_ACCOUNT fin_acc
                ON coalesce(src.ACCOUNT, '-') = coalesce(fin_acc.ACCOUNT_NAME, '-')
            left join DIM_CR_FIN_COST_CENTER fin_cc
                ON coalesce(src.COST_CENTER, '-') = coalesce(fin_cc.COST_CENTER, '-')
                AND fin_cc.COST_CENTER is not null
                AND fin_cc.RESPONSIBLE_CCTR is null
                AND fin_cc.REQUEST_CCTR is null
            left join DIM_CR_FIN_COST_ELEMENT fin_ce
                ON coalesce(src.COST_ELEMENT, '-') = coalesce(fin_ce.COST_ELEMENT_NUMBER, '-')
                AND coalesce(src.COST_ELEMENT_DESC, '-') = coalesce(fin_ce.COST_ELEMENT_SHORT_TEXT, '-')
            left join DIM_CR_REG_EXCHANGE_RATE exc
                ON coalesce(src.CURRENCY, '-') = coalesce(exc.CURRENCY_FROM, '-')
            left join DIM_CR_FIN_FUND_CENTER fin_fc
                ON coalesce(src.FUND, '-') = coalesce(fin_fc.FUND_CENTER_NAME, '-')
                AND coalesce(src.FUNDS_CENTER_DESC, '-') = coalesce(fin_fc.FUND_CENTER_DESCRIPTION, '-')
                AND coalesce(src.FUNDS_CENTER, '-') = coalesce(fin_fc.FUND_CENTER_CODE, '-')
            left join (SELECT DISTINCT DIM_FUND_GROUP_ID, FUND_GROUP_NAME
                        FROM DIM_CR_FIN_FUND_GROUP_SAP 
                        WHERE REQUESTING_FUND_GROUP is null
                        AND RESPONSIBLE_FUND_GROUP is null
                        AND HIERARCHY_GROUP is null
                        AND SEMI_GROUP_CODE is null) fin_fg
                ON coalesce(src.REGION, '-') = coalesce(fin_fg.FUND_GROUP_NAME, '-')                        
            left join DIM_CR_FIN_FUNCTIONAL_AREA fin_fa
                ON coalesce(src.FUND_AREA, '-') = coalesce(fin_fa.FUNCTIONAL_AREA, '-')
            left join DIM_CR_CUS_CUSTOMER_KIND_SAP ck
                ON coalesce(src.SECTOR, '-') = coalesce(ck.CUSTOMER_KIND_SECTOR, '-')
                AND ck.CUSTOMER_KIND_SECTOR_CODE is null
                AND ck.REQUESTING_SECTOR is null
                AND ck.RESPONSIBLE_SECTOR is null
"""

WBSE_AWARDED_BUDGET = """
        Select          
            fin_acc.DIM_ACCOUNT_ID,
            fin_cc.DIM_COST_CENTER_ID,
            fin_ce.DIM_COST_ELEMENT_ID,
            exc.DIM_EXCHANGE_RATE_ID,
            fin_fc.DIM_FUND_CENTER_ID,
            fin_fg.DIM_FUND_GROUP_ID,
            fin_fa.DIM_FUNCTIONAL_AREA_ID,
            wp.DIM_PROGRAM_ID,
            work.DIM_WORK_ORDER_ID,
            ck.CUSTOMER_KIND_ID,
            src.Version as BUDGET_VERSION,
            src.Fiscal_Year as BUDGET_FISCAL_YEAR,
            src.Period as BUDGET_PERIOD,
            src.Transaction as BUDGET_TRANSACTION_CODE,
            src.Value_Type as BUDGET_VALUE_TYPE,
            src.Attribute as BUDGET_ATTRIBUTE,
            src.VALUE_IN_COMPANY_CURRENCY as BUDGET_VALUE_IN_COMPANY_CURRENCY,
            src.DATE as BUDGET_DATE,
            src.LAST_REFRESH_DATE as BUDGET_LAST_REFRESH_DATE,
            src.DELETION_INDICATOR as BUDGET_DELETION_INDICATOR,
            src.Sector_Req_AND_Resp as BUDGET_SECTOR_REQ_N_RESP,
            src.REGION_REQ_AND_RESP as BUDGET_REGION_REQ_N_RESP,
            'WBSE BUDGET' as BUDGET_CATEGORY,
            'AWARDED BUDGET' as BUDGET_TYPE
        From
            WBSE_AWARDED_BUDGET src
            left join DIM_CR_FIN_ACCOUNT fin_acc
                ON coalesce(src.ACCOUNT, '-') = coalesce(fin_acc.ACCOUNT_NAME, '-')
            left join DIM_CR_FIN_COST_CENTER fin_cc
                ON coalesce(src.REQUESTING_COST_CENTER_KEY, '-') = coalesce(fin_cc.REQUEST_CCTR, '-')
                AND coalesce(src.RESPONSIBLE_COST_CENTER_KEY, '-') = coalesce(fin_cc.RESPONSIBLE_CCTR, '-')
            left join DIM_CR_FIN_COST_ELEMENT fin_ce
                ON coalesce(src.COST_ELEMENT, '-') = coalesce(fin_ce.COST_ELEMENT_NUMBER, '-')
                AND coalesce(src.COST_ELEMENT_DESC, '-') = coalesce(fin_ce.COST_ELEMENT_SHORT_TEXT, '-')
            left join DIM_CR_REG_EXCHANGE_RATE exc
                ON coalesce(src.CURRENCY, '-') = coalesce(exc.CURRENCY_FROM, '-')
            left join DIM_CR_FIN_FUND_CENTER fin_fc
                ON coalesce(src.FUND, '-') = coalesce(fin_fc.FUND_CENTER_NAME, '-')
                AND coalesce(src.FUNDS_CENTER_DESC, '-') = coalesce(fin_fc.FUND_CENTER_DESCRIPTION, '-')
                AND coalesce(src.FUNDS_CENTER, '-') = coalesce(fin_fc.FUND_CENTER_CODE, '-')
            left join DIM_CR_FIN_FUND_GROUP_SAP fin_fg
                ON coalesce(src.REQUESTING_REGION, '-') = coalesce(fin_fg.REQUESTING_FUND_GROUP, '-')
                AND coalesce(src.RESPONSIBLE_REGION, '-') = coalesce(fin_fg.RESPONSIBLE_FUND_GROUP, '-')
                AND fin_fg.FUND_GROUP_NAME is null
                AND fin_fg.HIERARCHY_GROUP is null
                AND fin_fg.SEMI_GROUP_CODE is null
            left join DIM_CR_FIN_FUNCTIONAL_AREA fin_fa
                ON coalesce(src.FUND_AREA, '-') = coalesce(fin_fa.FUNCTIONAL_AREA, '-')
            left join DIM_CR_WORK_PROGRAM wp
                ON coalesce(src.PROGRAM_DEFINITION_KEY, '-') = coalesce(wp.PROGRAM_DEFINITION_KEY, '-')
                AND coalesce(src.PROGRAM_DEFINITION_DESC, '-') = coalesce(wp.PROGRAM_DEFINITION_DESC, '-')
            left join DIM_CR_WORK_WORK_ORDER work
                ON coalesce(src.WBS_Element, '-') = coalesce(work.ORDER, '-')
                AND coalesce(src.WBS_Element_Desc, '-') = coalesce(work.ORDER_DESCRIPTION, '-')
                AND coalesce(src.WBS_Element_Key, '-') = coalesce(work.ORDER_ELEMENT_KEY, '-')
            left join DIM_CR_CUS_CUSTOMER_KIND_SAP ck
                ON coalesce(src.Requesting_Sector, '-') = coalesce(ck.REQUESTING_SECTOR, '-')
                AND coalesce(src.RESPONSIBLE_SECTOR, '-') = coalesce(ck.RESPONSIBLE_SECTOR, '-')
                AND ck.CUSTOMER_KIND_SECTOR is null
"""

INTERNAL_ORDER_AWARDED_BUDGET = """
        Select          
            fin_acc.DIM_ACCOUNT_ID,
            fin_cc.DIM_COST_CENTER_ID,
            fin_ce.DIM_COST_ELEMENT_ID,
            exc.DIM_EXCHANGE_RATE_ID,
            fin_fc.DIM_FUND_CENTER_ID,
            fin_fg.DIM_FUND_GROUP_ID,
            fin_fa.DIM_FUNCTIONAL_AREA_ID,
            NULL AS DIM_PROGRAM_ID,
            work.DIM_WORK_ORDER_ID,
            ck.CUSTOMER_KIND_ID,
            src.Version as BUDGET_VERSION,
            src.Fiscal_Year as BUDGET_FISCAL_YEAR,
            src.Period as BUDGET_PERIOD,
            src.Transaction as BUDGET_TRANSACTION_CODE,
            src.Value_Type as BUDGET_VALUE_TYPE,
            src.Attribute as BUDGET_ATTRIBUTE,
            src.VALUE_IN_COMPANY_CURRENCY as BUDGET_VALUE_IN_COMPANY_CURRENCY,
            src.DATE_DT as BUDGET_DATE,
            src.LAST_REFRESH_DATE as BUDGET_LAST_REFRESH_DATE,
            NULL as BUDGET_DELETION_INDICATOR,
            src.Sector_Req_AND_Resp as BUDGET_SECTOR_REQ_N_RESP,
            src.REGION_REQ_AND_RESP as BUDGET_REGION_REQ_N_RESP,
            'IO BUDGET' as BUDGET_CATEGORY,
            'AWARDED BUDGET' as BUDGET_TYPE
        From
            INTERNAL_ORDER_AWARDED_BUDGET src
            left join DIM_CR_FIN_ACCOUNT fin_acc
                ON coalesce(src.ACCOUNT, '-') = coalesce(fin_acc.ACCOUNT_NAME, '-')
            left join DIM_CR_FIN_COST_CENTER fin_cc
                ON coalesce(src.REQUESTING_COST_CENTER_KEY, '-') = coalesce(fin_cc.REQUEST_CCTR, '-')
                AND coalesce(src.RESPONSIBLE_COST_CENTER_KEY, '-') = coalesce(fin_cc.RESPONSIBLE_CCTR, '-')
            left join DIM_CR_FIN_COST_ELEMENT fin_ce
                ON coalesce(src.COST_ELEMENT, '-') = coalesce(fin_ce.COST_ELEMENT_NUMBER, '-')
                AND coalesce(src.COST_ELEMENT_DESC, '-') = coalesce(fin_ce.COST_ELEMENT_SHORT_TEXT, '-')
            left join DIM_CR_REG_EXCHANGE_RATE exc
                ON coalesce(src.CURRENCY, '-') = coalesce(exc.CURRENCY_FROM, '-')
            left join DIM_CR_FIN_FUND_CENTER fin_fc
                ON coalesce(src.FUND, '-') = coalesce(fin_fc.FUND_CENTER_NAME, '-')
                AND coalesce(src.FUNDS_CENTER_DESC, '-') = coalesce(fin_fc.FUND_CENTER_DESCRIPTION, '-')
                AND coalesce(src.FUNDS_CENTER, '-') = coalesce(fin_fc.FUND_CENTER_CODE, '-')
            left join DIM_CR_FIN_FUND_GROUP_SAP fin_fg
                ON coalesce(src.REQUESTING_REGION, '-') = coalesce(fin_fg.REQUESTING_FUND_GROUP, '-')
                AND coalesce(src.RESPONSIBLE_REGION, '-') = coalesce(fin_fg.RESPONSIBLE_FUND_GROUP, '-')
                AND fin_fg.FUND_GROUP_NAME is null
                AND fin_fg.HIERARCHY_GROUP is null
                AND fin_fg.SEMI_GROUP_CODE is null
            left join DIM_CR_FIN_FUNCTIONAL_AREA fin_fa
                ON coalesce(src.FUND_AREA, '-') = coalesce(fin_fa.FUNCTIONAL_AREA, '-')
            left join DIM_CR_WORK_WORK_ORDER work
                ON coalesce(src.ORDER, '-') = coalesce(work.ORDER, '-')
                AND work.IO_WBS_DESCRIPTION is null
                AND work.ORDER_DESCRIPTION is null
                AND work.ORDER_ELEMENT_KEY is null
            left join DIM_CR_CUS_CUSTOMER_KIND_SAP ck
                ON coalesce(src.Requesting_Sector, '-') = coalesce(ck.REQUESTING_SECTOR, '-')
                AND coalesce(src.RESPONSIBLE_SECTOR, '-') = coalesce(ck.RESPONSIBLE_SECTOR, '-')
                AND ck.CUSTOMER_KIND_SECTOR is null
"""

COST_CENTER_AWARDED_BUDGET = """
        Select          
            fin_acc.DIM_ACCOUNT_ID,
            fin_cc.DIM_COST_CENTER_ID,
            fin_ce.DIM_COST_ELEMENT_ID,
            exc.DIM_EXCHANGE_RATE_ID,
            fin_fc.DIM_FUND_CENTER_ID,
            fin_fg.DIM_FUND_GROUP_ID,
            fin_fa.DIM_FUNCTIONAL_AREA_ID,
            NULL AS DIM_PROGRAM_ID,
            NULL AS DIM_WORK_ORDER_ID,
            ck.CUSTOMER_KIND_ID,
            src.Version as BUDGET_VERSION,
            src.Fiscal_Year as BUDGET_FISCAL_YEAR,
            src.Period as BUDGET_PERIOD,
            src.BUSINESS_TRANSACTION as BUDGET_TRANSACTION_CODE,
            NULL as BUDGET_VALUE_TYPE,
            src.Attribute as BUDGET_ATTRIBUTE,
            src.VALUE_IN_COMPANY_CURRENCY as BUDGET_VALUE_IN_COMPANY_CURRENCY,
            src.DATE as BUDGET_DATE,
            src.LAST_REFRESH_DATE as BUDGET_LAST_REFRESH_DATE,
            NULL as BUDGET_DELETION_INDICATOR,
            NULL as BUDGET_SECTOR_REQ_N_RESP,
            NULL as BUDGET_REGION_REQ_N_RESP,
            'COST CENTER BUDGET' as BUDGET_CATEGORY,
            'AWARDED BUDGET' as BUDGET_TYPE
        From
            COST_CENTER_AWARDED_BUDGET src
            left join DIM_CR_FIN_ACCOUNT fin_acc
                ON coalesce(src.ACCOUNT, '-') = coalesce(fin_acc.ACCOUNT_NAME, '-')
            left join DIM_CR_FIN_COST_CENTER fin_cc
                ON coalesce(src.COST_CENTER, '-') = coalesce(fin_cc.COST_CENTER, '-')
                AND fin_cc.COST_CENTER is not null
                AND fin_cc.RESPONSIBLE_CCTR is null
                AND fin_cc.REQUEST_CCTR is null
            left join DIM_CR_FIN_COST_ELEMENT fin_ce
                ON coalesce(src.COST_ELEMENT, '-') = coalesce(fin_ce.COST_ELEMENT_NUMBER, '-')
                AND coalesce(src.COST_ELEMENT_DESC, '-') = coalesce(fin_ce.COST_ELEMENT_SHORT_TEXT, '-')
            left join DIM_CR_REG_EXCHANGE_RATE exc
                ON coalesce(src.CURRENCY, '-') = coalesce(exc.CURRENCY_FROM, '-')
            left join DIM_CR_FIN_FUND_CENTER fin_fc
                ON coalesce(src.FUND, '-') = coalesce(fin_fc.FUND_CENTER_NAME, '-')
                AND coalesce(src.FUNDS_CENTER_DESC, '-') = coalesce(fin_fc.FUND_CENTER_DESCRIPTION, '-')
                AND coalesce(src.FUNDS_CENTER, '-') = coalesce(fin_fc.FUND_CENTER_CODE, '-')
            left join (SELECT DISTINCT DIM_FUND_GROUP_ID, FUND_GROUP_NAME
                        FROM DIM_CR_FIN_FUND_GROUP_SAP 
                        WHERE REQUESTING_FUND_GROUP is null
                        AND RESPONSIBLE_FUND_GROUP is null
                        AND HIERARCHY_GROUP is null
                        AND SEMI_GROUP_CODE is null) fin_fg
                ON coalesce(src.REGION, '-') = coalesce(fin_fg.FUND_GROUP_NAME, '-')         
            left join DIM_CR_FIN_FUNCTIONAL_AREA fin_fa
                ON coalesce(src.FUND_AREA, '-') = coalesce(fin_fa.FUNCTIONAL_AREA, '-')
            left join DIM_CR_CUS_CUSTOMER_KIND_SAP ck
                ON coalesce(src.SECTOR, '-') = coalesce(ck.CUSTOMER_KIND_SECTOR, '-')
                AND ck.REQUESTING_SECTOR is null
                AND ck.RESPONSIBLE_SECTOR is null
                AND ck.CUSTOMER_KIND_SECTOR_CODE is null
"""

WBSE_BUDGET = """
        Select          
            fin_acc.DIM_ACCOUNT_ID,
            fin_cc.DIM_COST_CENTER_ID,
            fin_ce.DIM_COST_ELEMENT_ID,
            exc.DIM_EXCHANGE_RATE_ID,
            fin_fc.DIM_FUND_CENTER_ID,
            fin_fg.DIM_FUND_GROUP_ID,
            fin_fa.DIM_FUNCTIONAL_AREA_ID,
            wp.DIM_PROGRAM_ID,
            work.DIM_WORK_ORDER_ID,
            ck.CUSTOMER_KIND_ID,
            src.Version as BUDGET_VERSION,
            src.Fiscal_Year as BUDGET_FISCAL_YEAR,
            src.Period as BUDGET_PERIOD,
            src.Transaction as BUDGET_TRANSACTION_CODE,
            src.Value_Type as BUDGET_VALUE_TYPE,
            src.Attribute as BUDGET_ATTRIBUTE,
            src.VALUE_IN_COMPANY_CURRENCY as BUDGET_VALUE_IN_COMPANY_CURRENCY,
            src.DATE as BUDGET_DATE,
            src.LAST_REFRESH_DATE as BUDGET_LAST_REFRESH_DATE,
            src.DELETION_INDICATOR as BUDGET_DELETION_INDICATOR,
            Sector_Req_Resp as BUDGET_SECTOR_REQ_N_RESP,
            Region_Req_Resp as BUDGET_REGION_REQ_N_RESP,
            'WBSE BUDGET' as BUDGET_CATEGORY,
            'BUDGET' as BUDGET_TYPE
        From
            WBSE_BUDGET src
            left join DIM_CR_FIN_ACCOUNT fin_acc
                ON coalesce(src.ACCOUNT, '-') = coalesce(fin_acc.ACCOUNT_NAME, '-')
            left join DIM_CR_FIN_COST_CENTER fin_cc
                ON coalesce(src.REQUESTING_COST_CENTER_KEY, '-') = coalesce(fin_cc.REQUEST_CCTR, '-')
                AND coalesce(src.RESPONSIBLE_COST_CENTER_KEY, '-') = coalesce(fin_cc.RESPONSIBLE_CCTR, '-')
            left join DIM_CR_FIN_COST_ELEMENT fin_ce
                ON coalesce(src.COST_ELEMENT, '-') = coalesce(fin_ce.COST_ELEMENT_NUMBER, '-')
                AND coalesce(src.COST_ELEMENT_DESC, '-') = coalesce(fin_ce.COST_ELEMENT_SHORT_TEXT, '-')
            left join DIM_CR_REG_EXCHANGE_RATE exc
                ON coalesce(src.CURRENCY, '-') = coalesce(exc.CURRENCY_FROM, '-')
            left join DIM_CR_FIN_FUND_CENTER fin_fc
                ON coalesce(src.FUND, '-') = coalesce(fin_fc.FUND_CENTER_NAME, '-')
                AND coalesce(src.FUNDS_CENTER_DESC, '-') = coalesce(fin_fc.FUND_CENTER_DESCRIPTION, '-')
                AND coalesce(src.FUNDS_CENTER, '-') = coalesce(fin_fc.FUND_CENTER_CODE, '-')
            left join DIM_CR_FIN_FUND_GROUP_SAP fin_fg
                ON coalesce(src.REQUESTING_REGION, '-') = coalesce(fin_fg.REQUESTING_FUND_GROUP, '-')
                AND coalesce(src.RESPONSIBLE_REGION, '-') = coalesce(fin_fg.RESPONSIBLE_FUND_GROUP, '-')
                AND fin_fg.FUND_GROUP_NAME is null
                AND fin_fg.HIERARCHY_GROUP is null
                AND fin_fg.SEMI_GROUP_CODE is null
            left join DIM_CR_FIN_FUNCTIONAL_AREA fin_fa
                ON coalesce(src.FUND_AREA, '-') = coalesce(fin_fa.FUNCTIONAL_AREA, '-')
            left join DIM_CR_WORK_PROGRAM wp
                ON coalesce(src.PROGRAM_DEFINITION_KEY, '-') = coalesce(wp.PROGRAM_DEFINITION_KEY, '-')
                AND wp.PROGRAM_DEFINITION_DESC is null
            left join DIM_CR_WORK_WORK_ORDER work
                ON coalesce(src.WBS_Element, '-') = coalesce(work.ORDER, '-')
                AND coalesce(src.WBS_Element_Desc, '-') = coalesce(work.ORDER_DESCRIPTION, '-')
                AND coalesce(src.WBS_Element_Key, '-') = coalesce(work.ORDER_ELEMENT_KEY, '-')
            left join DIM_CR_CUS_CUSTOMER_KIND_SAP ck
                ON coalesce(src.Requesting_Sector, '-') = coalesce(ck.REQUESTING_SECTOR, '-')
                AND coalesce(src.RESPONSIBLE_SECTOR, '-') = coalesce(ck.RESPONSIBLE_SECTOR, '-')
                AND ck.CUSTOMER_KIND_SECTOR is null
"""

INTERNAL_ORDER_BUDGET = """
        Select          
            fin_acc.DIM_ACCOUNT_ID,
            fin_cc.DIM_COST_CENTER_ID,
            fin_ce.DIM_COST_ELEMENT_ID,
            exc.DIM_EXCHANGE_RATE_ID,
            fin_fc.DIM_FUND_CENTER_ID,
            fin_fg.DIM_FUND_GROUP_ID,
            fin_fa.DIM_FUNCTIONAL_AREA_ID,
            NULL AS DIM_PROGRAM_ID,
            work.DIM_WORK_ORDER_ID,
            ck.CUSTOMER_KIND_ID,
            src.Version as BUDGET_VERSION,
            src.Fiscal_Year as BUDGET_FISCAL_YEAR,
            src.Period as BUDGET_PERIOD,
            src.Transaction as BUDGET_TRANSACTION_CODE,
            src.Value_Type as BUDGET_VALUE_TYPE,
            src.Attribute as BUDGET_ATTRIBUTE,
            src.VALUE_IN_COMPANY_CURRENCY as BUDGET_VALUE_IN_COMPANY_CURRENCY,
            src.DATE as BUDGET_DATE,
            src.LAST_REFRESH_DATE as BUDGET_LAST_REFRESH_DATE,
            NULL as BUDGET_DELETION_INDICATOR,
            SECTOR_REQ_RESP as BUDGET_SECTOR_REQ_N_RESP,
            REGION_REQ_RESP as BUDGET_REGION_REQ_N_RESP,
            'IO BUDGET' as BUDGET_CATEGORY,
            'BUDGET' as BUDGET_TYPE
        From
            INTERNAL_ORDER_BUDGET src
            left join DIM_CR_FIN_ACCOUNT fin_acc
                ON coalesce(src.ACCOUNT, '-') = coalesce(fin_acc.ACCOUNT_NAME, '-')
            left join DIM_CR_FIN_COST_CENTER fin_cc
                ON coalesce(src.REQUESTING_COST_CENTER_KEY, '-') = coalesce(fin_cc.REQUEST_CCTR, '-')
                AND coalesce(src.RESPONSIBLE_COST_CENTER_KEY, '-') = coalesce(fin_cc.RESPONSIBLE_CCTR, '-')
            left join DIM_CR_FIN_COST_ELEMENT fin_ce
                ON coalesce(src.COST_ELEMENT, '-') = coalesce(fin_ce.COST_ELEMENT_NUMBER, '-')
                AND coalesce(src.COST_ELEMENT_DESC, '-') = coalesce(fin_ce.COST_ELEMENT_SHORT_TEXT, '-')
            left join DIM_CR_REG_EXCHANGE_RATE exc
                ON coalesce(src.CURRENCY, '-') = coalesce(exc.CURRENCY_FROM, '-')
            left join DIM_CR_FIN_FUND_CENTER fin_fc
                ON coalesce(src.FUND, '-') = coalesce(fin_fc.FUND_CENTER_NAME, '-')
                AND coalesce(src.FUNDS_CENTER_DESC, '-') = coalesce(fin_fc.FUND_CENTER_DESCRIPTION, '-')
                AND coalesce(src.FUNDS_CENTER, '-') = coalesce(fin_fc.FUND_CENTER_CODE, '-')
            left join DIM_CR_FIN_FUND_GROUP_SAP fin_fg
                ON coalesce(src.REQUESTING_REGION, '-') = coalesce(fin_fg.REQUESTING_FUND_GROUP, '-')
                AND coalesce(src.RESPONSIBLE_REGION, '-') = coalesce(fin_fg.RESPONSIBLE_FUND_GROUP, '-')
                AND fin_fg.FUND_GROUP_NAME is null
                AND fin_fg.HIERARCHY_GROUP is null
                AND fin_fg.SEMI_GROUP_CODE is null
            left join DIM_CR_FIN_FUNCTIONAL_AREA fin_fa
                ON coalesce(src.FUND_AREA, '-') = coalesce(fin_fa.FUNCTIONAL_AREA, '-')
            left join DIM_CR_WORK_WORK_ORDER work
                ON coalesce(src.ORDER, '-') = coalesce(work.ORDER, '-')
                AND work.IO_WBS_DESCRIPTION is null
                AND work.ORDER_DESCRIPTION is null
                AND work.ORDER_ELEMENT_KEY is null
            left join DIM_CR_CUS_CUSTOMER_KIND_SAP ck
                ON coalesce(src.Requesting_Sector, '-') = coalesce(ck.REQUESTING_SECTOR, '-')
                AND coalesce(src.RESPONSIBLE_SECTOR, '-') = coalesce(ck.RESPONSIBLE_SECTOR, '-')
                AND ck.CUSTOMER_KIND_SECTOR is null
"""

COST_CENTER_BUDGET = """
        Select          
            fin_acc.DIM_ACCOUNT_ID,
            fin_cc.DIM_COST_CENTER_ID,
            fin_ce.DIM_COST_ELEMENT_ID,
            exc.DIM_EXCHANGE_RATE_ID,
            fin_fc.DIM_FUND_CENTER_ID,
            fin_fg.DIM_FUND_GROUP_ID,
            fin_fa.DIM_FUNCTIONAL_AREA_ID,
            NULL AS DIM_PROGRAM_ID,
            NULL AS DIM_WORK_ORDER_ID,
            ck.CUSTOMER_KIND_ID,
            src.Version as BUDGET_VERSION,
            src.Fiscal_Year as BUDGET_FISCAL_YEAR,
            src.Period as BUDGET_PERIOD,
            src.BUSINESS_TRANSACTION as BUDGET_TRANSACTION_CODE,
            NULL as BUDGET_VALUE_TYPE,
            src.Attribute as BUDGET_ATTRIBUTE,
            src.VALUE_IN_COMPANY_CURRENCY as BUDGET_VALUE_IN_COMPANY_CURRENCY,
            src.DATE as BUDGET_DATE,
            src.LAST_REFRESH_DATE as BUDGET_LAST_REFRESH_DATE,
            NULL as BUDGET_DELETION_INDICATOR,
            NULL as BUDGET_SECTOR_REQ_N_RESP,
            NULL as BUDGET_REGION_REQ_N_RESP,
            'COST CENTER BUDGET' as BUDGET_CATEGORY,
            'BUDGET' as BUDGET_TYPE
        From
            COST_CENTER_BUDGET src
            left join DIM_CR_FIN_ACCOUNT fin_acc
                ON coalesce(src.ACCOUNT, '-') = coalesce(fin_acc.ACCOUNT_NAME, '-')
            left join DIM_CR_FIN_COST_CENTER fin_cc
                ON coalesce(src.COST_CENTER, '-') = coalesce(fin_cc.COST_CENTER, '-')
                AND fin_cc.COST_CENTER is not null
                AND fin_cc.RESPONSIBLE_CCTR is null
                AND fin_cc.REQUEST_CCTR is null
            left join DIM_CR_FIN_COST_ELEMENT fin_ce
                ON coalesce(src.COST_ELEMENT, '-') = coalesce(fin_ce.COST_ELEMENT_NUMBER, '-')
                AND coalesce(src.COST_ELEMENT_DESC, '-') = coalesce(fin_ce.COST_ELEMENT_SHORT_TEXT, '-')
            left join DIM_CR_REG_EXCHANGE_RATE exc
                ON coalesce(src.CURRENCY, '-') = coalesce(exc.CURRENCY_FROM, '-')
            left join DIM_CR_FIN_FUND_CENTER fin_fc
                ON coalesce(src.FUND, '-') = coalesce(fin_fc.FUND_CENTER_NAME, '-')
                AND coalesce(src.FUNDS_CENTER_DESC, '-') = coalesce(fin_fc.FUND_CENTER_DESCRIPTION, '-')
                AND coalesce(src.FUNDS_CENTER, '-') = coalesce(fin_fc.FUND_CENTER_CODE, '-')
            left join (SELECT DISTINCT DIM_FUND_GROUP_ID, FUND_GROUP_NAME
                        FROM DIM_CR_FIN_FUND_GROUP_SAP 
                        WHERE REQUESTING_FUND_GROUP is null
                        AND RESPONSIBLE_FUND_GROUP is null
                        AND HIERARCHY_GROUP is null
                        AND SEMI_GROUP_CODE is null) fin_fg
                ON coalesce(src.REGION, '-') = coalesce(fin_fg.FUND_GROUP_NAME, '-')         
            left join DIM_CR_FIN_FUNCTIONAL_AREA fin_fa
                ON coalesce(src.FUND_AREA, '-') = coalesce(fin_fa.FUNCTIONAL_AREA, '-')
            left join DIM_CR_CUS_CUSTOMER_KIND_SAP ck
                ON coalesce(src.SECTOR, '-') = coalesce(ck.CUSTOMER_KIND_SECTOR, '-')
                AND ck.CUSTOMER_KIND_SECTOR_CODE is null
                AND ck.REQUESTING_SECTOR is null
                AND ck.RESPONSIBLE_SECTOR is null
"""
