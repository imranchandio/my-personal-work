from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
import logging
from pyspark import StorageLevel
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

PO_DATA_BY_SUPPLIER_EXPORT="PO_DATA_BY_SUPPLIER_EXPORT"
GCFA_AGREEMENT="GCFA_AGREEMENT"
OUTLINE_AGREEMENT="OUTLINE_AGREEMENT"
GCFA_VERSION="GCFA_VERSION"
PO_DATA_BY_SUPPLIER_EXPORT_SOURCE = "PO_DATA_BY_SUPPLIER_EXPORT_SOURCE"

def prepare_transformed_df(
    spark: SparkSession,
    df_po_data_by_supplier_export: DataFrame,
) -> DataFrame:
    logging.info("Starting the transformation process for FACT_WA_EVE_SAMPLE_RESULT.")

    df_po_data_by_supplier_export.createOrReplaceTempView(
        PO_DATA_BY_SUPPLIER_EXPORT_SOURCE
    )

    sql_query = """
                select distinct
                sha2(
                    concat_ws("||",
                        NVL(CAST(GCFA_AGREEMENT AS STRING), '-'),
                        NVL(CAST(OUTLINE_AGREEMENT AS STRING), '-'),
                        NVL(CAST(GCFA_VERSION AS STRING), '-')
                    ), 256
                ) as DIM_AGREEMENT_ID,
                null as URN_N_TITLE,
                GCFA_AGREEMENT as OUTLINE_AGREEMENT_SAP,
                null as OUTLINE_AGREEMENT_OVERRIDE,
                OUTLINE_AGREEMENT as OUTLINE_AGREEMENT_CONSOLIDATED,
                GCFA_VERSION as AGREEMENT_VERSION,
                null as PLANNED_AWARD_DATE_SP,
                'SAP_PR' as AGREEMENT_DOMAIN_TYPE,
                'Outline GCFA' as AGREEMENT_SUB_DOMAIN_TYPE,
                null as LINE_ITEM_N_TEXT,
                null as LINE_NO,
                null as SUB_LINE,
                current_timestamp() AS CREATED_DATE,
                current_timestamp() AS LAST_UPDATED_DATE
                from PO_DATA_BY_SUPPLIER_EXPORT_SOURCE
            """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation.")

    df_transformed = df_transformed.persist(StorageLevel.MEMORY_AND_DISK)

    logging.info("Transformation process completed.")
    return df_transformed.distinct()


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrame by performing necessary transformations and returns the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames.
        primary_cols: List of primary columns
    Returns:
        DataFrame: The transformed DataFrame.
    """
    logging.info("Starting the transformation process.")

    df_po_data_by_supplier_export: DataFrame = (
        source_dfs[PO_DATA_BY_SUPPLIER_EXPORT]
        .select(
            GCFA_AGREEMENT,
            OUTLINE_AGREEMENT,
            GCFA_VERSION,
        )
        .distinct()
    )
    
    df_transformed = prepare_transformed_df(
        spark=spark,
        df_po_data_by_supplier_export=df_po_data_by_supplier_export
    )

    logging.info("Data transformation completed.")

    max_partition_size_mb = 1024
    logging.info("Calculating the number of partitions.")
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)
    logging.info(f"Repartitioning DataFrame into {num_partitions} partitions.")

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed

def execute_transform(
    spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    target_schema = {}

    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = transform(spark=spark, source_dfs=source_dfs)

    print(
        "execute_transform():transformed_df schema before imposing:",
        transformed_df.printSchema(),
    )

    transformed_df = impose_schema(transformed_df, target_schema)

    print(
        "execute_transform(): transformed_df schema after imposing::",
        transformed_df.printSchema(),
    )

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "50MB")

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
