# pylint:disable=unused-argument, import-error
"""
    This is the transformation file for dim_cr_fin_controlling_unit dimension
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")

def prepare_transformed_df(
        spark: SparkSession,
        df_account: DataFrame,
        df_fm_gl_mapping: DataFrame,
        df_wbse_transaction_data: DataFrame,
        df_internal_order_transaction_data: DataFrame,
        df_cost_center_transaction_data: DataFrame

) -> DataFrame:
    '''
        This function prepares the dataframe based on business logic for DIM_CR_CORP_DOCUMENT.
    '''
    logging.info("Starting the transformation process.")

    # Create temp views to use SQL on DataFrames
    df_account.createOrReplaceTempView("ACCOUNT")
    df_fm_gl_mapping.createOrReplaceTempView("FM_GL_MAPPING")
    df_wbse_transaction_data.createOrReplaceTempView("WBSE_TRANSACTION_DATA")
    df_internal_order_transaction_data.createOrReplaceTempView("INTERNAL_ORDER_TRANSACTION_DATA")
    df_cost_center_transaction_data.createOrReplaceTempView("COST_CENTER_TRANSACTION_DATA")


    sql_query = """
SELECT 
    'Cost Account' AS ACCOUNT_TYPE,
    NAME AS ACCOUNT_NAME,
    NULL AS ACCOUNT_NUMBER,
    NULL AS ACCOUNT_SHORT_DESC,
    SORTING AS COST_ACCOUNT_SORTING,
    COST_ELEMENT_GROUPING AS ACCOUNT_COST_ELEMENT_GROUPING,
    COST_ELEMENT_GROUPING_SORTING AS ACCOUNT_COST_ELEMENT_GROUPING_SORTING,
    COST_ELEMENT_TOTAL AS ACCOUNT_COST_ELEMENT_TOTAL,
    CURRENT_TIMESTAMP() AS LAST_UPDATED_DATE,
    CURRENT_TIMESTAMP() AS CREATED_DATE 
FROM ACCOUNT
UNION ALL
SELECT 
    'GL Account' AS ACCOUNT_TYPE,
    NULL AS ACCOUNT_NAME,
    GL_ACCOUNT AS ACCOUNT_NUMBER,
    GL_ACCT_SHORT_TEXT AS ACCOUNT_SHORT_DESC,
    NULL AS COST_ACCOUNT_SORTING,
    NULL AS ACCOUNT_COST_ELEMENT_GROUPING,
    NULL AS ACCOUNT_COST_ELEMENT_GROUPING_SORTING,
    NULL AS ACCOUNT_COST_ELEMENT_TOTAL,
    CURRENT_TIMESTAMP() AS LAST_UPDATED_DATE,
    CURRENT_TIMESTAMP() AS CREATED_DATE 
FROM FM_GL_MAPPING
UNION ALL
SELECT 
    'Offsetting Account' AS ACCOUNT_TYPE,
    NULL AS ACCOUNT_NAME,
    OFFSETTING_ACCOUNT AS ACCOUNT_NUMBER,
    OFFSETTING_ACCOUNT_DESC AS ACCOUNT_SHORT_DESC,
    NULL AS COST_ACCOUNT_SORTING,
    NULL AS ACCOUNT_COST_ELEMENT_GROUPING,
    NULL AS ACCOUNT_COST_ELEMENT_GROUPING_SORTING,
    NULL AS ACCOUNT_COST_ELEMENT_TOTAL,
    CURRENT_TIMESTAMP() AS LAST_UPDATED_DATE,
    CURRENT_TIMESTAMP() AS CREATED_DATE 
FROM WBSE_TRANSACTION_DATA
UNION ALL
SELECT 
    'Offsetting Account' AS ACCOUNT_TYPE,
    NULL AS ACCOUNT_NAME,
    OFFSETTING_ACCOUNT AS ACCOUNT_NUMBER,
    OFFSETTING_ACCOUNT_DESC AS ACCOUNT_SHORT_DESC,
    NULL AS COST_ACCOUNT_SORTING,
    NULL AS ACCOUNT_COST_ELEMENT_GROUPING,
    NULL AS ACCOUNT_COST_ELEMENT_GROUPING_SORTING,
    NULL AS ACCOUNT_COST_ELEMENT_TOTAL,
    CURRENT_TIMESTAMP() AS LAST_UPDATED_DATE,
    CURRENT_TIMESTAMP() AS CREATED_DATE 
FROM INTERNAL_ORDER_TRANSACTION_DATA
UNION ALL
SELECT 
    'Offsetting Account' AS ACCOUNT_TYPE,
    NULL AS ACCOUNT_NAME,
    OFFSETTING_ACCOUNT AS ACCOUNT_NUMBER,
    OFFSETTING_ACCOUNT_DESC AS ACCOUNT_SHORT_DESC,
    NULL AS COST_ACCOUNT_SORTING,
    NULL AS ACCOUNT_COST_ELEMENT_GROUPING,
    NULL AS ACCOUNT_COST_ELEMENT_GROUPING_SORTING,
    NULL AS ACCOUNT_COST_ELEMENT_TOTAL,
    CURRENT_TIMESTAMP() AS LAST_UPDATED_DATE,
    CURRENT_TIMESTAMP() AS CREATED_DATE 
FROM COST_CENTER_TRANSACTION_DATA;
    """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation.")

    df_transformed = df_transformed.withColumn(
        "DIM_ACCOUNT_ID", sha2(concat_ws("||", "ACCOUNT_NAME", "ACCOUNT_NUMBER","ACCOUNT_TYPE"), 256)
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "account": DataFrame for account.
            - "fm_gl_mapping": DataFrame for fm_gl_mapping.
            - "INTERNAL_ORDER_transaction_DATA": DataFrame for internal_order_transaction_data.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_account = source_dfs["ACCOUNT"]
    df_fm_gl_mapping = source_dfs["FM_GL_MAPPING"]
    df_wbse_transaction_data = source_dfs["WBSE_TRANSACTION_DATA"]
    df_internal_order_transaction_data = source_dfs["INTERNAL_ORDER_TRANSACTION_DATA"]
    df_cost_center_transaction_data = source_dfs["COST_CENTER_TRANSACTION_DATA"]


    # Apply transformations based on business logic
    transform_df = prepare_transformed_df(
        spark=spark,
        df_account=df_account,
        df_fm_gl_mapping=df_fm_gl_mapping,
        df_wbse_transaction_data=df_wbse_transaction_data,
        df_internal_order_transaction_data=df_internal_order_transaction_data,
        df_cost_center_transaction_data=df_cost_center_transaction_data
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print("spark_df schema:", spark_df.printSchema())

    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
