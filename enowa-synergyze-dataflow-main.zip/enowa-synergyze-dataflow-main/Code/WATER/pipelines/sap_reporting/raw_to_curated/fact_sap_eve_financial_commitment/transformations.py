# pylint: disable = import-error
"""
    This is the transformation file for fact_sap_eve_financial_commitment fact
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws, coalesce, lit
import pyspark.sql.functions as F
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_cost_center_df_parta(
        spark: SparkSession,
        df_cost_center_commitments: DataFrame,
        df_dim_cr_fin_account: DataFrame,
        df_dim_cr_work_assignment: DataFrame,
        df_dim_cr_fin_cost_center: DataFrame,
        df_dim_cr_fin_cost_element: DataFrame,
        df_dim_cr_corp_document: DataFrame,
        df_dim_cr_fin_fund_center: DataFrame,
        df_dim_cr_fin_fund_group: DataFrame,
        df_dim_cr_fin_fund_user: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from the raw layer table passed in as DataFrame.
    '''
    logging.info("Starting the transformation process in prepare_cost_center_df_parta.")

    df_dim_cr_fin_account.createOrReplaceTempView("DIM_CR_FIN_ACCOUNT")
    df_dim_cr_work_assignment.createOrReplaceTempView("DIM_CR_WORK_ASSIGNMENT")
    df_dim_cr_fin_cost_center.createOrReplaceTempView("DIM_CR_FIN_COST_CENTER")
    df_cost_center_commitments.createOrReplaceTempView("COST_CENTER_COMMITMENTS")
    df_dim_cr_fin_cost_element.createOrReplaceTempView("DIM_CR_FIN_COST_ELEMENT")
    df_dim_cr_corp_document.createOrReplaceTempView("DIM_CR_CORP_DOCUMENT")
    df_dim_cr_fin_fund_center.createOrReplaceTempView("DIM_CR_FIN_FUND_CENTER")
    df_dim_cr_fin_fund_group.createOrReplaceTempView("DIM_CR_FIN_FUND_GROUP")
    df_dim_cr_fin_fund_user.createOrReplaceTempView("DIM_CR_FIN_FUND_USER")

    logging.info("Executing SQL query for data transformation in prepare_cost_center_df_parta.")

    sql_query = """
                SELECT B.DIM_ACCOUNT_ID
                ,C.DIM_ASSIGNMENT_ID
                ,D.DIM_COST_CENTER_ID
                ,E.DIM_COST_ELEMENT_ID
                ,F.DIM_DOCUMENT_ID
                ,G.DIM_FUND_CENTER_ID
                ,H.DIM_FUND_GROUP_ID
                ,I.DIM_FUND_USER_ID
                ,A.MATERIAL_GROUP
                ,A.VENDOR
                ,A.VENDOR_NAME
                ,A.WBS_ELEMENT
                ,A.WBS_ELEMENT_DESC
                ,A.SECTOR
                ,A.PO_REF_PR
                ,A.PO_STATUS
                ,A.EXCHANGE_RATE
                ,A.DATE
                ,NULL AS EXPENSE_CATEGORY_DESC
                ,A.FISCAL_YEAR
                ,A.PERIOD
                ,A.EFFECTIVE_DATE
                ,A.EXPECTED_DEBIT_DATE
                ,A.LEAD_TIME
                ,A.PLAN_QUANTITY
                ,A.PLANNED_VALUE_RC
                ,A.PO_DOC_ITEM_DELETION_INDICATOR
                ,A.PO_DOC_ITEM
                ,A.REFERENCE_PROCEDURE
                ,NULL AS RELEASE_DATE
                ,NULL AS RELEASE_INDICATOR
                ,A.TOTAL_QUANTITY
                ,A.TOTAL_VALUE_RC
                ,A.WBS_DELETION_INDICATOR
            FROM COST_CENTER_COMMITMENTS A
            LEFT JOIN DIM_CR_FIN_ACCOUNT B ON A.ACCOUNT = B.ACCOUNT_NAME
            LEFT JOIN DIM_CR_WORK_ASSIGNMENT C ON A.ACCT_ASSIGNMENT = C.ASSIGNMENT_NO_NAMES
            LEFT JOIN DIM_CR_FIN_COST_CENTER D ON A.COST_CENTER = D.COST_CENTER
            LEFT JOIN DIM_CR_FIN_COST_ELEMENT E ON A.COST_ELEMENT = E.COST_ELEMENT_NUMBER
            LEFT JOIN DIM_CR_CORP_DOCUMENT F ON coalesce(A.DOCUMENT_DATE, '-') = coalesce(F.DOCUMENT_DATE, '-')
                AND coalesce(A.PURCHASING_DOCUMENT_NUMBER, '-') = coalesce(F.PURCHASING_DOC_NO, '-')
                AND coalesce(A.TEXT, '-') = coalesce(F.DOC_HEADER, '-')
                AND coalesce(A.PO_DOC_ITEM, '-') = coalesce(F.DOCUMENT_NUMBER, '-')
                AND coalesce(A.PURCHASING_DOCUMENT_ITEM, '-') = coalesce(F.DOC_ITEM, '-')
                AND coalesce(A.REFERENCE_DOC_TYPE, '-') = coalesce(F.REFERENCE_DOCUMENT_TYPE, '-')
            LEFT JOIN DIM_CR_FIN_FUND_CENTER G ON A.FUND = G.FUND_CENTER_NAME
                AND A.FUNDS_CENTER = G.FUND_CENTER_CODE
            LEFT JOIN DIM_CR_FIN_FUND_GROUP H 
                ON A.REGION = H.FUND_GROUP_NAME
                AND H.REQUESTING_FUND_GROUP is null
                AND H.RESPONSIBLE_FUND_GROUP is null
                AND H.HIERARCHY_GROUP is null 
                AND H.SEMI_GROUP_CODE is null
            LEFT JOIN DIM_CR_FIN_FUND_USER I ON A.USER_NAME_ID = I.USER_NAME_ID
                AND A.USER_NAME = I.USER_NAME

            """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation in prepare_cost_center_df_parta")

    return df_transformed


def prepare_cost_center_df_partb(
        spark: SparkSession,
        cost_center_df_part1: DataFrame,
        df_dim_cr_proc_material_group: DataFrame,
        df_dim_cr_work_program: DataFrame,
        df_dim_cr_work_project: DataFrame,
        df_dim_wa_org_waterqa_supplier_sap: DataFrame,
        df_dim_cr_work_work_order: DataFrame,
        df_dim_cr_cus_customer_kind_sap: DataFrame,
        df_dim_cr_proc_pr: DataFrame,
        df_dim_cr_proc_po: DataFrame,
        df_dim_cr_fin_functional_area: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from the raw layer table passed in as DataFrame.
    '''
    logging.info("Starting the transformation process in prepare_cost_center_df_partb.")
    cost_center_df_part1.createOrReplaceTempView("TRANSFORM_DF_PART1")
    df_dim_cr_proc_material_group.createOrReplaceTempView("DIM_CR_PROC_MATERIAL_GROUP")
    df_dim_cr_work_program.createOrReplaceTempView("DIM_CR_WORK_PROGRAM")
    df_dim_cr_work_project.createOrReplaceTempView("DIM_CR_WORK_PROJECT")
    df_dim_wa_org_waterqa_supplier_sap.createOrReplaceTempView("DIM_WATERQA_SUPPLIER")
    df_dim_cr_work_work_order.createOrReplaceTempView("DIM_CR_WORK_WORK_ORDER")
    df_dim_cr_cus_customer_kind_sap.createOrReplaceTempView("DIM_CR_CUS_CUSTOMER_KIND")
    df_dim_cr_proc_pr.createOrReplaceTempView("DIM_CR_PROC_PR")
    df_dim_cr_proc_po.createOrReplaceTempView("DIM_CR_PROC_PO")
    df_dim_cr_fin_functional_area.createOrReplaceTempView("DIM_CR_FIN_FUNCTIONAL_AREA")
    logging.info("Executing SQL query for data transformation in prepare_cost_center_df_partb.")

    sql_query = """
                select 
                A.DIM_ACCOUNT_ID,
                A.DIM_ASSIGNMENT_ID,
                A.DIM_COST_CENTER_ID,
                A.DIM_COST_ELEMENT_ID,
                A.DIM_DOCUMENT_ID,
                A.DIM_FUND_CENTER_ID,
                A.DIM_FUND_GROUP_ID,
                A.DIM_FUND_USER_ID,
                B.DIM_MATERIAL_GROUP_ID,
                NULL as DIM_PROGRAM_ID,
                NULL as DIM_PROJECT_ID,
                C.DIM_WATERQA_SUPPLIER_ID,
                CASE WHEN (A.WBS_ELEMENT is NULL or A.WBS_ELEMENT_DESC='Not assigned') THEN 'Not Assigned'
                ELSE G.DIM_WORK_ORDER_ID END DIM_WORK_ORDER_ID,
                D.CUSTOMER_KIND_ID,
                E.DIM_PR_ID,
                F.DIM_PR_PO_ID,
                NULL as DIM_FUNCTIONAL_AREA_ID,
                A.EXCHANGE_RATE,
                'Cost Center Commitments' as FINANCIAL_COMMITMENT_TYPE,
                A.DATE as COMMITMENT_DATE,
                A.EXPENSE_CATEGORY_DESC as COMMITMENT_EXPENSE_CATEGORY_DESC,
                A.FISCAL_YEAR as COMMITMENT_FISCAL_YEAR,
                A.PERIOD as COMMITMENT_PERIOD,
                A.EFFECTIVE_DATE,
                A.EXPECTED_DEBIT_DATE,
                A.LEAD_TIME,
                A.PLAN_QUANTITY,
                A.PLANNED_VALUE_RC,
                A.PO_DOC_ITEM_DELETION_INDICATOR,
                A.PO_DOC_ITEM,
                A.REFERENCE_PROCEDURE,
                A.RELEASE_DATE,
                A.RELEASE_INDICATOR,
                A.TOTAL_QUANTITY,
                A.TOTAL_VALUE_RC,
                A.WBS_DELETION_INDICATOR
                from TRANSFORM_DF_PART1 A
                left join DIM_CR_PROC_MATERIAL_GROUP B
                on A.MATERIAL_GROUP=B.MATERIAL_GROUP
                left join DIM_WATERQA_SUPPLIER C
                on A.VENDOR=C.SUPPLIER_CODE
                and A.VENDOR_NAME=C.SUPPLIER_NAME
                and C.GCFA_SUPPLIER_CODE is null
                and C.SUPPLIER_TYPE = 'SAP FI'
                left join DIM_CR_CUS_CUSTOMER_KIND D
                on A.SECTOR=D.CUSTOMER_KIND_SECTOR
                and D.CUSTOMER_KIND_SECTOR_CODE is null
                left join DIM_CR_PROC_PR E
                on A.PO_REF_PR=E.PURCHASE_REQUISITION
                and E.DATA_SOURCE='COST_CENTER_COMMITMENTS'
                left join DIM_CR_PROC_PO F
                on A.PO_STATUS=F.PO_STATUS
                and F.DATA_SOURCE='COST_CENTER_COMMITMENTS'
                left join (select distinct DIM_WORK_ORDER_ID,IO_WBS,IO_WBS_DESCRIPTION from DIM_CR_WORK_WORK_ORDER) G
                on A.WBS_ELEMENT=G.IO_WBS
                and A.WBS_ELEMENT_DESC=G.IO_WBS_DESCRIPTION
            """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation in prepare_cost_center_df_partb.")

    return df_transformed


def prepare_wbse_df_parta(
        spark: SparkSession,
        df_wbse_commitments: DataFrame,
        df_dim_cr_fin_account: DataFrame,
        df_dim_cr_work_assignment: DataFrame,
        df_dim_cr_fin_cost_center: DataFrame,
        df_dim_cr_fin_cost_element: DataFrame,
        df_dim_cr_corp_document: DataFrame,
        df_dim_cr_fin_fund_center: DataFrame,
        df_dim_cr_fin_fund_group: DataFrame,
        df_dim_cr_fin_fund_user: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from the raw layer table passed in as DataFrame.
    '''
    logging.info("Starting the transformation process in prepare_wbse_df_parta.")

    df_wbse_commitments.createOrReplaceTempView("WBSE_COMMITMENTS")
    df_dim_cr_fin_account.createOrReplaceTempView("DIM_CR_FIN_ACCOUNT")
    df_dim_cr_work_assignment.createOrReplaceTempView("DIM_CR_WORK_ASSIGNMENT")
    df_dim_cr_fin_cost_center.createOrReplaceTempView("DIM_CR_FIN_COST_CENTER")
    df_dim_cr_fin_cost_element.createOrReplaceTempView("DIM_CR_FIN_COST_ELEMENT")
    df_dim_cr_corp_document.createOrReplaceTempView("DIM_CR_CORP_DOCUMENT")
    df_dim_cr_fin_fund_center.createOrReplaceTempView("DIM_CR_FIN_FUND_CENTER")
    df_dim_cr_fin_fund_group.createOrReplaceTempView("DIM_CR_FIN_FUND_GROUP")
    df_dim_cr_fin_fund_user.createOrReplaceTempView("DIM_CR_FIN_FUND_USER")

    logging.info("Executing SQL query for data transformation in prepare_wbse_df_parta.")

    sql_query = """
                SELECT B.DIM_ACCOUNT_ID
                ,C.DIM_ASSIGNMENT_ID
                ,NULL AS DIM_COST_CENTER_ID
                ,E.DIM_COST_ELEMENT_ID
                ,F.DIM_DOCUMENT_ID
                ,G.DIM_FUND_CENTER_ID
                ,H.DIM_FUND_GROUP_ID
                ,I.DIM_FUND_USER_ID
                ,A.FUND_AREA
                ,A.MATERIAL_GROUP
                ,A.PROGRAM_DEFINITION_KEY
                ,A.PROJECT_DEFINITION_KEY
                ,A.VENDOR
                ,A.VENDOR_NAME
                ,A.WBS_ELEMENT
                ,A.WBS_ELEMENT_DESC
                ,A.REQUESTING_SECTOR
                ,A.RESPONSIBLE_SECTOR
                ,A.PO_REF_PR
                ,A.OBJNUMBER
                ,A.PO_STATUS
                ,A.EXCHANGE_RATE
                ,A.DATE
                ,NULL AS EXPENSE_CATEGORY_DESC
                ,A.FISCAL_YEAR
                ,A.PERIOD
                ,A.EFFECTIVE_DATE
                ,A.EXPECTED_DEBIT_DATE
                ,A.LEAD_TIME
                ,A.PLAN_QUANTITY
                ,A.PLANNED_VALUE_RC
                ,A.PO_DOC_ITEM_DELETION_INDICATOR
                ,A.PO_DOC_ITEM
                ,A.REFERENCE_PROCEDURE
                ,A.RELEASE_DATE
                ,A.RELEASE_INDICATOR
                ,A.TOTAL_QUANTITY
                ,A.TOTAL_VALUE_RC
                ,A.WBS_DELETION_INDICATOR
            FROM WBSE_COMMITMENTS A
            LEFT JOIN DIM_CR_FIN_ACCOUNT B ON coalesce(A.ACCOUNT, '-') = coalesce(B.ACCOUNT_NAME, '-')
            LEFT JOIN DIM_CR_WORK_ASSIGNMENT C ON coalesce(A.ACCT_ASSIGNMENT, '-') = coalesce(C.ASSIGNMENT_NO_NAMES, '-')
            LEFT JOIN DIM_CR_FIN_COST_ELEMENT E ON coalesce(A.COST_ELEMENT, '-') = coalesce(E.COST_ELEMENT_NUMBER, '-')
                AND coalesce(A.COST_ELEMENT_DESC, '-') = coalesce(E.COST_ELEMENT_SHORT_TEXT, '-')
            LEFT JOIN DIM_CR_CORP_DOCUMENT F ON coalesce(A.DOCUMENT_DATE, '-') = coalesce(F.DOCUMENT_DATE, '-')
                AND coalesce(A.DOCUMENT_TYPE_LONG, '-') = coalesce(F.DOC_TYPE_DESCR, '-')
                AND coalesce(A.PURCHASING_DOCUMENT_NUMBER, '-') = coalesce(F.PURCHASING_DOC_NO, '-')
                AND coalesce(A.TEXT, '-') = coalesce(F.DOC_HEADER, '-')
                AND coalesce(A.PO_DOC_ITEM, '-') = coalesce(F.DOCUMENT_NUMBER, '-')
                AND coalesce(A.PURCHASING_DOCUMENT_ITEM, '-') = coalesce(F.DOC_ITEM, '-')
                AND coalesce(A.REFERENCE_DOC_TYPE, '-') = coalesce(F.REFERENCE_DOCUMENT_TYPE, '-')
            LEFT JOIN DIM_CR_FIN_FUND_CENTER G ON coalesce(A.FUND, '-') = coalesce(G.FUND_CENTER_NAME, '-')
                AND coalesce(A.FUNDS_CENTER, '-') = coalesce(G.FUND_CENTER_CODE, '-')
                AND coalesce(A.FUNDS_CENTER_DESC, '-') = coalesce(G.FUND_CENTER_DESCRIPTION, '-')
            LEFT JOIN DIM_CR_FIN_FUND_GROUP H 
                ON coalesce(A.REQUESTING_REGION, '-') = coalesce(H.REQUESTING_FUND_GROUP, '-')
                AND coalesce(A.RESPONSIBLE_REGION, '-') = coalesce(H.RESPONSIBLE_FUND_GROUP, '-')
                AND H.FUND_GROUP_NAME is null
                AND H.HIERARCHY_GROUP is null
                AND H.SEMI_GROUP_CODE is null
            LEFT JOIN DIM_CR_FIN_FUND_USER I ON coalesce(A.USER_NAME_ID, '-') = coalesce(I.USER_NAME_ID, '-')
                AND coalesce(A.USER_NAME, '-') = coalesce(I.USER_NAME, '-')

            """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation in prepare_wbse_df_parta")

    return df_transformed


def prepare_wbse_df_partb(
        spark: SparkSession,
        wbse_df_part1: DataFrame,
        df_dim_cr_proc_material_group: DataFrame,
        df_dim_cr_work_program: DataFrame,
        df_dim_cr_work_project: DataFrame,
        df_dim_wa_org_waterqa_supplier_sap: DataFrame,
        df_dim_cr_work_work_order: DataFrame,
        df_dim_cr_cus_customer_kind_sap: DataFrame,
        df_dim_cr_proc_pr: DataFrame,
        df_dim_cr_proc_po: DataFrame,
        df_dim_cr_fin_functional_area: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from the raw layer table passed in as DataFrame.
    '''
    logging.info("Starting the transformation process in prepare_wbse_df_partb.")

    wbse_df_part1.createOrReplaceTempView("TRANSFORM_DF_PART1")
    df_dim_cr_proc_material_group.createOrReplaceTempView("DIM_CR_PROC_MATERIAL_GROUP")
    df_dim_cr_work_program.createOrReplaceTempView("DIM_CR_WORK_PROGRAM")
    df_dim_cr_work_project.createOrReplaceTempView("DIM_CR_WORK_PROJECT")
    df_dim_wa_org_waterqa_supplier_sap.createOrReplaceTempView("DIM_WATERQA_SUPPLIER")
    df_dim_cr_work_work_order.createOrReplaceTempView("DIM_CR_WORK_WORK_ORDER")
    df_dim_cr_cus_customer_kind_sap.createOrReplaceTempView("DIM_CR_CUS_CUSTOMER_KIND")
    df_dim_cr_proc_pr.createOrReplaceTempView("DIM_CR_PROC_PR")
    df_dim_cr_proc_po.createOrReplaceTempView("DIM_CR_PROC_PO")
    df_dim_cr_fin_functional_area.createOrReplaceTempView("DIM_CR_FIN_FUNCTIONAL_AREA")

    logging.info("Executing SQL query for data transformation in prepare_wbse_df_partb.")

    sql_query = """
                select 
                A.DIM_ACCOUNT_ID,
                A.DIM_ASSIGNMENT_ID,
                A.DIM_COST_CENTER_ID,
                A.DIM_COST_ELEMENT_ID,
                A.DIM_DOCUMENT_ID,
                A.DIM_FUND_CENTER_ID,
                A.DIM_FUND_GROUP_ID,
                A.DIM_FUND_USER_ID,
                B.DIM_MATERIAL_GROUP_ID,
                C1.DIM_PROGRAM_ID,
                C2.DIM_PROJECT_ID,
                C.DIM_WATERQA_SUPPLIER_ID,
                CASE WHEN (A.WBS_ELEMENT is NULL or A.WBS_ELEMENT_DESC='Not assigned') THEN 'Not Assigned'
                ELSE G.DIM_WORK_ORDER_ID END as DIM_WORK_ORDER_ID,
                D.CUSTOMER_KIND_ID,
                E.DIM_PR_ID,
                F.DIM_PR_PO_ID,
                H.DIM_FUNCTIONAL_AREA_ID,
                A.EXCHANGE_RATE,
                'WBSE Commitments' as FINANCIAL_COMMITMENT_TYPE,
                A.DATE as COMMITMENT_DATE,
                A.EXPENSE_CATEGORY_DESC as COMMITMENT_EXPENSE_CATEGORY_DESC,
                A.FISCAL_YEAR as COMMITMENT_FISCAL_YEAR,
                A.PERIOD as COMMITMENT_PERIOD,
                A.EFFECTIVE_DATE,
                A.EXPECTED_DEBIT_DATE,
                A.LEAD_TIME,
                A.PLAN_QUANTITY,
                A.PLANNED_VALUE_RC,
                A.PO_DOC_ITEM_DELETION_INDICATOR,
                A.PO_DOC_ITEM,
                A.REFERENCE_PROCEDURE,
                A.RELEASE_DATE,
                A.RELEASE_INDICATOR,
                A.TOTAL_QUANTITY,
                A.TOTAL_VALUE_RC,
                A.WBS_DELETION_INDICATOR
                from TRANSFORM_DF_PART1 A
                left join DIM_CR_PROC_MATERIAL_GROUP B
                on coalesce(A.MATERIAL_GROUP,'-')=coalesce(B.MATERIAL_GROUP,'-')
                left join DIM_CR_WORK_PROGRAM C1
                on coalesce(A.PROGRAM_DEFINITION_KEY,'-')=coalesce(C1.PROGRAM_DEFINITION_KEY,'-')
                and C1.PROGRAM_DEFINITION_DESC is NULL
                left join DIM_CR_WORK_PROJECT C2
                on coalesce(A.PROJECT_DEFINITION_KEY,'-')=coalesce(C2.PROJECT_DEFINITION_KEY,'-')
                left join DIM_WATERQA_SUPPLIER C
                on coalesce(A.VENDOR,'-')=coalesce(C.SUPPLIER_CODE,'-')
                and coalesce(A.VENDOR_NAME,'-')=coalesce(C.SUPPLIER_NAME,'-')
                and C.GCFA_SUPPLIER_CODE is null
                and C.SUPPLIER_TYPE = 'SAP FI'
                left join DIM_CR_CUS_CUSTOMER_KIND D
                on coalesce(A.REQUESTING_SECTOR,'-')=coalesce(D.REQUESTING_SECTOR,'-')
                and coalesce(A.RESPONSIBLE_SECTOR,'-')=coalesce(D.RESPONSIBLE_SECTOR,'-')
                and D.CUSTOMER_KIND_SECTOR is NULL
                left join DIM_CR_PROC_PR E
                on coalesce(A.PO_REF_PR,'-')=coalesce(E.PURCHASE_REQUISITION,'-')
                and coalesce(A.OBJNUMBER,'-')=coalesce(E.PR_OBJECT_NUMBER,'-')
                and E.DATA_SOURCE='WBSE_COMMITMENTS'
                left join DIM_CR_PROC_PO F
                on coalesce(A.PO_STATUS,'-')=coalesce(F.PO_STATUS,'-')
                and F.DATA_SOURCE='WBSE_COMMITMENTS'
                left join DIM_CR_WORK_WORK_ORDER G
                on coalesce(A.WBS_ELEMENT,'-')=coalesce(G.IO_WBS,'-')
                and coalesce(A.WBS_ELEMENT_DESC,'-')=coalesce(G.IO_WBS_DESCRIPTION,'-')
                and G.ORDER_ELEMENT_KEY IS NULL
                left join DIM_CR_FIN_FUNCTIONAL_AREA H
                on coalesce(A.FUND_AREA,'-')=coalesce(H.FUNCTIONAL_AREA,'-')
            """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation in prepare_wbse_df_partb.")

    return df_transformed


def prepare_io_df_parta(
        spark: SparkSession,
        df_internal_order_commitments: DataFrame,
        df_dim_cr_fin_account: DataFrame,
        df_dim_cr_work_assignment: DataFrame,
        df_dim_cr_fin_cost_center: DataFrame,
        df_dim_cr_fin_cost_element: DataFrame,
        df_dim_cr_corp_document: DataFrame,
        df_dim_cr_fin_fund_center: DataFrame,
        df_dim_cr_fin_fund_group: DataFrame,
        df_dim_cr_fin_fund_user: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from the raw layer table passed in as DataFrame.
    '''
    logging.info("Starting the transformation process in prepare_io_df_parta.")

    df_internal_order_commitments.createOrReplaceTempView("INTERNAL_ORDER_COMMITMENTS")
    df_dim_cr_fin_account.createOrReplaceTempView("DIM_CR_FIN_ACCOUNT")
    df_dim_cr_work_assignment.createOrReplaceTempView("DIM_CR_WORK_ASSIGNMENT")
    df_dim_cr_fin_cost_center.createOrReplaceTempView("DIM_CR_FIN_COST_CENTER")
    df_dim_cr_fin_cost_element.createOrReplaceTempView("DIM_CR_FIN_COST_ELEMENT")
    df_dim_cr_corp_document.createOrReplaceTempView("DIM_CR_CORP_DOCUMENT")
    df_dim_cr_fin_fund_center.createOrReplaceTempView("DIM_CR_FIN_FUND_CENTER")
    df_dim_cr_fin_fund_group.createOrReplaceTempView("DIM_CR_FIN_FUND_GROUP")
    df_dim_cr_fin_fund_user.createOrReplaceTempView("DIM_CR_FIN_FUND_USER")

    logging.info("Executing SQL query for data transformation in prepare_io_df_parta.")

    sql_query = """
                SELECT B.DIM_ACCOUNT_ID
                ,C.DIM_ASSIGNMENT_ID
                ,D.DIM_COST_CENTER_ID
                ,E.DIM_COST_ELEMENT_ID
                ,F.DIM_DOCUMENT_ID
                ,G.DIM_FUND_CENTER_ID
                ,H.DIM_FUND_GROUP_ID
                ,I.DIM_FUND_USER_ID
                ,A.FUND_AREA
                ,A.MATERIAL_GROUP
                ,A.VENDOR
                ,A.VENDOR_NAME
                ,A.ORDER
                ,A.WBS_ELEMENT
                ,A.WBS_ELEMENT_DESC
                ,A.REQUESTING_SECTOR
                ,A.RESPONSIBLE_SECTOR
                ,A.PO_REF_PR
                ,A.PO_STATUS
                ,A.EXCHANGE_RATE
                ,DATE_FORMAT(A.DATE_DT, 'yyyy-MM-dd HH:mm:ss') AS DATE
                ,A.EXPENSE_CATEGORY_DESC
                ,A.FISCAL_YEAR
                ,A.PERIOD
                ,DATE_FORMAT(A.EFFECTIVE_DATE, 'yyyy-MM-dd HH:mm:ss') AS EFFECTIVE_DATE
                ,DATE_FORMAT(A.EXPECTED_DEBIT_DATE, 'yyyy-MM-dd HH:mm:ss') AS EXPECTED_DEBIT_DATE
                ,A.LEAD_TIME
                ,A.PLAN_QUANTITY
                ,A.PLANNED_VALUE_RC
                ,A.PO_DOC_ITEM_DELETION_INDICATOR
                ,A.PO_DOC_ITEM
                ,A.REFERENCE_PROCEDURE
                ,DATE_FORMAT(A.RELEASE_DATE, 'yyyy-MM-dd HH:mm:ss') AS RELEASE_DATE
                ,A.RELEASE_INDICATOR
                ,A.TOTAL_QUANTITY
                ,A.TOTAL_VALUE_RC
                ,A.WBS_DELETION_INDICATOR
            FROM INTERNAL_ORDER_COMMITMENTS A
            LEFT JOIN DIM_CR_FIN_ACCOUNT B ON A.ACCOUNT = B.ACCOUNT_NAME
            LEFT JOIN DIM_CR_WORK_ASSIGNMENT C ON A.ACCT_ASSIGNMENT = C.ASSIGNMENT_NO_NAMES
            LEFT JOIN DIM_CR_FIN_COST_CENTER D ON A.REQUESTING_COST_CENTER_KEY = D.REQUEST_CCTR
                AND A.RESPONSIBLE_COST_CENTER_KEY = D.RESPONSIBLE_CCTR
            LEFT JOIN DIM_CR_FIN_COST_ELEMENT E ON A.COST_ELEMENT = E.COST_ELEMENT_NUMBER
                AND A.COST_ELEMENT_DESC = E.COST_ELEMENT_SHORT_TEXT
            LEFT JOIN DIM_CR_CORP_DOCUMENT F ON coalesce(A.DOCUMENT_DATE, '-') = coalesce(F.DOCUMENT_DATE, '-')
                AND coalesce(A.PURCHASING_DOCUMENT_NUMBER, '-') = coalesce(F.PURCHASING_DOC_NO, '-')
                AND coalesce(A.TEXT, '-') = coalesce(F.DOC_HEADER, '-')
                AND coalesce(A.PO_DOC_ITEM, '-') = coalesce(F.DOCUMENT_NUMBER, '-')
                AND coalesce(A.PURCHASING_DOCUMENT_ITEM, '-') = coalesce(F.DOC_ITEM, '-')
                AND coalesce(A.REFERENCE_DOC_TYPE, '-') = coalesce(F.REFERENCE_DOCUMENT_TYPE, '-')
                AND F.DOC_TYPE_DESCR IS NULL
            LEFT JOIN DIM_CR_FIN_FUND_CENTER G ON A.FUND = G.FUND_CENTER_NAME
                AND A.FUNDS_CENTER = G.FUND_CENTER_CODE
                AND A.FUNDS_CENTER_DESC = G.FUND_CENTER_DESCRIPTION
            LEFT JOIN DIM_CR_FIN_FUND_GROUP H 
                ON A.REQUESTING_REGION = H.REQUESTING_FUND_GROUP
                AND A.RESPONSIBLE_REGION = H.RESPONSIBLE_FUND_GROUP
                AND H.FUND_GROUP_NAME is null
                AND H.HIERARCHY_GROUP is null
                AND H.SEMI_GROUP_CODE is null
            LEFT JOIN DIM_CR_FIN_FUND_USER I ON A.USER_NAME_ID = I.USER_NAME_ID
                AND A.USER_NAME = I.USER_NAME
        """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation in prepare_io_df_parta")

    return df_transformed


def prepare_io_df_partb(
        spark: SparkSession,
        io_df_part1: DataFrame,
        df_dim_cr_proc_material_group: DataFrame,
        df_dim_cr_work_program: DataFrame,
        df_dim_cr_work_project: DataFrame,
        df_dim_wa_org_waterqa_supplier_sap: DataFrame,
        df_dim_cr_work_work_order: DataFrame,
        df_dim_cr_cus_customer_kind_sap: DataFrame,
        df_dim_cr_proc_pr: DataFrame,
        df_dim_cr_proc_po: DataFrame,
        df_dim_cr_fin_functional_area: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from the raw layer table passed in as DataFrame.
    '''
    logging.info("Starting the transformation process in prepare_io_df_partb.")

    io_df_part1.createOrReplaceTempView("TRANSFORM_DF_PART1")
    df_dim_cr_proc_material_group.createOrReplaceTempView("DIM_CR_PROC_MATERIAL_GROUP")
    df_dim_cr_work_program.createOrReplaceTempView("DIM_CR_WORK_PROGRAM")
    df_dim_cr_work_project.createOrReplaceTempView("DIM_CR_WORK_PROJECT")
    df_dim_wa_org_waterqa_supplier_sap.createOrReplaceTempView("DIM_WATERQA_SUPPLIER")
    df_dim_cr_work_work_order.createOrReplaceTempView("DIM_CR_WORK_WORK_ORDER")
    df_dim_cr_cus_customer_kind_sap.createOrReplaceTempView("DIM_CR_CUS_CUSTOMER_KIND")
    df_dim_cr_proc_pr.createOrReplaceTempView("DIM_CR_PROC_PR")
    df_dim_cr_proc_po.createOrReplaceTempView("DIM_CR_PROC_PO")
    df_dim_cr_fin_functional_area.createOrReplaceTempView("DIM_CR_FIN_FUNCTIONAL_AREA")

    logging.info("Executing SQL query for data transformation in prepare_io_df_partb.")

    sql_query = """
                select
                A.DIM_ACCOUNT_ID,
                A.DIM_ASSIGNMENT_ID,
                A.DIM_COST_CENTER_ID,
                A.DIM_COST_ELEMENT_ID,
                A.DIM_DOCUMENT_ID,
                A.DIM_FUND_CENTER_ID,
                A.DIM_FUND_GROUP_ID,
                A.DIM_FUND_USER_ID,
                B.DIM_MATERIAL_GROUP_ID,
                NULL as DIM_PROGRAM_ID,
                NULL as DIM_PROJECT_ID,
                C.DIM_WATERQA_SUPPLIER_ID,
                CASE WHEN (A.WBS_ELEMENT is NULL or A.WBS_ELEMENT_DESC='Not assigned') THEN 'Not Assigned'
                ELSE G.DIM_WORK_ORDER_ID END as DIM_WORK_ORDER_ID,
                D.CUSTOMER_KIND_ID,
                E.DIM_PR_ID,
                F.DIM_PR_PO_ID,
                H.DIM_FUNCTIONAL_AREA_ID,
                A.EXCHANGE_RATE,
                'Internal Order Commitments' as FINANCIAL_COMMITMENT_TYPE,
                A.DATE as COMMITMENT_DATE,
                A.EXPENSE_CATEGORY_DESC as COMMITMENT_EXPENSE_CATEGORY_DESC,
                A.FISCAL_YEAR as COMMITMENT_FISCAL_YEAR,
                A.PERIOD as COMMITMENT_PERIOD,
                A.EFFECTIVE_DATE,
                A.EXPECTED_DEBIT_DATE,
                A.LEAD_TIME,
                A.PLAN_QUANTITY,
                A.PLANNED_VALUE_RC,
                A.PO_DOC_ITEM_DELETION_INDICATOR,
                A.PO_DOC_ITEM,
                A.REFERENCE_PROCEDURE,
                A.RELEASE_DATE,
                A.RELEASE_INDICATOR,
                A.TOTAL_QUANTITY,
                A.TOTAL_VALUE_RC,
                A.WBS_DELETION_INDICATOR
                from TRANSFORM_DF_PART1 A
                left join DIM_CR_PROC_MATERIAL_GROUP B
                on A.MATERIAL_GROUP=B.MATERIAL_GROUP
                left join DIM_WATERQA_SUPPLIER C
                on A.VENDOR=C.SUPPLIER_CODE
                and A.VENDOR_NAME=C.SUPPLIER_NAME
                and C.GCFA_SUPPLIER_CODE is null
                and C.SUPPLIER_TYPE = 'SAP FI'
                left join DIM_CR_CUS_CUSTOMER_KIND D
                on A.REQUESTING_SECTOR=D.REQUESTING_SECTOR
                and A.RESPONSIBLE_SECTOR=D.RESPONSIBLE_SECTOR
                and D.CUSTOMER_KIND_SECTOR is NULL
                left join DIM_CR_PROC_PR E
                on A.PO_REF_PR=E.PURCHASE_REQUISITION
                and E.DATA_SOURCE='INTERNAL_ORDER_COMMITMENTS'
                left join DIM_CR_PROC_PO F
                on A.PO_STATUS=F.PO_STATUS
                and F.DATA_SOURCE='INTERNAL_ORDER_COMMITMENTS'
                left join (select distinct DIM_WORK_ORDER_ID,
                            IO_WBS
                            from DIM_CR_WORK_WORK_ORDER) G
                on A.ORDER=G.IO_WBS
                left join DIM_CR_FIN_FUNCTIONAL_AREA H
                on A.FUND_AREA=H.FUNCTIONAL_AREA
            """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation in prepare_io_df_partb.")

    return df_transformed


def execute_transformed_df(
        spark: SparkSession,
        cost_center_df_part2: DataFrame,
        wbse_df_part2: DataFrame,
        io_df_part2: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from the raw layer table passed in as DataFrame.
    '''
    logging.info("Starting the transformation process.")

    cost_center_df_part2.createOrReplaceTempView("cost_center_data")
    wbse_df_part2.createOrReplaceTempView("wbse_data")
    io_df_part2.createOrReplaceTempView("io_data")

    logging.info("Executing SQL query for data transformation.")

    sql_query = """
                select 
                DIM_ACCOUNT_ID,
                DIM_ASSIGNMENT_ID,
                DIM_COST_CENTER_ID,
                DIM_COST_ELEMENT_ID,
                DIM_DOCUMENT_ID,
                DIM_FUND_CENTER_ID,
                DIM_FUND_GROUP_ID,
                DIM_FUND_USER_ID,
                DIM_MATERIAL_GROUP_ID,
                DIM_PROGRAM_ID,
                DIM_PROJECT_ID,
                DIM_WATERQA_SUPPLIER_ID,
                DIM_WORK_ORDER_ID,
                CUSTOMER_KIND_ID,
                DIM_PR_ID,
                DIM_PR_PO_ID,
                DIM_FUNCTIONAL_AREA_ID,
                EXCHANGE_RATE,
                FINANCIAL_COMMITMENT_TYPE,
                COMMITMENT_DATE,
                COMMITMENT_EXPENSE_CATEGORY_DESC,
                COMMITMENT_FISCAL_YEAR,
                COMMITMENT_PERIOD,
                EFFECTIVE_DATE,
                EXPECTED_DEBIT_DATE,
                LEAD_TIME,
                PLAN_QUANTITY,
                PLANNED_VALUE_RC,
                PO_DOC_ITEM_DELETION_INDICATOR,
                PO_DOC_ITEM,
                REFERENCE_PROCEDURE,
                RELEASE_DATE,
                RELEASE_INDICATOR,
                TOTAL_QUANTITY,
                TOTAL_VALUE_RC,
                WBS_DELETION_INDICATOR,
                current_timestamp() AS LAST_UPDATED_DATE,  
                current_timestamp() AS CREATED_DATE  
                from cost_center_data
                union
                select 
                DIM_ACCOUNT_ID,
                DIM_ASSIGNMENT_ID,
                DIM_COST_CENTER_ID,
                DIM_COST_ELEMENT_ID,
                DIM_DOCUMENT_ID,
                DIM_FUND_CENTER_ID,
                DIM_FUND_GROUP_ID,
                DIM_FUND_USER_ID,
                DIM_MATERIAL_GROUP_ID,
                DIM_PROGRAM_ID,
                DIM_PROJECT_ID,
                DIM_WATERQA_SUPPLIER_ID,
                DIM_WORK_ORDER_ID,
                CUSTOMER_KIND_ID,
                DIM_PR_ID,
                DIM_PR_PO_ID,
                DIM_FUNCTIONAL_AREA_ID,
                EXCHANGE_RATE,
                FINANCIAL_COMMITMENT_TYPE,
                COMMITMENT_DATE,
                COMMITMENT_EXPENSE_CATEGORY_DESC,
                COMMITMENT_FISCAL_YEAR,
                COMMITMENT_PERIOD,
                EFFECTIVE_DATE,
                EXPECTED_DEBIT_DATE,
                LEAD_TIME,
                PLAN_QUANTITY,
                PLANNED_VALUE_RC,
                PO_DOC_ITEM_DELETION_INDICATOR,
                PO_DOC_ITEM,
                REFERENCE_PROCEDURE,
                RELEASE_DATE,
                RELEASE_INDICATOR,
                TOTAL_QUANTITY,
                TOTAL_VALUE_RC,
                WBS_DELETION_INDICATOR,
                current_timestamp() AS LAST_UPDATED_DATE,  
                current_timestamp() AS CREATED_DATE  
                from wbse_data
                union
                select 
                DIM_ACCOUNT_ID,
                DIM_ASSIGNMENT_ID,
                DIM_COST_CENTER_ID,
                DIM_COST_ELEMENT_ID,
                DIM_DOCUMENT_ID,
                DIM_FUND_CENTER_ID,
                DIM_FUND_GROUP_ID,
                DIM_FUND_USER_ID,
                DIM_MATERIAL_GROUP_ID,
                DIM_PROGRAM_ID,
                DIM_PROJECT_ID,
                DIM_WATERQA_SUPPLIER_ID,
                DIM_WORK_ORDER_ID,
                CUSTOMER_KIND_ID,
                DIM_PR_ID,
                DIM_PR_PO_ID,
                DIM_FUNCTIONAL_AREA_ID,
                EXCHANGE_RATE,
                FINANCIAL_COMMITMENT_TYPE,
                COMMITMENT_DATE,
                COMMITMENT_EXPENSE_CATEGORY_DESC,
                COMMITMENT_FISCAL_YEAR,
                COMMITMENT_PERIOD,
                EFFECTIVE_DATE,
                EXPECTED_DEBIT_DATE,
                LEAD_TIME,
                PLAN_QUANTITY,
                PLANNED_VALUE_RC,
                PO_DOC_ITEM_DELETION_INDICATOR,
                PO_DOC_ITEM,
                REFERENCE_PROCEDURE,
                RELEASE_DATE,
                RELEASE_INDICATOR,
                TOTAL_QUANTITY,
                TOTAL_VALUE_RC,
                WBS_DELETION_INDICATOR,
                current_timestamp() AS LAST_UPDATED_DATE,  
                current_timestamp() AS CREATED_DATE  
                from io_data
            """

    df_transformed = spark.sql(sql_query)
    logging.info("Executed SQL query for data transformation.")
    # List of columns for generating the key
    columns = [
        'DIM_ACCOUNT_ID',
        'DIM_ASSIGNMENT_ID',
        'DIM_COST_CENTER_ID',
        'DIM_COST_ELEMENT_ID',
        'DIM_DOCUMENT_ID',
        'DIM_FUND_CENTER_ID',
        'DIM_FUND_GROUP_ID',
        'DIM_FUND_USER_ID',
        'DIM_MATERIAL_GROUP_ID',
        'DIM_PROGRAM_ID',
        'DIM_PROJECT_ID',
        'DIM_WATERQA_SUPPLIER_ID',
        'DIM_WORK_ORDER_ID',
        'CUSTOMER_KIND_ID',
        'DIM_PR_ID',
        'DIM_PR_PO_ID',
        'DIM_FUNCTIONAL_AREA_ID',
        'EXCHANGE_RATE',
        'FINANCIAL_COMMITMENT_TYPE',
        'COMMITMENT_DATE',
        'COMMITMENT_EXPENSE_CATEGORY_DESC',
        'COMMITMENT_FISCAL_YEAR',
        'COMMITMENT_PERIOD',
        'EFFECTIVE_DATE',
        'EXPECTED_DEBIT_DATE',
        'LEAD_TIME',
        'PO_DOC_ITEM_DELETION_INDICATOR',
        'REFERENCE_PROCEDURE',
        'RELEASE_DATE',
        'RELEASE_INDICATOR',
        'WBS_DELETION_INDICATOR',
        'PO_DOC_ITEM'
    ]

    # Generate the key
    df_transformed = df_transformed.withColumn(
        "FACT_FINANCIAL_COMMITMENT_ID",
        sha2(
            concat_ws(
                "||",
                *[coalesce((col), lit("-")) for col in columns]
            ),
            256
        )
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def standardize_date_format(df: DataFrame):
    """
        Converts the 'DOCUMENT_DATE' column in the input DataFrame from
        'yyyy-MM-dd HH:mm:ss' format to 'DD-MMM-YY' string format.

        Args:
            df (DataFrame): Input DataFrame with 'DOCUMENT_DATE' as a string column.

        Returns:
            DataFrame: DataFrame with 'DOCUMENT_DATE' standardized to 'DD-MMM-YY'.
    """
    return df.withColumn(
        "DOCUMENT_DATE",
        F.upper(
            F.concat_ws(
                "-",
                F.lpad(
                    F.substring("DOCUMENT_DATE", 9, 2),
                    2,
                    "0"
                ),
                F.upper(
                    F.date_format(
                        F.to_date(F.substring("DOCUMENT_DATE", 1, 10), "yyyy-MM-dd"),
                        "MMM"
                    )
                ),
                F.substring("DOCUMENT_DATE", 3, 2)
            )
        )
    )


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_cost_center_commitments = standardize_date_format(source_dfs["COST_CENTER_COMMITMENTS"])
    df_wbse_commitments = standardize_date_format(source_dfs["WBSE_COMMITMENTS"])
    df_internal_order_commitments = standardize_date_format(source_dfs["INTERNAL_ORDER_COMMITMENTS"])

    df_dim_cr_fin_account = source_dfs["DIM_CR_FIN_ACCOUNT"]
    df_dim_cr_work_assignment = source_dfs["DIM_CR_WORK_ASSIGNMENT"]
    df_dim_cr_fin_cost_center = source_dfs["DIM_CR_FIN_COST_CENTER"]
    df_dim_cr_fin_cost_element = source_dfs["DIM_CR_FIN_COST_ELEMENT"]
    df_dim_cr_corp_document = source_dfs["DIM_CR_CORP_DOCUMENT"]
    df_dim_cr_fin_fund_center = source_dfs["DIM_CR_FIN_FUND_CENTER"]
    df_dim_cr_fin_fund_group = source_dfs["DIM_CR_FIN_FUND_GROUP"]
    df_dim_cr_fin_fund_user = source_dfs["DIM_CR_FIN_FUND_USER"]
    df_dim_cr_proc_material_group = source_dfs["DIM_CR_PROC_MATERIAL_GROUP"]
    df_dim_cr_work_program = source_dfs["DIM_CR_WORK_PROGRAM"]
    df_dim_cr_work_project = source_dfs["DIM_CR_WORK_PROJECT"]
    df_dim_wa_org_waterqa_supplier_sap = source_dfs["DIM_WA_ORG_WATERQA_SUPPLIER_SAP"]
    df_dim_cr_work_work_order = source_dfs["DIM_CR_WORK_WORK_ORDER"]
    df_dim_cr_cus_customer_kind_sap = source_dfs["DIM_CR_CUS_CUSTOMER_KIND_SAP"]
    df_dim_cr_proc_pr = source_dfs["DIM_CR_PROC_PR"]
    df_dim_cr_proc_po = source_dfs["DIM_CR_PROC_PO"]
    df_dim_cr_fin_functional_area = source_dfs["DIM_CR_FIN_FUNCTIONAL_AREA"]

    cost_center_df_part1 = prepare_cost_center_df_parta(
        spark=spark,
        df_cost_center_commitments=df_cost_center_commitments,
        df_dim_cr_fin_account=df_dim_cr_fin_account,
        df_dim_cr_work_assignment=df_dim_cr_work_assignment,
        df_dim_cr_fin_cost_center=df_dim_cr_fin_cost_center,
        df_dim_cr_fin_cost_element=df_dim_cr_fin_cost_element,
        df_dim_cr_corp_document=df_dim_cr_corp_document,
        df_dim_cr_fin_fund_center=df_dim_cr_fin_fund_center,
        df_dim_cr_fin_fund_group=df_dim_cr_fin_fund_group,
        df_dim_cr_fin_fund_user=df_dim_cr_fin_fund_user
    )

    cost_center_df_part2 = prepare_cost_center_df_partb(
        spark=spark,
        cost_center_df_part1=cost_center_df_part1,
        df_dim_cr_proc_material_group=df_dim_cr_proc_material_group,
        df_dim_cr_work_program=df_dim_cr_work_program,
        df_dim_cr_work_project=df_dim_cr_work_project,
        df_dim_wa_org_waterqa_supplier_sap=df_dim_wa_org_waterqa_supplier_sap,
        df_dim_cr_work_work_order=df_dim_cr_work_work_order,
        df_dim_cr_cus_customer_kind_sap=df_dim_cr_cus_customer_kind_sap,
        df_dim_cr_proc_pr=df_dim_cr_proc_pr,
        df_dim_cr_proc_po=df_dim_cr_proc_po,
        df_dim_cr_fin_functional_area=df_dim_cr_fin_functional_area
    )

    wbse_df_part1 = prepare_wbse_df_parta(
        spark=spark,
        df_wbse_commitments=df_wbse_commitments,
        df_dim_cr_fin_account=df_dim_cr_fin_account,
        df_dim_cr_work_assignment=df_dim_cr_work_assignment,
        df_dim_cr_fin_cost_center=df_dim_cr_fin_cost_center,
        df_dim_cr_fin_cost_element=df_dim_cr_fin_cost_element,
        df_dim_cr_corp_document=df_dim_cr_corp_document,
        df_dim_cr_fin_fund_center=df_dim_cr_fin_fund_center,
        df_dim_cr_fin_fund_group=df_dim_cr_fin_fund_group,
        df_dim_cr_fin_fund_user=df_dim_cr_fin_fund_user
    )

    wbse_df_part2 = prepare_wbse_df_partb(
        spark=spark,
        wbse_df_part1=wbse_df_part1,
        df_dim_cr_proc_material_group=df_dim_cr_proc_material_group,
        df_dim_cr_work_program=df_dim_cr_work_program,
        df_dim_cr_work_project=df_dim_cr_work_project,
        df_dim_wa_org_waterqa_supplier_sap=df_dim_wa_org_waterqa_supplier_sap,
        df_dim_cr_work_work_order=df_dim_cr_work_work_order,
        df_dim_cr_cus_customer_kind_sap=df_dim_cr_cus_customer_kind_sap,
        df_dim_cr_proc_pr=df_dim_cr_proc_pr,
        df_dim_cr_proc_po=df_dim_cr_proc_po,
        df_dim_cr_fin_functional_area=df_dim_cr_fin_functional_area
    )

    io_df_part1 = prepare_io_df_parta(
        spark=spark,
        df_internal_order_commitments=df_internal_order_commitments,
        df_dim_cr_fin_account=df_dim_cr_fin_account,
        df_dim_cr_work_assignment=df_dim_cr_work_assignment,
        df_dim_cr_fin_cost_center=df_dim_cr_fin_cost_center,
        df_dim_cr_fin_cost_element=df_dim_cr_fin_cost_element,
        df_dim_cr_corp_document=df_dim_cr_corp_document,
        df_dim_cr_fin_fund_center=df_dim_cr_fin_fund_center,
        df_dim_cr_fin_fund_group=df_dim_cr_fin_fund_group,
        df_dim_cr_fin_fund_user=df_dim_cr_fin_fund_user
    )

    io_df_part2 = prepare_io_df_partb(
        spark=spark,
        io_df_part1=io_df_part1,
        df_dim_cr_proc_material_group=df_dim_cr_proc_material_group,
        df_dim_cr_work_program=df_dim_cr_work_program,
        df_dim_cr_work_project=df_dim_cr_work_project,
        df_dim_wa_org_waterqa_supplier_sap=df_dim_wa_org_waterqa_supplier_sap,
        df_dim_cr_work_work_order=df_dim_cr_work_work_order,
        df_dim_cr_cus_customer_kind_sap=df_dim_cr_cus_customer_kind_sap,
        df_dim_cr_proc_pr=df_dim_cr_proc_pr,
        df_dim_cr_proc_po=df_dim_cr_proc_po,
        df_dim_cr_fin_functional_area=df_dim_cr_fin_functional_area
    )

    transform_df = execute_transformed_df(
        spark=spark,
        cost_center_df_part2=cost_center_df_part2,
        wbse_df_part2=wbse_df_part2,
        io_df_part2=io_df_part2
    )

    transform_df = transform_df.distinct()
    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
) -> DataFrame:
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.
    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )
    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.
    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.
    Returns:
        DataFrame: The resulting DataFrame from the executed task.
    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")
    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
