# pylint:disable=unused-argument, import-error
"""
    This is the transformation file for dim_cr_corp_document dimension
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F

from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_po_data_by_supplier: DataFrame,
        df_cost_center_commitment: DataFrame,
        df_internal_order_commitment: DataFrame,
        df_wbse_commitment: DataFrame,
        df_cc_transaction_data: DataFrame,
        df_io_transaction_data: DataFrame,
        df_wbs_transaction_data: DataFrame,
        df_pr_po_status: DataFrame,
        df_pr_po_profile: DataFrame
) -> DataFrame:
    '''
        This function prepares the dataframe based on business logic for DIM_CR_CORP_DOCUMENT.
    '''
    logging.info("Starting the transformation process.")

    # Create temp views to use SQL on DataFrames
    df_po_data_by_supplier.createOrReplaceTempView("PO_DATA_BY_SUPPLIER_EXPORT_SOURCE")
    df_cost_center_commitment.createOrReplaceTempView("COST_CENTER_COMMITMENTS_SOURCE")
    df_internal_order_commitment.createOrReplaceTempView("INTERNAL_ORDER_COMMITMENTS_SOURCE")
    df_wbse_commitment.createOrReplaceTempView("WBSE_COMMITMENTS")
    df_cc_transaction_data.createOrReplaceTempView("COST_CENTER_TRANSACTION_DATA_SOURCE")
    df_io_transaction_data.createOrReplaceTempView("INTERNAL_ORDER_TRANSACTION_DATA")
    df_wbs_transaction_data.createOrReplaceTempView("WBSE_TRANSACTION_DATA")
    df_pr_po_status.createOrReplaceTempView("PR_PO_STATUS")
    df_pr_po_profile.createOrReplaceTempView("PR_PO_PROFILE")

    merged_query = """
    WITH 
    -- CTE for COST data with PO reference
    cost_data AS (
        SELECT 
            'COST' AS SOURCE,
            cost.PO_DOC_ITEM AS DOCUMENT_NUMBER,
            cost.DOCUMENT_DATE,
            cost.TEXT AS DOC_HEADER,
            NULL AS DOC_LINE_ITEM,
            cost.REFERENCE_DOC_TYPE,
            NULL AS CO_LINE_TEXT,
            NULL AS REFERENCE,
            NULL AS REFERENCE_DOC_NO,
            cost.PURCHASING_DOCUMENT_NUMBER AS PURCHASING_DOC_NO,
            NULL AS CO_DOCUMENT_NUMBER,
            cost.PURCHASING_DOCUMENT_ITEM AS DOC_ITEM,
            cost.PURCHASING_DOCUMENT_NUMBER AS PURCHASING_DOCUMENT_NUMBER,
            NULL AS DOC_TYPE_DESCR
        FROM COST_CENTER_COMMITMENTS_SOURCE cost
    ),
    -- CTE for IO_COMMIT data with PO reference
    io_commit_data AS (
        SELECT 
            'IO_COMMIT' AS SOURCE,
            io_commit.PO_DOC_ITEM AS DOCUMENT_NUMBER,
            io_commit.DOCUMENT_DATE,
            io_commit.TEXT AS DOC_HEADER,
            NULL AS DOC_LINE_ITEM,
            io_commit.REFERENCE_DOC_TYPE,
            NULL AS CO_LINE_TEXT,
            NULL AS REFERENCE,
            NULL AS REFERENCE_DOC_NO,
            io_commit.PURCHASING_DOCUMENT_NUMBER AS PURCHASING_DOC_NO,
            NULL AS CO_DOCUMENT_NUMBER,
            io_commit.PURCHASING_DOCUMENT_ITEM AS DOC_ITEM,
            io_commit.PURCHASING_DOCUMENT_NUMBER AS PURCHASING_DOCUMENT_NUMBER,
            NULL AS DOC_TYPE_DESCR
        FROM INTERNAL_ORDER_COMMITMENTS_SOURCE io_commit
    ),
    -- CTE for WBSE_COMMIT data with PO reference
    wbse_commit_data AS (
        SELECT 
            'WBSE_COMMIT' AS SOURCE,
            wbse.PO_DOC_ITEM AS DOCUMENT_NUMBER,
            wbse.DOCUMENT_DATE,
            wbse.TEXT AS DOC_HEADER,
            NULL AS DOC_LINE_ITEM,
            wbse.REFERENCE_DOC_TYPE,
            NULL AS CO_LINE_TEXT,
            NULL AS REFERENCE,
            NULL AS REFERENCE_DOC_NO,
            wbse.PURCHASING_DOCUMENT_NUMBER AS PURCHASING_DOC_NO,
            NULL AS CO_DOCUMENT_NUMBER,
            wbse.PURCHASING_DOCUMENT_ITEM AS DOC_ITEM,
            wbse.PURCHASING_DOCUMENT_NUMBER AS PURCHASING_DOCUMENT_NUMBER,
            wbse.DOCUMENT_TYPE_LONG AS DOC_TYPE_DESCR
        FROM WBSE_COMMITMENTS wbse
    ),
    -- CTE for COST_CENTER_TRANS data with PO reference
    cost_center_trans_data AS (
        SELECT 
            'COST_CENTER_TRANS' AS SOURCE,
            cc.CO_DOCUMENT_NUMBER AS DOCUMENT_NUMBER,
            cc.DOCUMENT_DATE,
            NULL AS DOC_HEADER,
            cc.CO_DOC_LINE_ITEM AS DOC_LINE_ITEM,
            NULL AS REFERENCE_DOC_TYPE,
            cc.CO_LINE_ITEM_TEXT AS CO_LINE_TEXT,
            NULL AS REFERENCE,
            cc.REFERENCE_DOC AS REFERENCE_DOC_NO,
            cc.PURCHASING_DOCUMENT AS PURCHASING_DOC_NO,
            cc.CO_DOCUMENT_NUMBER AS CO_DOCUMENT_NUMBER,
            cc.PURCHASING_DOC_ITEM AS DOC_ITEM,
            NULL AS PURCHASING_DOCUMENT_NUMBER,
            NULL AS DOC_TYPE_DESCR
        FROM COST_CENTER_TRANSACTION_DATA_SOURCE cc
    ),
    -- CTE for IO_TRANS data with PO reference
    io_trans_data AS (
        SELECT 
            'IO_TRANS' AS SOURCE,
            io_trans.CO_DOCUMENT_NUMBER AS DOCUMENT_NUMBER,
            io_trans.DOCUMENT_DATE,
            io_trans.DOCUMENT_HEADER_TEXT AS DOC_HEADER,
            io_trans.CO_DOC_LINE_ITEM AS DOC_LINE_ITEM,
            NULL AS REFERENCE_DOC_TYPE,
            io_trans.CO_LINE_TEXT AS CO_LINE_TEXT,
            io_trans.REFERENCE AS REFERENCE,
            io_trans.REFERENCE_DOC_NO AS REFERENCE_DOC_NO,
            io_trans.PURCHASING_DOCUMENT AS PURCHASING_DOC_NO,
            io_trans.CO_DOCUMENT_NUMBER AS CO_DOCUMENT_NUMBER,
            io_trans.PURCHASING_DOC_ITEM AS DOC_ITEM,
            NULL AS PURCHASING_DOCUMENT_NUMBER,
            NULL AS DOC_TYPE_DESCR
        FROM INTERNAL_ORDER_TRANSACTION_DATA io_trans
    ),
    -- CTE for WBSE_TRANS data with PO reference
    wbse_trans_data AS (
        SELECT 
            'WBSE_TRANS' AS SOURCE,
            wbs.CO_DOCUMENT_NUMBER AS DOCUMENT_NUMBER,
            wbs.DOCUMENT_DATE,
            wbs.DOCUMENT_HEADER_TEXT AS DOC_HEADER,
            wbs.CO_DOC_LINE_ITEM AS DOC_LINE_ITEM,
            NULL AS REFERENCE_DOC_TYPE,
            wbs.CO_LINE_TEXT AS CO_LINE_TEXT,
            wbs.REFERENCE AS REFERENCE,
            wbs.REFERENCE_DOC AS REFERENCE_DOC_NO,
            wbs.PURCHASING_DOCUMENT AS PURCHASING_DOC_NO,
            wbs.CO_DOCUMENT_NUMBER AS CO_DOCUMENT_NUMBER,
            wbs.PURCHASING_DOC_ITEM AS DOC_ITEM,
            NULL AS PURCHASING_DOCUMENT_NUMBER,
            NULL AS DOC_TYPE_DESCR
        FROM WBSE_TRANSACTION_DATA wbs
    ),

    po_data AS (
        SELECT
            'PO_DATA' AS SOURCE,
            NULL AS DOCUMENT_NUMBER,
            po.DOCUMENT_DATE,
            NULL AS DOC_HEADER,
            NULL AS DOC_LINE_ITEM,
            NULL AS REFERENCE_DOC_TYPE,
            NULL AS CO_LINE_TEXT,
            NULL AS REFERENCE,
            NULL AS REFERENCE_DOC_NO,
            po.PURCHASING_DOCUMENT AS PURCHASING_DOC_NO,
            NULL AS CO_DOCUMENT_NUMBER,
            NULL AS DOC_ITEM,
            NULL AS PURCHASING_DOCUMENT_NUMBER,
            NULL AS DOC_TYPE_DESCR
        FROM PO_DATA_BY_SUPPLIER_EXPORT_SOURCE po
    ),

    combined_documents AS (
        -- Combine all CTEs using UNION ALL
        SELECT * FROM cost_data
        UNION ALL
        SELECT * FROM io_commit_data
        UNION ALL
        SELECT * FROM wbse_commit_data
        UNION ALL
        SELECT * FROM cost_center_trans_data
        UNION ALL
        SELECT * FROM io_trans_data
        UNION ALL
        SELECT * FROM wbse_trans_data
        UNION ALL
        SELECT * FROM po_data  -- Add unmatched PO data here
    ),

    pr_po_data AS (
        SELECT DISTINCT
            'PR_PO_PROFILE' AS SOURCE,
            NULL AS DOCUMENT_NUMBER,
            NULL AS DOCUMENT_DATE,
            NULL AS DOC_HEADER,
            NULL AS DOC_LINE_ITEM,
            NULL AS REFERENCE_DOC_TYPE,
            NULL AS CO_LINE_TEXT,
            NULL AS REFERENCE,
            NULL AS REFERENCE_DOC_NO,
            NULL AS PURCHASING_DOC_NO,
            NULL AS CO_DOCUMENT_NUMBER,
            NULL AS DOC_ITEM,
            NULL AS PURCHASING_DOCUMENT_NUMBER,
            NULL AS DOC_TYPE_DESCR,
            DOC_TYPE
        FROM PR_PO_PROFILE
        UNION ALL
        SELECT DISTINCT
            'PR_PO_STATUS' AS SOURCE,
            NULL AS DOCUMENT_NUMBER,
            NULL AS DOCUMENT_DATE,
            NULL AS DOC_HEADER,
            NULL AS DOC_LINE_ITEM,
            NULL AS REFERENCE_DOC_TYPE,
            NULL AS CO_LINE_TEXT,
            NULL AS REFERENCE,
            NULL AS REFERENCE_DOC_NO,
            NULL AS PURCHASING_DOC_NO,
            NULL AS CO_DOCUMENT_NUMBER,
            NULL AS DOC_ITEM,
            NULL AS PURCHASING_DOCUMENT_NUMBER,
            NULL AS DOC_TYPE_DESCR,
            DOC_TYPE
        FROM PR_PO_STATUS
    ),

    -- doc_type_data query to get DOC_TYPE
    doc_type_data AS (
        SELECT 
            PR_PO_STATUS.DOC_TYPE,
            PO.PURCHASING_DOCUMENT AS PURCHASING_DOC_NO
        FROM 
            PR_PO_STATUS
        JOIN 
            PO_DATA_BY_SUPPLIER_EXPORT_SOURCE PO
            ON PO.PURCHASE_REQUISITION = PR_PO_STATUS.PR  
        JOIN 
            combined_documents cd
            ON cd.PURCHASING_DOC_NO = PO.PURCHASING_DOCUMENT  
        LEFT JOIN 
            COST_CENTER_TRANSACTION_DATA_SOURCE cctd
            ON cctd.PURCHASING_DOCUMENT = cd.PURCHASING_DOC_NO
        LEFT JOIN 
            INTERNAL_ORDER_TRANSACTION_DATA iotd
            ON iotd.PURCHASING_DOCUMENT = cd.PURCHASING_DOC_NO
        LEFT JOIN 
            WBSE_TRANSACTION_DATA wtd
            ON wtd.PURCHASING_DOCUMENT = cd.PURCHASING_DOC_NO
        WHERE 
            cctd.PURCHASING_DOCUMENT IS NULL
            AND iotd.PURCHASING_DOCUMENT IS NULL
            AND wtd.PURCHASING_DOCUMENT IS NULL

        UNION ALL

        SELECT 
            PR_PO_PROFILE.DOC_TYPE,
            PO.PURCHASING_DOCUMENT AS PURCHASING_DOC_NO
        FROM 
            PR_PO_PROFILE
        JOIN 
            PO_DATA_BY_SUPPLIER_EXPORT_SOURCE PO
            ON PO.PURCHASE_REQUISITION = PR_PO_PROFILE.PR  
        JOIN 
            combined_documents cd
            ON cd.PURCHASING_DOC_NO = PO.PURCHASING_DOCUMENT  
        LEFT JOIN 
            COST_CENTER_TRANSACTION_DATA_SOURCE cctd
            ON cctd.PURCHASING_DOCUMENT = cd.PURCHASING_DOC_NO
        LEFT JOIN 
            INTERNAL_ORDER_TRANSACTION_DATA iotd
            ON iotd.PURCHASING_DOCUMENT = cd.PURCHASING_DOC_NO
        LEFT JOIN 
            WBSE_TRANSACTION_DATA wtd
            ON wtd.PURCHASING_DOCUMENT = cd.PURCHASING_DOC_NO
        WHERE 
            cctd.PURCHASING_DOCUMENT IS NULL
            AND iotd.PURCHASING_DOCUMENT IS NULL
            AND wtd.PURCHASING_DOCUMENT IS NULL
    )

    

    -- Query to get DOC_TYPE
    SELECT 
        'SAP-PR, SAP-PO, SAP-MM, SAP-FI' AS DOCUMENT_NAME,       
        CASE
            WHEN cd.SOURCE IN ('COST', 'IO_COMMIT', 'WBSE_COMMIT') and cd.PURCHASING_DOCUMENT_NUMBER IS NOT NULL THEN 'PR-PO DOCUMENT'  -- When the source is Commitments
            WHEN cd.SOURCE IN ('COST_CENTER_TRANS', 'IO_TRANS', 'WBSE_TRANS') AND cd.CO_DOCUMENT_NUMBER IS NOT NULL THEN 'CO DOCUMENT' -- When the source is Transaction Data
            WHEN cd.SOURCE IN ('PO_DATA') AND cd.PURCHASING_DOCUMENT_NUMBER IS NULL AND cd.CO_DOCUMENT_NUMBER IS NULL THEN 'PR DOCUMENT'  -- When the source is PO Data By Supplier
            ELSE 'Unknown'  -- Default case in case of unexpected sources
        END AS DOCUMENT_CATEGORY,
        cd.DOCUMENT_DATE,
        --doc_type_data.DOC_TYPE AS DOCUMENT_TYPE,
        NULL AS DOCUMENT_TYPE,
        cd.DOC_TYPE_DESCR,
        cd.PURCHASING_DOC_NO,
        cd.DOCUMENT_NUMBER,
        cd.DOC_HEADER,
        cd.DOC_LINE_ITEM,
        cd.DOC_ITEM,
        cd.REFERENCE_DOC_TYPE AS REFERENCE_DOCUMENT_TYPE,
        cd.CO_LINE_TEXT,
        cd.REFERENCE,
        cd.REFERENCE_DOC_NO,
        'CORPORATE' AS DOMAIN_TYPE,
        'SAP' AS PARTITION_KEY,
        current_timestamp() AS LAST_UPDATED_DATE,
        current_timestamp() AS CREATION_DATE
    FROM 
        combined_documents cd
    LEFT JOIN 
        doc_type_data
    ON
        cd.PURCHASING_DOC_NO = doc_type_data.PURCHASING_DOC_NO -- Join on DOC_TYPE to repeat rows based on doc_type

    UNION ALL
    SELECT
        NULL AS DOCUMENT_NAME,
        NULL AS DOCUMENT_CATEGORY,
        NULL AS DOCUMENT_DATE,
        pr_po_data.DOC_TYPE AS DOCUMENT_TYPE,
        NULL AS DOC_TYPE_DESCR,
        NULL AS PURCHASING_DOC_NO,
        NULL AS DOCUMENT_NUMBER,
        NULL AS DOC_HEADER,
        NULL AS DOC_LINE_ITEM,
        NULL AS DOC_ITEM,
        NULL AS REFERENCE_DOCUMENT_TYPE,
        NULL AS CO_LINE_TEXT,
        NULL AS REFERENCE,
        NULL AS REFERENCE_DOC_NO,
        'CORPORATE' AS DOMAIN_TYPE,
        'SAP' AS PARTITION_KEY,
        current_timestamp() AS LAST_UPDATED_DATE,
        current_timestamp() AS CREATION_DATE
    FROM 
        pr_po_data;
    """

    # Execute the query
    df_merge_documents = spark.sql(merged_query)

    # Create a temporary view if needed
    df_merge_documents.createOrReplaceTempView("combined")

    df_merge_documents.printSchema()

    # List of columns for generating the key
    columns = [
        'DOCUMENT_NAME',
        'DOCUMENT_CATEGORY',
        'DOCUMENT_DATE',
        'DOCUMENT_TYPE',
        'DOCUMENT_NUMBER',
        'REFERENCE_DOC_NO',
        'DOC_LINE_ITEM',
        'DOC_ITEM',
        'PURCHASING_DOC_NO'
    ]

    # Generate the key
    df_with_dim_document_id = df_merge_documents.withColumn(
        "DIM_DOCUMENT_ID",
        F.sha2(
            F.concat_ws(
                "||",
                *[F.coalesce(F.col(col), F.lit("-")) for col in columns]
            ),
            256
        )
    )

    # Repartition DataFrame for better performance based on partition size
    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_with_dim_document_id, max_partition_size_mb)
    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)
    df_with_dim_document_id = df_with_dim_document_id.repartition(num_partitions)

    return df_with_dim_document_id


def standardize_date_format(df: DataFrame):
    """
        Converts the 'DOCUMENT_DATE' column in the input DataFrame from
        'yyyy-MM-dd HH:mm:ss' format to 'DD-MMM-YY' string format.

        Args:
            df (DataFrame): Input DataFrame with 'DOCUMENT_DATE' as a string column.

        Returns:
            DataFrame: DataFrame with 'DOCUMENT_DATE' standardized to 'DD-MMM-YY'.
    """
    return df.withColumn(
        "DOCUMENT_DATE",
        F.upper(
            F.concat_ws(
                "-",
                F.lpad(
                    F.substring("DOCUMENT_DATE", 9, 2),
                    2,
                    "0"
                ),
                F.upper(
                    F.date_format(
                        F.to_date(F.substring("DOCUMENT_DATE", 1, 10), "yyyy-MM-dd"),
                        "MMM"
                    )
                ),
                F.substring("DOCUMENT_DATE", 3, 2)
            )
        )
    )


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "PO_DATA_BY_SUPPLIER": DataFrame for PO data.
            - "COST_CENTER_COMMITMENT": DataFrame for cost center commitment.
            - "INTERNAL_ORDER_COMMITMENT": DataFrame for internal order commitment.
            - "WBSE_COMMITMENT": DataFrame for WBSE commitment.
            - "CC_TRANSACTION_DATA": DataFrame for CC transaction data.
            - "IO_TRANSACTION_DATA": DataFrame for IO transaction data.
            - "WBS_TRANSACTION_DATA": DataFrame for WBS transaction data.
            - "PR_PO_STATUS": DataFrame for PR PO status.
            - "PR_PO_PROFILE": DataFrame for PR PO profile.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_po_data_by_supplier = source_dfs["PO_DATA_BY_SUPPLIER"]
    df_po_data_by_supplier = df_po_data_by_supplier.withColumn(
        "DOCUMENT_DATE",
        F.upper(
            F.concat(
                F.substring("DOCUMENT_DATE", 1, 7),  # Extract 'DD-MON-'
                F.substring("DOCUMENT_DATE", 10, 2)  # Extract the last two digits of the year
            )
        )
    )

    df_cost_center_commitment = standardize_date_format(source_dfs["COST_CENTER_COMMITMENT"])
    df_wbse_commitment = standardize_date_format(source_dfs["WBSE_COMMITMENT"])
    df_cc_transaction_data = standardize_date_format(source_dfs["CC_TRANSACTION_DATA"])
    df_io_transaction_data = standardize_date_format(source_dfs["IO_TRANSACTION_DATA"])
    df_wbs_transaction_data = standardize_date_format(source_dfs["WBS_TRANSACTION_DATA"])
    df_internal_order_commitment = standardize_date_format(source_dfs["INTERNAL_ORDER_COMMITMENT"])

    df_pr_po_status = source_dfs["PR_PO_STATUS"]
    df_pr_po_profile = source_dfs["PR_PO_PROFILE"]

    # Apply transformations based on business logic
    transform_df = prepare_transformed_df(
        spark=spark,
        df_po_data_by_supplier=df_po_data_by_supplier,
        df_cost_center_commitment=df_cost_center_commitment,
        df_internal_order_commitment=df_internal_order_commitment,
        df_wbse_commitment=df_wbse_commitment,
        df_cc_transaction_data=df_cc_transaction_data,
        df_io_transaction_data=df_io_transaction_data,
        df_wbs_transaction_data=df_wbs_transaction_data,
        df_pr_po_status=df_pr_po_status,
        df_pr_po_profile=df_pr_po_profile
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print("spark_df schema:", spark_df.printSchema())

    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
