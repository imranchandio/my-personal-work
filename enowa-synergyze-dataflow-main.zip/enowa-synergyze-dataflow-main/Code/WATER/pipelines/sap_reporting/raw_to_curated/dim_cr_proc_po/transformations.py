#OCID: ocid1.dataflowapplication.oc1.me-jeddah-1.anvgkljrsvwgetyaxohs7pnuph7szfgvt5xezvpgfranbbtcofgkralcrjtq

import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_pr_po_profile: DataFrame,
        df_po_data_by_supplier_export: DataFrame,
        df_cost_center_commitments: DataFrame,
        df_internal_order_commitments: DataFrame,
        df_wbse_commitments: DataFrame,
        df_dim_cr_proc_pr: DataFrame

) -> DataFrame:
    # Register DataFrames as temporary views
    df_pr_po_profile.createOrReplaceTempView("PR_PO_PROFILE")
    df_po_data_by_supplier_export.createOrReplaceTempView("PO_DATA_BY_SUPPLIER_EXPORT")
    df_cost_center_commitments.createOrReplaceTempView("COST_CENTER_COMMITMENTS")
    df_internal_order_commitments.createOrReplaceTempView("INTERNAL_ORDER_COMMITMENTS")
    df_wbse_commitments.createOrReplaceTempView("WBSE_COMMITMENTS")
    df_dim_cr_proc_pr.createOrReplaceTempView("DIM_CR_PROC_PR")

    logging.info("Executing SQL query for data transformation.")

    # SQL query using the tables that are now temporary views
    sql_query = """
    WITH 
    -- CTE for consolidating PO data with different sources
    POData AS (
        SELECT 
            PO AS PO_NUMBER,
            NULL AS PO_STATUS,
            NULL AS PO_SHELL,
            NULL AS ACTIVE_OR_CLOSED,
            PR AS PURCHASE_REQUISITION,
            proc_pr.DIM_PR_ID,
            'PR_PO_PROFILE' as DATA_SOURCE
        FROM PR_PO_PROFILE po
        LEFT JOIN DIM_CR_PROC_PR proc_pr
            ON coalesce(po.PR, ' ') = coalesce(proc_pr.PURCHASE_REQUISITION, ' ')
            AND coalesce(po.SHORT_TEXT, ' ') = coalesce(proc_pr.PR_SHORT_TEXT, ' ')
            AND coalesce(po.ROUTE, ' ') = coalesce(proc_pr.PROCUREMENT_ROUTE, ' ')
            AND coalesce(po.ROUTE_GROUPS, ' ') = coalesce(proc_pr.PROCUREMENT_ROUTE_GROUP, ' ')
            AND coalesce(po.CREATION_DATE, ' ') = coalesce(proc_pr.PR_CREATION_DATE, ' ')
            AND coalesce(po.STATUS, ' ') = coalesce(proc_pr.PR_STATUS, ' ')
            AND coalesce(po.MATERIAL_SERVICE, ' ') = coalesce(proc_pr.IS_MATERIAL_SERVICE, ' ')
            AND coalesce(po.WITH_WITHOUT_PO, ' ') = coalesce(proc_pr.PO_AVAILABILITY, ' ')
            AND coalesce(po.PURCHASING_GROUP_FULL, ' ') = coalesce(proc_pr.PR_GROUP, ' ')
            AND coalesce(po.APPROVAL_REJECTION_DATE, ' ') = coalesce(proc_pr.PR_LATEST_APPROVAL_DATE, ' ')
            AND coalesce(po.TAXONOMY_1, ' ') = coalesce(proc_pr.TAXONOMY_1, ' ')
            AND coalesce(po.TAXONOMY_2, ' ') = coalesce(proc_pr.TAXONOMY_2, ' ')
            AND coalesce(po.TAXONOMY_3, ' ') = coalesce(proc_pr.TAXONOMY_3, ' ')     
            AND proc_pr.DATA_SOURCE = 'PR_PO_PROFILE'
        UNION ALL
        SELECT 
            NULL AS PO_NUMBER, 
            PO_STATUS, 
            PO_SHELL, 
            ACTIVE_CLOSED AS ACTIVE_OR_CLOSED,
            PURCHASE_REQUISITION,
            NULL as DIM_PR_ID,
            'PO_DATA_BY_SUPPLIER' as DATA_SOURCE
        FROM PO_DATA_BY_SUPPLIER_EXPORT
        UNION ALL
        SELECT 
            NULL AS PO_NUMBER, 
            PO_STATUS, 
            NULL AS PO_SHELL, 
            NULL AS ACTIVE_OR_CLOSED,
            PO_REF_PR AS PURCHASE_REQUISITION,
            NULL as DIM_PR_ID,
            'WBSE_COMMITMENTS' as DATA_SOURCE
        FROM WBSE_COMMITMENTS
        UNION ALL
        SELECT 
            NULL AS PO_NUMBER, 
            PO_STATUS, 
            NULL AS PO_SHELL, 
            NULL AS ACTIVE_OR_CLOSED,
            PO_REF_PR AS PURCHASE_REQUISITION,
            NULL as DIM_PR_ID,
            'INTERNAL_ORDER_COMMITMENTS' as DATA_SOURCE
        FROM INTERNAL_ORDER_COMMITMENTS
        UNION ALL
        SELECT 
            NULL AS PO_NUMBER, 
            PO_STATUS, 
            NULL AS PO_SHELL, 
            NULL AS ACTIVE_OR_CLOSED,
            PO_REF_PR AS PURCHASE_REQUISITION,
            NULL as DIM_PR_ID,
            'COST_CENTER_COMMITMENTS' as DATA_SOURCE
        FROM COST_CENTER_COMMITMENTS
    )
    SELECT 
        pd.DIM_PR_ID,  
        NULL AS PO_KEY_SORTER, 
        NULL AS PO_KEY, 
        pd.PO_NUMBER AS PO_NUMBER,  
        NULL AS PO_KEY_USER,
        NULL AS PO_TITLE, 
        pd.PO_STATUS AS PO_STATUS,
        NULL AS DELIVERY_DATE,
        NULL AS APPROVAL_REJECTION_DATE,
        NULL AS PO_CHECKER,
        NULL AS CLOSED_PO_INDICATOR,
        NULL AS MILESTONE_VALUE_PO_VALUE_CHECKER,
        NULL AS PO_SECTOR_DIVISION,
        NULL AS PO_DOC_TYPE_DESCRIPT,
        NULL AS PO_SHORT_TEXT,
        NULL AS PO_CURRENCY,
        NULL AS PO_PAYMENT_TERMS,
        NULL AS PO_TITLE_1,
        pd.PO_SHELL AS PO_SHELL,  
        NULL AS PLANT,
        NULL AS PURCHASING_GROUP,
        NULL AS PURCH_ORGANIZATION,
        NULL AS PO_ITEM_PROGRESS,
        NULL AS PO_CATEGORY,
        NULL AS PO_START_EFFECTIVE_DATE,
        NULL AS PO_DURATION,
        NULL AS PO_COMPLETION_TERMINATION_DATE,
        NULL AS PO_TYPE,
        NULL AS SOURCING_TYPE,
        NULL AS PO_PRICE_STRUCTURE,
        NULL AS PO_PROGRESS_FROM_Q_2,
        NULL AS PO_KEY_N_TITLE,
        NULL AS PO_NO_N_PO_TITLE,
        NULL AS PO_ITEM_N_SHORT_TEXT,
        NULL AS PO_COMPLETION_TERMINATION_DATE_NULLS,
        NULL AS COUNTING_DUPLICATE_PO_KEY,
        pd.ACTIVE_OR_CLOSED AS ACTIVE_OR_CLOSED,
        'WATER' AS PO_DOMAIN_TYPE, 
        'WATER-SAP PR' AS PO_SUB_DOMAIN_TYPE,
        NULL AS PERCENTAGE_COMPLETION,
        DATA_SOURCE,
        current_timestamp() AS LAST_UPDATED_DATE,
        current_timestamp() AS CREATED_DATE
    FROM POData pd
   """

    # Execute the SQL query
    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation.")

    # Add a new column for the unique DIM_WATERQA_SUPPLIER_ID
    df_transformed = df_transformed.withColumn(
        "DIM_PR_PO_ID",
        sha2(
            concat_ws("||",
                      "DIM_PR_ID",
                      "PO_NUMBER",
                      "PO_STATUS",
                      "PO_SHELL",
                      "ACTIVE_OR_CLOSED",
                      "DATA_SOURCE"
                      ),
            256
        )
    )

    logging.info("Calculating the number of partitions.")

    # Repartition DataFrame based on size
    max_partition_size_mb = 1024
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)
    logging.info(f"Repartitioning the DataFrame into {num_partitions} partitions.")
    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.
    """
    # Extract the required DataFrames from the source dictionary

    df_pr_po_profile = source_dfs["PR_PO_PROFILE"]
    df_po_data_by_supplier_export = source_dfs["PO_DATA_BY_SUPPLIER_EXPORT"]
    df_cost_center_commitments = source_dfs["COST_CENTER_COMMITMENTS"]
    df_internal_order_commitments = source_dfs["INTERNAL_ORDER_COMMITMENTS"]
    df_wbse_commitments = source_dfs["WBSE_COMMITMENTS"]
    df_dim_cr_proc_pr = source_dfs["DIM_CR_PROC_PR"]

    # Perform the transformation
    transform_df = prepare_transformed_df(
        spark=spark,

        df_pr_po_profile=df_pr_po_profile,
        df_po_data_by_supplier_export=df_po_data_by_supplier_export,
        df_cost_center_commitments=df_cost_center_commitments,
        df_internal_order_commitments=df_internal_order_commitments,
        df_wbse_commitments=df_wbse_commitments,
        df_dim_cr_proc_pr=df_dim_cr_proc_pr

    )

    # Ensure distinct rows
    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
) -> DataFrame:
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.
    """
    # Read the source DataFrames from the pipeline storage
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    # Perform the transformation
    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    # Extract the target schema from the pipeline storage
    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    # Impose the target schema on the transformed DataFrame
    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.
    """
    if spark_df:
        print(spark_df.printSchema())

    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "50MB")

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    # Execute the transformation if the task name matches
    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
