# pylint: disable = import-error
"""
    This is the transformation file for dim_cr_proc_material_group dimension
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_cost_center_commitments: DataFrame,
        df_wbse_commitments: DataFrame,
        df_internal_order_commitments: DataFrame,
        df_po_data_supplier_export: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from the raw layer table passed in as DataFrame.
    '''
    logging.info("Starting the transformation process.")

    df_cost_center_commitments.createOrReplaceTempView("COST_CENTER_COMMITMENTS")
    df_wbse_commitments.createOrReplaceTempView("WBSE_COMMITMENTS")
    df_internal_order_commitments.createOrReplaceTempView("INTERNAL_ORDER_COMMITMENTS")
    df_po_data_supplier_export.createOrReplaceTempView("PO_DATA_SUPPLIER_EXPORT")

    logging.info("Executing SQL query for data transformation.")

    sql_query = """
                select distinct 
                MATERIAL_GROUP,
                current_timestamp() AS LAST_UPDATED_DATE,  
                current_timestamp() AS CREATED_DATE 
                from COST_CENTER_COMMITMENTS
                union
                select distinct 
                MATERIAL_GROUP,
                current_timestamp() AS LAST_UPDATED_DATE,  
                current_timestamp() AS CREATED_DATE
                from WBSE_COMMITMENTS
                union
                select distinct 
                MATERIAL_GROUP,
                current_timestamp() AS LAST_UPDATED_DATE,  
                current_timestamp() AS CREATED_DATE
                from INTERNAL_ORDER_COMMITMENTS
                union
                select distinct 
                MATERIAL_GROUP,
                current_timestamp() AS LAST_UPDATED_DATE,  
                current_timestamp() AS CREATED_DATE
                from PO_DATA_SUPPLIER_EXPORT
            """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation.")

    df_transformed = df_transformed.withColumn(
        "DIM_MATERIAL_GROUP_ID", sha2(concat_ws( "MATERIAL_GROUP" ), 256)
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "WBSE_COMMITMENTS": DataFrame for WBSE_COMMITMENTS.
            - "COST_CENTER_COMMITMENTS": DataFrame for COST_CENTER_COMMITMENTS.
            - "INTERNAL_ORDER_COMMITMENTS": DataFrame for INTERNAL_ORDER_COMMITMENTS.
            - "PO_DATA_BY_SUPPLIER_EXPORT": DataFrame for PO_DATA_BY_SUPPLIER_EXPORT.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_cost_center_commitments = source_dfs["COST_CENTER_COMMITMENTS"]
    df_wbse_commitments = source_dfs["WBSE_COMMITMENTS"]
    df_internal_order_commitments = source_dfs["INTERNAL_ORDER_COMMITMENTS"]
    df_po_data_supplier_export = source_dfs["PO_DATA_BY_SUPPLIER_EXPORT"]

    # Perform joins, filters, etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_cost_center_commitments=df_cost_center_commitments,
        df_wbse_commitments=df_wbse_commitments,
        df_internal_order_commitments=df_internal_order_commitments,
        df_po_data_supplier_export=df_po_data_supplier_export
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
) -> DataFrame:
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
