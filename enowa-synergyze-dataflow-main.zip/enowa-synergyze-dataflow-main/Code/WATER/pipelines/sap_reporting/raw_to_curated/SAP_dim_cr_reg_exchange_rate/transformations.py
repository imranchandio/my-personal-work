from pyspark.sql import DataFrame, SparkSession, Row
from pyspark.sql.functions import (
    udf,
    sha2,
    concat_ws,
    lit,
    col,
    current_timestamp,
    coalesce
)
from pyspark.sql.types import StringType, StructType, StructField, TimestampType
import logging
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")
from common_utils import calculate_num_partitions, impose_schema, uuid5_hash, trim_spaces
from read_utils import read


def prepare_transformed_df(
        spark: SparkSession,
        dfs: dict
) -> DataFrame:
    logging.info("Starting the transformation process.")
    for key, df in dfs.items():
        df.createOrReplaceTempView(key)
        logging.info(f"Created temporary view: {key}")
    logging.info("All temporary views are created for SQL operations.")

    sql_query_all_suppliers = """
                        SELECT
                            dqer.Currency AS CURRENCY_FROM,
                            'SAR' AS CURRENCY_TO,
                            dqer.ExchangeRate_Latest AS EXCHANGE_RATE_LATEST,
                            dqer.ExchangeRate_UnknownDate AS EXCHANGE_RATE_UNKNOWN_DATE,
                            CURRENT_DATE() AS LAST_UPDATED_DATE,
                            CURRENT_DATE() AS CREATED_DATE
                        FROM data_q_exchange_rates dqer;
    """

    df_transformed = spark.sql(sql_query_all_suppliers)

    logging.info("Executed SQL query for data transformation.")

    df_transformed = df_transformed.withColumn(
        "DIM_EXCHANGE_RATE_ID",
        sha2(
            concat_ws(
                "||",
                "CURRENCY_FROM",
                "CURRENCY_TO"
            ),
            256,
        ),
    )
    df_transformed = df_transformed.distinct()

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info(f"Repartitioning the DataFrame into {num_partitions} partitions.")

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters, returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_data_q_exchange_rates = source_dfs["PROCUREMENT_TRACKER_POWER_QUERY_DATA_Q_EXCHANGE_RATES"]

    source_dfs_dict = {
        'data_q_exchange_rates': df_data_q_exchange_rates}

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        dfs=source_dfs_dict
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
