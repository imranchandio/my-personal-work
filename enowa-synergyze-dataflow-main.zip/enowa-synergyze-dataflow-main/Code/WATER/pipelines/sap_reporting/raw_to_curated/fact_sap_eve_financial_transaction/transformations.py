from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
import logging
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read


def prepare_cost_center_df(
        spark: SparkSession,
        **kwargs
) -> DataFrame:
    """
    Returns an SQL query based on the specified source type.

    Args:
        spark: SparkSession
        kwargs: The source type determining the query structure.
    """
    logging.info("Starting the transformation process in prepare_cost_center_df.")

    kwargs.get('df_cost_center_transaction_data').createOrReplaceTempView("cost_center_transaction_data_source")
    kwargs.get('df_dim_cr_fin_account').createOrReplaceTempView("dim_cr_fin_account")
    kwargs.get('df_dim_cr_work_assignment').createOrReplaceTempView("dim_cr_work_assignment")
    kwargs.get('df_dim_cr_corp_company_unit').createOrReplaceTempView("dim_cr_corp_company_unit")
    kwargs.get('df_dim_cr_reg_exchange_rate').createOrReplaceTempView("dim_cr_reg_exchange_rate_sap")
    kwargs.get('df_dim_cr_fin_cost_center').createOrReplaceTempView("dim_cr_fin_cost_center")
    kwargs.get('df_dim_cr_fin_cost_element').createOrReplaceTempView("dim_cr_fin_cost_element")
    kwargs.get('df_dim_cr_corp_document').createOrReplaceTempView("dim_cr_corp_document")
    kwargs.get('df_dim_cr_fin_fund_center').createOrReplaceTempView("dim_cr_fin_fund_center")
    kwargs.get('df_dim_cr_fin_fund_group').createOrReplaceTempView("dim_cr_fin_fund_group_sap")
    kwargs.get('df_dim_wa_org_waterqa_supplier').createOrReplaceTempView("dim_wa_org_waterqa_supplier_sap")
    kwargs.get('df_dim_cr_cus_customer_kind').createOrReplaceTempView("dim_cr_cus_customer_kind_sap")
    kwargs.get('df_dim_cr_proc_pr').createOrReplaceTempView("dim_cr_proc_pr")
    kwargs.get('df_dim_cr_fin_functional_area').createOrReplaceTempView("dim_cr_fin_functional_area")

    logging.info("Executing SQL query for data transformation in prepare_cost_center_df.")

    sql_query = """
                SELECT
                    B.DIM_ACCOUNT_ID,
                    C.DIM_ASSIGNMENT_ID,
                    D.DIM_COMPANY_UNIT_ID,
                    H.DIM_COST_CENTER_ID,
                    I.DIM_COST_ELEMENT_ID,
                    J.DIM_DOCUMENT_ID,
                    G.DIM_EXCHANGE_RATE_ID,
                    K.DIM_FUND_CENTER_ID,
                    L.DIM_FUND_GROUP_ID,
                    R.DIM_FUNCTIONAL_AREA_ID,
                    P.DIM_PR_ID,
                    M.DIM_WATERQA_SUPPLIER_ID,
                    N.CUSTOMER_KIND_ID,
                    A.CO_TRANSACTION as TRANSACTION_CO_TRANSACTION,
                    A.FISCAL_YEAR as TRANSACTION_FISCAL_YEAR,
                    A.OBJECT_KEY as TRANSACTION_OBJECT_KEY,
                    A.PERIOD as TRANSACTION_PERIOD,
                    A.POSTING_DATE as TRANSACTION_POSTING_DATE,
                    A.VALUE_CONTROLLING_AREA as TRANSACTION_VALUE_CONTROLLING_AREA,
                    'Cost Center Transaction Data' as TRANSACTION_VALUE_SOURCE_TYPE,
                    A.VALUE_TYPE as TRANSACTION_VALUE_TYPE,
                    A.VERSION as TRANSACTION_VERSION,
                    A.LAST_REFRESH_DATE as TRANSACTION_LAST_REFRESH_DATE,
                    NULL as TRANSACTION_REFERENCE_PROCEDURE,
                    NULL as DIM_CONTROLLING_UNIT_ID,
                    NULL as DIM_EXPENSE_CATEGORY_ID,
                    NULL as DIM_WORK_ORDER_ID,
                    NULL as TRANSACTION_VALUE_RESPONSIBLE,
                    NULL as TRANSACTION_AWKEY,
                    NULL as TRANSACTION_GL_EXCLUSION,
                    NULL as TRANSACTION_VALUE_TRANSACTION_CURRENCY
                FROM cost_center_transaction_data_source A
                LEFT JOIN dim_cr_fin_account B
                    ON coalesce(A.OFFSETTING_ACCOUNT, '-') = coalesce(B.ACCOUNT_NUMBER, '-')
                    and coalesce(A.OFFSETTING_ACCOUNT_DESC, '-') = coalesce(B.ACCOUNT_SHORT_DESC, '-')
                    AND B.ACCOUNT_NAME is null
                    AND B.ACCOUNT_TYPE = 'Offsetting Account'
                LEFT JOIN dim_cr_work_assignment C
                    on coalesce(A.ASSIGNMENT, '-') = coalesce(C.ASSIGNMENT_NO_NAMES, '-')                
                LEFT JOIN dim_cr_corp_company_unit D
                    on coalesce(A.COMPANY_CODE, '-') = coalesce(D.COMPANY_CODE, '-')
                    and coalesce(A.COMPANY_CODE_DESC, '-') = coalesce(D.COMPANY_CODE_DESC, '-')
                LEFT JOIN dim_cr_reg_exchange_rate_sap G
                    on coalesce(A.COMPANY_CODE_CURRENCY, '-') = coalesce(G.CURRENCY_TO, '-')
                    and coalesce(A.COMPANY_CODE_CURRENCY, '-') = coalesce(G.CURRENCY_FROM, '-')
                LEFT JOIN dim_cr_fin_cost_center H
                    on coalesce(A.COST_CENTER, '-') = coalesce(H.COST_CENTER, '-')
                LEFT JOIN dim_cr_fin_cost_element I
                    on coalesce(A.COST_ELEMENT, '-') = coalesce(I.COST_ELEMENT_NUMBER, '-')
                    and coalesce(A.COST_ELEMENT_DESC, '-') = coalesce(I.COST_ELEMENT_SHORT_TEXT, '-')
                LEFT JOIN dim_cr_corp_document J
                    ON coalesce(A.CO_DOCUMENT_NUMBER, '-') = coalesce(J.DOCUMENT_NUMBER, '-')
                    AND coalesce(A.DOCUMENT_DATE, '-') = coalesce(J.DOCUMENT_DATE, '-')
                    AND coalesce(A.CO_DOC_LINE_ITEM, '-') = coalesce(J.DOC_LINE_ITEM, '-')
                    AND coalesce(A.REFERENCE_DOC, '-') = coalesce(J.REFERENCE_DOC_NO, '-')
                    AND coalesce(A.PURCHASING_DOCUMENT, '-') = coalesce(J.PURCHASING_DOC_NO, '-')
                    AND coalesce(A.PURCHASING_DOC_ITEM, '-') = coalesce(J.DOC_ITEM, '-')
                LEFT JOIN dim_cr_fin_fund_center K
                    on coalesce(A.FUND, '-') = coalesce(K.FUND_CENTER_NAME, '-')
                    and coalesce(A.FUNDS_CENTER, '-') = coalesce(K.FUND_CENTER_CODE, '-')
                    and coalesce(A.FUNDS_CENTER_DESC, '-') = coalesce(K.FUND_CENTER_DESCRIPTION, '-')
                LEFT JOIN dim_cr_fin_fund_group_sap L
                    on coalesce(A.REGION, '-') = coalesce(L.FUND_GROUP_NAME, '-')
                    and L.REQUESTING_FUND_GROUP IS NULL
                    and L.RESPONSIBLE_FUND_GROUP IS NULL
                    and L.HIERARCHY_GROUP IS NULL
                    and L.SEMI_GROUP_CODE IS NULL
                LEFT JOIN dim_wa_org_waterqa_supplier_sap M
                    on coalesce(A.VENDOR, '-') = coalesce(M.SUPPLIER_CODE, '-')
                    and coalesce(A.VENDOR_NAME, '-') = coalesce(M.SUPPLIER_NAME, '-')
                    and M.GCFA_SUPPLIER_CODE IS NULL
                    and M.SUPPLIER_TYPE = 'SAP FI'
                LEFT JOIN dim_cr_cus_customer_kind_sap N
                    on coalesce(A.SECTOR, '-') = coalesce(N.CUSTOMER_KIND_SECTOR, '-')
                    and N.REQUESTING_SECTOR IS NULL
                    and N.RESPONSIBLE_SECTOR IS NULL
                    and N.CUSTOMER_KIND_SECTOR_CODE IS NULL
                LEFT JOIN dim_cr_proc_pr P
                    on coalesce(A.OBJECT_KEY, '-') = coalesce(P.PR_OBJECT_NUMBER, '-')
                    AND P.DATA_SOURCE = 'COST_CENTER_TRANSACTION_DATA'
                LEFT JOIN dim_cr_fin_functional_area R
                    on coalesce(A.FUND_AREA, '-') = coalesce(R.FUNCTIONAL_AREA, '-');
                """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation in prepare_cost_center_df")

    return df_transformed


def prepare_wbse_df(
        spark: SparkSession,
        **kwargs) -> DataFrame:
    """
    Returns an SQL query based on the specified source type.

    Args:
        source (str): The source type determining the query structure.
    """
    logging.info("Starting the transformation process in prepare_wbse_df.")

    kwargs.get('df_wbse_transaction_data').createOrReplaceTempView('wbse_transaction_data_source')
    kwargs.get('df_dim_cr_fin_account').createOrReplaceTempView("dim_cr_fin_account")
    kwargs.get('df_dim_cr_work_assignment').createOrReplaceTempView("dim_cr_work_assignment")
    kwargs.get('df_dim_cr_corp_company_unit').createOrReplaceTempView("dim_cr_corp_company_unit")
    kwargs.get('df_dim_cr_fin_controlling_unit').createOrReplaceTempView("dim_cr_fin_controlling_unit")
    kwargs.get('df_dim_cr_reg_exchange_rate').createOrReplaceTempView("dim_cr_reg_exchange_rate_sap")
    kwargs.get('df_dim_cr_fin_cost_element').createOrReplaceTempView("dim_cr_fin_cost_element")
    kwargs.get('df_dim_cr_corp_document').createOrReplaceTempView("dim_cr_corp_document")
    kwargs.get('df_dim_cr_fin_fund_center').createOrReplaceTempView("dim_cr_fin_fund_center")
    kwargs.get('df_dim_cr_fin_fund_group').createOrReplaceTempView("dim_cr_fin_fund_group_sap")
    kwargs.get('df_dim_wa_org_waterqa_supplier').createOrReplaceTempView("dim_wa_org_waterqa_supplier_sap")
    kwargs.get('df_dim_cr_work_work_order').createOrReplaceTempView("dim_cr_work_work_order")
    kwargs.get('df_dim_cr_cus_customer_kind').createOrReplaceTempView("dim_cr_cus_customer_kind_sap")
    kwargs.get('df_dim_cr_proc_pr').createOrReplaceTempView("dim_cr_proc_pr")
    kwargs.get('df_dim_cr_fin_functional_area').createOrReplaceTempView("dim_cr_fin_functional_area")

    logging.info("Executing SQL query for data transformation in prepare_wbse_df.")

    sql_query = """
                SELECT
                    B.DIM_ACCOUNT_ID,
                    C.DIM_ASSIGNMENT_ID,
                    D.DIM_COMPANY_UNIT_ID,
                    E.DIM_CONTROLLING_UNIT_ID,
                    I.DIM_COST_ELEMENT_ID,
                    J.DIM_DOCUMENT_ID,
                    G.DIM_EXCHANGE_RATE_ID,
                    K.DIM_FUND_CENTER_ID,
                    L.DIM_FUND_GROUP_ID,
                    T.DIM_FUNCTIONAL_AREA_ID,
                    R.DIM_PR_ID,
                    M.DIM_WATERQA_SUPPLIER_ID,
                    N.DIM_WORK_ORDER_ID,
                    P.CUSTOMER_KIND_ID,
                    A.AWKEY as TRANSACTION_AWKEY,
                    A.CO_TRANSACTION as TRANSACTION_CO_TRANSACTION,
                    A.FISCAL_YEAR as TRANSACTION_FISCAL_YEAR,
                    A.GL_EXCLUSION as TRANSACTION_GL_EXCLUSION,
                    A.PERIOD as TRANSACTION_PERIOD,
                    A.POSTING_DATE as TRANSACTION_POSTING_DATE,
                    A.REFERENCE_PROCEDURE as TRANSACTION_REFERENCE_PROCEDURE,
                    A.VALUE_CONTROLLING_AREA as TRANSACTION_VALUE_CONTROLLING_AREA,
                    A.VALUE_TRANSACTION_CURRENCY as TRANSACTION_VALUE_TRANSACTION_CURRENCY,
                    'WBSE Transaction Data' as TRANSACTION_VALUE_SOURCE_TYPE,
                    A.VALUE_TYPE as TRANSACTION_VALUE_TYPE,
                    A.VERSION as TRANSACTION_VERSION,
                    NULL as DIM_EXPENSE_CATEGORY_ID,
                    NULL as DIM_COST_CENTER_ID,
                    NULL as TRANSACTION_OBJECT_KEY,
                    NULL as TRANSACTION_VALUE_RESPONSIBLE,
                    NULL as TRANSACTION_LAST_REFRESH_DATE
                FROM wbse_transaction_data_source A
                LEFT JOIN dim_cr_fin_account B
                    ON coalesce(A.OFFSETTING_ACCOUNT, '-') = coalesce(B.ACCOUNT_NUMBER, '-')
                    AND coalesce(A.OFFSETTING_ACCOUNT_DESC, '-') = coalesce(B.ACCOUNT_SHORT_DESC, '-')
                    AND B.ACCOUNT_NAME is null
                    AND B.ACCOUNT_TYPE = 'Offsetting Account'
                LEFT JOIN dim_cr_work_assignment C
                    on coalesce(A.ASSIGNMENT, '-') = coalesce(C.ASSIGNMENT_NO_NAMES, '-')
                LEFT JOIN dim_cr_corp_company_unit D
                    on coalesce(A.COMPANY_CODE, '-') = coalesce(D.COMPANY_CODE, '-')
                    and coalesce(A.COMPANY_CODE_DESC, '-') = coalesce(D.COMPANY_CODE_DESC, '-')
                LEFT JOIN dim_cr_fin_controlling_unit E
                    on coalesce(A.CONTROLLING_AREA, '-') = coalesce(E.CONTROLLING_UNITS, '-')
                LEFT JOIN dim_cr_reg_exchange_rate_sap G
                    ON coalesce(A.COMPANY_CURRENCY, '-') = coalesce(G.CURRENCY_TO, '-')
                    AND coalesce(A.COMPANY_CURRENCY, '-') = coalesce(G.CURRENCY_FROM, '-')
                LEFT JOIN dim_cr_fin_cost_element I
                    on coalesce(A.COST_ELEMENT, '-') = coalesce(I.COST_ELEMENT_NUMBER, '-')
                    and coalesce(A.COST_ELEMENT_DESC, '-') = coalesce(I.COST_ELEMENT_SHORT_TEXT, '-')
                LEFT JOIN dim_cr_corp_document J
                    ON coalesce(A.CO_DOCUMENT_NUMBER, '-') = coalesce(J.DOCUMENT_NUMBER, '-')
                    AND coalesce(A.DOCUMENT_DATE, '-') = coalesce(J.DOCUMENT_DATE, '-')
                    AND coalesce(A.CO_DOC_LINE_ITEM, '-') = coalesce(J.DOC_LINE_ITEM, '-')
                    AND coalesce(A.REFERENCE_DOC, '-') = coalesce(J.REFERENCE_DOC_NO, '-')
                    AND coalesce(A.PURCHASING_DOCUMENT, '-') = coalesce(J.PURCHASING_DOC_NO, '-')
                    AND coalesce(A.PURCHASING_DOC_ITEM, '-') = coalesce(J.DOC_ITEM, '-')
                LEFT JOIN dim_cr_fin_fund_center K
                    on coalesce(A.FUND, '-') = coalesce(K.FUND_CENTER_NAME, '-')
                    and coalesce(A.FUNDS_CENTER, '-') = coalesce(K.FUND_CENTER_CODE, '-')
                    and coalesce(A.FUNDS_CENTER_DESC, '-') = coalesce(K.FUND_CENTER_DESCRIPTION, '-')
                LEFT JOIN dim_cr_fin_fund_group_sap L
                    ON coalesce(A.REQUESTING_REGION, '-') = coalesce(L.REQUESTING_FUND_GROUP, '-')
                    AND coalesce(A.RESPONSIBLE_REGION, '-') = coalesce(L.RESPONSIBLE_FUND_GROUP, '-')
                LEFT JOIN dim_wa_org_waterqa_supplier_sap M
                    on coalesce(A.VENDOR, '-') = coalesce(M.SUPPLIER_CODE, '-')
                    and coalesce(A.VENDOR_NAME, '-') = coalesce(M.SUPPLIER_NAME, '-')
                    and M.GCFA_SUPPLIER_CODE IS NULL
                    and M.SUPPLIER_TYPE = 'SAP FI'
                LEFT JOIN dim_cr_work_work_order N
                    ON coalesce(A.WBS_ELEMENT_KEY, '-') = coalesce(N.IO_WBS, '-')
                    AND coalesce(A.WBS_ELEMENT_DESC, '-') = coalesce(N.IO_WBS_DESCRIPTION, '-')
                    AND coalesce(A.WBS_ELEMENT_KEY, '-') = coalesce(N.ORDER_ELEMENT_KEY, '-')
                LEFT JOIN dim_cr_cus_customer_kind_sap P
                    ON coalesce(A.REQUESTING_SECTOR, '-') = coalesce(P.REQUESTING_SECTOR, '-')
                    AND coalesce(A.RESPONSIBLE_SECTOR, '-') = coalesce(P.RESPONSIBLE_SECTOR, '-')
                LEFT JOIN dim_cr_proc_pr R
                    ON coalesce(A.OBJECT_NUMBER, '-') = coalesce(R.PR_OBJECT_NUMBER, '-')
                    AND coalesce(A.OBJECT_TYPE, '-') = coalesce(R.PR_TYPE, '-')
                    and R.DATA_SOURCE = 'WBSE_TRANSACTION_DATA'
                LEFT JOIN dim_cr_fin_functional_area T
                    ON coalesce(A.FUND_AREA, '-') = coalesce(T.FUNCTIONAL_AREA, '-')
                """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation in prepare_wbse_df")

    return df_transformed


def prepare_io_df(
        spark: SparkSession,
        **kwargs) -> DataFrame:
    """
    Returns an SQL query based on the specified source type.

    Args:
        source (str): The source type determining the query structure.
    """
    logging.info("Starting the transformation process in prepare_io_df.")

    kwargs.get('df_internal_order_transaction_data').createOrReplaceTempView("internal_order_transaction_data_source")
    kwargs.get('df_dim_cr_fin_account').createOrReplaceTempView("dim_cr_fin_account")
    kwargs.get('df_dim_cr_work_assignment').createOrReplaceTempView("dim_cr_work_assignment")
    kwargs.get('df_dim_cr_corp_company_unit').createOrReplaceTempView("dim_cr_corp_company_unit")
    kwargs.get('df_dim_cr_fin_expense_category').createOrReplaceTempView("dim_cr_fin_expense_category_sap")
    kwargs.get('df_dim_cr_reg_exchange_rate').createOrReplaceTempView("dim_cr_reg_exchange_rate_sap")
    kwargs.get('df_dim_cr_fin_cost_center').createOrReplaceTempView("dim_cr_fin_cost_center")
    kwargs.get('df_dim_cr_fin_cost_element').createOrReplaceTempView("dim_cr_fin_cost_element")
    kwargs.get('df_dim_cr_corp_document').createOrReplaceTempView("dim_cr_corp_document")
    kwargs.get('df_dim_cr_fin_fund_center').createOrReplaceTempView("dim_cr_fin_fund_center")
    kwargs.get('df_dim_cr_fin_fund_group').createOrReplaceTempView("dim_cr_fin_fund_group_sap")
    kwargs.get('df_dim_wa_org_waterqa_supplier').createOrReplaceTempView("dim_wa_org_waterqa_supplier_sap")
    kwargs.get('df_dim_cr_work_work_order').createOrReplaceTempView("dim_cr_work_work_order")
    kwargs.get('df_dim_cr_cus_customer_kind').createOrReplaceTempView("dim_cr_cus_customer_kind_sap")
    kwargs.get('df_dim_cr_proc_pr').createOrReplaceTempView("dim_cr_proc_pr")
    kwargs.get('df_dim_cr_fin_functional_area').createOrReplaceTempView("dim_cr_fin_functional_area")

    logging.info("Executing SQL query for data transformation in prepare_io_df.")

    sql_query = """
                SELECT
                    B.DIM_ACCOUNT_ID,
                    C.DIM_ASSIGNMENT_ID,
                    D.DIM_COMPANY_UNIT_ID,
                    F.DIM_EXPENSE_CATEGORY_ID,
                    H.DIM_COST_CENTER_ID,
                    I.DIM_COST_ELEMENT_ID,
                    J.DIM_DOCUMENT_ID,
                    K.DIM_FUND_CENTER_ID,
                    L.DIM_FUND_GROUP_ID,
                    T.DIM_FUNCTIONAL_AREA_ID,
                    G.DIM_EXCHANGE_RATE_ID,
                    R.DIM_PR_ID,
                    M.DIM_WATERQA_SUPPLIER_ID,
                    N.DIM_WORK_ORDER_ID,
                    P.CUSTOMER_KIND_ID,
                    A.CO_TRANSACTION as TRANSACTION_CO_TRANSACTION,
                    A.FISCAL_YEAR as TRANSACTION_FISCAL_YEAR,
                    A.OBJECT_KEY as TRANSACTION_OBJECT_KEY,
                    A.PERIOD as TRANSACTION_PERIOD,
                    A.POSTING_DATE as TRANSACTION_POSTING_DATE,
                    A.REFERENCE_PROCEDURE as TRANSACTION_REFERENCE_PROCEDURE,
                    A.VALUE_CONTROLLING_AREA as TRANSACTION_VALUE_CONTROLLING_AREA,
                    'Internal Order Transaction Data' as TRANSACTION_VALUE_SOURCE_TYPE,
                    A.VALUE_TYPE as TRANSACTION_VALUE_TYPE,
                    A.VALUE_RESPONSIBLE as TRANSACTION_VALUE_RESPONSIBLE,
                    A.LAST_REFRESH_DATE as TRANSACTION_LAST_REFRESH_DATE,
                    NULL as TRANSACTION_AWKEY,
                    NULL as DIM_CONTROLLING_UNIT_ID,
                    NULL as TRANSACTION_GL_EXCLUSION,
                    NULL as TRANSACTION_VALUE_TRANSACTION_CURRENCY,
                    NULL as TRANSACTION_VERSION
                FROM internal_order_transaction_data_source A
                LEFT JOIN dim_cr_fin_account B
                    ON coalesce(A.OFFSETTING_ACCOUNT, '-') = coalesce(B.ACCOUNT_NUMBER, '-')
                    AND coalesce(A.OFFSETTING_ACCOUNT_DESC, '-') = coalesce(B.ACCOUNT_SHORT_DESC, '-')
                    AND B.ACCOUNT_NAME is null
                    AND B.ACCOUNT_TYPE = 'Offsetting Account'
                LEFT JOIN dim_cr_work_assignment C
                    on coalesce(A.ASSIGNMENT, '-') = coalesce(C.ASSIGNMENT_NO_NAMES, '-')
                LEFT JOIN dim_cr_corp_company_unit D
                    on coalesce(A.COMPANY_CODE, '-') = coalesce(D.COMPANY_CODE, '-')
                    and coalesce(A.COMPANY_CODE_DESC, '-') = coalesce(D.COMPANY_CODE_DESC, '-')
                LEFT JOIN dim_cr_fin_expense_category_sap F
                    ON coalesce(A.EXPENSE_CATEGORY_KEY, '-') = coalesce(F.EXPENSE_CATEGORY_KEY, '-')
                    AND coalesce(A.EXPENSE_CATEGORY_DESC, '-') = coalesce(F.EXPENSE_CATEGORY_DESC, '-')
                    and F.SUB_CAT_KEY IS NULL
                    and F.SUB_CAT_DESC IS NULL
                LEFT JOIN dim_cr_reg_exchange_rate_sap G
                    on coalesce(A.COMPANY_CODE_CURRENCY, '-') = coalesce(G.CURRENCY_TO, '-')
                    and coalesce(A.COMPANY_CODE_CURRENCY, '-') = coalesce(G.CURRENCY_FROM, '-')
                LEFT JOIN dim_cr_fin_cost_center H
                    ON coalesce(A.REQUESTING_COST_CENTER_KEY, '-') = coalesce(H.REQUEST_CCTR, '-')
                    AND coalesce(A.RESPONSIBLE_COST_CENTER_KEY, '-') = coalesce(H.RESPONSIBLE_CCTR, '-')
                LEFT JOIN dim_cr_fin_cost_element I
                    on coalesce(A.COST_ELEMENT, '-') = coalesce(I.COST_ELEMENT_NUMBER, '-')
                    and coalesce(A.COST_ELEMENT_DESC, '-') = coalesce(I.COST_ELEMENT_SHORT_TEXT, '-')
                LEFT JOIN dim_cr_corp_document J
                    ON coalesce(A.CO_DOCUMENT_NUMBER, '-') = coalesce(J.DOCUMENT_NUMBER, '-')
                    AND coalesce(A.DOCUMENT_DATE, '-') = coalesce(J.DOCUMENT_DATE, '-')
                    AND coalesce(A.CO_DOC_LINE_ITEM, '-') = coalesce(J.DOC_LINE_ITEM, '-')
                    AND coalesce(A.REFERENCE_DOC_NO, '-') = coalesce(J.REFERENCE_DOC_NO, '-')
                    AND coalesce(A.PURCHASING_DOCUMENT, '-') = coalesce(J.PURCHASING_DOC_NO, '-')
                    AND coalesce(A.PURCHASING_DOC_ITEM, '-') = coalesce(J.DOC_ITEM, '-')
                LEFT JOIN dim_cr_fin_fund_center K
                    on coalesce(A.FUND, '-') = coalesce(K.FUND_CENTER_NAME, '-')
                    and coalesce(A.FUNDS_CENTER, '-') = coalesce(K.FUND_CENTER_CODE, '-')
                    and coalesce(A.FUNDS_CENTER_DESC, '-') = coalesce(K.FUND_CENTER_DESCRIPTION, '-')
                LEFT JOIN dim_cr_fin_fund_group_sap L
                    ON coalesce(A.REQUESTING_REGION, '-') = coalesce(L.REQUESTING_FUND_GROUP, '-')
                    AND coalesce(A.RESPONSIBLE_REGION, '-') = coalesce(L.RESPONSIBLE_FUND_GROUP, '-')
                LEFT JOIN dim_wa_org_waterqa_supplier_sap M
                    on coalesce(A.VENDOR, '-') = coalesce(M.SUPPLIER_CODE, '-')
                    and coalesce(A.VENDOR_NAME, '-') = coalesce(M.SUPPLIER_NAME, '-')
                    and M.GCFA_SUPPLIER_CODE IS NULL
                    and M.SUPPLIER_TYPE = 'SAP FI'
                LEFT JOIN dim_cr_work_work_order N
                    ON coalesce(A.ORDER, '-') = coalesce(N.IO_WBS, '-')
                    AND coalesce(A.ORDER_DESC, '-') = coalesce(N.IO_WBS_DESCRIPTION, '-')
                LEFT JOIN dim_cr_cus_customer_kind_sap P
                    ON coalesce(A.REQUESTING_SECTOR, '-') = coalesce(P.REQUESTING_SECTOR, '-')
                    AND coalesce(A.RESPONSIBLE_SECTOR, '-') = coalesce(P.RESPONSIBLE_SECTOR, '-')
                LEFT JOIN dim_cr_proc_pr R
                    ON coalesce(A.OBJECT_KEY, '-') = coalesce(R.PR_OBJECT_NUMBER, '-')
                    AND R.DATA_SOURCE = 'INTERNAL_ORDER_TRANSACTION_DATA'
                LEFT JOIN dim_cr_fin_functional_area T
                    ON coalesce(A.FUND_AREA, '-') = coalesce(T.FUNCTIONAL_AREA, '-')
            """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation in prepare_io_df")

    return df_transformed


def execute_transformed_df(
        spark: SparkSession,
        cost_center_df: DataFrame,
        wbse_df: DataFrame,
        io_df: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from the raw layer table passed in as DataFrame.
    '''
    logging.info("Starting the transformation process.")
    cost_center_df.createOrReplaceTempView("cost_center_data")
    wbse_df.createOrReplaceTempView("wbse_data")
    io_df.createOrReplaceTempView("io_data")

    logging.info("Executing SQL query for data transformation.")

    sql_query = """
                SELECT
                    DIM_ACCOUNT_ID,
                    DIM_ASSIGNMENT_ID,
                    DIM_COMPANY_UNIT_ID,
                    DIM_CONTROLLING_UNIT_ID,
                    DIM_EXPENSE_CATEGORY_ID,
                    DIM_COST_CENTER_ID,
                    DIM_COST_ELEMENT_ID,
                    DIM_DOCUMENT_ID,
                    DIM_EXCHANGE_RATE_ID,
                    DIM_FUND_CENTER_ID,
                    DIM_FUND_GROUP_ID,
                    DIM_FUNCTIONAL_AREA_ID,
                    DIM_PR_ID,
                    DIM_WATERQA_SUPPLIER_ID,
                    DIM_WORK_ORDER_ID,
                    CUSTOMER_KIND_ID,
                    TRANSACTION_AWKEY,
                    TRANSACTION_CO_TRANSACTION,
                    TRANSACTION_FISCAL_YEAR,
                    TRANSACTION_GL_EXCLUSION,
                    TRANSACTION_OBJECT_KEY,
                    TRANSACTION_PERIOD,
                    TRANSACTION_POSTING_DATE,
                    TRANSACTION_REFERENCE_PROCEDURE,
                    TRANSACTION_VALUE_CONTROLLING_AREA,
                    TRANSACTION_VALUE_TRANSACTION_CURRENCY,
                    TRANSACTION_VALUE_SOURCE_TYPE,
                    TRANSACTION_VALUE_TYPE,
                    TRANSACTION_VERSION,
                    TRANSACTION_VALUE_RESPONSIBLE,
                    TRANSACTION_LAST_REFRESH_DATE
                FROM cost_center_data
                UNION
                SELECT
                    DIM_ACCOUNT_ID,
                    DIM_ASSIGNMENT_ID,
                    DIM_COMPANY_UNIT_ID,
                    DIM_CONTROLLING_UNIT_ID,
                    DIM_EXPENSE_CATEGORY_ID,
                    DIM_COST_CENTER_ID,
                    DIM_COST_ELEMENT_ID,
                    DIM_DOCUMENT_ID,
                    DIM_EXCHANGE_RATE_ID,
                    DIM_FUND_CENTER_ID,
                    DIM_FUND_GROUP_ID,
                    DIM_FUNCTIONAL_AREA_ID,
                    DIM_PR_ID,
                    DIM_WATERQA_SUPPLIER_ID,
                    DIM_WORK_ORDER_ID,
                    CUSTOMER_KIND_ID,
                    TRANSACTION_AWKEY,
                    TRANSACTION_CO_TRANSACTION,
                    TRANSACTION_FISCAL_YEAR,
                    TRANSACTION_GL_EXCLUSION,
                    TRANSACTION_OBJECT_KEY,
                    TRANSACTION_PERIOD,
                    TRANSACTION_POSTING_DATE,
                    TRANSACTION_REFERENCE_PROCEDURE,
                    TRANSACTION_VALUE_CONTROLLING_AREA,
                    TRANSACTION_VALUE_TRANSACTION_CURRENCY,
                    TRANSACTION_VALUE_SOURCE_TYPE,
                    TRANSACTION_VALUE_TYPE,
                    TRANSACTION_VERSION,
                    TRANSACTION_VALUE_RESPONSIBLE,
                    TRANSACTION_LAST_REFRESH_DATE
                FROM wbse_data
                UNION
                SELECT
                    DIM_ACCOUNT_ID,
                    DIM_ASSIGNMENT_ID,
                    DIM_COMPANY_UNIT_ID,
                    DIM_CONTROLLING_UNIT_ID,
                    DIM_EXPENSE_CATEGORY_ID,
                    DIM_COST_CENTER_ID,
                    DIM_COST_ELEMENT_ID,
                    DIM_DOCUMENT_ID,
                    DIM_EXCHANGE_RATE_ID,
                    DIM_FUND_CENTER_ID,
                    DIM_FUND_GROUP_ID,
                    DIM_FUNCTIONAL_AREA_ID,
                    DIM_PR_ID,
                    DIM_WATERQA_SUPPLIER_ID,
                    DIM_WORK_ORDER_ID,
                    CUSTOMER_KIND_ID,
                    TRANSACTION_AWKEY,
                    TRANSACTION_CO_TRANSACTION,
                    TRANSACTION_FISCAL_YEAR,
                    TRANSACTION_GL_EXCLUSION,
                    TRANSACTION_OBJECT_KEY,
                    TRANSACTION_PERIOD,
                    TRANSACTION_POSTING_DATE,
                    TRANSACTION_REFERENCE_PROCEDURE,
                    TRANSACTION_VALUE_CONTROLLING_AREA,
                    TRANSACTION_VALUE_TRANSACTION_CURRENCY,
                    TRANSACTION_VALUE_SOURCE_TYPE,
                    TRANSACTION_VALUE_TYPE,
                    TRANSACTION_VERSION,
                    TRANSACTION_VALUE_RESPONSIBLE,
                    TRANSACTION_LAST_REFRESH_DATE
                FROM io_data
                """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation.")

    # List of columns for generating the key
    columns = [
        "DIM_ACCOUNT_ID", "DIM_ASSIGNMENT_ID", "DIM_COMPANY_UNIT_ID", "DIM_CONTROLLING_UNIT_ID",
        "DIM_EXPENSE_CATEGORY_ID", "DIM_COST_CENTER_ID", "DIM_COST_ELEMENT_ID", "DIM_DOCUMENT_ID",
        "DIM_EXCHANGE_RATE_ID", "DIM_FUND_CENTER_ID", "DIM_FUND_GROUP_ID", "DIM_FUNCTIONAL_AREA_ID",
        "DIM_PR_ID", "DIM_WATERQA_SUPPLIER_ID", "DIM_WORK_ORDER_ID", "CUSTOMER_KIND_ID",
        "TRANSACTION_AWKEY", "TRANSACTION_CO_TRANSACTION", "TRANSACTION_FISCAL_YEAR",
        "TRANSACTION_GL_EXCLUSION", "TRANSACTION_OBJECT_KEY", "TRANSACTION_PERIOD",
        "TRANSACTION_POSTING_DATE", "TRANSACTION_REFERENCE_PROCEDURE",
        "TRANSACTION_VALUE_CONTROLLING_AREA", "TRANSACTION_VALUE_TRANSACTION_CURRENCY",
        "TRANSACTION_VALUE_SOURCE_TYPE", "TRANSACTION_VALUE_TYPE",
        "TRANSACTION_VERSION", "TRANSACTION_VALUE_RESPONSIBLE", "TRANSACTION_LAST_REFRESH_DATE"
    ]

    # Generate the key
    df_transformed = df_transformed.withColumn(
        "FACT_FINANCIAL_TRANSACTION_ID",
        F.sha2(
            F.concat_ws(
                "||",
                *[F.coalesce((col), F.lit("-")) for col in columns]
            ),
            256
        )
    )

    # Technical metadata columns
    df_transformed = df_transformed.withColumn(
        "LAST_UPDATED_DATE", F.current_timestamp()
    ).withColumn(
        "CREATED_DATE", F.current_timestamp()
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def standardize_date_format(df: DataFrame):
    """
        Converts the 'DOCUMENT_DATE' column in the input DataFrame from
        'yyyy-MM-dd HH:mm:ss' format to 'DD-MMM-YY' string format.

        Args:
            df (DataFrame): Input DataFrame with 'DOCUMENT_DATE' as a string column.

        Returns:
            DataFrame: DataFrame with 'DOCUMENT_DATE' standardized to 'DD-MMM-YY'.
    """
    return df.withColumn(
        "DOCUMENT_DATE",
        F.upper(
            F.concat_ws(
                "-",
                F.lpad(
                    F.substring("DOCUMENT_DATE", 9, 2),
                    2,
                    "0"
                ),
                F.upper(
                    F.date_format(
                        F.to_date(F.substring("DOCUMENT_DATE", 1, 10), "yyyy-MM-dd"),
                        "MMM"
                    )
                ),
                F.substring("DOCUMENT_DATE", 3, 2)
            )
        )
    )


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters, returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_dim_cr_fin_account = source_dfs["DIM_CR_FIN_ACCOUNT"]
    df_dim_cr_work_assignment = source_dfs["DIM_CR_WORK_ASSIGNMENT"]
    df_dim_cr_corp_company_unit = source_dfs["DIM_CR_CORP_COMPANY_UNIT"]
    df_dim_cr_fin_controlling_unit = source_dfs["DIM_CR_FIN_CONTROLLING_UNIT"]
    df_dim_cr_fin_expense_category = source_dfs["DIM_CR_FIN_EXPENSE_CATEGORY"]
    df_dim_cr_reg_exchange_rate = source_dfs["DIM_CR_REG_EXCHANGE_RATE"]
    df_dim_cr_fin_cost_center = source_dfs["DIM_CR_FIN_COST_CENTER"]
    df_dim_cr_fin_cost_element = source_dfs["DIM_CR_FIN_COST_ELEMENT"]
    df_dim_cr_corp_document = source_dfs["DIM_CR_CORP_DOCUMENT"]
    df_dim_cr_fin_fund_center = source_dfs["DIM_CR_FIN_FUND_CENTER"]
    df_dim_cr_fin_fund_group = source_dfs["DIM_CR_FIN_FUND_GROUP"]
    df_dim_wa_org_waterqa_supplier = source_dfs["DIM_WA_ORG_WATERQA_SUPPLIER"]
    df_dim_cr_proc_pr = source_dfs["DIM_CR_PROC_PR"]
    df_dim_cr_work_work_order = source_dfs["DIM_CR_WORK_WORK_ORDER"]
    df_dim_cr_cus_customer_kind = source_dfs["DIM_CR_CUS_CUSTOMER_KIND"]
    df_dim_cr_fin_functional_area = source_dfs["DIM_CR_FIN_FUNCTIONAL_AREA"]

    df_cost_center_transaction_data = standardize_date_format(source_dfs["COST_CENTER_TRANSACTION_DATA"])
    print("df_cost_center_transaction_data data:", df_cost_center_transaction_data.show(truncate=False))
    df_wbse_transaction_data = standardize_date_format(source_dfs["WBSE_TRANSACTION_DATA"])
    df_internal_order_transaction_data = standardize_date_format(source_dfs["INTERNAL_ORDER_TRANSACTION_DATA"])

    # Perform joins, filters, etc.
    cost_center_df = prepare_cost_center_df(
        spark=spark,
        df_cost_center_transaction_data=df_cost_center_transaction_data,
        df_dim_cr_fin_account=df_dim_cr_fin_account,
        df_dim_cr_work_assignment=df_dim_cr_work_assignment,
        df_dim_cr_corp_company_unit=df_dim_cr_corp_company_unit,
        df_dim_cr_reg_exchange_rate=df_dim_cr_reg_exchange_rate,
        df_dim_cr_fin_cost_center=df_dim_cr_fin_cost_center,
        df_dim_cr_fin_cost_element=df_dim_cr_fin_cost_element,
        df_dim_cr_corp_document=df_dim_cr_corp_document,
        df_dim_cr_fin_fund_center=df_dim_cr_fin_fund_center,
        df_dim_cr_fin_fund_group=df_dim_cr_fin_fund_group,
        df_dim_wa_org_waterqa_supplier=df_dim_wa_org_waterqa_supplier,
        df_dim_cr_cus_customer_kind=df_dim_cr_cus_customer_kind,
        df_dim_cr_proc_pr=df_dim_cr_proc_pr,
        df_dim_cr_fin_functional_area=df_dim_cr_fin_functional_area
    )

    wbse_df = prepare_wbse_df(
        spark=spark,
        df_wbse_transaction_data=df_wbse_transaction_data,
        df_dim_cr_fin_account=df_dim_cr_fin_account,
        df_dim_cr_work_assignment=df_dim_cr_work_assignment,
        df_dim_cr_corp_company_unit=df_dim_cr_corp_company_unit,
        df_dim_cr_fin_controlling_unit=df_dim_cr_fin_controlling_unit,
        df_dim_cr_reg_exchange_rate=df_dim_cr_reg_exchange_rate,
        df_dim_cr_fin_cost_element=df_dim_cr_fin_cost_element,
        df_dim_cr_corp_document=df_dim_cr_corp_document,
        df_dim_cr_fin_fund_center=df_dim_cr_fin_fund_center,
        df_dim_cr_fin_fund_group=df_dim_cr_fin_fund_group,
        df_dim_wa_org_waterqa_supplier=df_dim_wa_org_waterqa_supplier,
        df_dim_cr_work_work_order=df_dim_cr_work_work_order,
        df_dim_cr_cus_customer_kind=df_dim_cr_cus_customer_kind,
        df_dim_cr_proc_pr=df_dim_cr_proc_pr,
        df_dim_cr_fin_functional_area=df_dim_cr_fin_functional_area
    )

    io_df = prepare_io_df(
        spark=spark,
        df_internal_order_transaction_data=df_internal_order_transaction_data,
        df_dim_cr_fin_account=df_dim_cr_fin_account,
        df_dim_cr_work_assignment=df_dim_cr_work_assignment,
        df_dim_cr_corp_company_unit=df_dim_cr_corp_company_unit,
        df_dim_cr_fin_expense_category=df_dim_cr_fin_expense_category,
        df_dim_cr_reg_exchange_rate=df_dim_cr_reg_exchange_rate,
        df_dim_cr_fin_cost_center=df_dim_cr_fin_cost_center,
        df_dim_cr_fin_cost_element=df_dim_cr_fin_cost_element,
        df_dim_cr_corp_document=df_dim_cr_corp_document,
        df_dim_cr_fin_fund_center=df_dim_cr_fin_fund_center,
        df_dim_cr_fin_fund_group=df_dim_cr_fin_fund_group,
        df_dim_wa_org_waterqa_supplier=df_dim_wa_org_waterqa_supplier,
        df_dim_cr_work_work_order=df_dim_cr_work_work_order,
        df_dim_cr_cus_customer_kind=df_dim_cr_cus_customer_kind,
        df_dim_cr_proc_pr=df_dim_cr_proc_pr,
        df_dim_cr_fin_functional_area=df_dim_cr_fin_functional_area
    )

    # Perform joins, filters etc.
    transform_df = execute_transformed_df(
        spark=spark,
        cost_center_df=cost_center_df,
        wbse_df=wbse_df,
        io_df=io_df
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
