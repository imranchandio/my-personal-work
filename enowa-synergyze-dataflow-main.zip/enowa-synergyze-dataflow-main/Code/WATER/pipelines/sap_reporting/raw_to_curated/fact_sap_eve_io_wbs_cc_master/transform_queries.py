WBSE_MASTER_DATA = """
    SELECT 
        fin_acc.DIM_ACCOUNT_ID,
        NULL AS DIM_AGREEMENT_ID,
        NULL AS DIM_CONTRACT_ID,
        cc_unit.DIM_COMPANY_UNIT_ID,
        fin_cu.DIM_CONTROLLING_UNIT_ID,
        fin_cc.DIM_COST_CENTER_ID,
        NULL AS DIM_EXPENSE_CATEGORY_ID,
        fin_fc.DIM_FUND_CENTER_ID,
        fin_fg.DIM_FUND_GROUP_ID,
        fin_fa.DIM_FUNCTIONAL_AREA_ID,
        dept.DIM_ORG_DEPT_ID,
        proc_pr.DIM_PR_ID,
        wp.DIM_PROGRAM_ID,
        project.DIM_PROJECT_ID,
        fpc.DIM_PROFIT_CENTER_ID,
        work_order.DIM_WORK_ORDER_ID,
        ck.CUSTOMER_KIND_ID,
        crk.CUSTOMER_REVENUE_KIND_ID,
        NULL AS SECTOR_CODE,
        src.DELETION_INDICATOR,
        NULL AS IS_FALSE,
        NULL AS IN_LULUH_LIST,
        NULL AS LAST_REFRESH_DATE,
        NULL AS MASTER_IO_WBS_LIST,
        NULL AS MASTER_IO_WBS_LIST_1,
        NULL as NEOM_MAPPING,
        NULL AS OPEX_CAPEX,
        NULL AS ORDER_CLOSED_FLAG,
        NULL AS REQUEST_COST_CENTER,
        NULL AS RESPONSIBLE_CCTR,
        NULL AS SHEET,
        'WBSE MASTER DATA' as SOURCE
    from
    WBSE_MASTER_DATA_SOURCE src
    LEFT JOIN DIM_CR_FIN_ACCOUNT fin_acc
        ON src.ACCOUNT = fin_acc.ACCOUNT_NAME
    LEFT JOIN DIM_CR_CORP_COMPANY_UNIT cc_unit
        ON src.COMPANY_CODE_KEY = CC_UNIT.COMPANY_CODE
    LEFT JOIN DIM_CR_FIN_CONTROLLING_UNIT fin_cu
        ON src.CONTROLLING_AREA_DESC = fin_cu.CONTROLLING_UNITS
    LEFT JOIN DIM_CR_FIN_COST_CENTER fin_cc
        ON coalesce(src.REQUESTING_COST_CENTER_KEY, '') = coalesce(fin_cc.REQUEST_CCTR, '')
        AND coalesce(src.REQUESTING_COST_CENTER_DESC, '') = coalesce(fin_cc.REQUEST_CCTR_DESC, '')
        AND coalesce(src.RESPONSIBLE_COST_CENTER_KEY, '') = coalesce(fin_cc.RESPONSIBLE_CCTR, '')
        AND coalesce(src.RESPONSIBLE_COST_CENTER_DESC, '') = coalesce(fin_cc.RESPONSIBLE_CCTR_DESC, '')
    LEFT JOIN DIM_CR_FIN_FUND_CENTER fin_fc
        ON coalesce(src.FUND, '') = coalesce(fin_fc.FUND_CENTER_NAME, '')
        AND coalesce(src.FUNDS_CENTER, '') = coalesce(fin_fc.FUND_CENTER_CODE, '')
        AND coalesce(src.FUNDS_CENTER_DESC, '') = coalesce(fin_fc.FUND_CENTER_DESCRIPTION, '')
    LEFT JOIN DIM_CR_FIN_FUND_GROUP_SAP fin_fg
        ON coalesce(src.REQUESTING_REGION, '-') = coalesce(fin_fg.REQUESTING_FUND_GROUP, '-')
        AND coalesce(src.RESPONSIBLE_REGION, '-') = coalesce(fin_fg.RESPONSIBLE_FUND_GROUP, '-')
    LEFT JOIN DIM_CR_FIN_FUNCTIONAL_AREA fin_fa
        ON coalesce(src.FUND_AREA, '-') = coalesce(fin_fa.FUNCTIONAL_AREA, '-')
    LEFT JOIN DIM_CR_CORP_DEPT dept
        ON coalesce(src.DIVISION, '-') = coalesce(dept.DIVISION, '-')
    LEFT JOIN DIM_CR_PROC_PR proc_pr
        ON coalesce(src.CO_OBJECT_NUMBER, '-') = coalesce(proc_pr.PURCHASE_REQUISITION, '-')
        AND proc_pr.DATA_SOURCE = 'WBSE_MASTER_DATA'
    LEFT JOIN DIM_CR_WORK_PROGRAM wp
        ON coalesce(src.PROGRAM_DEFINITION_KEY, '-') = coalesce(wp.PROGRAM_DEFINITION_KEY, '-')
        AND coalesce(src.PROGRAM_DEFINITION_DESC, '-') = coalesce(wp.PROGRAM_DEFINITION_DESC, '-')
    LEFT JOIN DIM_CR_WORK_PROJECT project
        ON coalesce(src.PROJECT_DEFINITION_KEY, '-') = coalesce(project.PROJECT_DEFINITION_KEY, '-')
    LEFT JOIN DIM_CR_FIN_PROFIT_CENTER fpc
        ON coalesce(src.PROFIT_CENTER_KEY, '-') = coalesce(fpc.PROFIT_CENTER_KEY, '-')
        AND coalesce(src.PROFIT_CENTER_DESC, '-') = coalesce(fpc.PROFIT_CENTER_DESC, '-')
    LEFT JOIN DIM_CR_WORK_WORK_ORDER work_order
        ON coalesce(src.WBS_Element_Key, '-') = coalesce(work_order.IO_WBS, '-')
        AND coalesce(src.WBS_Element_Desc, '-') = coalesce(work_order.IO_WBS_DESCRIPTION, '-')
        AND coalesce(src.WBS_Element_Key, '-') = coalesce(work_order.ORDER_ELEMENT_KEY, '-')
    LEFT JOIN DIM_CR_CUS_CUSTOMER_KIND_SAP ck
        ON coalesce(src.REQUESTING_SECTOR, '-') = coalesce(ck.REQUESTING_SECTOR, '-')
        AND coalesce(src.RESPONSIBLE_SECTOR, '-') = coalesce(ck.RESPONSIBLE_SECTOR, '-')
    LEFT JOIN DIM_CR_CUS_CUSTOMER_REVENUE_KIND_SAP crk
        ON coalesce(src.BUSINESS_AREA_KEY, '-') = coalesce(crk.REVENUE_KIND_KEYS, '-')
        AND coalesce(src.BUSINESS_AREA_DESC, '-') = coalesce(crk.REVENUE_KIND_DESCRIPTIONS, '-')
"""

COST_CENTER_MASTER_DATA = """
    SELECT 
        NULL AS DIM_ACCOUNT_ID,
        NULL AS DIM_AGREEMENT_ID,
        NULL AS DIM_CONTRACT_ID,
        cc_unit.DIM_COMPANY_UNIT_ID,
        fin_cu.DIM_CONTROLLING_UNIT_ID,
        fin_cc.DIM_COST_CENTER_ID,
        NULL AS DIM_EXPENSE_CATEGORY_ID,
        fin_fc.DIM_FUND_CENTER_ID,
        fin_fg.DIM_FUND_GROUP_ID,
        fin_fa.DIM_FUNCTIONAL_AREA_ID,
        dept.DIM_ORG_DEPT_ID,
        NULL AS DIM_PR_ID,
        NULL AS DIM_PROGRAM_ID,
        NULL AS DIM_PROJECT_ID,
        fpc.DIM_PROFIT_CENTER_ID,
        NULL AS DIM_WORK_ORDER_ID,
        ck.CUSTOMER_KIND_ID,
        crk.CUSTOMER_REVENUE_KIND_ID,
        src.SECTOR_CODE AS SECTOR_CODE,
        NULL AS DELETION_INDICATOR,
        NULL AS IS_FALSE,
        NULL AS IN_LULUH_LIST,
        src.LAST_REFRESH_DATE,
        NULL AS MASTER_IO_WBS_LIST,
        NULL AS MASTER_IO_WBS_LIST_1,
        NULL as NEOM_MAPPING, 
        NULL AS OPEX_CAPEX,
        NULL AS ORDER_CLOSED_FLAG,
        NULL AS REQUEST_COST_CENTER,
        NULL AS RESPONSIBLE_CCTR,
        NULL AS SHEET,
        'COST CENTER MASTER DATA' as SOURCE
    from
    COST_CENTER_MASTER_DATA_SOURCE src
    LEFT JOIN DIM_CR_CORP_COMPANY_UNIT cc_unit
        ON src.COMPANY_CODE_KEY = CC_UNIT.COMPANY_CODE
    LEFT JOIN DIM_CR_FIN_CONTROLLING_UNIT fin_cu
        ON src.CONTROLLING_AREA_DESC = fin_cu.CONTROLLING_UNITS
    LEFT JOIN DIM_CR_FIN_COST_CENTER fin_cc
        ON coalesce(src.COST_CENTER_KEY, '') = coalesce(fin_cc.COST_CENTER, '')
        AND fin_cc.REQUEST_CCTR is null 
        AND fin_cc.RESPONSIBLE_CCTR is null
    LEFT JOIN DIM_CR_FIN_FUND_CENTER fin_fc
        ON coalesce(src.FUND, '') = coalesce(fin_fc.FUND_CENTER_NAME, '')
        AND coalesce(src.FUNDS_CENTER, '') = coalesce(fin_fc.FUND_CENTER_CODE, '')
        AND coalesce(src.FUNDS_CENTER_DESC, '') = coalesce(fin_fc.FUND_CENTER_DESCRIPTION, '')
    LEFT JOIN DIM_CR_FIN_FUND_GROUP_SAP fin_fg
        ON coalesce(src.REGION, '-') = coalesce(fin_fg.FUND_GROUP_NAME, '-')
        AND coalesce(src.REGION_CODE, '-') = coalesce(fin_fg.FUND_GROUP_CODE, '-')
        AND coalesce(src.HIERARCHY_AREA, '-') = coalesce(fin_fg.HIERARCHY_GROUP, '-')
        AND coalesce(src.SUBREGION_CODE, '-') = coalesce(fin_fg.SEMI_GROUP_CODE, '-')
        AND fin_fg.REQUESTING_FUND_GROUP is null
        AND fin_fg.RESPONSIBLE_FUND_GROUP is null
    LEFT JOIN DIM_CR_FIN_FUNCTIONAL_AREA fin_fa
        ON coalesce(src.FUND_AREA, '-') = coalesce(fin_fa.FUNCTIONAL_AREA, '-')
    LEFT JOIN DIM_CR_CORP_DEPT dept
        ON coalesce(src.DEPARTMENT, '-') = coalesce(dept.DEPARTMENT, '-')
        AND dept.DIVISION is null
    LEFT JOIN DIM_CR_FIN_PROFIT_CENTER fpc
        ON coalesce(src.PROFIT_CENTER_KEY, '-') = coalesce(fpc.PROFIT_CENTER_KEY, '-')
        AND coalesce(src.PROFIT_CENTER_DESC, '-') = coalesce(fpc.PROFIT_CENTER_DESC, '-')
    LEFT JOIN DIM_CR_CUS_CUSTOMER_KIND_SAP ck
        ON coalesce(src.SECTOR, '-') = coalesce(ck.CUSTOMER_KIND_SECTOR, '-')
        AND coalesce(src.SECTOR_CODE, '-') = coalesce(ck.CUSTOMER_KIND_SECTOR_CODE, '-')
        AND ck.REQUESTING_SECTOR is null
        AND ck.RESPONSIBLE_SECTOR is null
    LEFT JOIN DIM_CR_CUS_CUSTOMER_REVENUE_KIND_SAP crk
        ON coalesce(src.BUSINESS_AREA_KEY, '-') = coalesce(crk.REVENUE_KIND_KEYS, '-')
        AND coalesce(src.BUSINESS_AREA_DESC, '-') = coalesce(crk.REVENUE_KIND_DESCRIPTIONS, '-')
"""

INTERNAL_ORDER_MASTER_DATA = """
    SELECT 
        NULL AS DIM_ACCOUNT_ID,
        NULL AS DIM_AGREEMENT_ID,
        NULL AS DIM_CONTRACT_ID,
        NULL AS DIM_COMPANY_UNIT_ID,
        fin_cu.DIM_CONTROLLING_UNIT_ID,
        fin_cc.DIM_COST_CENTER_ID,
        fin_exp.DIM_EXPENSE_CATEGORY_ID,
        fin_fc.DIM_FUND_CENTER_ID,
        fin_fg.DIM_FUND_GROUP_ID,
        fin_fa.DIM_FUNCTIONAL_AREA_ID,
        NULL AS DIM_ORG_DEPT_ID,
        NULL AS DIM_PR_ID,
        NULL AS DIM_PROGRAM_ID,
        NULL AS DIM_PROJECT_ID,
        fpc.DIM_PROFIT_CENTER_ID,
        work_order.DIM_WORK_ORDER_ID,
        ck.CUSTOMER_KIND_ID,
        crk.CUSTOMER_REVENUE_KIND_ID,
        NULL AS SECTOR_CODE,
        NULL AS DELETION_INDICATOR,
        NULL AS IS_FALSE,
        NULL AS IN_LULUH_LIST,
        src.LAST_REFRESH_DATE,
        NULL AS MASTER_IO_WBS_LIST,
        NULL AS MASTER_IO_WBS_LIST_1,
        src.NEOM_MAPPING,
        NULL AS OPEX_CAPEX,
        src.ORDER_CLOSED_FLAG,
        NULL AS REQUEST_COST_CENTER,
        NULL AS RESPONSIBLE_CCTR,
        NULL AS SHEET,
        'INTERNAL ORDER MASTER DATA' as SOURCE
    from
    INTERNAL_ORDER_MASTER_DATA_SOURCE src
    LEFT JOIN DIM_CR_FIN_CONTROLLING_UNIT fin_cu
        ON src.CONTROLLING_AREA_DESC = fin_cu.CONTROLLING_UNITS
    LEFT JOIN DIM_CR_FIN_COST_CENTER fin_cc
        ON coalesce(src.REQUESTING_COST_CENTER_KEY, '') = coalesce(fin_cc.REQUEST_CCTR, '')
        AND coalesce(src.REQUESTING_COST_CENTER_DESC, '') = coalesce(fin_cc.REQUEST_CCTR_DESC, '')
        AND coalesce(src.RESPONSIBLE_COST_CENTER_KEY, '') = coalesce(fin_cc.RESPONSIBLE_CCTR, '')
        AND coalesce(src.RESPONSIBLE_COST_CENTER_DESC, '') = coalesce(fin_cc.RESPONSIBLE_CCTR_DESC, '')
    LEFT JOIN DIM_CR_FIN_EXPENSE_CATEGORY_SAP fin_exp
        ON coalesce(src.EXPENSE_CATEGORY_KEY, '') = coalesce(fin_exp.EXPENSE_CATEGORY_KEY, '')
        AND coalesce(src.EXPENSE_CATEGORY_DESC, '') = coalesce(fin_exp.EXPENSE_CATEGORY_DESC, '')
        AND coalesce(src.SUBCAT_KEY, '') = coalesce(fin_exp.SUB_CAT_KEY, '')
        AND coalesce(src.SUBCAT_DESC, '') = coalesce(fin_exp.SUB_CAT_DESC, '')
    LEFT JOIN DIM_CR_FIN_FUND_CENTER fin_fc
        ON coalesce(src.FUND, '') = coalesce(fin_fc.FUND_CENTER_NAME, '')
        AND coalesce(src.FUNDS_CENTER, '') = coalesce(fin_fc.FUND_CENTER_CODE, '')
        AND coalesce(src.FUNDS_CENTER_DESC, '') = coalesce(fin_fc.FUND_CENTER_DESCRIPTION, '')
    LEFT JOIN DIM_CR_FIN_FUND_GROUP_SAP fin_fg
        ON coalesce(src.REQUESTING_REGION, '-') = coalesce(fin_fg.REQUESTING_FUND_GROUP, '-')
        AND coalesce(src.RESPONSIBLE_REGION, '-') = coalesce(fin_fg.RESPONSIBLE_FUND_GROUP, '-')
    LEFT JOIN DIM_CR_FIN_FUNCTIONAL_AREA fin_fa
        ON coalesce(src.FUND_AREA, '-') = coalesce(fin_fa.FUNCTIONAL_AREA, '-')
    LEFT JOIN DIM_CR_FIN_PROFIT_CENTER fpc
        ON coalesce(src.PROFIT_CENTER_KEY, '-') = coalesce(fpc.PROFIT_CENTER_KEY, '-')
        AND coalesce(src.PROFIT_CENTER_DESC, '-') = coalesce(fpc.PROFIT_CENTER_DESC, '-')
    LEFT JOIN DIM_CR_WORK_WORK_ORDER work_order
        ON coalesce(src.ORDERNO_KEY, '-') = coalesce(work_order.ORDER, '-')
        AND coalesce(src.ORDERNO_DESC, '-') = coalesce(work_order.ORDER_DESCRIPTION, '-')
    LEFT JOIN DIM_CR_CUS_CUSTOMER_KIND_SAP ck
        ON coalesce(src.REQUESTING_SECTOR, '-') = coalesce(ck.REQUESTING_SECTOR, '-')
        AND coalesce(src.RESPONSIBLE_SECTOR, '-') = coalesce(ck.RESPONSIBLE_SECTOR, '-')
    LEFT JOIN DIM_CR_CUS_CUSTOMER_REVENUE_KIND_SAP crk
        ON coalesce(src.BUSINESS_AREA_KEY, '-') = coalesce(crk.REVENUE_KIND_KEYS, '-')
        AND coalesce(src.BUSINESS_AREA_DESC, '-') = coalesce(crk.REVENUE_KIND_DESCRIPTIONS, '-')
"""