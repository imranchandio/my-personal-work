# pylint:disable = C0301

# OCID: ocid1.dataflowapplication.oc1.me-jeddah-1.anvgkljrsvwgetyagpdnlrbxrpmpcqhlyfchors54aa3xzvzodoirka3nv4q

import logging
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")

from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from common_utils import calculate_num_partitions, impose_schema, trim_spaces
from read_utils import read
import transform_queries as queries


def prepare_transformed_df(**kwargs) -> DataFrame:
    logging.info("Starting the transformation process.")

    dataframes = {
        "WBSE_MASTER_DATA_SOURCE": "df_wbse_master_data",
        "COST_CENTER_MASTER_DATA_SOURCE": "df_cost_center_master_data",
        "INTERNAL_ORDER_MASTER_DATA_SOURCE": "df_internal_order_master_data",
        "DIM_CR_FIN_ACCOUNT": "df_dim_cr_fin_account",
        "DIM_CR_CORP_COMPANY_UNIT": "df_dim_cr_corp_company_unit",
        "DIM_CR_FIN_CONTROLLING_UNIT": "df_dim_cr_fin_controlling_unit",
        "DIM_CR_FIN_COST_CENTER": "df_dim_cr_fin_cost_center",
        "DIM_CR_FIN_EXPENSE_CATEGORY_SAP": "df_dim_cr_fin_expense_category_sap",
        "DIM_CR_FIN_FUND_CENTER": "df_dim_cr_fin_fund_center",
        "DIM_CR_FIN_FUND_GROUP_SAP": "df_dim_cr_fin_fund_group_sap",
        "DIM_CR_FIN_FUNCTIONAL_AREA": "df_dim_cr_fin_functional_area",
        "DIM_CR_CORP_DEPT": "df_dim_cr_corp_dept",
        "DIM_CR_PROC_PR": "df_dim_cr_proc_pr",
        "DIM_CR_WORK_PROGRAM": "df_dim_cr_work_program",
        "DIM_CR_WORK_PROJECT": "df_dim_cr_work_project",
        "DIM_CR_FIN_PROFIT_CENTER": "df_dim_cr_fin_profit_center",
        "DIM_CR_WORK_WORK_ORDER": "df_dim_cr_work_work_order",
        "DIM_CR_CUS_CUSTOMER_KIND_SAP": "df_dim_cr_cus_customer_kind_sap",
        "DIM_CR_CUS_CUSTOMER_REVENUE_KIND_SAP": "df_dim_cr_cus_customer_revenue_kind_sap",

    }

    for view_name, df_key in dataframes.items():
        try:
            kwargs.get(df_key).createOrReplaceTempView(view_name)
        except Exception:
            logging.error(f"Error while creating view {view_name}")
            raise ValueError(f"{view_name} dataframe is empty")

    # Execute the SQL query to generate the output DataFrame
    df_wbse_master_data_transformed = kwargs.get("spark").sql(queries.WBSE_MASTER_DATA)
    df_cost_center_master_data_transformed = kwargs.get("spark").sql(queries.COST_CENTER_MASTER_DATA)
    df_internal_order_master_data_transformed = kwargs.get("spark").sql(queries.INTERNAL_ORDER_MASTER_DATA)

    df_transformed = (
        df_wbse_master_data_transformed
        .unionByName(df_cost_center_master_data_transformed)
        .unionByName(df_internal_order_master_data_transformed)
    )

    # List of columns for generating the key
    columns = [
        'DIM_ACCOUNT_ID', 'DIM_AGREEMENT_ID', 'DIM_CONTRACT_ID', 'DIM_COMPANY_UNIT_ID',
        'DIM_CONTROLLING_UNIT_ID', 'DIM_COST_CENTER_ID', 'DIM_EXPENSE_CATEGORY_ID',
        'DIM_FUND_CENTER_ID', 'DIM_FUND_GROUP_ID', 'DIM_FUNCTIONAL_AREA_ID',
        'DIM_ORG_DEPT_ID', 'DIM_PR_ID', 'DIM_PROGRAM_ID', 'DIM_PROJECT_ID',
        'DIM_PROFIT_CENTER_ID', 'DIM_WORK_ORDER_ID', 'CUSTOMER_KIND_ID',
        'CUSTOMER_REVENUE_KIND_ID', 'SECTOR_CODE', 'DELETION_INDICATOR',
        'IS_FALSE', 'IN_LULUH_LIST', 'LAST_REFRESH_DATE', 'MASTER_IO_WBS_LIST',
        'MASTER_IO_WBS_LIST_1', 'NEOM_MAPPING', 'OPEX_CAPEX', 'ORDER_CLOSED_FLAG',
        'REQUEST_COST_CENTER', 'RESPONSIBLE_CCTR', 'SHEET', 'SOURCE'
    ]

    # Generate the key
    df_transformed = df_transformed.withColumn(
        "FACT_IO_WBS_CC_MASTER_ID",
        F.sha2(
            F.concat_ws(
                "||",
                *[F.coalesce(F.col(col), F.lit("-")) for col in columns]
            ),
            256
        )
    )

    # Remove duplicates in any
    df_transformed = df_transformed.distinct()

    # Technical metadata columns
    df_transformed = df_transformed.withColumn(
        "LAST_UPDATED_DATE", F.current_timestamp()
    ).withColumn(
        "CREATED_DATE", F.current_timestamp()
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 1024
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info(
        f"Repartitioning the DataFrame into {num_partitions} partitions."
    )

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters, returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_wbse_master_data = source_dfs["WBSE_MASTER_DATA"]
    df_cost_center_master_data = source_dfs["COST_CENTER_MASTER_DATA"]
    df_internal_order_master_data = source_dfs["INTERNAL_ORDER_MASTER_DATA"]
    df_dim_cr_fin_account = source_dfs["DIM_CR_FIN_ACCOUNT"]
    df_dim_cr_corp_company_unit = source_dfs["DIM_CR_CORP_COMPANY_UNIT"]
    df_dim_cr_fin_controlling_unit = source_dfs["DIM_CR_FIN_CONTROLLING_UNIT"]
    df_dim_cr_fin_cost_center = source_dfs["DIM_CR_FIN_COST_CENTER"]
    df_dim_cr_fin_expense_category_sap = source_dfs["DIM_CR_FIN_EXPENSE_CATEGORY_SAP"]
    df_dim_cr_fin_fund_center = source_dfs["DIM_CR_FIN_FUND_CENTER"]
    df_dim_cr_fin_fund_group_sap = source_dfs["DIM_CR_FIN_FUND_GROUP_SAP"]
    df_dim_cr_fin_functional_area = source_dfs["DIM_CR_FIN_FUNCTIONAL_AREA"]
    df_dim_cr_corp_dept = source_dfs["DIM_CR_CORP_DEPT"]
    df_dim_cr_proc_pr = source_dfs["DIM_CR_PROC_PR"]
    df_dim_cr_work_program = source_dfs["DIM_CR_WORK_PROGRAM"]
    df_dim_cr_work_project = source_dfs["DIM_CR_WORK_PROJECT"]
    df_dim_cr_fin_profit_center = source_dfs["DIM_CR_FIN_PROFIT_CENTER"]
    df_dim_cr_work_work_order = source_dfs["DIM_CR_WORK_WORK_ORDER"]
    df_dim_cr_cus_customer_kind_sap = source_dfs["DIM_CR_CUS_CUSTOMER_KIND_SAP"]
    df_dim_cr_cus_customer_revenue_kind_sap = source_dfs["DIM_CR_CUS_CUSTOMER_REVENUE_KIND_SAP"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_wbse_master_data=df_wbse_master_data,
        df_cost_center_master_data=df_cost_center_master_data,
        df_internal_order_master_data=df_internal_order_master_data,
        df_dim_cr_fin_account=df_dim_cr_fin_account,
        df_dim_cr_corp_company_unit=df_dim_cr_corp_company_unit,
        df_dim_cr_fin_controlling_unit=df_dim_cr_fin_controlling_unit,
        df_dim_cr_fin_cost_center=df_dim_cr_fin_cost_center,
        df_dim_cr_fin_expense_category_sap=df_dim_cr_fin_expense_category_sap,
        df_dim_cr_fin_fund_center=df_dim_cr_fin_fund_center,
        df_dim_cr_fin_fund_group_sap=df_dim_cr_fin_fund_group_sap,
        df_dim_cr_fin_functional_area=df_dim_cr_fin_functional_area,
        df_dim_cr_corp_dept=df_dim_cr_corp_dept,
        df_dim_cr_proc_pr=df_dim_cr_proc_pr,
        df_dim_cr_work_program=df_dim_cr_work_program,
        df_dim_cr_work_project=df_dim_cr_work_project,
        df_dim_cr_fin_profit_center=df_dim_cr_fin_profit_center,
        df_dim_cr_work_work_order=df_dim_cr_work_work_order,
        df_dim_cr_cus_customer_kind_sap=df_dim_cr_cus_customer_kind_sap,
        df_dim_cr_cus_customer_revenue_kind_sap=df_dim_cr_cus_customer_revenue_kind_sap,

    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
