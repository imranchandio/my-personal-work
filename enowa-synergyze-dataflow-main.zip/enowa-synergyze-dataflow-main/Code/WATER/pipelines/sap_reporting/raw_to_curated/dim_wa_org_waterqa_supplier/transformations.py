import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws, when, split
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def get_supplier_code(df: DataFrame) -> DataFrame:
    """
    Extracts numeric supplier codes from the `SUPPLIER` column and adds them as a new `supplier_code` column.
    If no code is present, `supplier_code` is set to NULL.

    Args:
        df (DataFrame): Input DataFrame with a `SUPPLIER` column.

    Returns:
        DataFrame: DataFrame with an additional `supplier_code` column.
    """
    return (
        df.withColumn(
            "supplier_code",
            when(
                df.SUPPLIER.rlike(r"^\d+\s"),
                split(df.SUPPLIER, r"\s")[0]
            ).otherwise(None)
        )
    )


def get_supplier_name(df: DataFrame) -> DataFrame:
    """
    Extracts the supplier name from the `SUPPLIER` column and adds it as a new `supplier_name` column.
    If a supplier code is present, the part after the code is used as the name. Otherwise, the entire
    `SUPPLIER` value is treated as the name.

    Args:
        df (DataFrame): Input DataFrame with a `SUPPLIER` column.

    Returns:
        DataFrame: DataFrame with an additional `supplier_name` column.
    """
    return (
        df.withColumn(
            "supplier_name",
            when(
                df.SUPPLIER.rlike(r"^\d+\s"),
                split(df.SUPPLIER, r"\s", 2)[1]
            ).otherwise(df.SUPPLIER)
        )
    )


def prepare_transformed_df(
        spark: SparkSession,
        df_pr_po_status: DataFrame,  # Replacing df_result_sourcing_plan
        df_pr_po_profile: DataFrame,  # Replacing df_q1_po_item_master_list
        df_po_data_by_supplier_export: DataFrame,  # Replacing df_q5_fwa_details
        df_cost_center_commitments: DataFrame,  # Replacing df_new_wcg_ses_tracker_master_ses_tracker
        df_internal_order_commitments: DataFrame,
        df_wbse_commitments: DataFrame,
        df_cost_center_transaction_data: DataFrame,
        df_internal_order_transaction_data: DataFrame,
        df_wbse_transaction_data: DataFrame
) -> DataFrame:
    df_pr_po_status = get_supplier_code(df_pr_po_status)
    df_pr_po_status = get_supplier_name(df_pr_po_status)

    df_pr_po_profile = get_supplier_code(df_pr_po_profile)
    df_pr_po_profile = get_supplier_name(df_pr_po_profile)

    df_po_data_by_supplier_export = get_supplier_code(df_po_data_by_supplier_export)
    df_po_data_by_supplier_export = get_supplier_name(df_po_data_by_supplier_export)

    # Register DataFrames as temporary views
    df_pr_po_status.createOrReplaceTempView("PR_PO_STATUS")
    df_pr_po_profile.createOrReplaceTempView("PR_PO_PROFILE")
    df_po_data_by_supplier_export.createOrReplaceTempView("PO_DATA_BY_SUPPLIER_EXPORT")
    df_cost_center_commitments.createOrReplaceTempView("COST_CENTER_COMMITMENTS")
    df_internal_order_commitments.createOrReplaceTempView("INTERNAL_ORDER_COMMITMENTS")
    df_wbse_commitments.createOrReplaceTempView("WBSE_COMMITMENTS")
    df_cost_center_transaction_data.createOrReplaceTempView("COST_CENTER_TRANSACTION_DATA")
    df_internal_order_transaction_data.createOrReplaceTempView("INTERNAL_ORDER_TRANSACTION_DATA")
    df_wbse_transaction_data.createOrReplaceTempView("WBSE_TRANSACTION_DATA")

    logging.info("Executing SQL query for data transformation.")

    # SQL query using the tables that are now temporary views
    sql_query = """
    WITH SupplierName AS (
        SELECT 
            supplier_code,
            supplier_name,
            NULL AS GCFA_SUPPLIER_CODE, 'SAP PR' AS SUPPLIER_TYPE, 'SAP PR' AS SUB_DOMAIN_TYPE
        FROM PR_PO_STATUS
        UNION ALL
        SELECT 
            supplier_code,
            supplier_name,
            NULL, 'SAP PR', 'SAP PR'
        FROM PR_PO_PROFILE
        UNION ALL
        SELECT 
            supplier_code,
            supplier_name,
            GCFA_SUPPLIER_CODE, 'SAP PR', 'SAP PR'
        FROM PO_DATA_BY_SUPPLIER_EXPORT
        UNION ALL
        SELECT 
            VENDOR AS SUPPLIER_CODE, 
            VENDOR_NAME AS SUPPLIER_NAME,
            NULL,  'SAP FI',  'SAP FI'
        FROM COST_CENTER_COMMITMENTS
        UNION ALL
        SELECT 
            VENDOR AS SUPPLIER_CODE, 
            VENDOR_NAME AS SUPPLIER_NAME,
            NULL,  'SAP FI',  'SAP FI'
        FROM INTERNAL_ORDER_COMMITMENTS
        UNION ALL
        SELECT 
            VENDOR AS SUPPLIER_CODE, 
            VENDOR_NAME AS SUPPLIER_NAME,
            NULL,  'SAP FI',  'SAP FI'
        FROM WBSE_COMMITMENTS
        UNION ALL
        SELECT 
            Vendor AS SUPPLIER_CODE, 
            Vendor_Name AS SUPPLIER_NAME,
            NULL,  'SAP FI',  'SAP FI'
        FROM COST_CENTER_TRANSACTION_DATA
        UNION ALL
        SELECT 
            VENDOR AS SUPPLIER_CODE, 
            VENDOR_NAME AS SUPPLIER_NAME,
            NULL,  'SAP FI',  'SAP FI'
        FROM INTERNAL_ORDER_TRANSACTION_DATA
        UNION ALL
        SELECT 
            VENDOR AS SUPPLIER_CODE, 
            VENDOR_NAME AS SUPPLIER_NAME,
            NULL,  'SAP FI',  'SAP FI'
        FROM WBSE_TRANSACTION_DATA
    )
    SELECT 
        NULL AS DIM_WW_SERVICE_LOCATION_ID, 
        sm.SUPPLIER_CODE, 
        sm.GCFA_SUPPLIER_CODE, 
        sm.SUPPLIER_NAME,
        NULL AS COMPANY_NAME, 
        NULL AS COMPANY_CATEGORY, 
        sm.SUPPLIER_TYPE, 
        sm.SUB_DOMAIN_TYPE,
        'SAP' AS DOMAIN_TYPE, 
        NULL AS SUPPLIER_DESCRIPTION, 
        NULL AS SUPPLIER_CONTRACT_PERIOD,
        NULL AS SUPPLIER_ADDRESS, 
        NULL AS SUPPLIER_CONTACT, 
        NULL AS IS_REGISTERED, 
        NULL AS NOTE_SUPPLIER,
        'SAP' AS PARTITION_KEY, 
        current_timestamp() AS LAST_UPDATED_DATE, 
        current_timestamp() AS CREATED_DATE
    FROM SupplierName sm;
    """

    # Execute the SQL query
    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation.")

    # Add a new column for the unique DIM_WATERQA_SUPPLIER_ID
    df_transformed = df_transformed.withColumn(
        "DIM_WATERQA_SUPPLIER_ID", sha2(concat_ws("||",\
                 "SUPPLIER_CODE", "SUPPLIER_NAME","SUPPLIER_TYPE","GCFA_SUPPLIER_CODE"), 256)
    )

    logging.info("Calculating the number of partitions.")

    # Repartition DataFrame based on size
    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info(f"Repartitioning the DataFrame into {num_partitions} partitions.")

    # Repartition the DataFrame
    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.
    """
    # Extract the required DataFrames from the source dictionary
    df_pr_po_status = source_dfs["PR_PO_STATUS"]
    df_pr_po_profile = source_dfs["PR_PO_PROFILE"]
    df_po_data_by_supplier_export = source_dfs["PO_DATA_BY_SUPPLIER_EXPORT"]
    df_cost_center_commitments = source_dfs["COST_CENTER_COMMITMENTS"]
    df_internal_order_commitments = source_dfs["INTERNAL_ORDER_COMMITMENTS"]
    df_wbse_commitments = source_dfs["WBSE_COMMITMENTS"]
    df_cost_center_transaction_data = source_dfs["COST_CENTER_TRANSACTION_DATA"]
    df_internal_order_transaction_data = source_dfs["INTERNAL_ORDER_TRANSACTION_DATA"]
    df_wbse_transaction_data = source_dfs["WBSE_TRANSACTION_DATA"]

    # Perform the transformation
    transform_df = prepare_transformed_df(
        spark=spark,
        df_pr_po_status=df_pr_po_status,
        df_pr_po_profile=df_pr_po_profile,
        df_po_data_by_supplier_export=df_po_data_by_supplier_export,
        df_cost_center_commitments=df_cost_center_commitments,
        df_internal_order_commitments=df_internal_order_commitments,
        df_wbse_commitments=df_wbse_commitments,
        df_cost_center_transaction_data=df_cost_center_transaction_data,
        df_internal_order_transaction_data=df_internal_order_transaction_data,
        df_wbse_transaction_data=df_wbse_transaction_data
    )

    # Ensure distinct rows
    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
) -> DataFrame:
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.
    """
    # Read the source DataFrames from the pipeline storage
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    # Perform the transformation
    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    # Extract the target schema from the pipeline storage
    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    # Impose the target schema on the transformed DataFrame
    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.
    """
    if spark_df:
        print(spark_df.printSchema())

    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "50MB")

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    # Execute the transformation if the task name matches
    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
