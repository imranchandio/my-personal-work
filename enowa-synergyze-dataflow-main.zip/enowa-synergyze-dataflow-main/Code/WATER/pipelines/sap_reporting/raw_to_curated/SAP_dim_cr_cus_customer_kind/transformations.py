# pylint: disable = import-error
"""
    This is the transformation file for DIM_CR_CU_CUSTOMER_KIND_SAP dimension
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")

def get_sql_query(source: str):
    """
        Returns an SQL query based on the specified source.

        Args:
            source (str): The source type determining the query structure.

        Returns:
            str: An SQL query string with columns `CUSTOMER_KIND_SECTOR`,
                 `REQUESTING_SECTOR`, and `RESPONSIBLE_SECTOR`.
    """
    sql_query = ''
    if source in ["COST_CENTER_MASTER_DATA", "COST_CENTER_AWARDED_BUDGET",
                  "COST_CENTER_BUDGET", "COST_CENTER_COMMITMENTS",
                  "COST_CENTER_CURRENT_BUDGET", "COST_CENTER_TRANSACTION_DATA"]:
        # Dynamically determine the column value
        customer_kind_sector_code = "SECTOR_CODE" if source == "COST_CENTER_MASTER_DATA" else "NULL"
        sql_query = f"""
                    SELECT 
                        {customer_kind_sector_code} as CUSTOMER_KIND_SECTOR_CODE,
                        SECTOR as CUSTOMER_KIND_SECTOR,
                        NULL as REQUESTING_SECTOR,
                        NULL as RESPONSIBLE_SECTOR
                    FROM {source}
                """
    elif source in ["PR_PO_STATUS", "PR_PO_PROFILE", "PO_DATA_BY_SUPPLIER_EXPORT"]:
        sql_query = f"""
                    SELECT
                        NULL as CUSTOMER_KIND_SECTOR_CODE, 
                        SECTOR_SPEND as CUSTOMER_KIND_SECTOR,
                        NULL as REQUESTING_SECTOR,
                        NULL as RESPONSIBLE_SECTOR
                    FROM {source}
                """
    else:
        sql_query = f"""
                    SELECT
                        NULL as CUSTOMER_KIND_SECTOR_CODE, 
                        NULL as CUSTOMER_KIND_SECTOR,
                        REQUESTING_SECTOR as REQUESTING_SECTOR,
                        RESPONSIBLE_SECTOR as RESPONSIBLE_SECTOR
                    FROM {source}
                """
    return sql_query


def prepare_transformed_df(
        spark: SparkSession,
        dfs: dict
) -> DataFrame:
    """
        Transforms and processes multiple DataFrames into a unified, cleaned DataFrame.

        Args:
            spark (SparkSession): The active SparkSession.
            dfs (dict): A dictionary where keys are source names and values are DataFrames.

        Returns:
            DataFrame: A transformed DataFrame with additional columns, deduplicated rows,
                       technical metadata, and optimized partitioning.
    """
    logging.info("Starting the transformation process.")
    df_transformed = None
    for key, df in dfs.items():
        # Register each DataFrame as a temporary view with a unique name
        table_name = str.upper(key)  # Ensure the name matches the SQL reference
        df.createOrReplaceTempView(table_name)
        sql_query = get_sql_query(table_name)
        try:
            if df_transformed is None:
                df_transformed = spark.sql(sql_query)
            else:
                df_transformed = df_transformed.unionByName(spark.sql(sql_query))
        except Exception:
            print("ERROR occurred, printing source schema: ", df.printSchema())
            raise ValueError(f"Error occured at schema {key}")

    logging.info("Executed SQL query for data transformation.")

    # Add CUSTOMER_KIND_NAME and CUSTOMER_KIND_DETAILS columns
    df_transformed = df_transformed.withColumn(
        "CUSTOMER_KIND_NAME", F.lit(None)
    ).withColumn(
        "CUSTOMER_KIND_DETAILS", F.lit(None)
    ).withColumn(
        "CUSTOMER_KIND_ID",
        F.sha2(
            F.concat_ws(
                "||",
                F.coalesce(F.col("CUSTOMER_KIND_SECTOR_CODE"), F.lit("-")),
                F.coalesce(F.col("CUSTOMER_KIND_SECTOR"), F.lit("-")),
                F.coalesce(F.col("REQUESTING_SECTOR"), F.lit("-")),
                F.coalesce(F.col("RESPONSIBLE_SECTOR"), F.lit("-"))
            ),
            256,
        ),
    )

    # Remove duplicates in any
    df_transformed = df_transformed.distinct()

    # Technical metadata columns
    df_transformed = df_transformed.withColumn(
        "LAST_UPDATED_DATE", F.current_timestamp()
    ).withColumn(
        "CREATED_DATE", F.current_timestamp()
    )

    # Drop null rows
    df_transformed = df_transformed.dropna(
        how="all",
        subset=["CUSTOMER_KIND_SECTOR_CODE","CUSTOMER_KIND_SECTOR",\
                 "REQUESTING_SECTOR", "RESPONSIBLE_SECTOR"]
    )

    print(
        "df_transformed schema before imposing schema:",
        df_transformed.printSchema()
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 1024
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info(
        f"Repartitioning the DataFrame into {num_partitions} partitions."
    )

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_cost_center_master_data = source_dfs["COST_CENTER_MASTER_DATA"]
    df_pr_po_status = source_dfs["PR_PO_STATUS"]
    df_pr_po_profile = source_dfs["PR_PO_PROFILE"]
    df_po_data_by_supplier_export = source_dfs["PO_DATA_BY_SUPPLIER_EXPORT"]
    df_cost_center_awarded_budget = source_dfs["COST_CENTER_AWARDED_BUDGET"]
    df_cost_center_budget = source_dfs["COST_CENTER_BUDGET"]
    df_cost_center_commitments = source_dfs["COST_CENTER_COMMITMENTS"]
    df_cost_center_current_budget = source_dfs["COST_CENTER_CURRENT_BUDGET"]
    df_cost_center_transaction_data = source_dfs["COST_CENTER_TRANSACTION_DATA"]
    df_internal_order_awarded_budget = source_dfs["INTERNAL_ORDER_AWARDED_BUDGET"]
    df_internal_order_budget = source_dfs["INTERNAL_ORDER_BUDGET"]
    df_internal_order_commitments = source_dfs["INTERNAL_ORDER_COMMITMENTS"]
    df_internal_order_current_budget = source_dfs["INTERNAL_ORDER_CURRENT_BUDGET"]
    df_internal_order_master_data = source_dfs["INTERNAL_ORDER_MASTER_DATA"]
    df_internal_order_transaction_data = source_dfs["INTERNAL_ORDER_TRANSACTION_DATA"]
    df_wbse_awarded_budget = source_dfs["WBSE_AWARDED_BUDGET"]
    df_wbse_budget = source_dfs["WBSE_BUDGET"]
    df_wbse_commitments = source_dfs["WBSE_COMMITMENTS"]
    df_wbse_current_budget = source_dfs["WBSE_CURRENT_BUDGET"]
    df_wbse_master_data = source_dfs["WBSE_MASTER_DATA"]
    df_wbse_transaction_data = source_dfs["WBSE_TRANSACTION_DATA"]

    source_dfs_dict = {
        'cost_center_master_data': df_cost_center_master_data,
        'pr_po_status': df_pr_po_status,
        'pr_po_profile': df_pr_po_profile,
        'po_data_by_supplier_export': df_po_data_by_supplier_export,
        'cost_center_awarded_budget': df_cost_center_awarded_budget,
        'cost_center_budget': df_cost_center_budget,
        'cost_center_commitments': df_cost_center_commitments,
        'cost_center_current_budget': df_cost_center_current_budget,
        'cost_center_transaction_data': df_cost_center_transaction_data,
        'internal_order_awarded_budget': df_internal_order_awarded_budget,
        'internal_order_budget': df_internal_order_budget,
        'internal_order_commitments': df_internal_order_commitments,
        'internal_order_current_budget': df_internal_order_current_budget,
        'internal_order_master_data': df_internal_order_master_data,
        'internal_order_transaction_data': df_internal_order_transaction_data,
        'wbse_awarded_budget': df_wbse_awarded_budget,
        'wbse_budget': df_wbse_budget,
        'wbse_commitments': df_wbse_commitments,
        'wbse_current_budget': df_wbse_current_budget,
        'wbse_master_data': df_wbse_master_data,
        'wbse_transaction_data': df_wbse_transaction_data
    }

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        dfs=source_dfs_dict
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage 
                                        configuration information.
        task_parameters (dict): A dictionary containing task parameters,
                                 including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
