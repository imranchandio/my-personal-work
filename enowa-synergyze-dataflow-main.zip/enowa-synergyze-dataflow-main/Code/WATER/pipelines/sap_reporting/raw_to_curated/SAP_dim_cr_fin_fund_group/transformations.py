from pyspark.sql import DataFrame, SparkSession, Row
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, StructType, StructField, TimestampType
import logging
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")
from common_utils import calculate_num_partitions, impose_schema, uuid5_hash, trim_spaces
from read_utils import read


def get_sql_query(source: str):
    """
    Returns an SQL query based on the specified source type.

    Args:
        source (str): The source type determining the query structure.
    """
    sql_query = ''
    if source in ["COST_CENTER_MASTER_DATA"]:
        sql_query = """
            SELECT
                REGION_CODE AS FUND_GROUP_CODE,
                REGION AS FUND_GROUP_NAME,
                NULL AS REQUESTING_FUND_GROUP,
                NULL AS RESPONSIBLE_FUND_GROUP,
                HIERARCHY_AREA AS HIERARCHY_GROUP,
                SUBREGION_CODE AS SEMI_GROUP_CODE
            FROM {source}
        """.format(source=source)

    elif source in [
        "COST_CENTER_AWARDED_BUDGET",
        "COST_CENTER_BUDGET",
        "COST_CENTER_COMMITMENTS",
        "COST_CENTER_CURRENT_BUDGET",
        "COST_CENTER_TRANSACTION_DATA"
    ]:
        sql_query = """
            SELECT
                NULL AS FUND_GROUP_CODE,
                REGION AS FUND_GROUP_NAME,
                NULL AS REQUESTING_FUND_GROUP,
                NULL AS RESPONSIBLE_FUND_GROUP,
                NULL AS HIERARCHY_GROUP,
                NULL AS SEMI_GROUP_CODE
            FROM {source}
        """.format(source=source)

    elif source in [
        "INTERNAL_ORDER_MASTER_DATA",
        "INTERNAL_ORDER_AWARDED_BUDGET",
        "INTERNAL_ORDER_BUDGET",
        "INTERNAL_ORDER_COMMITMENTS",
        "INTERNAL_ORDER_CURRENT_BUDGET",
        "INTERNAL_ORDER_TRANSACTION_DATA",
        "WBSE_MASTER_DATA",
        "WBSE_AWARDED_BUDGET",
        "WBSE_BUDGET",
        "WBSE_COMMITMENTS",
        "WBSE_CURRENT_BUDGET",
        "WBSE_TRANSACTION_DATA"
    ]:
        sql_query = """
            SELECT
                NULL AS FUND_GROUP_CODE,
                NULL AS FUND_GROUP_NAME,
                REQUESTING_REGION AS REQUESTING_FUND_GROUP,
                RESPONSIBLE_REGION AS RESPONSIBLE_FUND_GROUP,
                NULL AS HIERARCHY_GROUP,
                NULL AS SEMI_GROUP_CODE
            FROM {source}
        """.format(source=source)
    else:
        sql_query = """
            SELECT
                NULL AS FUND_GROUP_CODE,
                NULL AS FUND_GROUP_NAME,
                NULL AS REQUESTING_FUND_GROUP,
                NULL AS RESPONSIBLE_FUND_GROUP,
                NULL AS HIERARCHY_GROUP,
                NULL AS SEMI_GROUP_CODE
            FROM {source}
        """.format(source=source)

    return sql_query


def prepare_transformed_df(
        spark: SparkSession,
        dfs: dict
) -> DataFrame:
    logging.info("Starting the transformation process.")
    df_transformed = None
    for key, df in dfs.items():
        df.createOrReplaceTempView(key)
        logging.info(f"Created temporary view: {key}")
        sql_query = get_sql_query(str.upper(key))
        try:
            if df_transformed is None:
                df_transformed = spark.sql(sql_query)
            else:
                df_transformed = df_transformed.unionByName(spark.sql(sql_query))
        except Exception:
            print("ERROR occurred, printing source schema: ", df.printSchema())
            raise ValueError(f"Error occured at schema {key}")

    logging.info("All temporary views are created for SQL operations.")

    # List of columns for generating the key
    columns = [
        "FUND_GROUP_NAME",
        "REQUESTING_FUND_GROUP",
        "RESPONSIBLE_FUND_GROUP",
        "HIERARCHY_GROUP",
        "SEMI_GROUP_CODE"
    ]

    # Generate the key
    df_transformed = df_transformed.withColumn(
        "DIM_FUND_GROUP_ID",
        F.sha2(
            F.concat_ws(
                "||",
                *[F.coalesce(F.col(col), F.lit("-")) for col in columns]
            ),
            256
        )
    )

    # Remove duplicates in any
    df_transformed = df_transformed.distinct()

    # Technical metadata columns
    df_transformed = df_transformed.withColumn(
        "LAST_UPDATED_DATE", F.current_timestamp()
    ).withColumn(
        "CREATED_DATE", F.current_timestamp()
    )

    logging.info("Executed SQL query for data transformation.")

    print(
        "df_transformed schema before imposing schema:",
        df_transformed.printSchema()
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info(f"Repartitioning the DataFrame into {num_partitions} partitions.")

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters, returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_cost_center_master_data = source_dfs["COST_CENTER_MASTER_DATA"]
    df_cost_center_awarded_budget = source_dfs["COST_CENTER_AWARDED_BUDGET"]
    df_cost_center_budget = source_dfs["COST_CENTER_BUDGET"]
    df_cost_center_commitments = source_dfs["COST_CENTER_COMMITMENTS"]
    df_cost_center_current_budget = source_dfs["COST_CENTER_CURRENT_BUDGET"]
    df_cost_center_transaction_data = source_dfs["COST_CENTER_TRANSACTION_DATA"]
    df_internal_order_awarded_budget = source_dfs["INTERNAL_ORDER_AWARDED_BUDGET"]
    df_internal_order_budget = source_dfs["INTERNAL_ORDER_BUDGET"]
    df_internal_order_commitments = source_dfs["INTERNAL_ORDER_COMMITMENTS"]
    df_internal_order_current_budget = source_dfs["INTERNAL_ORDER_CURRENT_BUDGET"]
    df_internal_order_master_data = source_dfs["INTERNAL_ORDER_MASTER_DATA"]
    df_internal_order_transaction_data = source_dfs["INTERNAL_ORDER_TRANSACTION_DATA"]
    df_wbse_awarded_budget = source_dfs["WBSE_AWARDED_BUDGET"]
    df_wbse_budget = source_dfs["WBSE_BUDGET"]
    df_wbse_commitments = source_dfs["WBSE_COMMITMENTS"]
    df_wbse_current_budget = source_dfs["WBSE_CURRENT_BUDGET"]
    df_wbse_master_data = source_dfs["WBSE_MASTER_DATA"]
    df_wbse_transaction_data = source_dfs["WBSE_TRANSACTION_DATA"]

    source_dfs_dict = {
        'cost_center_master_data': df_cost_center_master_data,
        'cost_center_awarded_budget': df_cost_center_awarded_budget,
        'cost_center_budget': df_cost_center_budget,
        'cost_center_commitments': df_cost_center_commitments,
        'cost_center_current_budget': df_cost_center_current_budget,
        'cost_center_transaction_data': df_cost_center_transaction_data,
        'internal_order_awarded_budget': df_internal_order_awarded_budget,
        'internal_order_budget': df_internal_order_budget,
        'internal_order_commitments': df_internal_order_commitments,
        'internal_order_current_budget': df_internal_order_current_budget,
        'internal_order_master_data': df_internal_order_master_data,
        'internal_order_transaction_data': df_internal_order_transaction_data,
        'wbse_awarded_budget': df_wbse_awarded_budget,
        'wbse_budget': df_wbse_budget,
        'wbse_commitments': df_wbse_commitments,
        'wbse_current_budget': df_wbse_current_budget,
        'wbse_master_data': df_wbse_master_data,
        'wbse_transaction_data': df_wbse_transaction_data}

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        dfs=source_dfs_dict
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
