# pylint: disable = import-error
"""
    This is the transformation file for dim_cr_fin_fund_center dimension
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws, coalesce, col, lit
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_internal_order_awarded_budget: DataFrame,
        df_wbse_awarded_budget: DataFrame,
        df_cost_center_awarded_budget: DataFrame,
        df_cost_center_current_budget: DataFrame,
        df_wbse_current_budget: DataFrame,
        df_internal_order_current_budget: DataFrame,
        df_cost_center_budget: DataFrame,
        df_wbse_budget: DataFrame,
        df_internal_order_budget: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from the raw layer table passed in as DataFrame.
    '''
    logging.info("Starting the transformation process in prepare_transformed_df.")

    df_internal_order_awarded_budget.createOrReplaceTempView("INTERNAL_ORDER_AWARDED_BUDGET_SOURCE")
    df_wbse_awarded_budget.createOrReplaceTempView("WBSE_AWARDED_BUDGET_SOURCE")
    df_cost_center_awarded_budget.createOrReplaceTempView("COST_CENTER_AWARDED_BUDGET_SOURCE")
    df_internal_order_current_budget.createOrReplaceTempView("INTERNAL_ORDER_CURRENT_BUDGET_SOURCE")
    df_wbse_current_budget.createOrReplaceTempView("WBSE_CURRENT_BUDGET_SOURCE")
    df_cost_center_current_budget.createOrReplaceTempView("COST_CENTER_CURRENT_BUDGET_SOURCE")
    df_internal_order_budget.createOrReplaceTempView("INTERNAL_ORDER_BUDGET_SOURCE")
    df_wbse_budget.createOrReplaceTempView("WBSE_BUDGET_SOURCE")
    df_cost_center_budget.createOrReplaceTempView("COST_CENTER_BUDGET_SOURCE")

    logging.info("Executing SQL query for data transformation in prepare_transformed_df.")

    sql_query = """
                WITH CombinedSources AS (
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from INTERNAL_ORDER_AWARDED_BUDGET_SOURCE
                union
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from WBSE_AWARDED_BUDGET_SOURCE
                union
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from COST_CENTER_AWARDED_BUDGET_SOURCE
                union
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from INTERNAL_ORDER_CURRENT_BUDGET_SOURCE
                union
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from WBSE_CURRENT_BUDGET_SOURCE
                union
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from COST_CENTER_CURRENT_BUDGET_SOURCE
                union
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from INTERNAL_ORDER_BUDGET_SOURCE
                union
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from WBSE_BUDGET_SOURCE
                union
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from COST_CENTER_BUDGET_SOURCE
                )
                SELECT 
                    FUND_CENTER_NAME,
                    FUND_CENTER_CODE,
                    MAX(FUND_CENTER_DESCRIPTION) AS FUND_CENTER_DESCRIPTION
                FROM CombinedSources
                GROUP BY FUND_CENTER_NAME, FUND_CENTER_CODE;
            """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation in prepare_transformed_df")

    return df_transformed

def prepare_transformed_df_part(
        spark: SparkSession,
        df_cost_center_master_data: DataFrame,
        df_wbse_master_data: DataFrame,
        df_internal_order_master_data: DataFrame,
        df_cost_center_transaction_data: DataFrame,
        df_wbse_transaction_data: DataFrame,
        df_internal_order_transaction_data: DataFrame,
        df_internal_order_commitments: DataFrame,
        df_wbse_commitments: DataFrame,
        df_cost_center_commitments: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from the raw layer table passed in as DataFrame.
    '''
    logging.info("Starting the transformation process in prepare_transformed_df_part.")

    df_cost_center_master_data.createOrReplaceTempView("COST_CENTER_MASTER_DATA_SOURCE")
    df_wbse_master_data.createOrReplaceTempView("WBSE_MASTER_DATA_SOURCE")
    df_internal_order_master_data.createOrReplaceTempView("INTERNAL_ORDER_MASTER_DATA_SOURCE")
    df_cost_center_transaction_data.createOrReplaceTempView("COST_CENTER_TRANSACTION_DATA_SOURCE")
    df_wbse_transaction_data.createOrReplaceTempView("WBSE_TRANSACTION_DATA_SOURCE")
    df_internal_order_transaction_data.createOrReplaceTempView\
        ("INTERNAL_ORDER_TRANSACTION_DATA_SOURCE")
    df_internal_order_commitments.createOrReplaceTempView("INTERNAL_ORDER_COMMITMENTS_SOURCE")
    df_wbse_commitments.createOrReplaceTempView("WBSE_COMMITMENTS_SOURCE")
    df_cost_center_commitments.createOrReplaceTempView("COST_CENTER_COMMITMENTS_SOURCE")

    logging.info("Executing SQL query for data transformation in prepare_transformed_df_part.")

    sql_query = """
                WITH CombinedSources AS (
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from COST_CENTER_MASTER_DATA_SOURCE
                union
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from WBSE_MASTER_DATA_SOURCE
                union
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from INTERNAL_ORDER_MASTER_DATA_SOURCE
                union
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from COST_CENTER_TRANSACTION_DATA_SOURCE
                union
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from WBSE_TRANSACTION_DATA_SOURCE
                union
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from INTERNAL_ORDER_TRANSACTION_DATA_SOURCE
                union
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from INTERNAL_ORDER_COMMITMENTS_SOURCE
                union
                select distinct 
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                FUNDS_CENTER_DESC as FUND_CENTER_DESCRIPTION
                from WBSE_COMMITMENTS_SOURCE
                union
                select distinct
                FUND as FUND_CENTER_NAME,
                FUNDS_CENTER as FUND_CENTER_CODE,
                NULL as FUND_CENTER_DESCRIPTION
                from COST_CENTER_COMMITMENTS_SOURCE
                )
                SELECT 
                    FUND_CENTER_NAME,
                    FUND_CENTER_CODE,
                    MAX(FUND_CENTER_DESCRIPTION) AS FUND_CENTER_DESCRIPTION
                FROM CombinedSources
                GROUP BY FUND_CENTER_NAME, FUND_CENTER_CODE;
            """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation in prepare_transformed_df_part.")

    return df_transformed

def execute_transformed_df(
        spark: SparkSession,
        transform_df_part1: DataFrame,
        transform_df_part2: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from the raw layer table passed in as DataFrame.
    '''
    logging.info("Starting the transformation process.")

    transform_df_part1.createOrReplaceTempView("transform1")
    transform_df_part2.createOrReplaceTempView("transform2")

    logging.info("Executing SQL query for data transformation.")

    sql_query = """
                select distinct 
                FUND_CENTER_NAME,
                FUND_CENTER_CODE,
                FUND_CENTER_DESCRIPTION,
                current_timestamp() AS LAST_UPDATED_DATE,  
                current_timestamp() AS CREATED_DATE 
                from transform1
                union
                select distinct 
                FUND_CENTER_NAME,
                FUND_CENTER_CODE,
                FUND_CENTER_DESCRIPTION,
                current_timestamp() AS LAST_UPDATED_DATE,  
                current_timestamp() AS CREATED_DATE 
                from transform2
            """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation.")

    # List of columns for generating the key
    columns = [
        'FUND_CENTER_NAME',
        'FUND_CENTER_CODE',
        'FUND_CENTER_DESCRIPTION'
    ]

    # Generate the key
    df_transformed = df_transformed.withColumn(
        "DIM_FUND_CENTER_ID",
        sha2(
            concat_ws(
                "||",
                *[coalesce((col), lit("-")) for col in columns]
            ),
            256
        )
    )

    # df_transformed = df_transformed.withColumn(
    #     "DIM_FUND_CENTER_ID", sha2(concat_ws( "FUND_CENTER_NAME","FUND_CENTER_CODE" ), 256)
    # )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed

def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "COST_CENTER_MASTER_DATA": DataFrame for COST_CENTER_MASTER_DATA.
            - "WBSE_MASTER_DATA": DataFrame for WBSE_MASTER_DATA.
            - "INTERNAL_ORDER_MASTER_DATA": DataFrame for INTERNAL_ORDER_MASTER_DATA.
            - "COST_CENTER_TRANSACTION_DATA": DataFrame for COST_CENTER_TRANSACTION_DATA.
            - "WBSE_TRANSACTION_DATA": DataFrame for WBSE_TRANSACTION_DATA.
            - "INTERNAL_ORDER_TRANSACTION_DATA": DataFrame for INTERNAL_ORDER_TRANSACTION_DATA.
            - "INTERNAL_ORDER_COMMITMENTS": DataFrame for INTERNAL_ORDER_COMMITMENTS.
            - "WBSE_COMMITMENTS": DataFrame for WBSE_COMMITMENTS.
            - "COST_CENTER_COMMITMENTS": DataFrame for COST_CENTER_COMMITMENTS.
            - "COST_CENTER_AWARDED_BUDGET": DataFrame for COST_CENTER_AWARDED_BUDGET.
            - "WBSE_AWARDED_BUDGET": DataFrame for WBSE_AWARDED_BUDGET.
            - "INTERNAL_ORDER_AWARDED_BUDGET": DataFrame for INTERNAL_ORDER_AWARDED_BUDGET.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_cost_center_master_data = source_dfs["COST_CENTER_MASTER_DATA"]
    df_wbse_master_data = source_dfs["WBSE_MASTER_DATA"]
    df_internal_order_master_data = source_dfs["INTERNAL_ORDER_MASTER_DATA"]
    df_cost_center_transaction_data = source_dfs["COST_CENTER_TRANSACTION_DATA"]
    df_wbse_transaction_data = source_dfs["WBSE_TRANSACTION_DATA"]
    df_internal_order_transaction_data = source_dfs["INTERNAL_ORDER_TRANSACTION_DATA"]
    df_internal_order_commitments = source_dfs["INTERNAL_ORDER_COMMITMENTS"]
    df_wbse_commitments = source_dfs["WBSE_COMMITMENTS"]
    df_cost_center_commitments = source_dfs["COST_CENTER_COMMITMENTS"]
    df_cost_center_awarded_budget = source_dfs["COST_CENTER_AWARDED_BUDGET"]
    df_wbse_awarded_budget = source_dfs["WBSE_AWARDED_BUDGET"]
    df_internal_order_awarded_budget = source_dfs["INTERNAL_ORDER_AWARDED_BUDGET"]
    df_cost_center_current_budget = source_dfs["COST_CENTER_CURRENT_BUDGET"]
    df_wbse_current_budget = source_dfs["WBSE_CURRENT_BUDGET"]
    df_internal_order_current_budget = source_dfs["INTERNAL_ORDER_CURRENT_BUDGET"]
    df_cost_center_budget = source_dfs["COST_CENTER_BUDGET"]
    df_wbse_budget = source_dfs["WBSE_BUDGET"]
    df_internal_order_budget = source_dfs["INTERNAL_ORDER_BUDGET"]

    # Perform joins, filters, etc.
    transform_df_part1 = prepare_transformed_df(
        spark=spark,
        df_cost_center_awarded_budget=df_cost_center_awarded_budget,
        df_wbse_awarded_budget=df_wbse_awarded_budget,
        df_internal_order_awarded_budget=df_internal_order_awarded_budget,
        df_cost_center_current_budget=df_cost_center_current_budget,
        df_wbse_current_budget=df_wbse_current_budget,
        df_internal_order_current_budget=df_internal_order_current_budget,
        df_cost_center_budget=df_cost_center_budget,
        df_wbse_budget=df_wbse_budget,
        df_internal_order_budget=df_internal_order_budget
    )

    transform_df_part2 = prepare_transformed_df_part(
        spark=spark,
        df_cost_center_master_data=df_cost_center_master_data,
        df_wbse_master_data=df_wbse_master_data,
        df_internal_order_master_data=df_internal_order_master_data,
        df_cost_center_transaction_data=df_cost_center_transaction_data,
        df_wbse_transaction_data=df_wbse_transaction_data,
        df_internal_order_transaction_data=df_internal_order_transaction_data,
        df_internal_order_commitments=df_internal_order_commitments,
        df_wbse_commitments=df_wbse_commitments,
        df_cost_center_commitments=df_cost_center_commitments
    )

    transform_df = execute_transformed_df(
        spark=spark,
        transform_df_part1=transform_df_part1,
        transform_df_part2=transform_df_part2
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
) -> DataFrame:
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
