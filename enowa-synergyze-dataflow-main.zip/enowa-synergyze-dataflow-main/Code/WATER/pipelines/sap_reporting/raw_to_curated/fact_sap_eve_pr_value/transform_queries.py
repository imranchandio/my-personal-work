PR_PO_STATUS = """
    WITH DIM_CR_CORP_DOCUMENT_CTE
    AS (
        SELECT *
        FROM DIM_CR_CORP_DOCUMENT
        WHERE PURCHASING_DOC_NO IS NULL 
        AND DOCUMENT_NUMBER IS NULL
        )
    SELECT NULL AS DIM_COMPANY_UNIT_ID
        ,NULL AS DIM_COST_CENTER_ID
        ,NULL AS DIM_WORK_ORDER_ID
        ,proc_pr.DIM_PR_ID
        ,NULL AS DIM_PR_PO_ID
        ,ck.customer_kind_id
        ,NULL AS DIM_AGREEMENT_ID
        ,doc.DIM_DOCUMENT_ID
        ,cust.dim_customer_id
        ,supp.DIM_WATERQA_SUPPLIER_ID
        ,NULL AS DIM_ORG_DEPT_ID
        ,NULL AS PR_ITEM_COUNT
        ,NULL AS PR_VALUE_SAR
        ,NULL AS DELETION_INDICATOR
        ,NULL AS OPEX_CAPEX
        ,po.total_value_sar AS total_value_sar
        ,NULL AS NET_VALUE_SAR
        ,NULL AS PAID_VALUE_SAR
        ,po.stream_spend AS STREAM_SPEND
        ,po.WORKDAY AS WORKDAY
        ,po.BUCKETS AS BUCKETS
        ,'PR PO STATUS' AS PR_VALUE_SOURCE
    FROM PR_PO_STATUS_SOURCE po
    LEFT JOIN dim_cr_cus_customer_kind_sap ck 
        ON po.sector_spend = ck.CUSTOMER_KIND_SECTOR
        AND ck.CUSTOMER_KIND_SECTOR_CODE is null
    LEFT JOIN dim_cr_cus_customer_sap cust 
        ON po.buyer = cust.customer_name_en
    LEFT JOIN (
        SELECT DISTINCT DIM_WATERQA_SUPPLIER_ID
            ,SUPPLIER_CODE
            ,SUPPLIER_NAME
        FROM dim_wa_org_waterqa_supplier_sap
        WHERE GCFA_SUPPLIER_CODE IS NULL AND SUPPLIER_TYPE = 'SAP PR'
        ) supp ON po.supplier = trim(supp.SUPPLIER_CODE || ' ' || supp.SUPPLIER_NAME)
    LEFT JOIN DIM_CR_CORP_DOCUMENT_CTE doc 
        ON po.DOC_TYPE = doc.DOCUMENT_TYPE
    LEFT JOIN DIM_CR_PROC_PR proc_pr 
        ON coalesce(po.PR, ' ') = coalesce(proc_pr.PURCHASE_REQUISITION, ' ')
        AND coalesce(po.SHORT_TEXT, ' ') = coalesce(proc_pr.PR_SHORT_TEXT, ' ')
        AND coalesce(po.ROUTE, ' ') = coalesce(proc_pr.PROCUREMENT_ROUTE, ' ')
        AND coalesce(po.ROUTE_GROUPS, ' ') = coalesce(proc_pr.PROCUREMENT_ROUTE_GROUP, ' ')
        AND coalesce(po.CREATION_DATE, ' ') = coalesce(proc_pr.PR_CREATION_DATE, ' ')
        AND coalesce(po.STATUS, ' ') = coalesce(proc_pr.PR_STATUS, ' ')
        AND coalesce(po.MATERIAL_SERVICE, ' ') = coalesce(proc_pr.IS_MATERIAL_SERVICE, ' ')
        AND coalesce(po.WITH_WITHOUT_PO, ' ') = coalesce(proc_pr.PO_AVAILABILITY, ' ')
        AND coalesce(po.PURCHASING_GROUP_FULL, ' ') = coalesce(proc_pr.PR_GROUP, ' ')
        AND coalesce(po.APPROVAL_REJECTION_DATE, ' ') = coalesce(proc_pr.PR_LATEST_APPROVAL_DATE, ' ')
        AND coalesce(po.TAXONOMY_1, ' ') = coalesce(proc_pr.TAXONOMY_1, ' ')
        AND coalesce(po.TAXONOMY_2, ' ') = coalesce(proc_pr.TAXONOMY_2, ' ')
        AND coalesce(po.TAXONOMY_3, ' ') = coalesce(proc_pr.TAXONOMY_3, ' ')     
        AND proc_pr.DATA_SOURCE = 'PR_PO_STATUS'   
"""

PR_PO_PROFILE = """
    WITH DIM_CR_CORP_DOCUMENT_CTE
    AS (
        SELECT *
        FROM DIM_CR_CORP_DOCUMENT
        WHERE PURCHASING_DOC_NO IS NULL
        )
    SELECT NULL AS DIM_COMPANY_UNIT_ID
        ,NULL AS DIM_COST_CENTER_ID
        ,NULL AS DIM_WORK_ORDER_ID
        ,proc_pr.DIM_PR_ID
        ,proc_po.DIM_PR_PO_ID
        ,ck.customer_kind_id
        ,NULL AS DIM_AGREEMENT_ID
        ,doc.DIM_DOCUMENT_ID
        ,cust.dim_customer_id
        ,supp.DIM_WATERQA_SUPPLIER_ID
        ,NULL AS DIM_ORG_DEPT_ID
        ,NULL AS PR_ITEM_COUNT
        ,NULL AS PR_VALUE_SAR
        ,NULL AS DELETION_INDICATOR
        ,NULL AS OPEX_CAPEX
        ,po.total_value_sar AS total_value_sar
        ,NULL AS NET_VALUE_SAR
        ,NULL AS PAID_VALUE_SAR
        ,po.stream_spend AS STREAM_SPEND
        ,po.WORKDAY AS WORKDAY
        ,po.BUCKETS AS BUCKETS
        ,'PR PO PROFILE' AS PR_VALUE_SOURCE
    FROM PR_PO_PROFILE_SOURCE po
    LEFT JOIN dim_cr_cus_customer_kind_sap ck ON po.sector_spend = ck.CUSTOMER_KIND_SECTOR
        AND ck.CUSTOMER_KIND_SECTOR_CODE is null
    LEFT JOIN dim_cr_cus_customer_sap cust ON po.buyer = cust.customer_name_en
    LEFT JOIN DIM_CR_CORP_DOCUMENT_CTE doc ON po.DOC_TYPE = doc.DOCUMENT_TYPE
    LEFT JOIN (
        SELECT DISTINCT DIM_WATERQA_SUPPLIER_ID
            ,SUPPLIER_CODE
            ,SUPPLIER_NAME
        FROM dim_wa_org_waterqa_supplier_sap
        WHERE GCFA_SUPPLIER_CODE IS NULL AND SUPPLIER_TYPE = 'SAP PR'
        ) supp ON po.supplier = trim(supp.SUPPLIER_CODE || ' ' || supp.SUPPLIER_NAME)
    LEFT JOIN DIM_CR_PROC_PR proc_pr 
        ON coalesce(po.PR, ' ') = coalesce(proc_pr.PURCHASE_REQUISITION, ' ')
        AND coalesce(po.SHORT_TEXT, ' ') = coalesce(proc_pr.PR_SHORT_TEXT, ' ')
        AND coalesce(po.ROUTE, ' ') = coalesce(proc_pr.PROCUREMENT_ROUTE, ' ')
        AND coalesce(po.ROUTE_GROUPS, ' ') = coalesce(proc_pr.PROCUREMENT_ROUTE_GROUP, ' ')
        AND coalesce(po.CREATION_DATE, ' ') = coalesce(proc_pr.PR_CREATION_DATE, ' ')
        AND coalesce(po.STATUS, ' ') = coalesce(proc_pr.PR_STATUS, ' ')
        AND coalesce(po.MATERIAL_SERVICE, ' ') = coalesce(proc_pr.IS_MATERIAL_SERVICE, ' ')
        AND coalesce(po.WITH_WITHOUT_PO, ' ') = coalesce(proc_pr.PO_AVAILABILITY, ' ')
        AND coalesce(po.PURCHASING_GROUP_FULL, ' ') = coalesce(proc_pr.PR_GROUP, ' ')
        AND coalesce(po.APPROVAL_REJECTION_DATE, ' ') = coalesce(proc_pr.PR_LATEST_APPROVAL_DATE, ' ')
        AND coalesce(po.TAXONOMY_1, ' ') = coalesce(proc_pr.TAXONOMY_1, ' ')
        AND coalesce(po.TAXONOMY_2, ' ') = coalesce(proc_pr.TAXONOMY_2, ' ')
        AND coalesce(po.TAXONOMY_3, ' ') = coalesce(proc_pr.TAXONOMY_3, ' ')    
        AND proc_pr.DATA_SOURCE = 'PR_PO_PROFILE'
    LEFT JOIN DIM_CR_PROC_PO proc_po
        ON proc_po.DATA_SOURCE = 'PR_PO_PROFILE'
        AND proc_po.PO_NUMBER is not null
        AND po.PO = proc_po.PO_NUMBER
        AND proc_pr.DIM_PR_ID = proc_po.DIM_PR_ID
"""

PO_DATA_BY_SUPPLIER = """
    SELECT distinct NULL AS DIM_COMPANY_UNIT_ID
        ,NULL AS DIM_COST_CENTER_ID
        ,NULL AS DIM_WORK_ORDER_ID
        ,proc_pr.DIM_PR_ID
        --,NULL as DIM_PR_ID
        ,proc_po.DIM_PR_PO_ID
        ,ck.customer_kind_id
        ,agr.DIM_AGREEMENT_ID
        ,doc.DIM_DOCUMENT_ID
        ,cust.dim_customer_id
        ,supp.DIM_WATERQA_SUPPLIER_ID
        ,NULL AS DIM_ORG_DEPT_ID
        ,po.item AS PR_ITEM_COUNT
        ,NULL AS PR_VALUE_SAR
        ,NULL AS DELETION_INDICATOR
        ,NULL AS OPEX_CAPEX
        ,po.total_value_sar AS total_value_sar
        ,po.net_value_sar AS NET_VALUE_SAR
        ,po.paid_value_sar AS PAID_VALUE_SAR
        ,po.stream_spend AS STREAM_SPEND
        ,NULL AS WORKDAY
        ,NULL AS BUCKETS
        ,'PR PO BY SUPPLIER' AS PR_VALUE_SOURCE
    FROM PO_DATA_BY_SUPPLIER_EXPORT_SOURCE po
    LEFT JOIN dim_cr_cus_customer_kind_sap ck ON po.sector_spend = ck.CUSTOMER_KIND_SECTOR
        AND ck.CUSTOMER_KIND_SECTOR_CODE is null
    LEFT JOIN dim_cr_agr_agreement agr ON po.outline_agreement = agr.OUTLINE_AGREEMENT_CONSOLIDATED
        AND po.gcfa_version = agr.AGREEMENT_VERSION
        AND po.gcfa_agreement = agr.OUTLINE_AGREEMENT_SAP
    LEFT JOIN dim_cr_cus_customer_sap cust ON po.buyer = cust.customer_name_en
    LEFT JOIN (
        SELECT DISTINCT DIM_WATERQA_SUPPLIER_ID
            ,SUPPLIER_CODE
            ,SUPPLIER_NAME
            ,GCFA_SUPPLIER_CODE
        FROM dim_wa_org_waterqa_supplier_sap
        where SUPPLIER_TYPE = 'SAP PR'
        ) supp 
            ON po.supplier = trim(supp.SUPPLIER_CODE || ' ' || supp.SUPPLIER_NAME)
            AND po.GCFA_SUPPLIER_CODE = supp.GCFA_SUPPLIER_CODE        
    LEFT JOIN DIM_CR_PROC_PR proc_pr 
        ON coalesce(po.PURCHASE_REQUISITION, ' ') = coalesce(proc_pr.PURCHASE_REQUISITION, ' ')
        AND coalesce(po.SHORT_TEXT, ' ') = coalesce(proc_pr.PR_SHORT_TEXT, ' ')
        AND coalesce(po.ROUTES, ' ') = coalesce(proc_pr.PROCUREMENT_ROUTE, ' ')
        AND coalesce(po.ROUTE_GROUPS, ' ') = coalesce(proc_pr.PROCUREMENT_ROUTE_GROUP, ' ')
        AND coalesce(po.MATERIAL_SERVICE, ' ') = coalesce(proc_pr.IS_MATERIAL_SERVICE, ' ')
        AND coalesce(po.APPROVAL_REJECTION_DATE, ' ') = coalesce(proc_pr.PR_LATEST_APPROVAL_DATE, ' ')
        AND coalesce(po.APPROVER_NAME, ' ') = coalesce(proc_pr.APPROVER_NAME, ' ')
        AND coalesce(po.COUNTRY_NAME, ' ') = coalesce(proc_pr.PR_COUNTRY, ' ')
        AND coalesce(po.SAUDI_NONSAUDI, ' ') = coalesce(proc_pr.SAUDI_NONSAUDI, ' ')
        AND coalesce(po.TAXONOMY_1, ' ') = coalesce(proc_pr.TAXONOMY_1, ' ')
        AND coalesce(po.TAXONOMY_2, ' ') = coalesce(proc_pr.TAXONOMY_2, ' ')
        AND coalesce(po.TAXONOMY_3, ' ') = coalesce(proc_pr.TAXONOMY_3, ' ')    
        AND coalesce(po.PURCHASING_GROUP_FULL, ' ') = coalesce(proc_pr.PR_GROUP, ' ')
        AND proc_pr.DATA_SOURCE = 'PO_DATA_BY_SUPPLIER'
    LEFT JOIN DIM_CR_CORP_DOCUMENT doc
        ON coalesce(po.PURCHASING_DOCUMENT, '-') = coalesce(doc.PURCHASING_DOC_NO, '-')
        AND coalesce(po.DOCUMENT_DATE, '-') = coalesce(doc.DOCUMENT_DATE, '-')    
        AND doc.DOCUMENT_CATEGORY = 'PR DOCUMENT'
    LEFT JOIN DIM_CR_PROC_PO proc_po
        ON proc_po.DATA_SOURCE = 'PO_DATA_BY_SUPPLIER'
        AND po.PO_STATUS = proc_po.PO_STATUS
        AND po.PO_SHELL = proc_po.PO_SHELL
        AND po.ACTIVE_CLOSED = proc_po.ACTIVE_OR_CLOSED
        AND proc_pr.DIM_PR_ID = proc_po.DIM_PR_ID
"""
