# pylint:disable = C0301

# OCID: ocid1.dataflowapplication.oc1.me-jeddah-1.anvgkljrsvwgetyagpdnlrbxrpmpcqhlyfchors54aa3xzvzodoirka3nv4q

import logging
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")

from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from common_utils import calculate_num_partitions, impose_schema, trim_spaces
from read_utils import read
import transform_queries as queries
from common_utils import standardize_numeric_data


def prepare_transformed_df(**kwargs) -> DataFrame:
    logging.info("Starting the transformation process.")

    dataframes = {
        "PR_PO_STATUS_SOURCE": "df_pr_po_status",
        "PR_PO_PROFILE_SOURCE": "df_pr_po_profile",
        "PO_DATA_BY_SUPPLIER_EXPORT_SOURCE": "df_po_data_by_supplier_export",
        "DIM_CR_PROC_PR": "df_dim_cr_proc_pr",
        "DIM_CR_PROC_PO": "df_dim_cr_proc_po",
        "DIM_CR_CUS_CUSTOMER_KIND_SAP": "df_dim_cr_cus_customer_kind_sap",
        "DIM_CR_AGR_AGREEMENT": "df_dim_cr_agr_agreement",
        "DIM_CR_CORP_DOCUMENT": "df_dim_cr_corp_document",
        "DIM_CR_CUS_CUSTOMER_SAP": "df_dim_cr_cus_customer_sap",
        "DIM_WA_ORG_WATERQA_SUPPLIER_SAP": "df_dim_wa_org_waterqa_supplier_sap",
    }

    for view_name, df_key in dataframes.items():
        kwargs.get(df_key).createOrReplaceTempView(view_name)

    # Execute the SQL query to generate the output DataFrame
    df_pr_po_status_transformed = kwargs.get("spark").sql(queries.PR_PO_STATUS)
    df_pr_po_profile_transformed = kwargs.get("spark").sql(queries.PR_PO_PROFILE)
    df_po_data_by_supp_transformed = kwargs.get("spark").sql(queries.PO_DATA_BY_SUPPLIER)

    df_transformed = (
        df_pr_po_status_transformed
        .unionByName(df_pr_po_profile_transformed)
        .unionByName(df_po_data_by_supp_transformed)
    )

    numeric_columns = ["TOTAL_VALUE_SAR", "NET_VALUE_SAR", "PAID_VALUE_SAR"]

    df_transformed = standardize_numeric_data(
        df=df_transformed,
        numeric_columns=numeric_columns
    )

    # List of columns for generating the key
    columns = [
        'DIM_COMPANY_UNIT_ID', 'DIM_COST_CENTER_ID', 'DIM_WORK_ORDER_ID',
        'DIM_PR_ID', 'DIM_PR_PO_ID', 'CUSTOMER_KIND_ID', 'DIM_Agreement_ID',
        'DIM_DOCUMENT_ID', 'DIM_CUSTOMER_ID', 'DIM_WATERQA_SUPPLIER_ID',
        'DIM_ORG_DEPT_ID', 'PR_ITEM_COUNT', 'PR_VALUE_SAR', 'DELETION_INDICATOR',
        'OPEX_CAPEX', 'TOTAL_VALUE_SAR', 'NET_VALUE_SAR', 'PAID_VALUE_SAR',
        'STREAM_SPEND', 'WORKDAY', 'BUCKETS', 'PR_VALUE_SOURCE'
    ]

    # Generate the key
    df_transformed = df_transformed.withColumn(
        "FACT_PR_VALUE_ID",
        F.sha2(
            F.concat_ws(
                "||",
                *[F.coalesce(F.col(col), F.lit("-")) for col in columns]
            ),
            256
        )
    )

    # Remove duplicates in any
    df_transformed = df_transformed.distinct()

    # Technical metadata columns
    df_transformed = df_transformed.withColumn(
        "LAST_UPDATED_DATE", F.current_timestamp()
    ).withColumn(
        "CREATED_DATE", F.current_timestamp()
    )

    print(
        "df_transformed schema before imposing schema:",
        df_transformed.printSchema()
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 1024
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info(
        f"Repartitioning the DataFrame into {num_partitions} partitions."
    )

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def prepare_pr_po_status_data(df_pr_po_status: DataFrame):
    # List of columns for generating the key
    columns = [
        "PURCHASE_REQUISITION", "PR_OBJECT_NUMBER", "PR_SHORT_TEXT", "PROCUREMENT_ROUTE",
        "PROCUREMENT_ROUTE_GROUP", "PR_CREATION_DATE", "PR_STATUS", "IS_MATERIAL_SERVICE",
        "PO_AVAILABILITY", "PR_GROUP", "PR_LATEST_APPROVAL_DATE", "APPROVER_NAME",
        "PR_DOMAIN_TYPE", "PR_SUB_DOMAIN_TYPE", "PR_TYPE", "PR_COUNTRY",
        "SAUDI_NONSAUDI", "TAXONOMY_1", "TAXONOMY_2", "TAXONOMY_3", "DATA_SOURCE"
    ]

    # Generate the key
    df_pr_po_status = df_pr_po_status.withColumn(
        "DIM_PR_ID",
        F.sha2(
            F.concat_ws(
                "||",
                *[F.coalesce(F.col(col), F.lit("-")) for col in columns]
            ),
            256
        )
    )

    return df_pr_po_status


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters, returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_pr_po_status = source_dfs["PR_PO_STATUS"]
    df_pr_po_profile = source_dfs["PR_PO_PROFILE"]
    df_po_data_by_supplier_export = source_dfs["PO_DATA_BY_SUPPLIER_EXPORT"]
    df_dim_cr_proc_pr = source_dfs["DIM_CR_PROC_PR"]
    df_dim_cr_proc_po = source_dfs["DIM_CR_PROC_PO"]
    df_dim_cr_cus_customer_kind_sap = source_dfs["DIM_CR_CUS_CUSTOMER_KIND_SAP"]
    df_dim_cr_agr_agreement = source_dfs["DIM_CR_AGR_AGREEMENT"]
    df_dim_cr_corp_document = source_dfs["DIM_CR_CORP_DOCUMENT"]
    df_dim_cr_cus_customer_sap = source_dfs["DIM_CR_CUS_CUSTOMER_SAP"]
    df_dim_wa_org_waterqa_supplier_sap = source_dfs["DIM_WA_ORG_WATERQA_SUPPLIER_SAP"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_pr_po_status=df_pr_po_status,
        df_pr_po_profile=df_pr_po_profile,
        df_po_data_by_supplier_export=df_po_data_by_supplier_export,
        df_dim_cr_proc_pr=df_dim_cr_proc_pr,
        df_dim_cr_proc_po=df_dim_cr_proc_po,
        df_dim_cr_cus_customer_kind_sap=df_dim_cr_cus_customer_kind_sap,
        df_dim_cr_agr_agreement=df_dim_cr_agr_agreement,
        df_dim_cr_corp_document=df_dim_cr_corp_document,
        df_dim_cr_cus_customer_sap=df_dim_cr_cus_customer_sap,
        df_dim_wa_org_waterqa_supplier_sap=df_dim_wa_org_waterqa_supplier_sap
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
