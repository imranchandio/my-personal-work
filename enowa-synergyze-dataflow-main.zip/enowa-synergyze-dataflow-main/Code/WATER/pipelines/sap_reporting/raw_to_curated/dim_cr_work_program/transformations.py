# pylint:disable=unused-argument, import-error
"""
    This is the transformation file for dim_cr_fin_controlling_unit dimension
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")

def prepare_transformed_df(
        spark: SparkSession,
        df_wbse_awarded_budget: DataFrame,
        df_wbse_budget: DataFrame,
        df_wbse_commitments: DataFrame,
        df_current_budget: DataFrame,
        df_wbse_master_budget: DataFrame

) -> DataFrame:
    '''
        This function prepares the dataframe based on business logic for DIM_CR_CORP_DOCUMENT.
    '''
    logging.info("Starting the transformation process.")

    # Create temp views to use SQL on DataFrames
    df_wbse_awarded_budget.createOrReplaceTempView("WBSE_AWARDED_BUDGET")
    df_wbse_budget.createOrReplaceTempView("WBSE_BUDGET")
    df_wbse_commitments.createOrReplaceTempView("WBSE_COMMITMENTS")
    df_current_budget.createOrReplaceTempView("WBSE_CURRENT_BUDGET")
    df_wbse_master_budget.createOrReplaceTempView("WBSE_MASTER_DATA")


    sql_query = """
SELECT 
    PROGRAM_DEFINITION_KEY, 
    PROGRAM_DEFINITION_DESC, 
    CURRENT_TIMESTAMP() AS LAST_UPDATED_DATE,
    CURRENT_TIMESTAMP() AS CREATED_DATE 
FROM WBSE_AWARDED_BUDGET
UNION ALL
SELECT 
    Program_Definition_Key, 
    NULL, 
    CURRENT_TIMESTAMP() AS LAST_UPDATED_DATE,
    CURRENT_TIMESTAMP() AS CREATED_DATE 
FROM WBSE_BUDGET
UNION ALL
SELECT 
    PROGRAM_DEFINITION_KEY, 
    NULL, 
    CURRENT_TIMESTAMP() AS LAST_UPDATED_DATE,
    CURRENT_TIMESTAMP() AS CREATED_DATE 
FROM WBSE_COMMITMENTS
UNION ALL
SELECT 
    Program_Definition_Key, 
    Program_Definition_Desc, 
    CURRENT_TIMESTAMP() AS LAST_UPDATED_DATE,
    CURRENT_TIMESTAMP() AS CREATED_DATE 
FROM WBSE_CURRENT_BUDGET
UNION ALL
SELECT 
    Program_Definition_Key, 
    Program_Definition_Desc, 
    CURRENT_TIMESTAMP() AS LAST_UPDATED_DATE,
    CURRENT_TIMESTAMP() AS CREATED_DATE 
FROM WBSE_MASTER_DATA;


    """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation.")

    df_transformed = df_transformed.withColumn(
        "DIM_PROGRAM_ID", sha2(concat_ws("||", "PROGRAM_DEFINITION_KEY", "PROGRAM_DEFINITION_DESC"), 256)
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
           

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_wbse_awarded_budget = source_dfs["WBSE_AWARDED_BUDGET"]
    df_wbse_budget = source_dfs["WBSE_BUDGET"]
    df_wbse_commitments = source_dfs["WBSE_COMMITMENTS"]
    df_current_budget = source_dfs["WBSE_CURRENT_BUDGET"]
    df_wbse_master_budget = source_dfs["WBSE_MASTER_DATA"]


    # Apply transformations based on business logic
    transform_df = prepare_transformed_df(
        spark=spark,
        df_wbse_awarded_budget=df_wbse_awarded_budget,
        df_wbse_budget=df_wbse_budget,
        df_wbse_commitments=df_wbse_commitments,
        df_current_budget=df_current_budget,
        df_wbse_master_budget=df_wbse_master_budget
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print("spark_df schema:", spark_df.printSchema())

    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
