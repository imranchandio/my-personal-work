"""
Module: sample_exclude
Description: Process data from raw to curated for the sample_exclude.
It contains the necessary functions and logic to create sample_exclude table in curated.

Author: Vaishnavi Ruikar
Date: 14-10-2024
"""


def main(spark, spark_df, **kwargs):  # pylint: disable = unused-argument
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name = kwargs.get('task_name')
    print("Spark session:", spark)
    if task_name == "data_movement_task":
        print("transformations - main")
        return spark_df
    return None
