from pyspark.sql import DataFrame, SparkSession
import logging
from common_utils import (
    calculate_num_partitions,
    impose_schema,
    uuid5_hash,
    standardize_date_format
)
from read_utils import read


def prepare_transformed_df(
        spark: SparkSession,
        df_location_mapping_raw: DataFrame,
) -> DataFrame:
    logging.info("Starting the transformation process for location attributes.")

    logging.info(
        "Removed duplicate records from all the sources and Created temporary views"
    )

    df_location_mapping_raw = df_location_mapping_raw.distinct()
    df_location_mapping_raw.createOrReplaceTempView("location_mapping_raw")

    df_transformed = spark.sql("""select * from location_mapping_raw""")

    logging.info("Executed SQL query for data transformation.")

    max_partition_size_mb = 256
    logging.info("Calculating the number of partitions.")
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)
    logging.info(f"Repartitioning DataFrame into {num_partitions} partitions.")

    df_transformed = df_transformed.repartition(num_partitions)

    logging.info("Transformation process completed.")
    return df_transformed


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrame by performing necessary transformations and returns the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with the key "LOCATION_ATTRIBUTE".

    Returns:
        DataFrame: The transformed DataFrame.
    """
    logging.info("Starting the transformation process.")

    df_location_mapping_raw: DataFrame = source_dfs["raw_os_storage"].distinct()

    # Perform joins, filters, etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_location_mapping_raw=df_location_mapping_raw
    )
    logging.info("Data transformation completed.")
    logging.info("Transformation completed successfully..")

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def presentation_datavalidations(spark, spark_df):
    print("Inside presentation_datavalidations")
    print("spark::", spark)
    return spark_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """

    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "50MB")

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    elif task_name == "adw_presentation_data_validations_checks":
        print("transformations - adw_presentation_data_validations_checks")
        return presentation_datavalidations(spark, spark_df)
