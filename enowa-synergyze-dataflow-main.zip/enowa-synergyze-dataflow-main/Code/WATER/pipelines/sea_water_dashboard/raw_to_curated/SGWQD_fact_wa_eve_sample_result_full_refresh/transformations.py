from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
import logging
from pyspark import StorageLevel
from common_utils import (
    calculate_num_partitions,
    impose_schema,
    get_latest_partition,
    merge_dataframes,
    apply_als_exclusions,
    get_list_of_reporting_dates,
    perform_reorder_and_als_deduplication,
    trim_spaces
)
from read_utils import read

SAMPLE_PARAMETER_VALUE = "SAMPLE_PARAMETER_VALUE"
RECEIVED_DATE = "ReceivedDate"
SAMPLING_DATE = "SamplingDate"


def prepare_dim_wa_op_sample_data(spark: SparkSession, df_dim_wa_op_sample: DataFrame):
    df_dim_wa_op_sample.createOrReplaceTempView("DIM_WA_OP_SAMPLE")
    sql_query = """
        SELECT sample.*
        FROM DIM_WA_OP_SAMPLE sample
        INNER JOIN (
            SELECT DIM_SAMPLE_ID
                ,max(REPORTING_DATE) AS MAX_REPORTING_DATE
            FROM DIM_WA_OP_SAMPLE
            GROUP BY DIM_SAMPLE_ID
            ) max_sample ON sample.DIM_SAMPLE_ID = max_sample.DIM_SAMPLE_ID
            AND sample.REPORTING_DATE = max_sample.MAX_REPORTING_DATE 
    """
    return spark.sql(sql_query).distinct()


def drop_duplicates_from_sample_result(spark: SparkSession, df: DataFrame) -> DataFrame:
    """
    Removes duplicate records from a DataFrame based on specific columns and criteria using SQL logic.

    This function identifies and removes duplicates by grouping rows based on the columns:
    'DIM_SAMPLE_ID', 'SAMPLE_CAPTURE_DATE', 'PARAMETER_MAPPING_PARAMETER_NAME',
    'LOCATION_MAPPING_LOCATION_NAME', and 'SAMPLE_DESCRIPTION'. The deduplication logic is as follows:

    - If a group has multiple records (record count > 1) and at least one of them has a status
      of 'Pending', the 'Pending' record(s) are flagged for removal.
    - Records that are not flagged as 'Pending' are kept.

    The function uses two common table expressions (CTEs):
    1. `count_cte`: Counts the total number of records and the number of 'Pending' records in each group.
    2. `dedup_cte`: Flags records for removal or keeps them based on the deduplication logic.

    Args:
        spark (SparkSession): The Spark session object.
        df (DataFrame): The input DataFrame containing sample result data.

    Returns:
        DataFrame: A DataFrame with duplicates removed according to the defined criteria.
    """
    # Create a temporary view of the DataFrame for SQL operations
    df.createOrReplaceTempView("sample_result")
    df_cols = df.columns

    # SQL query to perform deduplication using CTEs
    sql_query = """
    WITH distinct_cte as (
        select distinct DIM_SAMPLE_ID, 
                    SAMPLE_CAPTURE_DATE,
                    PARAMETER_MAPPING_PARAMETER_NAME,
                    LOCATION_MAPPING_LOCATION_NAME,
                    SAMPLE_DESCRIPTION,
                    SAMPLE_TEST_STATUS
        FROM  sample_result     
    )    
    ,count_cte AS (
        SELECT 
            DIM_SAMPLE_ID, 
            SAMPLE_CAPTURE_DATE, 
            PARAMETER_MAPPING_PARAMETER_NAME, 
            LOCATION_MAPPING_LOCATION_NAME, 
            SAMPLE_DESCRIPTION,
            COUNT(*) AS record_count,
            SUM(CASE WHEN UPPER(SAMPLE_TEST_STATUS) = 'PENDING' THEN 1 ELSE 0 END) AS pending_count
        FROM distinct_cte
        GROUP BY 
            DIM_SAMPLE_ID, 
            SAMPLE_CAPTURE_DATE, 
            PARAMETER_MAPPING_PARAMETER_NAME, 
            LOCATION_MAPPING_LOCATION_NAME, 
            SAMPLE_DESCRIPTION
    ),
    dedup_cte AS (
        SELECT 
            res.*,
            CASE 
                WHEN cte.record_count > 1 
                     AND cte.pending_count > 0 
                     AND res.SAMPLE_TEST_STATUS = 'Pending' 
                THEN 'Remove' 
                ELSE 'Keep' 
            END AS dedup_flag
        FROM sample_result res
        LEFT JOIN count_cte cte ON
            res.DIM_SAMPLE_ID = cte.DIM_SAMPLE_ID AND
            COALESCE(res.SAMPLE_CAPTURE_DATE, '') = COALESCE(cte.SAMPLE_CAPTURE_DATE, '') AND 
            COALESCE(res.PARAMETER_MAPPING_PARAMETER_NAME, '') = COALESCE(cte.PARAMETER_MAPPING_PARAMETER_NAME, '') AND 
            COALESCE(res.LOCATION_MAPPING_LOCATION_NAME, '') = COALESCE(cte.LOCATION_MAPPING_LOCATION_NAME, '') AND 
            COALESCE(res.SAMPLE_DESCRIPTION, '') = COALESCE(cte.SAMPLE_DESCRIPTION, '')
    )
    SELECT * FROM dedup_cte WHERE dedup_flag = 'Keep'
    """

    # Execute the SQL query and select only the original columns
    df_deduped = spark.sql(sql_query).select(*df_cols)

    return df_deduped


def prepare_als_active_data(
        spark: SparkSession,
        df_als_active: DataFrame,
        df_parameter_mapping: DataFrame,
        df_parameter_attribute: DataFrame,
        df_location_mapping: DataFrame,
        df_location_attribute: DataFrame,
        df_dim_cr_loc_location: DataFrame,
        df_dim_wa_reg_parameter: DataFrame,
        df_dim_wa_op_sample: DataFrame,
        df_dim_wa_org_waterqa_supplier: DataFrame,
) -> DataFrame:
    logging.info("PREPARE_ALS_ACTIVE_DATA: Getting complete als data")

    df_als_active = df_als_active.withColumn(
        RECEIVED_DATE,
        F.coalesce(
            F.to_date(
                F.regexp_replace(RECEIVED_DATE, " ", "-"), "yyyy-MM-dd"),
            F.to_date(F.regexp_replace(RECEIVED_DATE, " ", "-"), "dd-MM-yyyy"),
        ),
    ).withColumn(
        SAMPLING_DATE,
        F.coalesce(
            F.to_date(F.regexp_replace(SAMPLING_DATE, " ", "-"), "yyyy-MM-dd"),
            F.to_date(F.regexp_replace(SAMPLING_DATE, " ", "-"), "dd-MM-yyyy"),
        ),
    )

    df_als_active_dedup = perform_reorder_and_als_deduplication(df=df_als_active)

    df_als_active_filtered = df_als_active_dedup.filter(
        (F.col("SamplingDate").isNotNull()) | (F.col("Result").isNotNull()) | (F.col("Result") != ''))

    df_als_active_filtered.createOrReplaceTempView("als_active")
    df_parameter_mapping.createOrReplaceTempView("parameter_mapping")
    df_parameter_attribute.createOrReplaceTempView("parameter_attribute")
    df_location_mapping.createOrReplaceTempView("location_mapping")
    df_location_attribute.createOrReplaceTempView("location_attribute")
    df_dim_cr_loc_location.createOrReplaceTempView("dim_cr_loc_location")
    df_dim_wa_reg_parameter.createOrReplaceTempView("dim_wa_reg_parameter")
    df_dim_wa_op_sample.createOrReplaceTempView("dim_wa_op_sample")
    df_dim_wa_org_waterqa_supplier.createOrReplaceTempView(
        "dim_wa_org_waterqa_supplier"
    )

    sql_query = """
    select distinct
        sha2(
            concat_ws("||",
                NVL(CAST(aa.SampleName AS STRING), '-'),
                NVL(CAST(aa.Test AS STRING), '-'),
                NVL(CAST(aa.SampleNumber AS STRING), '-'),
                NVL(CAST(aa.SamplingDate AS STRING), '-')
            ), 256
        ) as FACT_SAMPLE_RESULT_ID,
        NULL as DIM_ASSET_ID,
        dim_loc.DIM_LOCATION_ID  as DIM_LOCATION_ID,
        dim_reg_param.DIM_PARAMETER_ID as DIM_PARAMETER_ID,
        dim_reg_param.DIM_WATERQA_SUPPLIER_ID as DIM_WATERQA_SUPPLIER_ID,
        dim_sample.DIM_SAMPLE_ID as DIM_SAMPLE_ID,
        aa.Result as SAMPLE_PARAMETER_VALUE,
        aa.Unit as SAMPLE_PARAMETER_UNIT,
        aa.SamplingDate as SAMPLE_CAPTURE_DATE,
        aa.Test as SAMPLE_TEST_NAME,
        'WATER' as SAMPLE_DOMAIN_TYPE,
        'SEA-GROUND WATER' as SAMPLE_SUB_DOMAIN_TYPE,
        coalesce(pm.ChosenParameterName, aa.Test) AS PARAMETER_MAPPING_PARAMETER_NAME,
        CASE
           WHEN aa.TestStatus like 'Pend%' THEN 'Pending' ELSE 'Completed'
        END as SAMPLE_TEST_STATUS,
        aa.SampleEvaluation as SAMPLE_TEST_EVALUATION,
        aa.SampleName as SAMPLE_LOCATION_NAME,
        coalesce(lm.ChosenLocationName, aa.SampleName)  AS LOCATION_MAPPING_LOCATION_NAME,
        CASE WHEN pm.ParameterNameSource IS NULL THEN "Not in Mapping"
            ELSE "Mapped"
        END AS PARAMETER_MAPPING_FLAG,
        CASE WHEN pa.ParameterNameChosen IS NULL THEN "Not in Attribute"
            ELSE "In Attribute"
        END AS PARAMETER_ATTRIBUTE_FLAG,
        CASE WHEN lm.LocationNameSource IS NULL THEN "Not in Mapping"
            ELSE "Mapped"
        END AS LOCATION_MAPPING_FLAG,
        CASE WHEN la.LocationNameChosen IS NULL THEN "Not in Attribute"
            ELSE "In Attribute"
        END AS LOCATION_ATTRIBUTE_FLAG,
        dim_sample.REPORTING_DATE as REPORTING_DATE,
        dim_sample.SAMPLE_DESCRIPTION as SAMPLE_DESCRIPTION,
        current_timestamp() AS CREATED_DATE,
        current_timestamp() AS LAST_UPDATED_DATE,
        trim(aa.SampleStatus) as SAMPLE_STATUS
    from
    als_active aa
    left join location_mapping lm on trim(aa.SampleName) = trim(lm.LocationNameSource)
    left join location_attribute la on trim(lm.ChosenLocationName) = trim(la.LocationNameChosen)
    left join dim_cr_loc_location dim_loc on trim(la.LocationNameChosen) = trim(dim_loc.LOCATION_NAME)
    left join dim_wa_op_sample dim_sample on trim(aa.SampleNumber) = trim(dim_sample.SAMPLE_NO)
    left join parameter_mapping pm on trim(aa.Test) = trim(pm.ParameterNameSource)
    left join parameter_attribute pa on trim(pm.ChosenParameterName) = trim(pa.ParameterNameChosen)
    left join dim_wa_reg_parameter dim_reg_param on trim(pm.ChosenParameterName) = trim(dim_reg_param.PARAMETER_NAME)
        and dim_reg_param.PRIMARY_STANDARD_FLAG = 'Primary'
    where upper(trim(aa.SampleName)) not like 'PHASE 2 DDP SWRO%'
    and upper(trim(aa.Test)) != 'MISCELLANEOUS TESTS'
    and upper(trim(aa.Test)) != 'SUBCONTRACTED ANALYSIS'
    and upper(trim(aa.WorkOrder)) not in ("BATCH", "WORKORDER")
    and (upper(trim(aa.MATRIX_SUBMATRIX)) LIKE 'WATER%GROUNDWATER' OR
    upper(trim(aa.MATRIX_SUBMATRIX)) LIKE 'WATER%SEAWATER')
    """

    df_als_active_final = spark.sql(sql_query)

    df_als_active_final_dedup = drop_duplicates_from_sample_result(spark=spark, df=df_als_active_final)

    df_als_active_final_dedup = df_als_active_final_dedup.drop("SAMPLE_DESCRIPTION")

    df_als_active_final_dedup = df_als_active_final_dedup.withColumn(
        "reporting_date_dt",
        F.to_date("reporting_date")
    )

    max_dates_df = (
        df_als_active_final_dedup.
        groupBy("FACT_SAMPLE_RESULT_ID").
        agg(
            F.max("reporting_date_dt").alias("max_reporting_date")
        )
    )

    df_final = (
        df_als_active_final_dedup.
        join(
            max_dates_df,
            (df_als_active_final_dedup.FACT_SAMPLE_RESULT_ID == max_dates_df.FACT_SAMPLE_RESULT_ID)
            & (df_als_active_final_dedup.reporting_date_dt == max_dates_df.max_reporting_date)
        )
        .select(df_als_active_final_dedup["*"]))

    df_final = df_final.drop("reporting_date_dt")

    return df_final


def prepare_transformed_df(
        spark: SparkSession,
        df_als_active: DataFrame,
        df_location_mapping: DataFrame,
        df_parameter_mapping: DataFrame,
        df_location_attribute: DataFrame,
        df_parameter_attribute: DataFrame,
        df_dim_cr_loc_location: DataFrame,
        df_dim_wa_reg_parameter: DataFrame,
        df_dim_wa_op_sample: DataFrame,
        df_dim_wa_org_waterqa_supplier: DataFrame
) -> DataFrame:
    logging.info("Starting the transformation process for FACT_WA_EVE_SAMPLE_RESULT.")

    df_transformed_final = prepare_als_active_data(
        spark=spark,
        df_als_active=df_als_active,
        df_location_mapping=df_location_mapping,
        df_location_attribute=df_location_attribute,
        df_parameter_mapping=df_parameter_mapping,
        df_parameter_attribute=df_parameter_attribute,
        df_dim_cr_loc_location=df_dim_cr_loc_location,
        df_dim_wa_reg_parameter=df_dim_wa_reg_parameter,
        df_dim_wa_op_sample=df_dim_wa_op_sample,
        df_dim_wa_org_waterqa_supplier=df_dim_wa_org_waterqa_supplier,
    )

    logging.info("Executed SQL query for data transformation.")

    df_transformed_final = df_transformed_final.persist(StorageLevel.MEMORY_AND_DISK)

    logging.info("Transformation process completed.")
    return df_transformed_final.distinct()


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrame by performing necessary transformations and returns the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames.
        primary_cols: List of primary columns
    Returns:
        DataFrame: The transformed DataFrame.
    """
    logging.info("Starting the transformation process.")

    df_als_active: DataFrame = source_dfs["ALS"]

    df_location_mapping: DataFrame = trim_spaces(source_dfs["LOCATION_MAPPING"])
    df_parameter_mapping: DataFrame = trim_spaces(source_dfs["PARAMETER_MAPPING"])

    df_location_attribute: DataFrame = trim_spaces(source_dfs["LOCATION_ATTRIBUTE"])
    df_parameter_attribute: DataFrame = trim_spaces(source_dfs["PARAMETER_ATTRIBUTE"])

    df_dim_cr_loc_location: DataFrame = (
        source_dfs["DIM_CR_LOC_LOCATION_SGWQD"]
        .select("DIM_LOCATION_ID", "LOCATION_NAME")
        .distinct()
    )
    df_dim_wa_reg_parameter: DataFrame = source_dfs["DIM_WA_REG_PARAMETER_SGWQD"].distinct()

    df_dim_wa_op_sample = prepare_dim_wa_op_sample_data(
        spark=spark,
        df_dim_wa_op_sample=source_dfs["DIM_WA_OP_SAMPLE"]
    )

    df_dim_wa_org_waterqa_supplier: DataFrame = (
        source_dfs["DIM_WA_ORG_WATERQA_SUPPLIER"]
        .select("DIM_WATERQA_SUPPLIER_ID", "SUPPLIER_NAME", "SUPPLIER_CODE")
        .distinct()
    )

    df_transformed = prepare_transformed_df(
        spark=spark,
        df_als_active=df_als_active,
        df_location_mapping=df_location_mapping,
        df_parameter_mapping=df_parameter_mapping,
        df_location_attribute=df_location_attribute,
        df_parameter_attribute=df_parameter_attribute,
        df_dim_cr_loc_location=df_dim_cr_loc_location,
        df_dim_wa_reg_parameter=df_dim_wa_reg_parameter,
        df_dim_wa_op_sample=df_dim_wa_op_sample,
        df_dim_wa_org_waterqa_supplier=df_dim_wa_org_waterqa_supplier
    )

    logging.info("Data transformation completed.")

    max_partition_size_mb = 1024
    logging.info("Calculating the number of partitions.")
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)
    logging.info(f"Repartitioning DataFrame into {num_partitions} partitions.")

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    target_schema = {}

    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = transform(
        spark=spark, source_dfs=source_dfs
    )

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "50MB")

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
