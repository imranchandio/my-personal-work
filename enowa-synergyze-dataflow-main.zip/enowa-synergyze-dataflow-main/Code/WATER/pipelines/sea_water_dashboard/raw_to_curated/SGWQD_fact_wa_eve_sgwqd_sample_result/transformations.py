from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
import logging
from pyspark.sql.types import FloatType, DecimalType, StringType, DoubleType
import re
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read
from pyspark.sql.window import Window

THRESHOLD_NOT_AVAILABLE = "Threshold Not Available"
EXCEEDS_MIN = "Exceeds Min"
EXCEEDS_MAX = "Exceeds Max"
COMPLIANT = "Compliant"
NON_COMPLIANT = "Non-Compliant"
NOT_DETECTED = "Not Detected"
PENDING = "Pending"
SAMPLE_TEST_STATUS = "SAMPLE_TEST_STATUS"
STRING = "string"
BIOLOGICAL = "Biological"
CALCULATED_TEST_RESULT = "CALCULATED_TEST_RESULT"
EXCLUDED_PARAM_UNITS = ["cells/mL", "cells/100 mL", "MPN/100 mL"]
SAMPLE_PARAMETER_UNIT = "SAMPLE_PARAMETER_UNIT"
PARAMETER_THRESHOLD_MAX = "PARAMETER_THRESHOLD_MAX"
PARAMETER_THRESHOLD_MIN = "PARAMETER_THRESHOLD_MIN"
THRESHOLD_EXCEPTION_STATUS = "THRESHOLD_EXCEPTION_STATUS"
CALC_SAMPLE_PARAMETER_VALUE = "CALC_SAMPLE_PARAMETER_VALUE"
COMPLIANCE_STATUS = "COMPLIANCE_STATUS"
PARAMETER_TYPE = "PARAMETER_TYPE"
RESULT_SOURCE_NO_LESS_THAN = "Result Source - No Less Than"
RESULT_SOURCE_SPLIT_VALUE = "Result Source Split Value"
RESULT_SOURCE_SPLIT_SYMBOL = "Result Source Split Symbol"
SAMPLE_RESULT_DETECTION = "SAMPLE_RESULT_DETECTION"
RESULTS_STATUS = "Results Status"
DETECTED = "Detected"
SAMPLE_PARAMETER_VALUE = "SAMPLE_PARAMETER_VALUE"


def extract_number(text):
    if text:
        match = re.search(r"\d+\.?\d*", text)
        return float(match.group()) if match else None
    return None


def get_calc_sample_parameter_value(df: DataFrame):
    # Step 1: Duplicate the "Result" column
    df = df.withColumn(RESULT_SOURCE_NO_LESS_THAN, F.col(SAMPLE_PARAMETER_VALUE))

    # Step 2: Change the type of "Result Source - No Less Than" to text (StringType in PySpark)
    df = df.withColumn(RESULT_SOURCE_NO_LESS_THAN, F.col(RESULT_SOURCE_NO_LESS_THAN).cast(StringType()))

    # Step 3: Split the column "Result Source - No Less Than" by the delimiter "<"
    split_col = F.split(F.col(RESULT_SOURCE_NO_LESS_THAN), "<")
    df = df.withColumn(RESULT_SOURCE_SPLIT_VALUE, split_col.getItem(0).cast(DoubleType()))
    df = df.withColumn(RESULT_SOURCE_SPLIT_SYMBOL, split_col.getItem(1).cast(DoubleType()))

    # Step 4: Add the "Sample Result Detection" column
    df = df.withColumn(
        SAMPLE_RESULT_DETECTION,
        F.when(F.col(SAMPLE_TEST_STATUS) == PENDING, PENDING)
        .when(F.col(RESULT_SOURCE_SPLIT_SYMBOL).isNull(), DETECTED)
        .otherwise(NOT_DETECTED)
    )

    # Step 5: Add the "Result No Less than" column
    df = df.withColumn(
        CALC_SAMPLE_PARAMETER_VALUE,
        F.when(F.col(RESULT_SOURCE_SPLIT_SYMBOL).isNull(), F.col(RESULT_SOURCE_SPLIT_VALUE))
        .when(
            (F.col(PARAMETER_TYPE) == BIOLOGICAL) & (F.col(SAMPLE_PARAMETER_VALUE) == "<1"),
            F.lit(0)
        )
        .otherwise(F.col(RESULT_SOURCE_SPLIT_SYMBOL))
    )

    return df


def prepare_dim_wa_op_sample_data(
        spark: SparkSession,
        df_dim_wa_op_sample: DataFrame
):
    df_dim_wa_op_sample.createOrReplaceTempView("DIM_WA_OP_SAMPLE")
    sql_query = """
        SELECT sample.*
        FROM DIM_WA_OP_SAMPLE sample
        INNER JOIN (
            SELECT DIM_SAMPLE_ID
                ,max(REPORTING_DATE) AS MAX_REPORTING_DATE
            FROM DIM_WA_OP_SAMPLE
            GROUP BY DIM_SAMPLE_ID
            ) max_sample ON sample.DIM_SAMPLE_ID = max_sample.DIM_SAMPLE_ID
            AND sample.REPORTING_DATE = max_sample.MAX_REPORTING_DATE 
    """
    return spark.sql(sql_query).distinct()


def prepare_dim_wa_op_sample_batch_data(
        spark: SparkSession,
        df_dim_wa_op_sample_batch: DataFrame
):
    df_dim_wa_op_sample_batch.createOrReplaceTempView("DIM_WA_OP_SAMPLE_BATCH")
    sql_query = """
        SELECT sample_batch.*
        FROM DIM_WA_OP_SAMPLE_BATCH sample_batch
        INNER JOIN (
            SELECT DIM_SAMPLE_BATCH_ID
                ,max(REPORTING_DATE) AS MAX_REPORTING_DATE
            FROM DIM_WA_OP_SAMPLE_BATCH
            GROUP BY DIM_SAMPLE_BATCH_ID
            ) max_sample ON sample_batch.DIM_SAMPLE_BATCH_ID = max_sample.DIM_SAMPLE_BATCH_ID
            AND sample_batch.REPORTING_DATE = max_sample.MAX_REPORTING_DATE 
    """
    return spark.sql(sql_query).distinct()


def prepare_transformed_df(
        spark: SparkSession,
        df_dim_wa_reg_parameter: DataFrame,
        df_fact_wa_eve_sample_result: DataFrame,
        df_purchase_orders: DataFrame,
        df_dim_wa_op_sample: DataFrame,
        df_dim_wa_op_sample_batch: DataFrame
) -> DataFrame:
    logging.info(
        "Starting the transformation process for FACT_WA_EVE_WQD_SAMPLE_RESULT."
    )

    udf_extract_number = F.udf(extract_number, FloatType())

    df_dim_wa_reg_parameter = df_dim_wa_reg_parameter.withColumn(
        PARAMETER_THRESHOLD_MAX, udf_extract_number(PARAMETER_THRESHOLD_MAX)
    ).withColumn(
        PARAMETER_THRESHOLD_MIN, udf_extract_number(PARAMETER_THRESHOLD_MIN)
    )

    df_fact_wa_eve_sample_result.createOrReplaceTempView("fact")
    df_dim_wa_reg_parameter.createOrReplaceTempView("reg_param")
    df_dim_wa_op_sample.createOrReplaceTempView("dim_wa_op_sample")
    df_dim_wa_op_sample_batch.createOrReplaceTempView("dim_wa_op_sample_batch")

    query = """
        SELECT
            fact.FACT_SAMPLE_RESULT_ID,
            fact.DIM_PARAMETER_ID,
            fact.SAMPLE_TEST_STATUS,
            fact.SAMPLE_PARAMETER_VALUE,
            fact.SAMPLE_PARAMETER_UNIT,
            reg_param.NON_DETECTION_VARIABLE,
            CAST(reg_param.PARAMETER_THRESHOLD_MIN AS DECIMAL(10, 4)) AS PARAMETER_THRESHOLD_MIN,
            CAST(reg_param.PARAMETER_THRESHOLD_MAX AS DECIMAL(10, 4)) AS PARAMETER_THRESHOLD_MAX,
            reg_param.PARAMETER_UNIT,
            reg_param.PARAMETER_TYPE,
            sample_batch.PURCHASE_ORDER_NO
        FROM fact
        LEFT JOIN reg_param
            ON fact.DIM_PARAMETER_ID = reg_param.DIM_PARAMETER_ID
        LEFT JOIN dim_wa_op_sample sample
            ON fact.DIM_SAMPLE_ID = sample.DIM_SAMPLE_ID
        LEFT JOIN dim_wa_op_sample_batch sample_batch
            ON sample.DIM_SAMPLE_BATCH_ID = sample_batch.DIM_SAMPLE_BATCH_ID      
        """

    # Step 3: Execute the SQL query
    df_joined = spark.sql(query)

    df_joined = get_calc_sample_parameter_value(df=df_joined)

    df_joined = df_joined.withColumn(
        CALCULATED_TEST_RESULT,
        F.col(CALC_SAMPLE_PARAMETER_VALUE)
    )

    print("prepare_transformed_df(): df_joined schema:", df_joined.printSchema())

    # Cast the column to FloatType
    df_joined.createOrReplaceTempView("df_joined")
    df_purchase_orders.createOrReplaceTempView("df_purchase_orders")

    # SQL query for the first set of transformations
    sql_query_transformed_1 = f"""
    SELECT
        *,
        sha2(CAST(FACT_SAMPLE_RESULT_ID AS STRING), 256) AS FACT_WATERQUALITY_OVERVIEW_ID,
        SAMPLE_RESULT_DETECTION,
        CASE
            WHEN PARAMETER_THRESHOLD_MIN IS NULL AND PARAMETER_THRESHOLD_MAX IS NULL THEN '{THRESHOLD_NOT_AVAILABLE}'
            ELSE CONCAT_WS(' - ', CAST(PARAMETER_THRESHOLD_MIN AS STRING), CAST(PARAMETER_THRESHOLD_MAX AS STRING))
        END AS THRESHOLD_RANGE,
        CASE
            WHEN SAMPLE_TEST_STATUS = '{PENDING}' THEN '{PENDING}'
            WHEN PARAMETER_TYPE != '{BIOLOGICAL}' 
                AND PARAMETER_THRESHOLD_MIN IS NOT NULL 
                AND CALCULATED_TEST_RESULT IS NOT NULL 
                AND CALCULATED_TEST_RESULT < PARAMETER_THRESHOLD_MIN THEN '{NON_COMPLIANT}'
            WHEN PARAMETER_TYPE != '{BIOLOGICAL}' 
                AND PARAMETER_THRESHOLD_MAX IS NOT NULL 
                AND CALCULATED_TEST_RESULT IS NOT NULL 
                AND CALCULATED_TEST_RESULT > PARAMETER_THRESHOLD_MAX THEN '{NON_COMPLIANT}'
            WHEN PARAMETER_TYPE = '{BIOLOGICAL}' 
                AND PARAMETER_THRESHOLD_MIN IS NOT NULL 
                AND CALCULATED_TEST_RESULT IS NOT NULL 
                AND CALCULATED_TEST_RESULT > 0 
                AND SAMPLE_PARAMETER_UNIT NOT IN ('{','.join(EXCLUDED_PARAM_UNITS)}') THEN '{NON_COMPLIANT}'
            WHEN PARAMETER_THRESHOLD_MIN IS NOT NULL 
                AND CALCULATED_TEST_RESULT IS NOT NULL 
                AND CALCULATED_TEST_RESULT > 0 
                AND CALCULATED_TEST_RESULT < PARAMETER_THRESHOLD_MIN 
                AND SAMPLE_PARAMETER_UNIT NOT IN ('{','.join(EXCLUDED_PARAM_UNITS)}') THEN '{NON_COMPLIANT}'
            WHEN PARAMETER_THRESHOLD_MAX IS NOT NULL 
                AND CALCULATED_TEST_RESULT IS NOT NULL 
                AND CALCULATED_TEST_RESULT > 0 
                AND CALCULATED_TEST_RESULT > PARAMETER_THRESHOLD_MAX 
                AND SAMPLE_PARAMETER_UNIT NOT IN ('{','.join(EXCLUDED_PARAM_UNITS)}') THEN '{NON_COMPLIANT}'
            ELSE '{COMPLIANT}'
        END AS THRESHOLD_EXCEPTION_STATUS
    FROM df_joined
    """

    df_transformed_1 = spark.sql(sql_query_transformed_1)
    df_transformed_1.createOrReplaceTempView("df_transformed_1")

    # SQL query for the second set of transformations
    sql_query_transformed_2 = f"""
    SELECT
        *,
        CASE
            WHEN SAMPLE_TEST_STATUS = '{PENDING}' THEN '{PENDING}'
            WHEN PARAMETER_THRESHOLD_MIN IS NULL OR PARAMETER_THRESHOLD_MAX IS NULL THEN '{THRESHOLD_NOT_AVAILABLE}'
            WHEN CALCULATED_TEST_RESULT >= PARAMETER_THRESHOLD_MIN 
                AND CALCULATED_TEST_RESULT <= PARAMETER_THRESHOLD_MAX THEN '{COMPLIANT}'
            WHEN CALCULATED_TEST_RESULT < PARAMETER_THRESHOLD_MIN THEN '{EXCEEDS_MIN}'
            WHEN CALCULATED_TEST_RESULT > PARAMETER_THRESHOLD_MAX THEN '{EXCEEDS_MAX}'
            ELSE '{NON_COMPLIANT}'
        END AS COMPLIANCE_STATUS,
        CASE
            WHEN THRESHOLD_EXCEPTION_STATUS = '{NON_COMPLIANT}' AND COMPLIANCE_STATUS = '{EXCEEDS_MAX}' THEN 
                CALCULATED_TEST_RESULT - PARAMETER_THRESHOLD_MAX
            WHEN THRESHOLD_EXCEPTION_STATUS = '{NON_COMPLIANT}' AND COMPLIANCE_STATUS = '{EXCEEDS_MIN}' THEN 
                PARAMETER_THRESHOLD_MIN - CALCULATED_TEST_RESULT
            WHEN THRESHOLD_EXCEPTION_STATUS IN ('{COMPLIANT}', '{PENDING}') THEN 0.0
            ELSE 0.0
        END AS NON_COMPLIANT_AMOUNT,
        CASE
            WHEN THRESHOLD_EXCEPTION_STATUS = '{NON_COMPLIANT}' AND COMPLIANCE_STATUS = '{EXCEEDS_MAX}' THEN 
                (CALCULATED_TEST_RESULT - PARAMETER_THRESHOLD_MAX) / PARAMETER_THRESHOLD_MAX
            WHEN THRESHOLD_EXCEPTION_STATUS = '{NON_COMPLIANT}' AND COMPLIANCE_STATUS = '{EXCEEDS_MIN}' THEN 
                (PARAMETER_THRESHOLD_MIN - CALCULATED_TEST_RESULT) / PARAMETER_THRESHOLD_MIN
            WHEN THRESHOLD_EXCEPTION_STATUS IN ('{COMPLIANT}', '{PENDING}') THEN 0.0
            ELSE 0.0
        END AS NON_COMPLIANT_PERCENTAGE,
        current_date() AS LAST_UPDATED_DATE,
        current_date() AS CREATED_DATE
    FROM df_transformed_1
    """

    df_transformed_2 = spark.sql(sql_query_transformed_2)

    df_transformed_2 = df_transformed_2.withColumn(
        "PURCHASE_ORDER_NO",
        F.trim(F.regexp_replace(F.col("PURCHASE_ORDER_NO"), '[PO #]', ''))
    )

    df_transformed_final = df_transformed_2

    logging.info("Executed SQL query for data transformation.")

    max_partition_size_mb = 1024
    logging.info("Calculating the number of partitions.")
    num_partitions = calculate_num_partitions(df_transformed_final, max_partition_size_mb)
    logging.info(f"Repartitioning DataFrame into {num_partitions} partitions.")

    df_transformed = df_transformed_final.repartition(num_partitions)

    logging.info("Transformation process completed.")
    return df_transformed.distinct()


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrame by performing necessary transformations and returns the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    logging.info("Starting the transformation process.")

    df_dim_wa_reg_parameter: DataFrame = source_dfs["DIM_WA_REG_PARAMETER_SGWQD"]
    df_fact_wa_eve_sample_result: DataFrame = source_dfs["FACT_WA_EVE_SAMPLE_RESULT_SGWQD"]
    df_purchase_orders: DataFrame = source_dfs["PURCHASE_ORDERS"]
    df_dim_wa_op_sample = prepare_dim_wa_op_sample_data(
        spark=spark,
        df_dim_wa_op_sample=source_dfs["DIM_WA_OP_SAMPLE"]
    )
    df_dim_wa_op_sample_batch = prepare_dim_wa_op_sample_batch_data(
        spark=spark,
        df_dim_wa_op_sample_batch=source_dfs["DIM_WA_OP_SAMPLE_BATCH"]
    )

    # Perform joins, filters, etc.
    df_transformed = prepare_transformed_df(
        spark=spark,
        df_dim_wa_reg_parameter=df_dim_wa_reg_parameter,
        df_fact_wa_eve_sample_result=df_fact_wa_eve_sample_result,
        df_purchase_orders=df_purchase_orders,
        df_dim_wa_op_sample=df_dim_wa_op_sample,
        df_dim_wa_op_sample_batch=df_dim_wa_op_sample_batch
    )

    logging.info("Data transformation completed.")

    return df_transformed


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    select_cols = [schema["name"] for schema in target_schema]
    transformed_df = transformed_df.select(*select_cols)

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
