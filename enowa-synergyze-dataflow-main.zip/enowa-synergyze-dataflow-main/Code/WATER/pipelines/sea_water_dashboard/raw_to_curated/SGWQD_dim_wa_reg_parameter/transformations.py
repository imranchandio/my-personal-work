from pyspark.sql import DataFrame, SparkSession, Row
from pyspark.sql.functions import (
    sha2,
    concat_ws,
    lit,
    col,
    current_timestamp,
    upper
)
from pyspark.sql.types import StringType, StructType, StructField
import logging
from common_utils import (
    calculate_num_partitions,
    impose_schema,
    uuid5_hash,
    trim_spaces
)
from read_utils import read


def prepare_additional_parameters(spark: SparkSession):
    # Define the schema
    schema = StructType(
        [
            StructField("DIM_WATERQA_SUPPLIER_ID", StringType(), True),
            StructField("PARAMETER_NAME", StringType(), True),
            StructField("PRIMARY_STANDARD_FLAG", StringType(), True),
        ]
    )

    # Create rows with sample data
    row1 = Row(
        DIM_WATERQA_SUPPLIER_ID="DWS001",
        PARAMETER_NAME="THM Index",
        PRIMARY_STANDARD_FLAG="Primary",
    )
    row2 = Row(
        DIM_WATERQA_SUPPLIER_ID="DWS001",
        PARAMETER_NAME="Nitrogen Index",
        PRIMARY_STANDARD_FLAG="Primary",
    )

    # Convert rows to DataFrames and union them with the original DataFrame
    new_rows_df = spark.createDataFrame([row1, row2], schema)
    new_rows_df = new_rows_df \
        .withColumn("LAST_UPDATED_DATE", current_timestamp()) \
        .withColumn("CREATED_DATE", current_timestamp()) \
        .withColumn("PARTITION_KEY", lit("SEA-GROUND WATER"))

    return new_rows_df


def prepare_transformed_df(
        spark: SparkSession,
        df_parameter_attribute: DataFrame,
        df_dim_wa_org_waterqa_supplier: DataFrame,
        df_pwqd_parameter_attribute: DataFrame
) -> DataFrame:
    logging.info("Starting the transformation process.")
    df_parameter_attribute.createOrReplaceTempView("parameter_attributes_source")
    df_pwqd_parameter_attribute.createOrReplaceTempView("pwqd_parameter_attributes_source")
    df_dim_wa_org_waterqa_supplier.createOrReplaceTempView("waterqa_supplier")

    logging.info("Created temporary views for SQL operations.")
    logging.info("Executing SQL query for data transformation.")

    sql_query_all_suppliers = """
   SELECT DISTINCT
        'ALL' AS Supplier_Code,
        swqd_pa.ParameterNameChosen AS Parameter_Name,
        NULL AS Parameter_Code,
        NULL AS Parameter_Symbol,
        NULL as DIM_WW_PHASE_ID,
        'WATER' AS Parameter_Domain_Type,
        'SEA-GROUND WATER' AS Parameter_Sub_Domain_Type,
        NULL AS Parameter_Sample_Type,
        swqd_pa.ParameterType AS Parameter_Type,
        NULL AS Location_Type,
        NULL AS Threshold_Limit_Standard,
        'Primary' AS Primary_Standard_Flag,
        NULL AS Parameter_Threshold_Min,
        NULL AS Parameter_Threshold_Max,
        coalesce(swqd_pa.ParameterUnit, pwqd_pa.ParameterUnit) AS Parameter_Unit,
        NULL AS Non_Detection_Variable,
        pwqd_pa.ThresholdPriority AS Threshold_Priority,
        NULL AS Parameter_Guidelines_Note,
        NULL AS Testing_Frequency,
        NULL AS Technique_Method_Reference,
        NULL AS Threshold_Limit_Of_Reporting,
        NULL AS Max_Limit_Of_Reporting_Unit,
        NULL as PARAMETER_DASHBOARD_PRIORITY,
        'SEA-GROUND WATER' as PARTITION_KEY,
        current_date() as LAST_UPDATED_DATE,
        current_date() as CREATED_DATE
    FROM
    parameter_attributes_source swqd_pa
    left join pwqd_parameter_attributes_source pwqd_pa 
        ON swqd_pa.ParameterNameChosen = pwqd_pa.ParameterName
   """

    df_transformed = spark.sql(sql_query_all_suppliers)

    df_transformed = (
        df_transformed.alias("source")
        .join(
            df_dim_wa_org_waterqa_supplier.alias("supplier"),
            col("source.Supplier_Code") == col("supplier.SUPPLIER_CODE"),
            "LEFT_OUTER",
        )
        .select(col("source.*"), col("supplier.DIM_WATERQA_SUPPLIER_ID"))
    )

    logging.info("Executed SQL query for data transformation.")

    df_transformed = df_transformed.withColumn(
        "DIM_PARAMETER_ID",
        sha2(
            concat_ws(
                "||",
                "Dim_Waterqa_Supplier_Id",
                "Parameter_Name"
            ),
            256,
        ),
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info(f"Repartitioning the DataFrame into {num_partitions} partitions.")

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters, returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "PARAMETER_ATTRIBUTE": DataFrame for parameter attributes.
            - "DIM_WA_ORG_WATERQA_SUPPLIER": DataFrame for supplier details.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_parameter_attribute = trim_spaces(source_dfs["PARAMETER_ATTRIBUTE"])
    df_pwqd_parameter_attribute = trim_spaces(source_dfs["PWQD_PARAMETER_ATTRIBUTE"])
    df_dim_wa_org_waterqa_supplier = source_dfs["DIM_WA_ORG_WATERQA_SUPPLIER"]
    df_dim_wa_org_waterqa_supplier = df_dim_wa_org_waterqa_supplier \
        .filter(upper(df_dim_wa_org_waterqa_supplier.DOMAIN_TYPE) == "WATER")

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_parameter_attribute=df_parameter_attribute,
        df_dim_wa_org_waterqa_supplier=df_dim_wa_org_waterqa_supplier,
        df_pwqd_parameter_attribute=df_pwqd_parameter_attribute
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    print("spark_df schema::", spark_df.printSchema())
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
