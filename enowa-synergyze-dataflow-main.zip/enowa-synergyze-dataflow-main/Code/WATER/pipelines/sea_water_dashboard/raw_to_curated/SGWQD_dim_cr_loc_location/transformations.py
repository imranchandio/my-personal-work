# pylint: disable=line-too-long
# pylint: disable=import-error
# pylint: disable=missing-module-docstring
# pylint: disable=trailing-whitespace
# pylint: disable=inconsistent-return-statements
# pylint: disable=too-many-locals
import logging
from common_utils import (
    calculate_num_partitions,
    impose_schema,
    trim_spaces
)
from read_utils import read
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2


def prepare_transformed_df(
        spark: SparkSession,
        df_location_mapping: DataFrame,
        df_location_attribute: DataFrame,
        df_dim_cr_loc_location_area: DataFrame,
) -> DataFrame:
    """
        Transforms location mapping, location attribute, loc area and loc group data by selecting distinct columns,
        creating SQL temporary views, and returning the final transformed DataFrame.

        Parameters:
        df_location_mapping (DataFrame): location mapping data.
        df_location_attribute (DataFrame): location attribute data.
        df_dim_cr_loc_location_area (DataFrame): area data.

        Returns:
        DataFrame: Transformed DataFrame.
    """

    logging.info("Starting the transformation process.")

    df_location_attribute = df_location_attribute.distinct()
    logging.info("Removed duplicate records from df_location_attribute.")

    df_location_mapping.createOrReplaceTempView("location_mapping")
    df_location_attribute.createOrReplaceTempView("location_attribute")
    df_dim_cr_loc_location_area.createOrReplaceTempView("dim_cr_loc_location_area")
    logging.info("Created temporary views for SQL operations.")

    sql_query1 = """
                select distinct
                    loc_la.DIM_LOCATION_AREA_ID AS DIM_LOCATION_AREA_ID,
                    la.LocationNameChosen as LOCATION_NAME,
                    NULL as ASSET_NAME,
                    NULL AS IS_NEOM_LOCATION_YN,
                    la.LocationWaterType AS LOCATION_WATER_CATEGORY,
                    NULL AS LOCATION_SAMPLE_CATEGORY,
                    NULL AS LOCATION_SAMPLE_TYPE,
                    la.LocationDepth AS LOCATION_DEPTH,
                    NULL AS LOCATION_SAMPLE_FREQUENCY,
                    NULL AS LATITUDE,
                    NULL AS LONGITUDE,
                    NULL AS IS_COMMUNITY_LOCATION,
                    NULL AS COMMUNITY_LOCATION_TYPE,
                    NULL AS IS_ENOWA_NETWORK,
                    NULL AS IS_SWCC_FACILITY_YN,
                    NULL AS IS_COMMUNITY_YN,
                    NULL AS OTHER_YN,
                    NULL AS NOTES,
                    'WATER' as DOMAIN_TYPE,
                    'SEA-GROUND WATER' as SUB_DOMAIN_TYPE,
                    current_date() AS LAST_UPDATED_DATE,
                    current_date() AS CREATED_DATE,
                    'SEA-GROUND WATER' as PARTITION_KEY
                FROM location_attribute la
                LEFT JOIN dim_cr_loc_location_area loc_la
                ON la.LocationArea = loc_la.LOCATION_AREA
                """

    logging.info("Executing SQL query for data transformation.")
    df_attribute = spark.sql(sql_query1)
    df_transformed = df_attribute  # .union(df_mapping)
    logging.info("Executed SQL query for data transformation.")

    df_final = df_transformed

    df_final = df_final.withColumn("DIM_LOCATION_ID", sha2("LOCATION_NAME", 256))

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_final, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_final = df_final.repartition(num_partitions)

    return df_final


def transform(spark, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters, returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "LOCATION_MAPPING": DataFrame for location mapping.
            - "LOCATION_ATTRIBUTE": DataFrame for location attribute.
            - "DIM_CR_LOC_LOCATION_AREA": DataFrame for location area.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_location_mapping = trim_spaces(source_dfs["LOCATION_MAPPING"])
    df_location_attribute = trim_spaces(source_dfs["LOCATION_ATTRIBUTE"])
    df_dim_cr_loc_location_area = source_dfs["DIM_CR_LOC_LOCATION_AREA_SGWQD"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_location_mapping=df_location_mapping,
        df_location_attribute=df_location_attribute,
        df_dim_cr_loc_location_area=df_dim_cr_loc_location_area,
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage configuration information.
        task_parameters (dict): A dictionary containing task parameters, including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")
    print("dummy spark df passed as argument ", spark_df)

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
