# pylint: disable = unused-argument, import-error
"""
    This is the transformation file for DIM_CR_LOC_LOCATION_ALBADA dimension
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_tse_outflow_operator: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from the raw layer table passed in as DataFrame.
    '''
    logging.info("Starting the transformation process.")

    df_tse_outflow_operator.createOrReplaceTempView("tse_outflow_operator")

    logging.info("Executing SQL query for data transformation.")

    sql_query = """
        WITH temp_location AS (
    SELECT 
        DISTINCT 
        TRIM(RecycledWaterDestination) AS LOCATION_NAME, 
      CASE
        WHEN LOCATIONCOORDINATES IS NULL OR TRIM(LOCATIONCOORDINATES) = '' THEN 'NA'
        WHEN LOCATE(',', TRIM(LOCATIONCOORDINATES)) > 0 THEN TRIM(SPLIT(TRIM(LOCATIONCOORDINATES), ',')[0])
        ELSE TRIM(SPLIT(TRIM(LOCATIONCOORDINATES), ' ')[0])
       END AS LATITUDE,
      CASE
        WHEN LOCATIONCOORDINATES IS NULL OR TRIM(LOCATIONCOORDINATES) = '' THEN 'NA'
        WHEN LOCATE(',', TRIM(LOCATIONCOORDINATES)) > 0 THEN TRIM(SPLIT(TRIM(LOCATIONCOORDINATES), ',')[1])
        ELSE TRIM(SPLIT(TRIM(LOCATIONCOORDINATES), ' ')[1])
        END AS LONGITUDE
    FROM TSE_Outflow_Operator
    WHERE RecycledWaterDestination IS NOT NULL 
)

SELECT 
    NULL AS DIM_LOCATION_AREA_ID, 
    LOCATION_NAME, 
    NULL AS ASSET_NAME, 
    NULL AS IS_NEOM_LOCATION_YN, 
    'Waste Water' AS LOCATION_WATER_CATEGORY, 
    'Waste Water-AlBADA' AS LOCATION_SAMPLE_CATEGORY, 
    NULL AS LOCATION_SAMPLE_TYPE, 
    NULL AS LOCATION_SAMPLE_FREQUENCY, 
    LATITUDE, 
    LONGITUDE, 
    NULL AS IS_COMMUNITY_LOCATION, 
    NULL AS COMMUNITY_LOCATION_TYPE, 
    NULL AS IS_ENOWA_NETWORK, 
    NULL AS IS_SWCC_FACILITY_YN, 
    NULL AS IS_COMMUNITY_YN, 
    NULL AS OTHER_YN, 
    NULL AS NOTES, 
    'Albada' AS DOMAIN_TYPE, 
    'AL-BADA' AS PARTITION_KEY, 
    CURRENT_TIMESTAMP AS LAST_UPDATED_DATE, 
    CURRENT_TIMESTAMP AS CREATED_DATE
FROM temp_location
    """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation.")

    df_transformed = df_transformed.withColumn(
        "DIM_LOCATION_ID", sha2(concat_ws("||", "LOCATION_NAME", "LATITUDE", "LONGITUDE", "DOMAIN_TYPE"), 256)
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "TSE_OUTFLOW_OPERATOR": DataFrame for TSE Outflow Operator.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_tse_outflow_operator = source_dfs["TSE_OUTFLOW_OPERATOR"]

    # Perform joins, filters, etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_tse_outflow_operator=df_tse_outflow_operator
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
) -> DataFrame:
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
