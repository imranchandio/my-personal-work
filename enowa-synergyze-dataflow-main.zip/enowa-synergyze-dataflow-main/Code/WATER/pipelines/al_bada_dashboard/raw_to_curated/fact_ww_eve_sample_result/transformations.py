# pylint:disable = unused-argument, import-error, too-many-arguments, too-many-positional-arguments
"""
    This is the transformation file for fact_ww_eve_sample_result fact
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws, to_date, col, regexp_replace, when, trim
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_wrp_site_lab: DataFrame,
        df_parameter_on_off: DataFrame,
        df_wastewater_phase: DataFrame,
        df_parameter_albada: DataFrame,
        df_exclude_samples: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from the raw \
    and curation layer table passed in as DataFrame.
    '''
    logging.info("Starting the transformation process.")

    df_wrp_site_lab = (df_wrp_site_lab.withColumn("RESULT", regexp_replace(regexp_replace("RESULT", "[^0-9.]", ""),
                                                                           # Remove special characters except .
                                                                           "\\.{2,}", ".")))

    # Date conversion to yyyy-mm-dd format for all date columns
    df_wrp_site_lab = df_wrp_site_lab.withColumn("DATE", to_date( \
        col("DATE"), "d-MMM-yy"))

    df_parameter_on_off = df_parameter_on_off.withColumn("StartDate", \
                                                         regexp_replace(col("StartDate"),
                                                                        r"(\d{1,2})/(\d{1,2})/(\d{4})", r"$3-$1-$2"))

    df_exclude_samples = df_exclude_samples.withColumn("Date", to_date( \
        col("Date"), "d-MMM-yyyy"))

    # Fix the Aeration Zones - Category in wrp site lab raw data
    df_wrp_site_lab = df_wrp_site_lab.withColumn(
        'CATEGORY',
        when(col('CATEGORY') == 'Aeration Zones', 'Aeration').otherwise(col('CATEGORY'))
    )

    # Remove spaces from Parameter column
    df_wrp_site_lab = df_wrp_site_lab.withColumn('PARAMETER', trim(col('PARAMETER')))

    df_wrp_site_lab.createOrReplaceTempView("wrp_site_lab")
    df_parameter_on_off.createOrReplaceTempView("parameter_on_off")
    df_wastewater_phase.createOrReplaceTempView("wastewater_phase")
    df_parameter_albada.createOrReplaceTempView("parameter_albada")

    logging.info("Executing SQL query for data transformation.")

    sql_query = """
                select C.DIM_WW_PHASE_ID,
                    D.DIM_PARAMETER_ID,
                    A.PARAMETER as PARAMETER_NAME,
                    A.CATEGORY as WASTE_WATER_PHASE,
                    CASE WHEN D.DIM_PARAMETER_ID IS NULL THEN 'Not in Mapping' ELSE 'In Mapping' END as PARAMETER_MAPPING_FLAG,
                    CASE WHEN C.DIM_WW_PHASE_ID IS NULL THEN 'Not in Mapping' ELSE 'In Mapping' END as WWPHASE_MAPPING_FLAG,
                    B.ParameterStatus as PARAMETER_STATUS,
                    B.StartDate as PARAMETER_STATUS_START_DATE,
                    CAST(A.RESULT AS FLOAT) as REPORTED_TEST_RESULT,
                    CASE WHEN (D.DIM_PARAMETER_ID IS NOT NULL AND (CAST(D.Parameter_Threshold_Max  AS FLOAT) <  CAST(A.RESULT  AS FLOAT))) THEN 'Max'
                        WHEN (D.DIM_PARAMETER_ID IS NOT NULL AND (CAST(D.Parameter_Threshold_Min  AS FLOAT) > CAST(A.RESULT  AS FLOAT))) THEN 'Min'
                        ELSE 'Compliant' END as COMPLIANCE_STATUS,
                    CASE WHEN (D.DIM_PARAMETER_ID IS NOT NULL AND (CAST(D.Parameter_Threshold_Max  AS FLOAT) <  CAST(A.RESULT  AS FLOAT))) THEN A.RESULT - D.Parameter_Threshold_Max
                        WHEN (D.DIM_PARAMETER_ID IS NOT NULL AND (CAST(D.Parameter_Threshold_Min  AS FLOAT) > CAST(A.RESULT  AS FLOAT))) THEN D.Parameter_Threshold_Min - A.RESULT
                        ELSE 0 END as NON_COMPLIANT_AMOUNT,
                    CASE WHEN (D.DIM_PARAMETER_ID IS NOT NULL AND (CAST(D.Parameter_Threshold_Max  AS FLOAT) <  CAST(A.RESULT  AS FLOAT)) AND D.PARAMETER_UNIT='%') THEN (A.RESULT - D.Parameter_Threshold_Max)/D.Parameter_Threshold_Max
                        WHEN (D.DIM_PARAMETER_ID IS NOT NULL AND (CAST(D.Parameter_Threshold_Min  AS FLOAT) > CAST(A.RESULT  AS FLOAT)) AND D.PARAMETER_UNIT='%') THEN (D.Parameter_Threshold_Min - A.RESULT)/D.Parameter_Threshold_Min
                        WHEN (D.DIM_PARAMETER_ID IS NOT NULL AND (CAST(D.Parameter_Threshold_Max  AS FLOAT) <  CAST(A.RESULT  AS FLOAT))) THEN ((A.RESULT - D.Parameter_Threshold_Max)*100)/D.Parameter_Threshold_Max
                        WHEN (D.DIM_PARAMETER_ID IS NOT NULL AND (CAST(D.Parameter_Threshold_Min  AS FLOAT) > CAST(A.RESULT  AS FLOAT))) THEN ((D.Parameter_Threshold_Min - A.RESULT)*100)/D.Parameter_Threshold_Min
                        ELSE 0 END as NON_COMPLIANT_PERCENTAGE,
                    A.DATE as CAPTURED_DATE,
                    current_timestamp() AS LAST_UPDATED_DATE,
                    current_timestamp() AS CREATED_DATE
                    from wrp_site_lab A
                    left join parameter_on_off B
                    on A.PARAMETER=B.Parameter
                    and A.CATEGORY=B.Zone
                    left join wastewater_phase C
                    on A.CATEGORY=C.WASTE_WATER_PHASE_NAME
                    left join parameter_albada D
                    on A.PARAMETER=D.PARAMETER_SYMBOL
                    and C.DIM_WW_PHASE_ID=D.DIM_WW_PHASE_ID
                    and D.Parameter_Sample_Type='Waste Water'
                """

    df_transformed = spark.sql(sql_query)

    logging.info("Executed SQL query for data transformation.")

    logging.info("Executing sample exclusion.")

    df_transformed = df_transformed.join(df_exclude_samples \
                                         , (df_transformed["PARAMETER_NAME"] == df_exclude_samples["Parameter"]) \
                                         & (df_transformed["WASTE_WATER_PHASE"] == df_exclude_samples["Zone"]) \
                                         & (df_transformed["CAPTURED_DATE"] == df_exclude_samples["Date"]),
                                         how="left_anti")

    logging.info("Done with sample exclusion.")

    df_transformed = df_transformed.withColumn( \
        "FACT_WW_EVE_SAMPLE_RESULT_ID", sha2(concat_ws("||", \
                                                       "PARAMETER_NAME", "WASTE_WATER_PHASE", \
                                                       "CAPTURED_DATE"), 256)
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "WRP_SITE_LAB": DataFrame for raw data WRP Site Lab.
            - "PARAMETER_ON_OFF": DataFrame for raw data Parameter On Off.
            - "EXCLUDE_SAMPLES": DataFrame for raw data Exclude Samples.
            - "DIM_WA_OP_WASTEWATER_PHASE": DataFrame for dimension dim_wa_op_wastewater_phase.
            - "DIM_WA_REG_PARAMETER": DataFrame for dimension dim_wa_reg_parameter.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_wrp_site_lab = source_dfs["WRP_SITE_LAB"]
    df_parameter_on_off = source_dfs["PARAMETER_ON_OFF"]
    df_exclude_samples = source_dfs["EXCLUDE_SAMPLES"]
    df_wastewater_phase = source_dfs["DIM_WA_OP_WASTEWATER_PHASE"]
    df_parameter_albada = source_dfs["DIM_WA_REG_PARAMETER_ALBADA"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_wrp_site_lab=df_wrp_site_lab,
        df_parameter_on_off=df_parameter_on_off,
        df_wastewater_phase=df_wastewater_phase,
        df_parameter_albada=df_parameter_albada,
        df_exclude_samples=df_exclude_samples
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
