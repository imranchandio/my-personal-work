# pylint:disable = unused-argument, import-error, too-many-arguments, too-many-positional-arguments, logging-fstring-interpolation, too-many-locals, too-many-statements
"""
    This is the transformation file for fact_ww_eve_sample_result fact
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import sha2, concat_ws
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_abc_submit: DataFrame,
        df_tse_outflow_operator: DataFrame,
        df_supplier: DataFrame,
        df_transportation: DataFrame,
        df_measure_variable: DataFrame,
        df_service_location: DataFrame,
        df_source_mapping: DataFrame,
        df_loc_location: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from both inflow (ABC_SUBMIT_API)
    and outflow (TSE_OUTFLOW_OPERATOR) data sources,
    performs transformations using SQL, and combines them using UNION ALL 
    to generate the final FACT_WW_EVE_INFLOW_OUTFLOW table.
    '''
    logging.info("Starting the transformation process using Spark SQL queries.")

    # Register DataFrames as temporary views to use in SQL queries
    df_abc_submit.createOrReplaceTempView("ABC_SUBMIT_API")
    df_tse_outflow_operator.createOrReplaceTempView("TSE_Outflow_Operator")
    df_supplier.createOrReplaceTempView("DIM_WA_ORG_WATERQA_SUPPLIER_ALBADA")
    df_transportation.createOrReplaceTempView("DIM_WA_OP_TRANSPORTATION")
    df_measure_variable.createOrReplaceTempView("DIM_CR_OP_MEAS_VARIABLE_ALBADA")
    df_service_location.createOrReplaceTempView("DIM_CR_LOC_CUSTOMER_SERVICE_LOCATION_ALBADA")
    df_source_mapping.createOrReplaceTempView("SOURCE_MAPPING")
    df_loc_location.createOrReplaceTempView("DIM_CR_LOC_LOCATION_ALBADA")

    # Step 1: Extract base data from ABC_SUBMIT_API
    df_base = spark.sql("""
        SELECT
            api.ID AS SUBMIT_ID,
            api.DISCHARGEVOLUMEINM3 AS VOLUME,
            NULL AS RECEIPT_VALUE_IN_SAR,                -- Set to NULL for inflow
            api.CONTRACTOR AS PRIMARY_SUPPLIER,
            api.OTHERSOURCEOFWASTEWATER AS SECONDARY_SUPPLIER,
            api.OTHERCONTRACTOR AS NONLISTED_INFLOW_CONTRACTOR,
            current_timestamp() AS LAST_UPDATED_DATE,
            current_timestamp() AS CREATED_DATE,
            'Waste Water' AS WATER_CATEGORY,  -- Add the constant for WATER_CATEGORY
            'Inflow' AS IS_INFLOW_OUTFLOW     -- Add constant to distinguish inflow
        FROM ABC_SUBMIT_API api
    """)

    df_base.createOrReplaceTempView("df_base")  # Register the result for reuse

    # Step 2: Compute DIM_WATERQA_SUPPLIER_ID based on contractor and other contractor info
    df_supplier_transformed = spark.sql("""
        SELECT
            base.SUBMIT_ID,
            CASE
                WHEN TRIM(base.PRIMARY_SUPPLIER) = 'Other' OR TRIM(base.PRIMARY_SUPPLIER) = 'OTHER' OR TRIM(base.PRIMARY_SUPPLIER) = 'other'
                THEN s.DIM_WATERQA_SUPPLIER_ID
                ELSE s2.DIM_WATERQA_SUPPLIER_ID
            END AS DIM_WATERQA_SUPPLIER_ID,
            CASE
                WHEN TRIM(base.PRIMARY_SUPPLIER) = 'Other' OR TRIM(base.PRIMARY_SUPPLIER) = 'OTHER' OR TRIM(base.PRIMARY_SUPPLIER) = 'other' 
                THEN TRIM(COALESCE(s.COMPANY_NAME, base.SECONDARY_SUPPLIER, UPPER(base.PRIMARY_SUPPLIER)))
                ELSE TRIM(COALESCE(s2.COMPANY_NAME, base.PRIMARY_SUPPLIER))
            END AS COMPANY_NAME
        FROM df_base base
        LEFT JOIN DIM_WA_ORG_WATERQA_SUPPLIER_ALBADA s
            ON TRIM(s.SUPPLIER_NAME) = TRIM(base.SECONDARY_SUPPLIER) 
            AND s.SUPPLIER_TYPE_NAME = 'Waste Water Inflow'
        LEFT JOIN DIM_WA_ORG_WATERQA_SUPPLIER_ALBADA s2
            ON TRIM(s2.SUPPLIER_NAME) = TRIM(base.PRIMARY_SUPPLIER) 
            AND s2.SUPPLIER_TYPE_NAME = 'Waste Water Inflow'
    """)

    df_supplier_transformed.createOrReplaceTempView("df_supplier")  # Register result for reuse

    # Step 3: Compute DIM_TRANSPORTATION_ID
    df_transportation_transformed = spark.sql("""
        SELECT
            base.SUBMIT_ID,
            t.DIM_TRANSPORTATION_ID
        FROM df_base base
        LEFT JOIN DIM_WA_OP_TRANSPORTATION t
            ON base.SUBMIT_ID = t.DRIVER_ID
            AND t.IS_OUTFLOW_INFLOW = 'Inflow'
    """)

    # Register result for reuse
    df_transportation_transformed.createOrReplaceTempView("df_transportation")
    # Step 4: Compute MEAS_VARIABLE_ID
    df_variable_transformed = spark.sql("""
        SELECT
            base.SUBMIT_ID,
            m.MEAS_VARIABLE_ID,
            m.VARIABLE_UNIT AS UNIT  -- Adding the UNIT column
        FROM df_base base
        LEFT JOIN DIM_CR_OP_MEAS_VARIABLE_ALBADA m
            ON m.VARIABLE_NAME = 'Inflow Volume'
            AND m.VARIABLE_TYPE = 'Waste Water Inflow'
    """)

    df_variable_transformed.createOrReplaceTempView("df_variable")  # Register result for reuse
    # Step 5: Compute SERVICE_LOCATION_ID
    df_service_location_transformed = spark.sql("""
        SELECT
            base.SUBMIT_ID,
            sl.SERVICE_LOCATION_ID
        FROM df_base base
        LEFT JOIN DIM_CR_LOC_CUSTOMER_SERVICE_LOCATION_ALBADA sl
            ON sl.SERVICE_LOCATION_NAME = base.SECONDARY_SUPPLIER
            AND sl.SERVICE_LOCATION_TYPE = 'Inflow'                                
    """)

    # Register result for reuse
    df_service_location_transformed.createOrReplaceTempView("df_service_location")
    # Step 6: Combine all transformed DataFrames into one
    df_final = spark.sql("""
        SELECT
            base.SUBMIT_ID,
            base.VOLUME,
            base.RECEIPT_VALUE_IN_SAR,
            base.PRIMARY_SUPPLIER,
            base.SECONDARY_SUPPLIER,
            base.NONLISTED_INFLOW_CONTRACTOR,
            base.LAST_UPDATED_DATE,
            base.CREATED_DATE,
            base.WATER_CATEGORY,
            base.IS_INFLOW_OUTFLOW,
            supplier.DIM_WATERQA_SUPPLIER_ID,
            supplier.COMPANY_NAME,
            transportation.DIM_TRANSPORTATION_ID,
            variable.MEAS_VARIABLE_ID,
            variable.UNIT,
            service_location.SERVICE_LOCATION_ID
        FROM df_base base
        LEFT JOIN df_supplier supplier
            ON base.SUBMIT_ID = supplier.SUBMIT_ID
        LEFT JOIN df_transportation transportation
            ON base.SUBMIT_ID = transportation.SUBMIT_ID
        LEFT JOIN df_variable variable
            ON base.SUBMIT_ID = variable.SUBMIT_ID
        LEFT JOIN df_service_location service_location
            ON base.SUBMIT_ID = service_location.SUBMIT_ID
    """)

    # Return the transformed DataFrame
    df_final = df_final.withColumn(
        "FACT_WW_INFLOW_OUTFLOW_ID", sha2(concat_ws("||", \
                                                    "WATER_CATEGORY", "IS_INFLOW_OUTFLOW", "SUBMIT_ID"), 256)
    )

    df_final.createOrReplaceTempView("df_final")  # Register the result for reuse

    df_with_mapping = spark.sql("""
    SELECT
        f.SUBMIT_ID,
        f.VOLUME,
        f.UNIT,
        f.RECEIPT_VALUE_IN_SAR,
        f.WATER_CATEGORY,
        f.COMPANY_NAME,
        f.PRIMARY_SUPPLIER,
        f.SECONDARY_SUPPLIER,
        f.NONLISTED_INFLOW_CONTRACTOR,
        f.LAST_UPDATED_DATE,
        f.CREATED_DATE,
        f.DIM_WATERQA_SUPPLIER_ID,
        f.DIM_TRANSPORTATION_ID,
        f.MEAS_VARIABLE_ID,
        f.SERVICE_LOCATION_ID,
        f.FACT_WW_INFLOW_OUTFLOW_ID,
        f.IS_INFLOW_OUTFLOW,

        -- IN_MAPPING_FLAG_COMPANY Logic
        CASE 
            WHEN f.DIM_WATERQA_SUPPLIER_ID IS NULL THEN 'Not in Mapping' 
            ELSE 'In Mapping'
        END AS IN_MAPPING_FLAG_COMPANY,
        
        -- Perform the left join with SOURCE_MAPPING to get SourceNameFix
        sm.SourceNameFix AS SOURCE_NAME_FIX_MAPPING  -- Will handle further logic in next step

    FROM df_final f
    LEFT JOIN SOURCE_MAPPING sm
        ON sm.SourceName = f.SECONDARY_SUPPLIER
    """)

    df_with_mapping.createOrReplaceTempView("df_with_mapping")

    df_source_fix_applied = spark.sql("""
        SELECT 
            df_with_mapping.*,

            -- Apply SOURCE_NAME_FIX Logic
            CASE 
                WHEN IS_INFLOW_OUTFLOW = 'Inflow'
                THEN COALESCE(SOURCE_NAME_FIX_MAPPING, SECONDARY_SUPPLIER)
                ELSE SECONDARY_SUPPLIER
            END AS SOURCE_NAME_FIX

        FROM df_with_mapping
    """)

    df_source_fix_applied.createOrReplaceTempView("df_source_fix_applied")

    df_final_transformed = spark.sql("""
    SELECT
        df_source_fix_applied.*,

        -- IN_MAPPING_FLAG_SOURCE Logic
        CASE
            WHEN IS_INFLOW_OUTFLOW = 'Inflow' AND SOURCE_NAME_FIX_MAPPING IS NULL
            THEN 'Not in Mapping'
            ELSE 'In Mapping'
        END AS IN_MAPPING_FLAG_SOURCE

    FROM df_source_fix_applied
    """)

    # Register the result for reuse
    df_final_transformed.createOrReplaceTempView("df_final_transformed")

    # Step 1: Extract base data from TSE_Outflow_Operator
    df_base_outflow = spark.sql("""
        SELECT
            o.RECEIPTNUMBER AS SUBMIT_ID,
            o.TRUCKPLATENUMBER,
            o.FILLINGVOLUMEINM3 AS VOLUME,
            o.RECEIPTVALUEINSAR AS RECEIPT_VALUE_IN_SAR,
            o.CONTRACTORNAME AS PRIMARY_SUPPLIER,
            o.OTHERCONTRACTORNAME AS SECONDARY_SUPPLIER,
            o.LOCATIONCOORDINATES AS LOCATIONCOORDINATES,
            o.RECYCLEDWATERDESTINATION AS RECYCLEDWATERDESTINATION,
            NULL AS NONLISTED_INFLOW_CONTRACTOR,  -- Not applicable for outflow
            current_timestamp() AS LAST_UPDATED_DATE,
            current_timestamp() AS CREATED_DATE,
            'Recycled Water' AS WATER_CATEGORY,    -- Outflow-specific value
            'Outflow' AS IS_INFLOW_OUTFLOW         -- Add constant to distinguish outflow
        FROM TSE_Outflow_Operator o
    """)

    df_base_outflow.createOrReplaceTempView("df_base_outflow")  # Register the result for reuse

    # Step 2: Compute DIM_WATERQA_SUPPLIER_ID and COMPANY_NAME based
    #  on contractor and other contractor info for outflow
    df_supplier_outflow = spark.sql("""
        SELECT
            base.SUBMIT_ID,
            CASE
                WHEN TRIM(base.PRIMARY_SUPPLIER) = 'Other' OR TRIM(base.PRIMARY_SUPPLIER) = 'OTHER' OR TRIM(base.PRIMARY_SUPPLIER) = 'other'
                THEN s.DIM_WATERQA_SUPPLIER_ID
                ELSE s2.DIM_WATERQA_SUPPLIER_ID
            END AS DIM_WATERQA_SUPPLIER_ID,
            CASE
                WHEN TRIM(base.PRIMARY_SUPPLIER) = 'Other' OR TRIM(base.PRIMARY_SUPPLIER) = 'OTHER' OR TRIM(base.PRIMARY_SUPPLIER) = 'other'
                THEN TRIM(COALESCE(s.COMPANY_NAME, base.SECONDARY_SUPPLIER, UPPER(base.PRIMARY_SUPPLIER)))
                ELSE TRIM(COALESCE(s2.COMPANY_NAME, base.PRIMARY_SUPPLIER))
            END AS COMPANY_NAME
        FROM df_base_outflow base
        LEFT JOIN DIM_WA_ORG_WATERQA_SUPPLIER_ALBADA s
            ON TRIM(s.SUPPLIER_NAME) = TRIM(base.SECONDARY_SUPPLIER) 
            AND s.SUPPLIER_TYPE_NAME = 'Waste Water Outflow'
        LEFT JOIN DIM_WA_ORG_WATERQA_SUPPLIER_ALBADA s2
            ON TRIM(s2.SUPPLIER_NAME) = TRIM(base.PRIMARY_SUPPLIER) 
            AND s2.SUPPLIER_TYPE_NAME = 'Waste Water Outflow'
    """)

    # Register result for reuse
    df_supplier_outflow.createOrReplaceTempView("df_supplier_outflow")

    # Step 3: Compute DIM_TRANSPORTATION_ID for outflow
    df_transportation_outflow = spark.sql("""
        SELECT
            base.SUBMIT_ID,
            t.DIM_TRANSPORTATION_ID,
            t.VEHICLE_PLATE_NUMBER
        FROM df_base_outflow base
        LEFT JOIN DIM_WA_OP_TRANSPORTATION t
            ON base.SUBMIT_ID = t.DRIVER_ID
            AND TRIM(base.TRUCKPLATENUMBER) = TRIM(t.VEHICLE_PLATE_NUMBER)
            AND t.IS_OUTFLOW_INFLOW = 'Outflow'
    """)

    # Register result for reuse
    df_transportation_outflow.createOrReplaceTempView("df_transportation_outflow")

    # Step 4: Compute MEAS_VARIABLE_ID for outflow
    df_variable_outflow = spark.sql("""
        SELECT
            base.SUBMIT_ID,
            m.MEAS_VARIABLE_ID,
            m.VARIABLE_UNIT AS UNIT  -- Adding the UNIT column
        FROM df_base_outflow base
        LEFT JOIN DIM_CR_OP_MEAS_VARIABLE_ALBADA m
            ON m.VARIABLE_NAME = 'Outflow Volume'
            AND m.VARIABLE_TYPE = 'Waste Water Outflow'
    """)

    df_variable_outflow.createOrReplaceTempView("df_variable_outflow")  # Register result for reuse

    # Step 5: Compute SERVICE_LOCATION_ID for outflow
    df_service_location_outflow = spark.sql("""
        SELECT
            distinct
            base.SUBMIT_ID,
            s1.SERVICE_LOCATION_ID
        FROM df_base_outflow base
        LEFT JOIN DIM_CR_LOC_CUSTOMER_SERVICE_LOCATION_ALBADA s1
            ON base.RECYCLEDWATERDESTINATION = s1.SERVICE_LOCATION_NAME
            AND s1.SERVICE_LOCATION_TYPE='Outflow'
        INNER JOIN DIM_CR_LOC_LOCATION_ALBADA C
            ON s1.DIM_LOCATION_ID = C.DIM_LOCATION_ID
            AND COALESCE(base.LOCATIONCOORDINATES,'NA,NA') = CONCAT(TRIM(COALESCE(C.LATITUDE,'NA')),',',TRIM(COALESCE(C.LONGITUDE,'NA')))
    """)

    # Register result for reuse
    df_service_location_outflow.createOrReplaceTempView("df_service_location_outflow")

    # Step 6: Combine all transformed DataFrames into one
    df_final_outflow = spark.sql("""
        SELECT
            base.SUBMIT_ID,
            base.VOLUME,
            base.RECEIPT_VALUE_IN_SAR,
            base.PRIMARY_SUPPLIER,
            base.SECONDARY_SUPPLIER,
            base.NONLISTED_INFLOW_CONTRACTOR,
            base.RECYCLEDWATERDESTINATION,
            base.LAST_UPDATED_DATE,
            base.CREATED_DATE,
            base.WATER_CATEGORY,
            base.IS_INFLOW_OUTFLOW,
            supplier.DIM_WATERQA_SUPPLIER_ID,
            supplier.COMPANY_NAME,
            transportation.DIM_TRANSPORTATION_ID,
            variable.MEAS_VARIABLE_ID,
            variable.UNIT,
            service_location.SERVICE_LOCATION_ID
        FROM df_base_outflow base
        LEFT JOIN df_supplier_outflow supplier
            ON base.SUBMIT_ID = supplier.SUBMIT_ID
        LEFT JOIN df_transportation_outflow transportation
            ON base.SUBMIT_ID = transportation.SUBMIT_ID
            AND TRIM(base.TRUCKPLATENUMBER) = TRIM(transportation.VEHICLE_PLATE_NUMBER)
        LEFT JOIN df_variable_outflow variable
            ON base.SUBMIT_ID = variable.SUBMIT_ID
        LEFT JOIN df_service_location_outflow service_location
            ON base.SUBMIT_ID = service_location.SUBMIT_ID
    """)

    # Step 7: Generate the primary key for the outflow data
    df_final_outflow = df_final_outflow.withColumn(
        "FACT_WW_INFLOW_OUTFLOW_ID", sha2(concat_ws("||", \
                                                    "WATER_CATEGORY", "IS_INFLOW_OUTFLOW", "SUBMIT_ID"), 256)
    )

    df_final_outflow.createOrReplaceTempView("df_final_outflow")  # Register the result for reuse

    df_with_mapping_outflow = spark.sql("""
    SELECT
        f.SUBMIT_ID,
        f.VOLUME,
        f.UNIT,
        f.RECEIPT_VALUE_IN_SAR,
        f.WATER_CATEGORY,
        f.COMPANY_NAME,
        f.PRIMARY_SUPPLIER,
        f.SECONDARY_SUPPLIER,
        f.NONLISTED_INFLOW_CONTRACTOR,
        f.LAST_UPDATED_DATE,
        f.CREATED_DATE,
        f.DIM_WATERQA_SUPPLIER_ID,
        f.DIM_TRANSPORTATION_ID,
        f.MEAS_VARIABLE_ID,
        f.SERVICE_LOCATION_ID,
        f.FACT_WW_INFLOW_OUTFLOW_ID,
        f.IS_INFLOW_OUTFLOW,

        -- IN_MAPPING_FLAG_COMPANY Logic
        CASE 
            WHEN f.DIM_WATERQA_SUPPLIER_ID IS NULL THEN 'Not in Mapping' 
            ELSE 'In Mapping'
        END AS IN_MAPPING_FLAG_COMPANY,
        sm.SourceNameFix AS SOURCE_NAME_FIX_MAPPING,
        NULL AS SOURCE_NAME_FIX,
        NULL AS IN_MAPPING_FLAG_SOURCE

    FROM df_final_outflow f
    LEFT JOIN SOURCE_MAPPING sm
        ON sm.SourceName = f.SECONDARY_SUPPLIER
    """)

    # Register the result for reuse
    df_with_mapping_outflow.createOrReplaceTempView("df_with_mapping_outflow")

    # Combine Inflow and Outflow using UNION ALL
    combined_query = """
        SELECT * FROM df_with_mapping_outflow
        UNION ALL
        SELECT * FROM df_final_transformed
    """

    # Execute the combined SQL query
    df_combined = spark.sql(combined_query)

    df_combined.createOrReplaceTempView("df_combined")

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_combined, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_combined = df_combined.repartition(num_partitions)

    return df_combined


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "TSE_OUTFLOW_OPERATOR": DataFrame for TSE Outflow Operator raw data.
            - "ABC_SUBMIT_API": DataFrame for ABC Submit Data raw data.
            - "DIM_WA_ORG_WATERQA_SUPPLIER_ALBADA": DataFrame for DIM_WA_ORG_WATERQA_SUPPLIER.
            - "DIM_WA_OP_TRANSPORTATION": DataFrame for DIM_WA_OP_TRANSPORTATION.
            - "DIM_CR_OP_MEAS_VARIABLE_ALBADA": DataFrame for DIM_CR_OP_MEAS_VARIABLE.
            - "DIM_CR_LOC_CUSTOMER_SERVICE_LOCATION_ALBADA": DataFrame for Service location dim.
            - "DIM_CR_LOC_LOCATION_ALBADA": DataFrame for DIM_CR_LOC_LOCATION.


    Returns:
        DataFrame: The transformed DataFrame.
    """
    df_abc_submit = source_dfs["ABC_SUBMIT_API"]
    df_tse_outflow_operator = source_dfs["TSE_Outflow_Operator"]
    df_supplier = source_dfs["DIM_WA_ORG_WATERQA_SUPPLIER_ALBADA"]
    df_transportation = source_dfs["DIM_WA_OP_TRANSPORTATION"]
    df_measure_variable = source_dfs["DIM_CR_OP_MEAS_VARIABLE_ALBADA"]
    df_service_location = source_dfs["DIM_CR_LOC_CUSTOMER_SERVICE_LOCATION_ALBADA"]
    df_source_mapping = source_dfs["SOURCE_MAPPING"]
    df_loc_location = source_dfs["DIM_CR_LOC_LOCATION_ALBADA"]

    # Perform joins, filters, etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_abc_submit=df_abc_submit,
        df_tse_outflow_operator=df_tse_outflow_operator,
        df_supplier=df_supplier,
        df_transportation=df_transportation,
        df_measure_variable=df_measure_variable,
        df_service_location=df_service_location,
        df_source_mapping=df_source_mapping,
        df_loc_location=df_loc_location
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
) -> DataFrame:
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
