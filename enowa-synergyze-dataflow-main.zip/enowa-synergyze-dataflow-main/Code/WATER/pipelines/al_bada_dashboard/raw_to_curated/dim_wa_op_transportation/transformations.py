# pylint:disable = unused-argument, import-error
"""
    This is the transformation file for dim_wa_op_transportation dimension
"""
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_abc_submit: DataFrame,
        df_tse_outflow_operator: DataFrame
) -> DataFrame:
    '''
    This function prepares the dataframe from the raw layer table passed in as DataFrame.
    '''
    logging.info("Starting the transformation process.")

    # Define the cutoff date as a string
    cutoff_date = "2023-03-04 15:59:56"

    # Convert EnteredDate (assumed to be in Unix timestamp) to a readable date
    df_abc_submit = df_abc_submit.withColumn("DriverDate", \
                                             F.when(
                                                 F.from_unixtime(F.col("EnteredDate")) <= cutoff_date,
                                                 F.concat(
                                                     F.expr("substr(DriverDate, 4, 2)"), F.lit("/"),
                                                     F.expr("substr(DriverDate, 1, 2)"), F.lit("/"),
                                                     F.expr("substr(DriverDate, 7, 4)")
                                                 )
                                             ).otherwise(F.col("DriverDate"))
                                             )

    # Convert the resulting string to a date with the format 'YYYY-MM-DD'
    df_abc_submit = df_abc_submit.withColumn("DriverDate", \
                                             F.date_format(F.to_date(F.col("DriverDate"), "dd/MM/yyyy"), "yyyy-MM-dd")
                                             )

    # Convert the 12 hour time format into 24 hour format
    df_abc_submit = df_abc_submit.withColumn(
        "DriverTime",
        F.when(F.col("DriverTime").like("%AM"),
               # Handle AM cases
               F.when(F.substring(F.col("DriverTime"), 2, 1) == ":",
                      F.concat(
                          F.lit("0"),
                          F.substring(F.col("DriverTime"), 1, 1),
                          F.substring(F.col("DriverTime"), 3, 2),
                          F.lit("00")
                      )
                      ).otherwise(
                   F.concat(
                       F.substring(F.col("DriverTime"), 1, 2),
                       F.substring(F.col("DriverTime"), 4, 2),
                       F.lit("00")
                   )
               )
               ).otherwise(
            # Handle PM cases
            F.when(F.substring(F.col("DriverTime"), 2, 1) == ":",
                   F.concat(
                       F.expr("CAST(SUBSTRING(DriverTime, 1, 1) AS INT) + 12"),
                       F.substring(F.col("DriverTime"), 3, 2),
                       F.lit("00")
                   )
                   ).when(F.substring(F.col("DriverTime"), 1, 2) == "12",
                          F.concat(
                              F.substring(F.col("DriverTime"), 1, 2),
                              F.substring(F.col("DriverTime"), 4, 2),
                              F.lit("00")
                          )
                          ).otherwise(
                F.concat(
                    F.expr("CAST(SUBSTRING(DriverTime, 1, 2) AS INT) + 12"),
                    F.substring(F.col("DriverTime"), 4, 2),
                    F.lit("00")
                )
            )
        )
    )

    df_abc_submit.show()

    # Convert the resulting string to a date with the format 'EEE dd-MMM-yyyy'
    df_tse_outflow_operator = df_tse_outflow_operator.withColumn("TRAVEL_DAY", \
                                                                 F.date_format(F.to_date(F.expr \
                                                                                             ("regexp_replace(DATE, '^[A-Za-z]{3} ', '')"),
                                                                                         "dd-MMM-yyyy"), "EEEE")
                                                                 ) \
        .withColumn("TRAVEL_DATE", F.to_date(F.expr \
                                                 ("regexp_replace(DATE, '^[A-Za-z]{3} ', '')"), "dd-MMM-yyyy"))

    df_tse_outflow_operator.show()

    df_abc_submit.createOrReplaceTempView("abc_submit")
    df_tse_outflow_operator.createOrReplaceTempView("tse_outflow_operator")

    logging.info("Executing SQL query for data transformation.")

    sql_query = """
                WITH TempData AS (
                        SELECT 
                        id as DRIVER_ID,
                        FirstName AS  DRIVER_FIRST_NAME,
                        LastName AS DRIVER_LAST_NAME,
                        'Truck' AS VEHICLE_TYPE,
                        date_format(DriverDate,'EEEE') AS TRAVEL_DAY,
                        DriverDate AS TRAVEL_DATE,
                        date_format(to_timestamp(trim(DriverTime), 'HHmmss'),'HH:mm:ss') AS TRAVEL_TIME,
                        'AL-BADA' AS PARTITION_KEY,
                        TruckPlateNumber AS VEHICLE_PLATE_NUMBER,
                        'Inflow' AS IS_OUTFLOW_INFLOW,
                        'Albada' AS SUB_DOMAIN_TYPE,
                        current_timestamp() AS LAST_UPDATED_DATE,
                        current_timestamp() AS CREATED_DATE 
                        FROM abc_submit
                        UNION 
                        SELECT 
                        RECEIPTNUMBER  as DRIVER_ID,
                        NULL AS DRIVER_FIRST_NAME,
                        NULL AS DRIVER_LAST_NAME,
                        'Truck' AS VEHICLE_TYPE,
                        TRAVEL_DAY,
                        TRAVEL_DATE,
                        date_format(to_timestamp(trim(TIME), 'H:mm:ss'),'HH:mm:ss') AS TRAVEL_TIME,
                        'AL-BADA' AS PARTITION_KEY,
                        TRUCKPLATENUMBER AS VEHICLE_PLATE_NUMBER,
                        'Outflow' AS IS_OUTFLOW_INFLOW,
                        'Albada' AS SUB_DOMAIN_TYPE,
                        current_timestamp() AS LAST_UPDATED_DATE,
                        current_timestamp() AS CREATED_DATE 
                        FROM tse_outflow_operator
                    )
                    SELECT
                    *
                    FROM TempData
                """

    df_transformed = spark.sql(sqlQuery=sql_query)

    logging.info("Executed SQL query for data transformation.")

    df_transformed = df_transformed.withColumn( \
        "DIM_TRANSPORTATION_ID", F.sha2(F.concat_ws("||", \
                                                    "DRIVER_ID", "TRAVEL_DATE", "TRAVEL_TIME", "VEHICLE_PLATE_NUMBER"),
                                        256)
    )

    logging.info("Calculating the number of partitions.")

    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)

    logging.info("Repartitioning the DataFrame into %d partitions.", num_partitions)

    df_transformed = df_transformed.repartition(num_partitions)

    return df_transformed


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrames by performing necessary joins and filters,
    returning a transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with keys:
            - "ABC_SUBMIT": DataFrame for ABC_Submit.
            - "TSE_OUTFLOW_OPERATOR": DataFrame for TSE_Outflow_Operator.

    Returns:
        DataFrame: The transformed DataFrame.
    """

    df_abc_submit = source_dfs["ABC_SUBMIT"]
    df_tse_outflow_operator = source_dfs["TSE_OUTFLOW_OPERATOR"]

    # Perform joins, filters etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_abc_submit=df_abc_submit,
        df_tse_outflow_operator=df_tse_outflow_operator
    )

    transform_df = transform_df.distinct()

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing
        storage configuration information.
        task_parameters (dict): A dictionary containing task parameters,
        including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    if spark_df:
        print(spark_df.printSchema())

    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    return None
