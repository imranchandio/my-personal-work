# pylint:disable = unused-argument, import-error, singleton-comparison, f-string-without-interpolation, logging-fstring-interpolation, inconsistent-return-statements, no-else-return
'''
    This is the transformation file for mv_ww_albada_result
'''
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_fact_ww_eve_sample_result: DataFrame,
        df_dim_wa_reg_parameter_albada: DataFrame
) -> DataFrame:
    """
        This function is for transformation of fact_ww_eve_sample_result and 
        dim_wa_reg_parameter which includes the data formatting and KPI column caculations
        like MEAN, STANDARD_DEVIATION etc.
    """
    logging.info("Starting the transformation process\
                  for fact_ww_eve_sample_result & dim_wa_reg_parameter.")

    # Add a new column to indicate whether the condition is satisfied
    df_fact_ww_eve_sample_result = df_fact_ww_eve_sample_result.withColumn(
        "MEAN_STD_CONDITION", 
        F.when(
            (F.col("PARAMETER_STATUS") == "On") &\
            (F.col("CAPTURED_DATE").isNotNull()) &\
            (F.col("PARAMETER_STATUS_START_DATE").isNotNull()) &\
            (F.to_date(F.col("CAPTURED_DATE"), "yyyy-MM-dd")\
              >= F.to_date(F.col("PARAMETER_STATUS_START_DATE"), "yyyy-MM-dd")),\
            True
        ).otherwise(False)
    )

    # Converting REPORTED_TEST_RESULT into float
    df_fact_ww_eve_sample_result = df_fact_ww_eve_sample_result.withColumn\
        ("REPORTED_TEST_RESULT",F.col("REPORTED_TEST_RESULT").cast("float"))

    # Define the window specification
    window_spec = Window.partitionBy("PARAMETER_NAME")

    # Calculate the standard deviation conditionally
    df_fact_ww_eve_sample_result = df_fact_ww_eve_sample_result.withColumn(
        "STANDARD_DEV",
        F.when(
            F.col("MEAN_STD_CONDITION") == True,
            F.stddev(F.when(F.col("MEAN_STD_CONDITION"), F.col("REPORTED_TEST_RESULT")))\
                .over(window_spec)
        ).otherwise(F.lit(0.0))
    )

    # Calculate the mean conditionally
    df_fact_ww_eve_sample_result = df_fact_ww_eve_sample_result.withColumn(
        "MEAN",
        F.when(
            F.col("MEAN_STD_CONDITION") == True,
            F.mean(F.when(F.col("MEAN_STD_CONDITION"), F.col("REPORTED_TEST_RESULT")))\
                .over(window_spec)
        ).otherwise(F.lit(0.0))
    )

    # calcualting standard deviation above/below
    df_fact_ww_eve_sample_result = df_fact_ww_eve_sample_result.withColumn(
        "STANDARD_DEV_ABOVE", 
        F.col("MEAN") + (F.col("STANDARD_DEV") * 3)
    ).withColumn(
        "STANDARD_DEV_BELOW", 
        F.col("MEAN") - (F.col("STANDARD_DEV") * 3)
    )

    df_fact_ww_eve_sample_result.createOrReplaceTempView("FACT_WW_EVE_SAMPLE_RESULT")

    df_dim_wa_reg_parameter_albada.createOrReplaceTempView("DIM_WA_REG_PARAMETER_ALBADA")

    ## add try catch block for spark.sql

    df_transformed = spark.sql(
        """ 
            SELECT 
                CAST(A.CAPTURED_DATE AS DATE) as CAPTURED_DATE,
                A.WASTE_WATER_PHASE,
                B.PARAMETER_TYPE,
                B.PARAMETER_NAME,
                A.PARAMETER_NAME as PARAMETER_CODE,
                A.REPORTED_TEST_RESULT,
                B.PARAMETER_UNIT,
                A.PARAMETER_MAPPING_FLAG,
                A.WWPHASE_MAPPING_FLAG,
                B.PARAMETER_DASHBOARD_PRIORITY,
                B.PARAMETER_GUIDELINES_NOTE,
                A.PARAMETER_STATUS,
                CAST(A.PARAMETER_STATUS_START_DATE AS DATE)\
                      as PARAMETER_STATUS_START_DATE ,
                CASE 
                    WHEN B.PARAMETER_NAME='Temperature' THEN NULL 
                    ELSE B.PARAMETER_THRESHOLD_MIN
                    END as THRESHOLD_MIN,
                B.PARAMETER_THRESHOLD_MAX as THRESHOLD_MAX,
                CASE 
                    WHEN A.COMPLIANCE_STATUS='Max' or A.COMPLIANCE_STATUS='Min' THEN 'Non-Compliant' 
                    ELSE 'Compliant'
                    END as COMPLIANCE_STATUS,
                 A.NON_COMPLIANT_AMOUNT,
                 A.NON_COMPLIANT_PERCENTAGE as THRESHOLD_EXCEPTION_PERCENT,
                CASE 
                    WHEN A.REPORTED_TEST_RESULT < A.STANDARD_DEV_BELOW THEN 'BELOW' 
                    WHEN A.REPORTED_TEST_RESULT > A.STANDARD_DEV_ABOVE THEN 'ABOVE'
                    ELSE 'IN BETWEEN'
                    END as FLAG,
                CASE
                    WHEN A.COMPLIANCE_STATUS='Compliant' THEN 'Ok' 
                    ELSE A.COMPLIANCE_STATUS
                    END as THRESHOLD_EXCEPTION,
                A.MEAN,
                A.STANDARD_DEV,
                A.STANDARD_DEV_BELOW,
                A.STANDARD_DEV_ABOVE,
                A.MEAN_STD_CONDITION
            FROM 
            FACT_WW_EVE_SAMPLE_RESULT A
            LEFT JOIN DIM_WA_REG_PARAMETER_ALBADA B
            ON A.DIM_PARAMETER_ID = B.DIM_PARAMETER_ID
            
        """
    )

    logging.info("Executed SQL query for data transformation.")

    max_partition_size_mb = 256
    logging.info("Calculating the number of partitions.")
    num_partitions = calculate_num_partitions(df_transformed, max_partition_size_mb)
    logging.info(f"Repartitioning DataFrame into {num_partitions} partitions.")

    df_transformed = df_transformed.repartition(num_partitions)

    logging.info("Repartitioning process completed.")
    return df_transformed


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrame by performing necessary transformations and 
    returns the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with 
        the key "FACT_WW_EVE_SAMPLE_RESULT" and "DIM_WA_REG_PARAMETER_ALBADA".
            - "FACT_WW_EVE_SAMPLE_RESULT": DataFrame for FACT_WW_EVE_SAMPLE_RESULT.
            - "DIM_WA_REG_PARAMETER_ALBADA": DataFrame for DIM_WA_REG_PARAMETER.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    logging.info("Starting the transformation process.")


    df_fact_ww_eve_sample_result = source_dfs["FACT_WW_EVE_SAMPLE_RESULT"]
    df_dim_wa_reg_parameter_albada = source_dfs["DIM_WA_REG_PARAMETER_ALBADA"]

    # Perform joins, filters, etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_fact_ww_eve_sample_result=df_fact_ww_eve_sample_result,
        df_dim_wa_reg_parameter_albada=df_dim_wa_reg_parameter_albada
    )

    logging.info("Transformation completed successfully..")

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage
                                        configuration information.
        task_parameters (dict): A dictionary containing task parameters,
                                 including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def presentation_datavalidations(spark_df: DataFrame):
    """
        function for data validation
    """
    print("Inside presentation_datavalidations")
    return spark_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """

    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    elif task_name == "adw_presentation_data_validations_checks":
        print("transformations - adw_presentation_data_validations_checks")
        return presentation_datavalidations(spark_df)
