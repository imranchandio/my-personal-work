# pylint:disable = unused-argument, import-error, too-many-arguments, f-string-without-interpolation, logging-fstring-interpolation, inconsistent-return-statements, too-many-positional-arguments, no-else-return
'''
    This is the transformation file for mv_ww_albada_flow
'''
import logging
import os
import sys
from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from common_utils import calculate_num_partitions, impose_schema
from read_utils import read

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/utility")


def prepare_transformed_df(
        spark: SparkSession,
        df_dim_wa_op_transportation: DataFrame,
        df_fact_ww_eve_inflow_outflow: DataFrame,
        df_dim_wa_org_waterqa_supplier: DataFrame,
        df_dim_cr_op_meas_variable: DataFrame,
        df_dim_cr_loc_customer_service_location: DataFrame,
        df_dim_cr_loc_location: DataFrame
) -> DataFrame:
    """
        This function is for transformation of df_fact_ww_eve_inflow_outflow and 
        all dimensions related to it.
    """
    logging.info("Starting the transformation process.")


    df_dim_wa_op_transportation.createOrReplaceTempView("op_transportation")
    df_fact_ww_eve_inflow_outflow.createOrReplaceTempView("inflow_outflow")
    df_dim_wa_org_waterqa_supplier.createOrReplaceTempView("waterqa_supplier")
    df_dim_cr_op_meas_variable.createOrReplaceTempView("meas_variable")
    df_dim_cr_loc_customer_service_location.createOrReplaceTempView("customer_service_location")
    df_dim_cr_loc_location.createOrReplaceTempView("loc_location")

    df_inflow = spark.sql(
    """
      WITH CompanyDischarge AS (
        SELECT 
            TRIM(coalesce(C.SUPPLIER_NAME, A.COMPANY_NAME)) AS COMPANY_NAME,
            SUM(CAST(A.VOLUME AS INT)) AS TotalDischargeVolumePerCompany
        FROM 
            inflow_outflow A
        LEFT JOIN 
            waterqa_supplier C ON A.DIM_WATERQA_SUPPLIER_ID = C.DIM_WATERQA_SUPPLIER_ID
        WHERE 
            A.IS_INFLOW_OUTFLOW = 'Inflow'
        GROUP BY 
            TRIM(coalesce(C.SUPPLIER_NAME, A.COMPANY_NAME))
        ),
        TotalDischarge AS (
        SELECT 
            SUM(CAST(A.VOLUME AS INT)) AS TotalDischargeVolumeInM3
        FROM 
            inflow_outflow A
        WHERE 
            A.IS_INFLOW_OUTFLOW = 'Inflow'
        )
    SELECT 
        CAST(B.TRAVEL_DATE AS DATE) AS TRAVEL_DATE,
        B.TRAVEL_DAY,
        B.TRAVEL_TIME,
        A.PRIMARY_SUPPLIER as SOURCE_PRIMARY,
        A.SECONDARY_SUPPLIER as SOURCE_SECONDARY,
        A.NONLISTED_INFLOW_CONTRACTOR as OTHER_CONTRACTOR,
        TRIM(coalesce(C.SUPPLIER_NAME,A.COMPANY_NAME))  as COMPANY_NAME,
        CASE 
          WHEN (CD.TotalDischargeVolumePerCompany / TD.TotalDischargeVolumeInM3) * 100 < 1 
          THEN 'Other' 
           ELSE TRIM(coalesce(C.SUPPLIER_NAME, A.COMPANY_NAME))
        END AS COMPANY_NAME_FIX, 
        A.IN_MAPPING_FLAG_COMPANY,
        A.SECONDARY_SUPPLIER as SOURCE_OF_WW,
        A.SOURCE_NAME_FIX as SOURCE_OF_WW_FIX,
        A.IN_MAPPING_FLAG_SOURCE,
        A.IS_INFLOW_OUTFLOW as WATER_CATEGORY,
        D.VARIABLE_TYPE as MEASUREMENT_VARIABLE,
        A.VOLUME,
        A.UNIT,
        TRIM(B.VEHICLE_PLATE_NUMBER) as TRUCK_PLATE_NUMBER,
        B.DRIVER_FIRST_NAME,
        B.DRIVER_LAST_NAME,
        B.DRIVER_ID,
        A.SUBMIT_ID as RECEIPT_NO,
        A.RECEIPT_VALUE_IN_SAR as RECEIPT_VALUE_IN_SAR,
        E.SERVICE_LOCATION_NAME as RECYCLE_WATER_DESTINATION,
        concat(F.LATITUDE, ',', F.LONGITUDE) as RECYCLE_WATER_LOCATION
    FROM 
        inflow_outflow A
    LEFT JOIN 
        op_transportation B ON A.DIM_TRANSPORTATION_ID = B.DIM_TRANSPORTATION_ID
    LEFT JOIN 
        waterqa_supplier C ON A.DIM_WATERQA_SUPPLIER_ID = C.DIM_WATERQA_SUPPLIER_ID
    LEFT JOIN 
        meas_variable D ON A.MEAS_VARIABLE_ID = D.MEAS_VARIABLE_ID
    LEFT JOIN 
        customer_service_location E ON A.SERVICE_LOCATION_ID = E.SERVICE_LOCATION_ID
    LEFT JOIN 
        loc_location F ON E.DIM_LOCATION_ID = F.DIM_LOCATION_ID
    LEFT JOIN 
        CompanyDischarge CD ON TRIM(coalesce(C.SUPPLIER_NAME, A.COMPANY_NAME)) = CD.COMPANY_NAME
    CROSS JOIN 
        TotalDischarge TD
    WHERE 
        A.IS_INFLOW_OUTFLOW = 'Inflow'
    """
    )
    # Outflow category query
    df_outflow = spark.sql(
    """
        WITH CompanyDischarge AS (
        SELECT 
            TRIM(coalesce(C.SUPPLIER_NAME, A.COMPANY_NAME)) AS COMPANY_NAME,
            SUM(CAST(A.VOLUME AS INT)) AS TotalDischargeVolumePerCompany
        FROM 
            inflow_outflow A
        LEFT JOIN 
            waterqa_supplier C ON A.DIM_WATERQA_SUPPLIER_ID = C.DIM_WATERQA_SUPPLIER_ID
        WHERE 
            A.IS_INFLOW_OUTFLOW = 'Outflow'
        GROUP BY 
            TRIM(coalesce(C.SUPPLIER_NAME, A.COMPANY_NAME))
        ),
        TotalDischarge AS (
        SELECT 
            SUM(CAST(A.VOLUME AS INT)) AS TotalDischargeVolumeInM3
        FROM 
            inflow_outflow A
        WHERE 
            A.IS_INFLOW_OUTFLOW = 'Outflow'
        )
    SELECT 
        CAST(B.TRAVEL_DATE AS DATE) AS TRAVEL_DATE,
        B.TRAVEL_DAY,
        B.TRAVEL_TIME,
        A.PRIMARY_SUPPLIER as SOURCE_PRIMARY,
        A.SECONDARY_SUPPLIER as SOURCE_SECONDARY,
        A.NONLISTED_INFLOW_CONTRACTOR as OTHER_CONTRACTOR,
        TRIM(coalesce(C.SUPPLIER_NAME,A.COMPANY_NAME))  as COMPANY_NAME,
        CASE 
          WHEN (CD.TotalDischargeVolumePerCompany / TD.TotalDischargeVolumeInM3) * 100 < 1 
          THEN 'Other' 
           ELSE TRIM(coalesce(C.SUPPLIER_NAME, A.COMPANY_NAME))
        END AS COMPANY_NAME_FIX,
        A.IN_MAPPING_FLAG_COMPANY,
        A.SECONDARY_SUPPLIER as SOURCE_OF_WW,
        A.SOURCE_NAME_FIX as SOURCE_OF_WW_FIX,
        A.IN_MAPPING_FLAG_SOURCE,
        A.IS_INFLOW_OUTFLOW as WATER_CATEGORY,
        D.VARIABLE_TYPE as MEASUREMENT_VARIABLE,
        A.VOLUME,
        A.UNIT,
        B.VEHICLE_PLATE_NUMBER as TRUCK_PLATE_NUMBER,
        B.DRIVER_FIRST_NAME,
        B.DRIVER_LAST_NAME,
        B.DRIVER_ID,
        A.SUBMIT_ID as RECEIPT_NO,
        A.RECEIPT_VALUE_IN_SAR as RECEIPT_VALUE_IN_SAR,
        E.SERVICE_LOCATION_NAME as RECYCLE_WATER_DESTINATION,
        concat(F.LATITUDE, ',', F.LONGITUDE) as RECYCLE_WATER_LOCATION
    FROM 
        inflow_outflow A
    LEFT JOIN 
        op_transportation B ON A.DIM_TRANSPORTATION_ID = B.DIM_TRANSPORTATION_ID
    LEFT JOIN 
        waterqa_supplier C ON A.DIM_WATERQA_SUPPLIER_ID = C.DIM_WATERQA_SUPPLIER_ID
    LEFT JOIN 
        meas_variable D ON A.MEAS_VARIABLE_ID = D.MEAS_VARIABLE_ID
    LEFT JOIN 
        customer_service_location E ON A.SERVICE_LOCATION_ID = E.SERVICE_LOCATION_ID
    LEFT JOIN 
        loc_location F ON E.DIM_LOCATION_ID = F.DIM_LOCATION_ID
    LEFT JOIN 
        CompanyDischarge CD ON TRIM(coalesce(C.SUPPLIER_NAME, A.COMPANY_NAME)) = CD.COMPANY_NAME
    CROSS JOIN 
        TotalDischarge TD
    WHERE 
        A.IS_INFLOW_OUTFLOW = 'Outflow'
    """
    )

    logging.info("Executed SQL query for data transformation.")
    # Generate df1: Filter for inflow and drop duplicates
    # Step 2: Deduplicate each DataFrame
    #df_inflow_deduped = df_inflow.dropDuplicates\
       # (["COMPANY_NAME", "TRAVEL_DATE", "TRAVEL_TIME", "TRUCK_PLATE_NUMBER"])

    window_spec = Window.partitionBy(
    F.trim(df_inflow["COMPANY_NAME"]),
    df_inflow["TRAVEL_DATE"],
    df_inflow["TRAVEL_TIME"],
    df_inflow["TRUCK_PLATE_NUMBER"]
        ).orderBy(
        F.col("VOLUME").cast("int").desc(),  # First order by VOLUME in descending order
        F.col("RECEIPT_NO")\
        .cast("int").desc()# Then order by RECEIPT_NO (cast to int) in descending order
    )    # Cast VOLUME as int

# Step 2: Add a row number column based on the partition and volume ordering
    df_inflow_with_row_number = df_inflow.withColumn("rn", F.row_number().over(window_spec))

# Step 3: Filter to retain only the rows where row number is 1 (highest volume in each group)
    df_inflow_deduped = df_inflow_with_row_number.filter(F.col("rn") == 1).drop("rn")
    # Generate df2: Filter for outflow and drop duplicates based on RECEIPT_NO
    # df_outflow_deduped = df_outflow.dropDuplicates(["RECEIPT_NO"])
    df_outflow_deduped = df_outflow.dropDuplicates\
        (["RECEIPT_NO","SOURCE_PRIMARY","TRAVEL_DATE","TRAVEL_TIME","TRUCK_PLATE_NUMBER"])
    # Union df1 and df2 after applying the transformations
    df_union = df_inflow_deduped.unionByName(df_outflow_deduped)

    # Continue with the repartitioning and further transformations if needed
    max_partition_size_mb = 256
    num_partitions = calculate_num_partitions(df_union, max_partition_size_mb)
    logging.info(f"Repartitioning the union DataFrame into {num_partitions} partitions.")

    df_union = df_union.repartition(num_partitions)

    # Return the final DataFrame
    return df_union


def transform(spark: SparkSession, source_dfs: dict) -> DataFrame:
    """
    Transforms the source DataFrame by performing necessary transformations and 
    returns the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        source_dfs (dict): A dictionary containing the source DataFrames with 
        the key:
            - "FACT_WW_EVE_INFLOW_OUTFLOW": DataFrame for FACT_WW_EVE_INFLOW_OUTFLOW.
            - "DIM_WA_ORG_WATERQA_SUPPLIER_ALBADA": DataFrame for DIM_WA_ORG_WATERQA_SUPPLIER.
            - "DIM_WA_OP_TRANSPORTATION": DataFrame for DIM_WA_OP_TRANSPORTATION.
            - "DIM_CR_OP_MEAS_VARIABLE_ALBADA": DataFrame for DIM_CR_OP_MEAS_VARIABLE.
            - "DIM_CR_LOC_LOCATION_ALBADA": DataFrame for DIM_CR_LOC_LOCATION.
            - "DIM_CR_LOC_CUSTOMER_SERVICE_LOCATION_ALBADA": DataFrame for Service location Dim.

    Returns:
        DataFrame: The transformed DataFrame.
    """
    logging.info("Starting the transformation process.")


    df_dim_wa_op_transportation = source_dfs["DIM_WA_OP_TRANSPORTATION"]
    df_fact_ww_eve_inflow_outflow = source_dfs["FACT_WW_EVE_INFLOW_OUTFLOW"]
    df_dim_wa_org_waterqa_supplier = source_dfs["DIM_WA_ORG_WATERQA_SUPPLIER_ALBADA"]
    df_dim_cr_op_meas_variable = source_dfs["DIM_CR_OP_MEAS_VARIABLE_ALBADA"]
    df_dim_cr_loc_customer_service_location\
          = source_dfs["DIM_CR_LOC_CUSTOMER_SERVICE_LOCATION_ALBADA"]
    df_dim_cr_loc_location = source_dfs["DIM_CR_LOC_LOCATION_ALBADA"]

    # Perform joins, filters, etc.
    transform_df = prepare_transformed_df(
        spark=spark,
        df_dim_wa_op_transportation=df_dim_wa_op_transportation,
        df_fact_ww_eve_inflow_outflow=df_fact_ww_eve_inflow_outflow,
        df_dim_wa_org_waterqa_supplier=df_dim_wa_org_waterqa_supplier,
        df_dim_cr_op_meas_variable=df_dim_cr_op_meas_variable,
        df_dim_cr_loc_customer_service_location=df_dim_cr_loc_customer_service_location,
        df_dim_cr_loc_location=df_dim_cr_loc_location
    )

    logging.info("Transformation completed successfully..")

    return transform_df


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
    Executes the transformation process by reading source data, transforming it,
    and returning the transformed DataFrame.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        pipeline_storage (list[dict]): A list of dictionaries containing storage
                                        configuration information.
        task_parameters (dict): A dictionary containing task parameters,
                                 including the sources to read from.

    Returns:
        DataFrame: The transformed DataFrame resulting from the transformation process.
    """
    source_dfs: dict = read(
        spark=spark, pipeline_storage=pipeline_storage, task_parameters=task_parameters
    )

    transformed_df: DataFrame = transform(spark=spark, source_dfs=source_dfs)

    target_schema = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_schema = storage_config["schema"]

    transformed_df = impose_schema(transformed_df, target_schema)

    return transformed_df


def presentation_datavalidations(spark_df: DataFrame):
    """
        This function is for data validation
    """
    print("Inside presentation_datavalidations")
    return spark_df


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """

    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "curated_data_processing_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    elif task_name == "adw_presentation_data_validations_checks":
        print("transformations - adw_presentation_data_validations_checks")
        return presentation_datavalidations(spark_df)
