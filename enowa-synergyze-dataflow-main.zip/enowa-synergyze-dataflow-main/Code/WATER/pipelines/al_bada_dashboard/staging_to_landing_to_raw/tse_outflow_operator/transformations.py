'''
This is the transformation file for Tse Outflow Operator data
'''
import logging
import gc
import re
from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from common_utils import (
    impose_schema,
    calculate_num_partitions,
    list_files_from_object_uri,
    get_excel_sheet_names
)
from read_utils import excel_reader
from oci_services import OCIConnectionFactory


def get_storage_config(storage_config, storage_name):
    """
    Retrieve a storage configuration by matching the given storage name.

    This function searches for a storage configuration within a list of dictionaries based on the provided storage name.

    Args:
        storage_config (list of dict): A list of dictionaries containing storage configurations.
        storage_name (str): The name of the storage configuration to retrieve.

    Returns:
        dict or None: A dictionary containing the storage configuration if found, otherwise None.
    """
    for config in storage_config:
        if config["name"].strip().lower() == storage_name.strip().lower():
            return config
    return None


def write(target_info: dict, spark_df: DataFrame):
    """
    Writes a Spark DataFrame to a target location with optional partitioning.

    Parameters:
    target_info : dict
        Dictionary with keys: 'target_url', 'write_mode', 'file_partition_col', 'type', and 'header'.
    spark_df : DataFrame
        The DataFrame to be written.

    Returns:
    None
    """
    print("Inside write funtion..")
    target_file_url = target_info.get("target_url")
    mode = target_info.get("write_mode")
    partition_col = target_info.get("file_partition_col")
    file_format = target_info.get("type")
    header = target_info.get("header")

    if partition_col:
        spark_df.write.partitionBy(*partition_col).options(header=header).mode(mode).format(
            file_format).save(target_file_url)
    else:
        spark_df.write.options(header=header).mode(mode).format(file_format).save(
            target_file_url)

    spark_df.unpersist()
    del spark_df
    gc.collect()
    logging.info("Data saved to Object Storage!")

    logging.info("Data Loader Task --- FINISHED !")


def get_source_config(pipeline_storage, task_parameters):
    source_config = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["source"]:
            source_config = storage_config
            print("source_config:", source_config)

    return source_config


def get_target_config(pipeline_storage, task_parameters):
    target_info = {}
    for storage_config in pipeline_storage:
        if storage_config["name"] == task_parameters["target"]:
            target_info = storage_config
    return target_info


def execute_transform(
        spark: SparkSession, pipeline_storage: list[dict], task_parameters: dict
):
    """
        Processes Excel files from Object Storage, transforms their data, and writes the results to a target location.

        Parameters:
        ----------
        spark : SparkSession
            The active Spark session.
        pipeline_storage : list[dict]
            Configuration details for source and target storage.
        task_parameters : dict
            Parameters specifying the source and target storage names.

        Returns:
        -------
        tuple
            A tuple containing the execution status, message, list of processed file URIs, and the processed count.
    """
    logging.info("Inside execute_transform function")
    processed_count = 0
    passed_files_target = []
    execution_status = ''
    execution_message = ''

    try:
        # Initialize the Object Storage client
        oci_factory = OCIConnectionFactory()
        object_storage_client = oci_factory.get_oci_client("ObjectStorageClient")

        source_config = get_source_config(
            pipeline_storage=pipeline_storage,
            task_parameters=task_parameters
        )

        list_of_files = list_files_from_object_uri(source_config=source_config)
        logging.info("List of files to process: %s", list_of_files)

        for file_name in list_of_files:
            logging.info("Processing file: %s", file_name)
            absolute_file_uri = source_config["source_url"] + file_name.split("/")[-1]
            source_config["file_name"] = file_name

            namespace = source_config["namespace"]
            bucket_name = source_config["bucket_name"]
            file_name = source_config["file_name"]
            sheet_filter = source_config["sheet_pattern"]

            sheets = get_excel_sheet_names(
                object_storage_client=object_storage_client,
                namespace=namespace,
                bucket_name=bucket_name,
                object_name=file_name
            )

            print("execute_transform():: sheets:", sheets)

            # Filter sheets based on the provided filter
            print(f"execute_transform(): Search for {sheet_filter} sheets")
            filtered_sheets = [
                sheet for sheet in sheets
                if re.match(sheet_filter, sheet, re.IGNORECASE)
            ]

            print("execute_transform(): filtered_sheets:", filtered_sheets)

            for sheet_name in filtered_sheets:
                print("execute_transform(): processing sheet: ", sheet_name)
                source_config["sheet_name"] = sheet_name
                source_file_name = source_config["file_name"].split("/")[-1]
                source_config["source_file_url"] = (
                        source_config["source_url"] + source_file_name
                )

                df: DataFrame = excel_reader(spark=spark, source_config=source_config)

                # Drop blank rows
                df = df.dropna(how="all")

                # Extract the first row (header row)
                header_row = df.first()

                # Create a new schema using the first row's values as the column names
                new_column_names = [str.strip(str(c)) for c in header_row]

                # Recreate the DataFrame with new column names and drop the first row
                transformed_df = (
                    df.toDF(*new_column_names)
                    .filter(F.trim(df['_c0']) != new_column_names[0])
                )

                # Drop rows with null receipt number as it should be rectified before ingested
                transformed_df = transformed_df.dropna(subset=["RECEIPT NUMBER"])

                # select distinct rows based on all columns
                transformed_df = transformed_df.drop_duplicates()

                transformed_df = transformed_df.withColumn("PARTITION_KEY", F.to_date(F.expr \
                                                                                          ("regexp_replace(DATE, '^[A-Za-z]{3} ', '')"),
                                                                                      "dd-MMM-yyyy"))

                transformed_df = transformed_df.withColumnRenamed \
                    ("CONTRACTOR NAME", "CONTRACTORNAME") \
                    .withColumnRenamed("OTHER CONTRACTOR NAME", "OTHERCONTRACTORNAME") \
                    .withColumnRenamed("TRUCK PLATE NUMBER", "TRUCKPLATENUMBER") \
                    .withColumnRenamed("FILLING VOLUME IN M3", "FILLINGVOLUMEINM3") \
                    .withColumnRenamed("RECYCLED WATER DESTINATION", "RECYCLEDWATERDESTINATION") \
                    .withColumnRenamed("LOCATION COORDINATES", "LOCATIONCOORDINATES") \
                    .withColumnRenamed("RECEIPT NUMBER", "RECEIPTNUMBER") \
                    .withColumnRenamed("RECEIPT VALUE IN SAR", "RECEIPTVALUEINSAR")

                target_info = get_target_config(pipeline_storage, task_parameters)

                logging.info("execute_transform(): Imposing schema on transformed_df")

                if transformed_df:
                    transformed_df = impose_schema(transformed_df, target_info["schema"])

                max_partition_size_mb = 256
                num_partitions = calculate_num_partitions(transformed_df, max_partition_size_mb)
                logging.info(
                    "execute_transform(): Repartitioning the DataFrame into %s partitions.",
                    num_partitions
                )
                transformed_df = transformed_df.coalesce(num_partitions)
                logging.info(
                    "execute_transform(): Final transformed_df schema: %s",
                    transformed_df.printSchema()
                )

                # write to target
                write(target_info, transformed_df)
                if absolute_file_uri not in passed_files_target:
                    passed_files_target.append(absolute_file_uri)
                execution_status = 'SUCCESS'
                execution_message = (
                    f"Successfully processed data from {sheet_name} "
                    f"sheet in file {file_name}"
                )

                transformed_df.unpersist()
                del transformed_df
                gc.collect()
        return execution_status, execution_message, passed_files_target, processed_count
    except Exception as err:
        print("execute_transform(): Error occured: ", err)
        passed_files_target = []
        processed_count = 0
        execution_status = None
        execution_message = err
        return execution_status, execution_message, passed_files_target, processed_count


def main(spark: SparkSession, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: source dataframe
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """

    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")

    # Extract arguments from kwargs with default values if not provided
    task_name: dict = kwargs.get("task_name")
    task_parameters: dict = kwargs.get("task_parameters")
    pipeline_storage: list[dict] = kwargs.get("pipeline_storage")

    if task_name == "energy_data_movement_task":
        return execute_transform(spark, pipeline_storage, task_parameters)
    
    return None
