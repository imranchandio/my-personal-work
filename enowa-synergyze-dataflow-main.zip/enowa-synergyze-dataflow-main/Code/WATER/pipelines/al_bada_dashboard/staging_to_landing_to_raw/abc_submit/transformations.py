'''
This is the transformation file for ABC Submit data
'''
import logging
from pyspark.sql.functions import col, to_date, from_unixtime
from pyspark.sql.functions import input_file_name, regexp_extract, col, concat_ws
from pyspark.sql import DataFrame, SparkSession


def transform_dataframe(df : DataFrame):
    '''
    This function transforms the input dataframe removing the data row having header
    as while reading the file, header is read as data row to deal with missing key error
    for columns having no data

    Returns:
        DataFrame: The resulting DataFrame from the transformation.

    Raises:
        Exception: If an error occurs during transformation.
    '''
    try:
        df = df.filter(
            col("DriverDate") != 'DriverDate'
        )

        date_pattern = r'abc_submit_results_(\d{4})(\d{2})(\d{2})\.xlsx'
        df = df.withColumn("year", regexp_extract(col("file_name"), date_pattern, 1))
        df = df.withColumn("month", regexp_extract(col("file_name"), date_pattern, 2))
        df = df.withColumn("day", regexp_extract(col("file_name"), date_pattern, 3))

        # Concatenate year, month, and day to form the date string 
        df = df.withColumn("reporting_date", concat_ws("-", col("year"), col("month"), col("day")))


        return df

    except Exception as e:
        raise ValueError("Error in Transforming Data", e)


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):

    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: source dataframe
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    print("Spark Session:", spark)  # Printing spark session object to avoid SonarQube issues
    if spark_df is not None:
        # Log the schema of spark_df if it's not None
        logging.info("Schema of spark_df:\n%s", spark_df.schema.simpleString())
    else:
        logging.warning("spark_df is None; skipping schema logging.")
    # Extract arguments from kwargs with default values if not provided
    task_name = kwargs.get('task_name')

    if task_name == "data_movement_task":
        print("transformations - main")
        return transform_dataframe(spark_df)
    return None
