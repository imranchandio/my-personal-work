'''
This is the transformation file for Al-Bada WRP Site Lab data
'''
import logging
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F


def transform_dataframe(spark, df):
    '''
    This function transforms the input dataframe by unpivoting
    Categories, Parameters, Limits, Units from row to column

    Returns:
        DataFrame: The resulting DataFrame from the transformation.

    Raises:
        Exception: If an error occurs during transformation.
    '''
    try:
        # Extract specific rows for metadata: Categories (Row 1),
        # Parameters (Row 2), Limits (Row 3), Units (Row 4)
        categories_row = df.limit(1).collect()[0]  # Row 1 for Categories
        parameters_row = df.limit(2).collect()[1]  # Row 2 for Parameters
        limits_row = df.limit(3).collect()[2]  # Row 3 for Limits
        units_row = df.limit(4).collect()[3]  # Row 4 for Units

        # Create a new list to store the transformed values
        result = []
        last_value = None

        for value in categories_row:
            if value is not None:
                last_value = value  # Update last_value to the current non-null value
            # Append the last non-null value (or None if it's the first value)
            result.append(last_value)

        categories_imputed_row = result
        # Convert rows to a list to work with them more easily
        # Exclude the date column
        categories_list = categories_imputed_row[1:]
        parameters_list = list(parameters_row.asDict().values())[1:]  # Exclude the date column
        limits_list = list(limits_row.asDict().values())[1:]  # Exclude the date column
        units_list = list(units_row.asDict().values())[1:]  # Exclude the date column

        # Create metadata DataFrame from the lists (Category, Parameter, Limit, Unit)
        metadata_columns = ['Category', 'Parameter', 'Limit', 'Unit']
        metadata_values = list(zip(categories_list, parameters_list, limits_list, units_list))

        metadata_df = spark.createDataFrame(metadata_values, schema=metadata_columns)

        # Load the actual data from row 5 onward
        data_df = df.filter(F.col('Date').isNotNull()).filter(F.col('Date') != 'DATE')

        # Rename the columns, keeping the 'Date' column  and 'File_Name' column intact
        new_column_names = [data_df.columns[0]] \
                           + [str(g.replace(' ', '998') + "_" + h.replace(' ', '998').replace('-', '999') + f"_{i}") \
                              for i, (h, g) in enumerate(zip(parameters_row[1:-1], categories_imputed_row[1:-1]) \
                                                         , start=1)] \
                           + [data_df.columns[-1]]

        data_df = data_df.toDF(*new_column_names)

        # Reshape the data by converting wide format to long format using stack
        stack_columns = list(data_df.columns[1:-1])  # Exclude the 'Date' and 'file_name' column
        stack_expr = F.expr("stack({}, {})".format( \
            len(stack_columns), ", ".join(["'{}',{}".format(col, col) for col in stack_columns])
        ))

        reshaped_df = data_df.select('Date', \
                                     stack_expr.alias('Parameter', 'Result'), 'file_name')

        # Extract the Category from Parameter Column
        # Change the placeholder 998 with space(' ')
        reshaped_df = reshaped_df.withColumn(
            "Category",
            F.regexp_replace(
                F.regexp_replace(F.regexp_extract \
                                     (F.col("Parameter"), r'^[A-Za-z0-9]+_', 0), '_', '') \
                , '998', ' '
            )
        )

        # Clean Parameter Column
        # Change back the placeholders to originals
        # (998 with space(' ') , 999 with hypen(-), _x with '')
        reshaped_df = reshaped_df.withColumn(
            "Parameter",
            F.regexp_replace(
                F.regexp_replace(
                    F.regexp_replace(
                        F.regexp_replace(F.col("Parameter"),
                                         r'_\d+$', ''), r'^[A-Za-z0-9]+_', ''
                    ), '998', ' '
                ), '999', '-'
            )
        )

        # Join the reshaped data with the metadata to match the output format
        final_df = reshaped_df.join(metadata_df, ["Category", "Parameter"])

        # Filter out/remove the rows where all columns are null except Date
        final_df = final_df.filter(
            F.col('Result').isNotNull()
        )

        # Re-arrange and rename columns
        final_df = final_df.select(
            F.col('Date'),
            F.col('Category'),
            F.col('Parameter'),
            F.col('Limit'),
            F.col('Unit'),
            F.col('Result')
        )

        return final_df

    except Exception as e:
        raise ValueError("Error in Transforming Data", e)


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):

    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: source dataframe
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name = kwargs.get('task_name')

    if spark_df is not None:
        # Log the schema of spark_df if it's not None
        logging.info("Schema of spark_df:\n%s", spark_df.schema.simpleString())
    else:
        logging.warning("spark_df is None; skipping schema logging.")

    if task_name == "data_movement_task":
        print("transformations - main")
        return transform_dataframe(spark, spark_df)
    return None
