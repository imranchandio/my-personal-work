'''
This is the transformation file for ABC Submit data
'''
import logging
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col  # pylint:disable=import-error


def transform_dataframe(df):
    '''
    This function transforms the input dataframe by removing the data row having
    null values for all columns and category being the always non-null field
    is used in the filtering

    Returns:
        DataFrame: The resulting DataFrame from the transformation.

    Raises:
        Exception: If an error occurs during transformation.
    '''
    try:
        df = df.filter(
            col("Category").isNotNull()
        )

        return df

    except Exception as e:  # pylint:disable=unused-variable
        raise ValueError("Error in Transforming Data", e)  # pylint:disable=raise-missing-from,broad-exception-raised


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: source dataframe
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    print("Spark Session:", spark)  # Printing spark session object to avoid SonarQube issues
    # Extract arguments from kwargs with default values if not provided

    if spark_df is not None:
        # Log the schema of spark_df if it's not None
        logging.info("Schema of spark_df:\n%s", spark_df.schema.simpleString())
    else:
        logging.warning("spark_df is None; skipping schema logging.")

    task_name = kwargs.get('task_name')

    if task_name == "data_movement_task":
        print("transformations - main")
        return transform_dataframe(spark_df)
    return None
