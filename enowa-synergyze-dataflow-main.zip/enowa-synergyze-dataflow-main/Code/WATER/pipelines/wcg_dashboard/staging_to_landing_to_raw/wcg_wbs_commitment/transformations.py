"""
Module: wcg_wbs_commitment
Description: Process data from raw to curated for the database.
It contains the necessary functions and logic to create database 
table in curated.

Author: Vaishnavi Ruikar
Date: 22-10-2024
"""

def transform_dataframe(df):
    """
    function to execute the appropriate transformations based
    Args:
        df:  dataframe.
    Returns:
        DataFrame: The resulting transformed DataFrame.
    """
    df.show(truncate=False)
    return df

def main(spark, spark_df, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Extract arguments from kwargs with default values if not provided
    task_name = kwargs.get('task_name')
    task_parameters = kwargs.get('task_parameters')
    if task_name == "data_movement_task":
        print("transformations - main")
        print(task_parameters)
        print(spark)
        return transform_dataframe(spark_df)
    return None
