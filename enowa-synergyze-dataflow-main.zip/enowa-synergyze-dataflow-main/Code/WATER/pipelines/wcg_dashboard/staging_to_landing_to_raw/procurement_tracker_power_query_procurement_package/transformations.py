"""
Module: wcg_cc_master_list
Description: Process data from raw to curated for the database.
It contains the necessary functions and logic to create database 
table in curated.

Author: Vaishnavi Ruikar
Date: 22-10-2024
"""
import pyspark.sql.functions as F
from pyspark.sql import DataFrame, SparkSession
from common_utils import standardize_numeric_data

MMDDYYYY = "MM/dd/yyyy"


def transform_dataframe(df: DataFrame):
    df_transformed = df.withColumn(
        "PR_REQUEST_FROM_PROPONENT_DATE",
        F.to_date(F.col("PR_REQUEST_FROM_PROPONENT_DATE"), MMDDYYYY)
    ).withColumn(
        "PR_CREATION_DATE",
        F.to_date(F.col("PR_CREATION_DATE"), MMDDYYYY)
    ).withColumn(
        "PR_LATEST_APPROVAL",
        F.to_date(F.col("PR_LATEST_APPROVAL"), MMDDYYYY)
    ).withColumn(
        "LAST_UPDATED_DATE",
        F.to_date(F.col("LAST_UPDATED_DATE"), MMDDYYYY)
    )

    numeric_columns = ["PR_VALUE_SAR"]

    df_transformed = standardize_numeric_data(
        df=df_transformed,
        numeric_columns=numeric_columns
    )

    return df_transformed


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Executes a specified task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session for processing.
        spark_df (DataFrame): A dummy DataFrame.
        **kwargs: Additional arguments, including 'task_name' and 'task_parameters'.

    Returns:
        DataFrame: Transformed DataFrame for recognized tasks, or None otherwise.
    """
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")

    # Extract arguments from kwargs with default values if not provided
    task_name = kwargs.get('task_name')
    task_parameters = kwargs.get('task_parameters')

    if task_name == "data_movement_task":
        print("task_parameters:", task_parameters)
        return transform_dataframe(spark_df)

    return None
