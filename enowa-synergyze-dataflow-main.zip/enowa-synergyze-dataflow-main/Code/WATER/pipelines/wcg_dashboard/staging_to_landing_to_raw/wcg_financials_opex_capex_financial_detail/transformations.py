from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from common_utils import standardize_numeric_data


def transform_dataframe(df: DataFrame):
    """
    Transforms the input PySpark DataFrame by standardizing specific numeric columns.

    Summary:
        This function cleans and converts values in predefined numeric columns
        to ensure they are in a valid numeric format.

    Args:
        df (pyspark.sql.DataFrame): The input PySpark DataFrame to transform.

    Returns:
        pyspark.sql.DataFrame: A new DataFrame with standardized numeric columns.
    """
    numeric_columns = [
        "BUDGET", "COMMITMENTS_PO", "COMMITMENTS_PR", "GRN",
        "ACCRUALS", "AVAILABLE", "PLANNED", "FORECAST_OVER_UNDER_SPEND",
        "COMMITMENTS"
    ]

    df_transformed = standardize_numeric_data(df=df, numeric_columns=numeric_columns)

    return df_transformed


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")

    # Extract arguments from kwargs with default values if not provided
    task_name = kwargs.get('task_name')
    task_parameters = kwargs.get('task_parameters')
    if task_name == "data_movement_task":
        print("main(): task_parameters:", task_parameters)
        return transform_dataframe(spark_df)
    return None
