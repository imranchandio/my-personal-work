"""
Module: wcg_po_master_q_5_fwa_details
Description: Process data from raw to curated for the database.
It contains the necessary functions and logic to create a database 
table in curated.
"""

from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from common_utils import standardize_numeric_data

def transform_dataframe(df_source: DataFrame) -> DataFrame:
    """
    Transforms the input dataframe by converting specific columns 
    to date format based on the provided MMDDYYYY format.

    Args:
        df (DataFrame): Input DataFrame to transform.

    Returns:
        DataFrame: Transformed DataFrame with date columns.
    """

    date_columns = ["DOCUMENT_DATE_PO_PR_APPROVED_DATE_PR_PLANNED_AWARD_DATE_SP", "CONTRACT_START_EFFECTIVE_DATE", "COMPLETION_TERMINATION_DATE", "EXPIRY_DATE"]

    for column_name in date_columns:
        df_source = df_source.withColumn(column_name, F.to_date(F.col(column_name), "MM/dd/yy"))

    numeric_columns = [
        "STILL_TO_BE_DELIVERED_EXCLUDING_COMMITMENTS_VALUE_SAR", "CURRENT_OA_CAP_SAR", "GROSS_ORDER_VALUE_SAR", "TOTAL_GRN_VALUE_SAR", "DELIVERED_VALUE_SAR", "OMITTED_VALUE_SAR", "STILL_TO_BE_DELIVERED_VALUE_SAR", "COMMITMENTS_PR", "PLANNED", "DELIVERED_SAR_VE", "TOTAL_GRN_VALUE_SAR_VE", "OMITTED_VALUE_SAR_VE", "STILL_TO_BE_DELIVERED_SAR_VE", "COMMITMENTS_SAR_VE", "PLANNED_SAR_VE", "FORECAST_SPEND_SAR"
    ]

    df_transformed = standardize_numeric_data(
        df=df_source,
        numeric_columns=numeric_columns
    )
    
    return df_transformed

def main(spark: SparkSession, spark_df: DataFrame, **kwargs) -> DataFrame:
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")
    
    # Extract arguments from kwargs
    task_name = kwargs.get('task_name')
    task_parameters = kwargs.get('task_parameters')
    print("Spark Session:", spark)  # Printing spark session object to avoid SonarQube issues

    if task_name == "data_movement_task":
        print("Transformations - main")
        print(task_parameters)
        return transform_dataframe(spark_df)  # The parameter spark_df is not needed
    else:
        raise ValueError(f"Unsupported task name: {task_name}")