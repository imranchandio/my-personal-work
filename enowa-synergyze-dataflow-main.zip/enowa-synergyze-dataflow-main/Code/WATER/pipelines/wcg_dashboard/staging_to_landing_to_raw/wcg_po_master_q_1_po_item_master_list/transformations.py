"""
This module process the data WCG_PO_Master.xlsx to
ENOWA/WATER/DOWNSTREAM/SAP/WCG_PO_MASTER_Q_1_PO_ITEM_MASTER_LIST/ in RAW bucket
"""
# pylint: disable= E0401

from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from common_utils import standardize_numeric_data


def transform_dataframe(df_source: DataFrame):
    """
        Transforms the input PySpark DataFrame by standardizing specific numeric columns.
        Summary:
            This function cleans and converts values in predefined numeric columns
            to ensure they are in a valid numeric format.
        Args:
            df_source (pyspark.sql.DataFrame): The input PySpark DataFrame to transform.
        Returns:
            pyspark.sql.DataFrame: A new DataFrame with standardized numeric columns.
    """
    date_columns = ["DELIVERY_DATE", "DOCUMENT_DATE", "CONTRACT_EXPIRY_DATE"]

    for column_name in date_columns:
        df_source = df_source.withColumn(column_name, F.to_date(F.col(column_name), "dd-MMM-yy"))

    date_columns = ["APPROVAL_REJECTION_DATE", "LAST_PAID_DATE"]

    for column_name in date_columns:
        df_source = df_source.withColumn(column_name, F.to_date(F.col(column_name), "MM/dd/yyyy"))

    df_source = df_source.where("PO_KEY is not null")

    numeric_columns = [
        "GROSS_ORDER_VALUE", "GROSS_ORDER_VALUE_SAR", "TOTAL_SES_VALUE", "TOTAL_SES_SAR",
        "TOTAL_GRN_VALUE", "TOTAL_GRN_VALUE_SAR", "EXCHANGE_RATE_VALUE_CHANGE", "VALUE_CHANGE",
        "TOTAL_VALUE_CHANGE_SAR", "PARKED_INVOICE_VALUE", "INVOICE_VALUE", "INVOICE_VALUE_LC", "PAID_AMOUNT",
        "TOTAL_PAID_AMOUNT_SAR", "PAID_AMOUNT_IN_LC", "STILL_TO_BE_INVOICED_VAL",
        "STILL_TO_BE_INVOICED_VALUE_SAR", "STILL_TO_BE_INVOICED_QTY", "OMITTED_VALUE_SAR",
        "STILL_TO_BE_DELIVERED_VALUE", "STILL_TO_BE_DELIVERED_VALUE_SAR"
    ]

    df_transformed = standardize_numeric_data(
        df=df_source,
        numeric_columns=numeric_columns
    )

    return df_transformed.distinct()


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
    Returns:
        DataFrame: The resulting DataFrame from the executed task.
    Raises:
        ValueError: If an unsupported task name is provided.
    """
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")

    task_name = kwargs.get('task_name')
    print("main(): task_name:", task_name)

    return transform_dataframe(spark_df)
