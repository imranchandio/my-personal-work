"""
This module process the data from WCG_PO_MASTER.xlsx file to
ENOWA/WATER/DOWNSTREAM/SAP/WCG_PO_MASTER_4_MANUAL_INPUT_FA_SUMMARY/ in RAW bucket
"""
# pylint: disable= E0401

from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from common_utils import standardize_numeric_data
import pyspark.sql.types as T
import datetime


# Define a UDF to convert Excel serial date to Python datetime
def excel_date_to_datetime(serial):
    """
    Converts Excel serial date to Python datetime.
    Handles Excel's 1900 leap year bug.
    """
    try:
        if serial is None or serial == "":
            return None
        # Convert to float if it is a string
        serial = float(serial)
        base_date = datetime.datetime(1899, 12, 30)  # Excel's base date
        delta = datetime.timedelta(days=serial)
        return base_date + delta
    except ValueError:
        # Handle cases where conversion fails
        return None


def transform_dataframe(df_source: DataFrame):
    """
        Transforms the input PySpark DataFrame by standardizing specific numeric columns.
        Summary:
            This function cleans and converts values in predefined numeric columns
            to ensure they are in a valid numeric format.
        Args:
            df_source (pyspark.sql.DataFrame): The input PySpark DataFrame to transform.
        Returns:
            pyspark.sql.DataFrame: A new DataFrame with standardized numeric columns.
    """
    date_columns = ["EARLIEST_FW_START_DATE", "EARLIEST_FW_EXPIRY_DATE"]

    # Register the UDF
    excel_date_udf = F.udf(excel_date_to_datetime, T.DateType())

    for column_name in date_columns:
        # Ensure the column is numeric before applying the UDF
        df_source = df_source.withColumn(
            column_name,
            F.col(column_name).cast(T.DoubleType())
        )

        # Apply the UDF to convert to a readable date
        df_source = df_source.withColumn(
            column_name,
            excel_date_udf(F.col(column_name))
        )

    numeric_columns = [
        "TOTAL_BUDGET_SAR_NUMERICAL", "TOTAL_CURRENT_OA_CAP_SAR",
        "TOTAL_AVAILABLE_SAR", "WO_VALUE_SAR", "STILL_TO_BE_DELIVERED_VALUE_SAR",
        "SUM_OF_PR_VALUE", "SUM_OF_PLANNED_VALUE", "AVAILABLE_INCL_PR_AND_PLANNED"
    ]

    df_transformed = standardize_numeric_data(
        df=df_source,
        numeric_columns=numeric_columns
    )

    return df_transformed


def main(spark: SparkSession, spark_df: DataFrame, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")

    # Extract arguments from kwargs with default values if not provided
    task_name = kwargs.get('task_name')
    task_parameters = kwargs.get('task_parameters')
    if task_name == "data_movement_task":
        print("main(): task_parameters: ", task_parameters)
        return transform_dataframe(spark_df)
    return None
