"""
Module: wcg_cc_master_list
Description: Process data from raw to curated for the database.
It contains the necessary functions and logic to create database 
table in curated.

Date: 22-10-2024
"""

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import StringType
import pyspark.sql.functions as F

# original_name: expected_name
column_mapping = {
    'PO Key (Sorter)': 'POKEY_SORTER',
    'Key User': 'KEY_USER',
    'Proponent': 'PROPONENT',
    'PO Number': 'PO_NUMBER',
    'Line No': 'LINE_NO',
    'Sub-line': 'SUB_LINE',
    'Milestone Completion Date (DD-MMM-YY / MMM-YY / QQ-YY)': 'MILESTONE_COMPLETIONDATE',
    'Milestone Value': 'MILESTONE_VALUE',
    'Milestone Description': 'MILESTONE_DESCRIPTION',
    'SES#': 'SES_NO',
    'Comment': 'COMMENT',
    'CA Validation (Yes / No)': 'CA_VALIDATION',
    'PO Checker': 'PO_CHECKER',
    'SES Checker (Exist)': 'SESCHECKER_EXIST',
    'Missing SES for PO': 'MISSING_SES_FOR_PO',
    'Flag': 'FLAG',
    'Closed PO Indicator': 'CLOSED_PO_INDICATOR',
    'Flagging issues with SES payments': 'FLAGGING_ISSUES_WITH_SESPAYMENTS',
    'Sum of Milestone Value': 'SUM_MILESTONE_VALUE',
    'PO Value': 'PO_VALUE',
    'Milestone Value - PO Value CHECKER': 'MILESTONEVALUE_POVALUECHECKER',
    'Duplicate SES in Master': 'DUPLICATE_SES_IN_MASTER',
    'Blank cells': 'BLANK_CELLS',
    'Counting dupplicate PO Keys': 'COUNTING_DUPPLICATE_POKEYS',
    # 'Column25': 'COLUMN_25',
    # 'Column26': 'COLUMN_26',
    'Active or Closed': 'ACTIVE_OR_CLOSED',
    'Active Vs. Closed': 'ACTIVE_VS_CLOSED',
    'Full IO-WBS List.Water Dept': 'FULLIO_WBSLIST_WATERDEPT',
    'SES_Report.Pur. Order': 'SES_REPORT_PUR_ORDER',
    'SES_Report.Entry Sheet': 'SES_REPORT_ENTRYSHEET',
    'SES_Report.SES Creation Date': 'SES_REPORT_SES_CREATIONDATE',
    'SES_Report.SES Value': 'SES_REPORT_SESVALUE',
    'SES_Report.Invoice Number': 'SES_REPORT_INVOICENUMBER',
    'SES_Report.Baseline Date': 'SES_REPORT_BASELINEDATE',
    'SES_Report.Paid Amount': 'SES_REPORT_PAIDAMOUNT',
    'SES_Report.Paid Date': 'SES_REPORT_PAIDDATE',
    'SES_Report.Payment in': 'SES_REPORT_PAYMENTIN',
    'SES_Report.Line No': 'SES_REPORT_LINENO',
    'SES_Report.PO Value': 'SES_REPORT_POVALUE',
    'SES_Report.Due_Date': 'SES_REPORT_DUE_DATE',
    'SES_Report.Today_date': 'SES_REPORT_TODAY_DATE',
    'SES_Report.Final_Status': 'SES_REPORT_FINAL_STATUS',
    'SES_Report.SES_Value_Summary': 'SES_REPORT_SES_VALUE_SUMMARY',
    'PO Key': 'POKEY',
    'PO.PO Number': 'PO_PONUMBER',
    'PO.Item': 'PO_ITEM',
    'PO.PR_Number': 'PO_PR_NUMBER',
    'PO.Sector/Division': 'PO_SECTOR_OR_DIVISION',
    'PO.Doc. Type Descript.': 'PO_DOC_TYPE_DESCRIPT',
    'PO.Short Text': 'PO_SHORT_TEXT',
    'PO.Delivery date': 'PO_DELIVERYDATE',
    'PO.Outline agreement': 'PO_OUTLINE_AGREEMENT',
    'PO.Vendor': 'PO_VENDOR',
    'PO.Currency': 'PO_CURRENCY',
    'PO.Gross order value': 'PO_GROSS_ORDER_VALUE',
    'PO.Payment terms': 'po_payment_terms',
    'PO.Deletion indicator': 'PO_DELETION_INDICATOR',
    'PO.PO Key': 'PO_POKEY',
    'PO (Sum PO).PO Number': 'PO_SUM_PO_PONUMBER',
    'Sum of Gross Order Value': 'SUM_OF_GROSS_ORDERVALUE',
    'SES(Sum SES by PO).Total_SES_Paid_Value': 'SES_SUMSESBYPO_TOTAL_SES_PAID_VALUE',
    '% total paid / total PO Value': 'TOTALPAID_OR_TOTALPOVALUE_PERCENTAGE',
    'Merged_IO_WBS': 'MERGED_IO_WBS',
    'Full IO-WBS List.Status': 'FULLIO_WBSLIST_STATUS',
    '% of total invoice / total PO Value': 'TOTALINVOICE_OR_TOTALPOVALUE_PERCENTAGE',
    'True_Payment': 'TRUE_PAYMENT',
    'LineItem&Text': 'LINEITEM_TEXT',
    'PO Title.1': 'PO_TITLE1',
    'Days Overdue': 'DAYS_OVERDUE',
    'Duplicate SES': 'DUPLICATE_SES',
    'invoice Payment checker': 'INVOICE_PAYMENT_CHECKER',
}


def transform_dataframe(df_source: DataFrame):
    """
    function to execute the appropriate transformations based
    Args:
        df_source:  dataframe.
    Returns:
        DataFrame: The resulting transformed DataFrame.
    """

    for old_name, new_name in column_mapping.items():
        print(f"Renaming column from {old_name} to {new_name}")
        df_source = df_source.withColumnRenamed(old_name, new_name)

    # Cast all columns to StringType
    for column in df_source.columns:
        df_source = df_source.withColumn(
            column, df_source[column].cast(StringType())
        )

    # Select only columns from column_mapping
    select_cols = []
    for value in column_mapping.values():
        if value not in df_source.columns:
            df_source = df_source.withColumn(value, F.lit(None).cast(StringType()))
        select_cols = list(column_mapping.values())

    df_transformed = df_source.select(*select_cols)

    return df_transformed


def main(spark, spark_df, **kwargs):
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df: dummy dataframe. Should be ignored.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")
    spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "LEGACY")

    # Extract arguments from kwargs with default values if not provided
    task_name = kwargs.get('task_name')
    task_parameters = kwargs.get('task_parameters')
    if task_name == "data_movement_task":
        print("transformations - main")
        print(task_parameters)
        print(spark)
        return transform_dataframe(spark_df)
    return None
