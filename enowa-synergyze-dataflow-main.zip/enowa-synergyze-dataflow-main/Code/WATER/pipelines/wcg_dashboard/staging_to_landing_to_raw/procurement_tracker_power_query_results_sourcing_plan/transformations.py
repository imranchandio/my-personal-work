"""
Module: procurement_tracker_power_query_results_sourcing_plan
Description: Process data from raw to curated for the database.
It contains the necessary functions and logic to create database 
table in curated.
"""

import pyspark.sql.functions as F
from pyspark.sql import DataFrame, SparkSession
from common_utils import standardize_numeric_data

def transform_dataframe(df_source: DataFrame) -> DataFrame:
    """
    Transforms the input dataframe by converting specific columns 
    to date format based on the provided MMDDYYYY format.

    Args:
        df (DataFrame): Input DataFrame to transform.

    Returns:
        DataFrame: Transformed DataFrame with date columns.
    """
    


    date_columns = ["PLANNED_AWARD_DATE", "CONTRACT_END_DATE","PR_APPROVAL_ES", "PR_APPROVAL_MID", "PR_APPROVAL_LS"]
    
    for column_name in date_columns:
        df_source = df_source.withColumn(column_name, F.to_date(F.col(column_name), "MM/dd/yy"))
        
    numeric_columns = [
        "BUDGET_VALUE_2026_2030", "PLANNED_SPEND_2023", "PLANNED_SPEND_2024", "PLANNED_SPEND_2025", "PLANNED_SPEND_2026", "PLANNED_SPEND_2027", "PLANNED_SPEND_2028", "PLANNED_SPEND_2029", "PLANNED_SPEND_2030", "PLANNED_SPEND_2026_2030"
    ]

    df_transformed = standardize_numeric_data(
        df=df_source,
        numeric_columns=numeric_columns
    )
 
    return df_transformed

def main(spark: SparkSession, spark_df: DataFrame, **kwargs) -> DataFrame:

    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        **kwargs: Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")
    
    # Extract arguments from kwargs
    task_name = kwargs.get('task_name')
    task_parameters = kwargs.get('task_parameters')
    print("Spark Session:", spark)  # Printing spark session object to avoid SonarQube issues

    if task_name == "data_movement_task":
        print("Transformations - main")
        print(task_parameters)
        return transform_dataframe(spark_df)  # The parameter spark_df is not needed
    else:
        raise ValueError(f"Unsupported task name: {task_name}")