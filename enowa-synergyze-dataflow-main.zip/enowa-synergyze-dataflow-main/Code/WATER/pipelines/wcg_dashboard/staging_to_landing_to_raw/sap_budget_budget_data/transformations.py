# pylint: disable= E0401

from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from common_utils import standardize_numeric_data

MMDDYYYY = "MM/dd/yyyy"  # Define date format explicitly

def transform_dataframe(df_source: DataFrame) -> DataFrame:
    """
    Transforms the input PySpark DataFrame by standardizing specific numeric columns.
    Also converts the date columns from string to actual date type.

    Args:
        df_source (pyspark.sql.DataFrame): The input PySpark DataFrame to transform.

    Returns:
        pyspark.sql.DataFrame: A new DataFrame with standardized numeric columns and converted date columns.
    """
    # List of date columns that need to be converted
    date_columns = ["Budget_date"]

    # Apply transformations on the date columns
    for column_name in date_columns:
        # Convert the date string to a date using the provided format
        df_source = df_source.withColumn(column_name, F.to_date(F.col(column_name), MMDDYYYY))

    # Return the transformed DataFrame
    return df_source


def main(spark: SparkSession, spark_df: DataFrame, **kwargs) -> DataFrame:
    """
    Main function to execute the appropriate task based on the provided task name.

    Args:
        spark (SparkSession): The Spark session used for data processing.
        spark_df (DataFrame): The dummy dataframe passed into the function.
        **kwargs (dict): Keyword arguments containing:
            - task_name (str): The name of the task to execute.
            - task_parameters (dict): Parameters for the task.
            - pipeline_storage (list[dict]): Storage configuration information for the pipeline.

    Returns:
        DataFrame: The resulting DataFrame from the executed task.

    Raises:
        ValueError: If an unsupported task name is provided.
    """
    # Set Spark configuration
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")

    # Extract arguments from kwargs with default values if not provided
    task_name = kwargs.get('task_name')
    task_parameters = kwargs.get('task_parameters')

    # Execute data movement task
    if task_name == "data_movement_task":
        print("main(): task_parameters: ", task_parameters)
        # Transform the dataframe by converting date columns
        return transform_dataframe(spark_df)

    # If no valid task name is provided
    return None
